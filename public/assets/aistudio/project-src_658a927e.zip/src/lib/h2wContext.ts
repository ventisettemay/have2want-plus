import React, { createContext, useContext, useState, useEffect, ReactNode, useCallback, useMemo } from "react";

export interface H2WContextValue {
  h2wPoints: number;
  h2wDaily: number;
  h2wWeekly: number;
  h2wMonthly: number;
  dailyUsed: number;
  weeklyUsed: number;
  monthlyUsed: number;
  merchantPiBalance: number;
  addPoints: (points: number) => void;
  incrementDaily: (points: number) => void;
  incrementWeekly: (points: number) => void;
  incrementMonthly: (points: number) => void;
  canPublish: (isExerciser: boolean, variant?: "VOICE_AI" | "PHOTO_TEXT") => boolean;
  resetDaily: () => void;
  resetWeekly: () => void;
  resetMonthly: () => void;
  getRemainingDaily: (isExerciser: boolean) => number;
  getRemainingWeekly: (isExerciser: boolean) => number;
  getRemainingMonthly: (isExerciser: boolean) => number;
  deductMerchantSubscription: (period: "DAILY" | "WEEKLY" | "MONTHLY" | "DAILY_SCONTO" | "WEEKLY_SCONTO" | "MONTHLY_SCONTO") => boolean;
  addMerchantPiBalance: (amount: number) => void;
}

const H2WContext = createContext<H2WContextValue | null>(null);

interface H2WProviderProps {
  children: React.ReactNode;
}

// Chiavi localStorage
const STORAGE_KEYS = {
  POINTS: "h2w_points",
  DAILY: "h2w_daily",
  WEEKLY: "h2w_weekly",
  MONTHLY: "h2w_monthly",
  DAILY_RESET: "h2w_daily_reset_ts",
  WEEKLY_RESET: "h2w_weekly_reset_ts",
  MONTHLY_RESET: "h2w_monthly_reset_ts",
  MERCHANT_PI_BALANCE: "h2w_merchant_pi_balance",
} as const;

// Costi punti per tipo annuncio (INVARIATI)
export const H2W_COST = {
  CHAT: 1,
  TESTO_FOTO: 2,
  FOTO_VOCE: 4,
  ESERCENTE: 6,
};

// Limiti in PUNTI H2W per esercenti (derivati da tariffe π fisse)
// Giornaliero: 20 π = 80 punti
// Settimanale: 120 π = 480 punti
// Mensile: 475 π = 1900 punti
export const H2W_LIMITS = {
  DAILY: 80,
  WEEKLY: 480,
  MONTHLY: 1900,
};

// Tariffe fisse in π per abbonamento esercente (nessun coefficiente traffico)
export const MERCHANT_SUBSCRIPTION_PI = {
  DAILY: 20,
  WEEKLY: 120,
  MONTHLY: 475,
  DAILY_SCONTO: 10,
  WEEKLY_SCONTO: 60,
  MONTHLY_SCONTO: 237.5,
} as const;

// REGOLA FONDAMENTALE: 0.25 π = 1 punto H2W  →  1 π = 4 punti H2W
export const TEST_MODE = true;
export const AD_REWARD_POINTS = 1;        // 1 punto H2W per vista ads
export const AD_REWARD_PI = 0.25;         // 0.25 π per vista ads

/**
 * Verifica se è passato un nuovo giorno (mezzanotte locale)
 */
function isNewDay(lastResetTs: number): boolean {
  const now = new Date();
  const lastReset = new Date(lastResetTs);
  return (
    now.getFullYear() !== lastReset.getFullYear() ||
    now.getMonth() !== lastReset.getMonth() ||
    now.getDate() !== lastReset.getDate()
  );
}

/**
 * Verifica se è passata una nuova settimana (lunedì mattina)
 */
function isNewWeek(lastResetTs: number): boolean {
  const now = new Date();
  const lastReset = new Date(lastResetTs);
  
  // Calcola il lunedì di questa settimana
  const getMonday = (d: Date) => {
    const day = d.getDay(); // 0 = domenica, 1 = lunedì, ...
    const diff = d.getDate() - day + (day === 0 ? -6 : 1); // aggiusta per lunedì
    return new Date(d.setDate(diff));
  };
  
  const thisMonday = getMonday(new Date(now));
  const lastMonday = getMonday(new Date(lastReset));
  
  return thisMonday.getTime() > lastMonday.getTime();
}

/**
 * Verifica se è passato un nuovo mese (1 del mese)
 */
function isNewMonth(lastResetTs: number): boolean {
  const now = new Date();
  const lastReset = new Date(lastResetTs);
  return (
    now.getFullYear() !== lastReset.getFullYear() ||
    now.getMonth() !== lastReset.getMonth()
  );
}

/**
 * Ottiene timestamp corrente per reset
 */
function getNowTs(): number {
  return Date.now();
}

export function H2WProvider({ children }: H2WProviderProps) {
  // Carica valori da localStorage all'inizializzazione
  const [h2wPoints, setH2wPoints] = useState<number>(() => {
    if (typeof window !== "undefined") {
      return parseInt(localStorage.getItem(STORAGE_KEYS.POINTS) || "0", 10);
    }
    return 0;
  });
  
  const [h2wDaily, setH2wDaily] = useState<number>(() => {
    if (typeof window !== "undefined") {
      const stored = localStorage.getItem(STORAGE_KEYS.DAILY);
      const resetTs = parseInt(localStorage.getItem(STORAGE_KEYS.DAILY_RESET) || "0", 10);
      if (stored && resetTs && !isNewDay(resetTs)) {
        return parseInt(stored, 10);
      }
      // Reset se è un nuovo giorno
      if (resetTs && isNewDay(resetTs)) {
        localStorage.setItem(STORAGE_KEYS.DAILY, "0");
        localStorage.setItem(STORAGE_KEYS.DAILY_RESET, getNowTs().toString());
      }
      return 0;
    }
    return 0;
  });
  
  const [h2wWeekly, setH2wWeekly] = useState<number>(() => {
    if (typeof window !== "undefined") {
      const stored = localStorage.getItem(STORAGE_KEYS.WEEKLY);
      const resetTs = parseInt(localStorage.getItem(STORAGE_KEYS.WEEKLY_RESET) || "0", 10);
      if (stored && resetTs && !isNewWeek(resetTs)) {
        return parseInt(stored, 10);
      }
      // Reset se è una nuova settimana
      if (resetTs && isNewWeek(resetTs)) {
        localStorage.setItem(STORAGE_KEYS.WEEKLY, "0");
        localStorage.setItem(STORAGE_KEYS.WEEKLY_RESET, getNowTs().toString());
      }
      return 0;
    }
    return 0;
  });
  
  const [h2wMonthly, setH2wMonthly] = useState<number>(() => {
    if (typeof window !== "undefined") {
      const stored = localStorage.getItem(STORAGE_KEYS.MONTHLY);
      const resetTs = parseInt(localStorage.getItem(STORAGE_KEYS.MONTHLY_RESET) || "0", 10);
      if (stored && resetTs && !isNewMonth(resetTs)) {
        return parseInt(stored, 10);
      }
      // Reset se è un nuovo mese
      if (resetTs && isNewMonth(resetTs)) {
        localStorage.setItem(STORAGE_KEYS.MONTHLY, "0");
        localStorage.setItem(STORAGE_KEYS.MONTHLY_RESET, getNowTs().toString());
      }
      return 0;
    }
    return 0;
  });

  // Saldo Pi del commerciante per abbonamenti
  const [merchantPiBalance, setMerchantPiBalance] = useState<number>(() => {
    if (typeof window !== "undefined") {
      return parseFloat(localStorage.getItem(STORAGE_KEYS.MERCHANT_PI_BALANCE) || "0");
    }
    return 0;
  });

  // Persistenza su localStorage ad ogni cambiamento
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.POINTS, h2wPoints.toString());
  }, [h2wPoints]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.DAILY, h2wDaily.toString());
    localStorage.setItem(STORAGE_KEYS.DAILY_RESET, getNowTs().toString());
  }, [h2wDaily]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.WEEKLY, h2wWeekly.toString());
    localStorage.setItem(STORAGE_KEYS.WEEKLY_RESET, getNowTs().toString());
  }, [h2wWeekly]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.MONTHLY, h2wMonthly.toString());
    localStorage.setItem(STORAGE_KEYS.MONTHLY_RESET, getNowTs().toString());
  }, [h2wMonthly]);

  // Persistenza saldo Pi commerciante
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.MERCHANT_PI_BALANCE, merchantPiBalance.toFixed(8));
  }, [merchantPiBalance]);

  // Controlli periodici per reset automatico (ogni minuto)
  useEffect(() => {
    const interval = setInterval(() => {
      const now = getNowTs();
      
      // Check daily reset
      const dailyResetTs = parseInt(localStorage.getItem(STORAGE_KEYS.DAILY_RESET) || "0", 10);
      if (dailyResetTs && isNewDay(dailyResetTs)) {
        setH2wDaily(0);
        localStorage.setItem(STORAGE_KEYS.DAILY, "0");
        localStorage.setItem(STORAGE_KEYS.DAILY_RESET, now.toString());
      }
      
      // Check weekly reset
      const weeklyResetTs = parseInt(localStorage.getItem(STORAGE_KEYS.WEEKLY_RESET) || "0", 10);
      if (weeklyResetTs && isNewWeek(weeklyResetTs)) {
        setH2wWeekly(0);
        localStorage.setItem(STORAGE_KEYS.WEEKLY, "0");
        localStorage.setItem(STORAGE_KEYS.WEEKLY_RESET, now.toString());
      }
      
      // Check monthly reset
      const monthlyResetTs = parseInt(localStorage.getItem(STORAGE_KEYS.MONTHLY_RESET) || "0", 10);
      if (monthlyResetTs && isNewMonth(monthlyResetTs)) {
        setH2wMonthly(0);
        localStorage.setItem(STORAGE_KEYS.MONTHLY, "0");
        localStorage.setItem(STORAGE_KEYS.MONTHLY_RESET, now.toString());
      }
    }, 60000); // ogni minuto
    
    return () => clearInterval(interval);
  }, []);

  const addPoints = useCallback((points: number) => {
    setH2wPoints((prev) => prev + points);
  }, []);

  const incrementDaily = useCallback((points: number) => {
    setH2wDaily((prev) => Math.min(prev + points, H2W_LIMITS.DAILY));
  }, []);

  const incrementWeekly = useCallback((points: number) => {
    setH2wWeekly((prev) => Math.min(prev + points, H2W_LIMITS.WEEKLY));
  }, []);

  const incrementMonthly = useCallback((points: number) => {
    setH2wMonthly((prev) => Math.min(prev + points, H2W_LIMITS.MONTHLY));
  }, []);

  const canPublish = useCallback((isExerciser: boolean, variant: "VOICE_AI" | "PHOTO_TEXT" = "VOICE_AI"): boolean => {
    if (!isExerciser) return true; // Utenti normali: nessun limite
    
    // Per esercenti: controlla limiti reali
    const cost = variant === "VOICE_AI" ? H2W_COST.FOTO_VOCE : H2W_COST.TESTO_FOTO;
    
    // Verifica se c'è spazio nei limiti
    const dailyRemaining = H2W_LIMITS.DAILY - h2wDaily;
    const weeklyRemaining = H2W_LIMITS.WEEKLY - h2wWeekly;
    const monthlyRemaining = H2W_LIMITS.MONTHLY - h2wMonthly;
    
    return dailyRemaining >= cost && weeklyRemaining >= cost && monthlyRemaining >= cost;
  }, [h2wDaily, h2wWeekly, h2wMonthly]);

  const resetDaily = useCallback(() => {
    setH2wDaily(0);
    localStorage.setItem(STORAGE_KEYS.DAILY, "0");
    localStorage.setItem(STORAGE_KEYS.DAILY_RESET, getNowTs().toString());
  }, []);

  const resetWeekly = useCallback(() => {
    setH2wWeekly(0);
    localStorage.setItem(STORAGE_KEYS.WEEKLY, "0");
    localStorage.setItem(STORAGE_KEYS.WEEKLY_RESET, getNowTs().toString());
  }, []);

  const resetMonthly = useCallback(() => {
    setH2wMonthly(0);
    localStorage.setItem(STORAGE_KEYS.MONTHLY, "0");
    localStorage.setItem(STORAGE_KEYS.MONTHLY_RESET, getNowTs().toString());
  }, []);

  // Aggiunge Pi al saldo commerciante
  const addMerchantPiBalance = useCallback((amount: number) => {
    setMerchantPiBalance((prev) => prev + amount);
  }, []);

  // Scala la tariffa di abbonamento dal saldo Pi del commerciante
  // Restituisce true se l'addebito è riuscito, false se saldo insufficiente
  const deductMerchantSubscription = useCallback((period: "DAILY" | "WEEKLY" | "MONTHLY" | "DAILY_SCONTO" | "WEEKLY_SCONTO" | "MONTHLY_SCONTO"): boolean => {
    const cost = MERCHANT_SUBSCRIPTION_PI[period];
    let success = false;
    setMerchantPiBalance((prev) => {
      if (prev >= cost) {
        success = true;
        return parseFloat((prev - cost).toFixed(8));
      }
      return prev;
    });
    return success;
  }, []);

  const getRemainingDaily = useCallback((isExerciser: boolean): number => {
    if (!isExerciser) return Infinity;
    return Math.max(0, H2W_LIMITS.DAILY - h2wDaily);
  }, [h2wDaily]);

  const getRemainingWeekly = useCallback((isExerciser: boolean): number => {
    if (!isExerciser) return Infinity;
    return Math.max(0, H2W_LIMITS.WEEKLY - h2wWeekly);
  }, [h2wWeekly]);

  const getRemainingMonthly = useCallback((isExerciser: boolean): number => {
    if (!isExerciser) return Infinity;
    return Math.max(0, H2W_LIMITS.MONTHLY - h2wMonthly);
  }, [h2wMonthly]);

  // Valori computed per l'UI
  const dailyUsed = h2wDaily;
  const weeklyUsed = h2wWeekly;
  const monthlyUsed = h2wMonthly;

  const value = useMemo(() => ({
    h2wPoints,
    h2wDaily,
    h2wWeekly,
    h2wMonthly,
    dailyUsed,
    weeklyUsed,
    monthlyUsed,
    merchantPiBalance,
    addPoints,
    incrementDaily,
    incrementWeekly,
    incrementMonthly,
    canPublish,
    resetDaily,
    resetWeekly,
    resetMonthly,
    getRemainingDaily,
    getRemainingWeekly,
    getRemainingMonthly,
    deductMerchantSubscription,
    addMerchantPiBalance,
  }), [
    h2wPoints,
    h2wDaily,
    h2wWeekly,
    h2wMonthly,
    dailyUsed,
    weeklyUsed,
    monthlyUsed,
    merchantPiBalance,
    addPoints,
    incrementDaily,
    incrementWeekly,
    incrementMonthly,
    canPublish,
    resetDaily,
    resetWeekly,
    resetMonthly,
    getRemainingDaily,
    getRemainingWeekly,
    getRemainingMonthly,
    deductMerchantSubscription,
    addMerchantPiBalance,
  ]);

  return (
    <H2WContext.Provider value={value}>
      {children}
    </H2WContext.Provider>
  );
}

export function useH2W() {
  const context = useContext(H2WContext);
  if (!context) {
    throw new Error("useH2W must be used within an H2WProvider");
  }
  return context;
}

export { H2WProvider };
export { useH2W };
export type { H2WContextValue };
