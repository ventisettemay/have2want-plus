/**
 * Base44 BaaS Entity Schemas & Integration Engine for HAVE2WANT (Simply Discreet)
 * Strict RealEs Architecture & Automated Review Normalization Engine
 */

export type ProfileCategory =
  | "CITADINO_PRIVATO"
  | "PROFESSIONISTA_SOCIALE"
  | "AZIENDA_STABILE";

export interface Base44Profile {
  id: string;
  username: string;
  category: ProfileCategory;
  ad_completed_streak: number; // int
  ad_abbuoni_disponibili: number; // int
  ad_interrupt_count: number; // int
  pi_circuit_suspended_until: string | null; // ISO datetime string
  specialist_municipality_cap_verified: boolean;
  avatar_url?: string;
  created_at?: string;
  updated_at?: string;
}

export type ListingVisibilityLevel =
  | "STANDARD"
  | "PREMIUM_ILLUMINATO"
  | "OFF_SPENTO";

export interface Base44Listing {
  id: string;
  profile_id: string;
  have_description: string;
  want_description: string;
  visibility_level: ListingVisibilityLevel;
  visibility_expires_at: string; // ISO datetime
  pi_testnet_tx_id: string;
  meeting_point_verified: boolean;
  handshake_pin: string;
  handshake_confirmed: boolean;
  exact_lat: number;
  exact_lng: number;
  municipality_centroid_lat: number;
  municipality_centroid_lng: number;
  privacy_mode_active: boolean;
  created_at?: string;
  updated_at?: string;
}

export type ReportTargetType = "listing" | "user";

export interface Base44Report {
  id: string;
  reporter_id: string;
  target_id: string;
  target_type: ReportTargetType; // enum ['listing', 'user']
  reason: string;
  details: string;
  status: "pending" | "resolved" | "dismissed";
  created_at?: string;
}

/**
 * System Prompt for base44.integrations.Core.InvokeLLM
 * Used for Discreet Review Rewriting (Ratings 1-3)
 */
export const DISCREET_MODERATION_SYSTEM_PROMPT =
  "Tu sei l'algoritmo di moderazione invisibile di HAVE2WANT (Simply Discreet). " +
  "Il tuo compito è prendere il testo di una recensione negativa o adirata scritta da un utente e " +
  "riscriverla completamente in un tono formale, civile, freddo e puramente oggettivo. " +
  "Elimina insulti, espressioni emotive o dettagli personali. Restituisci solo i fatti per evitare conflitti sulla mappa pubblica.";

/**
 * Base44 Integration Engine Client Mock/Bridge
 */
export const base44 = {
  entities: {
    Profile: {
      schema: {
        category: ["CITADINO_PRIVATO", "PROFESSIONISTA_SOCIALE", "AZIENDA_STABILE"],
        ad_completed_streak: "integer",
        ad_abbuoni_disponibili: "integer",
        ad_interrupt_count: "integer",
        pi_circuit_suspended_until: "datetime",
        specialist_municipality_cap_verified: "boolean",
      },
    },
    Listing: {
      schema: {
        have_description: "string",
        want_description: "string",
        visibility_level: ["STANDARD", "PREMIUM_ILLUMINATO", "OFF_SPENTO"],
        visibility_expires_at: "datetime",
        pi_testnet_tx_id: "string",
        meeting_point_verified: "boolean",
        handshake_pin: "string",
        handshake_confirmed: "boolean",
        exact_lat: "number",
        exact_lng: "number",
        municipality_centroid_lat: "number",
        municipality_centroid_lng: "number",
        privacy_mode_active: "boolean",
      },
    },
    Report: {
      schema: {
        target_type: ["listing", "user"],
      },
    },
  },
  integrations: {
    Core: {
      /**
       * InvokeLLM for Discreet AI Moderation & Rewriting
       */
      InvokeLLM: async (params: {
        prompt: string;
        systemPrompt?: string;
      }): Promise<{ response: string }> => {
        const effectiveSystemPrompt = params.systemPrompt || DISCREET_MODERATION_SYSTEM_PROMPT;
        
        try {
          // If server-side API is available, invoke it
          const res = await fetch("/api/discreet-moderation", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              text: params.prompt,
              systemPrompt: effectiveSystemPrompt,
            }),
          });
          if (res.ok) {
            const data = await res.json();
            if (data.civilText) {
              return { response: data.civilText };
            }
          }
        } catch {
          // Fallback to client-side deterministic objective formatting
        }

        // Deterministic objective synthesis fallback
        const cleaned = params.prompt
          .replace(/[!?,;]+/g, ".")
          .replace(/\b(truffa|ladro|schifo|pessimo|vergogna|maledetto|cretino)\b/gi, "")
          .trim();

        return {
          response: `La transazione non ha soddisfatto le aspettative concordate: ${cleaned || "difformità riscontrata nelle condizioni concordate per lo scambio."} Non risultano ulteriori anomalie segnalate.`,
        };
      },
    },
  },
};
