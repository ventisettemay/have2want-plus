export interface ExternalMarketplace {
  id: string;
  name: string;
  country: string;
  url: string;
}

export interface ExternalListing {
  id: string;
  title: string;
  price: string;
  url: string;
  marketplace: string;
  country: string;
}

// Associazione dinamica Paese -> Marketplace leader
export const COUNTRY_MARKETPLACES: Record<string, ExternalMarketplace[]> = {
  IT: [
    { id: 'subito', name: 'Subito.it', country: 'IT', url: 'https://subito.it{query}' },
    { id: 'wallapop_it', name: 'Wallapop Italia', country: 'IT', url: 'https://wallapop.com{query}' },
    { id: 'ebay_it', name: 'eBay Italia', country: 'IT', url: 'https://ebay.it{query}' },
  ],
  ES: [
    { id: 'wallapop_es', name: 'Wallapop', country: 'ES', url: 'https://wallapop.com{query}' },
    { id: 'milanuncios', name: 'Milanuncios', country: 'ES', url: 'https://milanuncios.com{query}.html' },
    { id: 'ebay_es', name: 'eBay España', country: 'ES', url: 'https://ebay.es{query}' },
  ],
  IN: [
    { id: 'flipkart', name: 'Flipkart', country: 'IN', url: 'https://flipkart.com{query}' },
    { id: 'olx_in', name: 'OLX India', country: 'IN', url: 'https://olx.in{query}' },
  ],
  CN: [
    { id: 'taobao', name: 'Taobao', country: 'CN', url: 'https://taobao.com{query}' },
    { id: 'jd', name: 'JD.com', country: 'CN', url: 'https://jd.com{query}' },
  ],
  US: [
    { id: 'ebay_us', name: 'eBay USA', country: 'US', url: 'https://ebay.com{query}' },
    { id: 'craigslist', name: 'Craigslist', country: 'US', url: 'https://craigslist.org{query}' },
  ],
  DE: [
    { id: 'ebay_de', name: 'eBay Deutschland', country: 'DE', url: 'https://ebay.de{query}' },
    { id: 'ebay_kleinanzeigen', name: 'eBay Kleinanzeigen', country: 'DE', url: 'https://ebay-kleinanzeigen.de{query}' },
  ],
  FR: [
    { id: 'leboncoin', name: 'Leboncoin', country: 'FR', url: 'https://leboncoin.fr{query}' },
    { id: 'ebay_fr', name: 'eBay France', country: 'FR', url: 'https://ebay.fr{query}' },
  ],
  GB: [
    { id: 'ebay_gb', name: 'eBay UK', country: 'GB', url: 'https://ebay.co.uk{query}' },
    { id: 'gumtree', name: 'Gumtree UK', country: 'GB', url: 'https://gumtree.com{query}' },
  ],
  JP: [
    { id: 'mercari', name: 'Mercari JP', country: 'JP', url: 'https://mercari.com{query}' },
    { id: 'yahoo_auctions', name: 'Yahoo Auctions JP', country: 'JP', url: 'https://yahoo.co.jp{query}' },
  ],
};

export function getMarketplaces(country: string): ExternalMarketplace[] {
  return COUNTRY_MARKETPLACES[country.toUpperCase()] || [];
}

export function buildExternalListing(marketplace: ExternalMarketplace, query: string): ExternalListing {
  return {
    id: `ext_${marketplace.id}_${encodeURIComponent(query)}`,
    title: `${query} su ${marketplace.name}`,
    price: 'Vedi su ' + marketplace.name,
    url: marketplace.url.replace('{query}', encodeURIComponent(query)),
    marketplace: marketplace.name,
    country: marketplace.country,
  };
}

export function fetchExternal(country: string, query: string): ExternalListing[] {
  if (!country || country === 'ALL') {
    return [];
  }
  const mps = getMarketplaces(country);
  return mps.map((mp) => buildExternalListing(mp, query));
}
