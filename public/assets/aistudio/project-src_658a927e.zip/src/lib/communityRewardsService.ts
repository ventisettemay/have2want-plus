/**
 * communityRewardsService.ts
 * Gestione economica sostenibile dei Punti Comunitari HAVE2WANT e conversione in Pi Network (Testnet/Mainnet).
 * 
 * Regole Chiave Stabilite:
 * 1. NO Wallet Interno Custodial: il wallet appartiene unicamente al Pioneer.
 * 2. Soglia Minima di Prelievo: 0.50 π.
 * 3. Costo di transazione Blockchain (Gas Fee): 0.01 π a carico del pioniere (detratto dall'importo).
 * 4. Micro-azioni e banner: premi ridotti per evitare inflazione gratuita (es. +2 a +5 punti).
 * 5. Annunci Reali autentici territoriali: premi elevati e proporzionali al valore e alla completezza (+50 a +250 punti).
 */

export interface RewardTransaction {
  id: string;
  type: 'EARN_REAL_LISTING' | 'EARN_AD_VIEW' | 'EARN_COMMUNITY_ENGAGE' | 'WITHDRAW_PI';
  description: string;
  pointsDelta: number;
  piEquivalent?: number;
  timestamp: number;
  txHash?: string;
  status: 'completed' | 'pending' | 'rejected';
}

export interface PioneerRewardsState {
  pointsBalance: number;
  totalPointsEarned: number;
  pioneerUsername: string;
  pioneerWalletAddress: string;
  history: RewardTransaction[];
}

// Parametri Economici Matematici
export const REWARDS_CONFIG = {
  // Tasso di conversione: 1000 Punti = 1.0 π (quindi 100 Punti = 0.10 π, 500 Punti = 0.50 π)
  POINTS_PER_PI: 1000,
  
  // Soglia minima di prelievo richiesta
  MIN_WITHDRAWAL_PI: 0.50,
  MIN_WITHDRAWAL_POINTS: 500, // 0.50 * 1000

  // Costo fisso transazione Blockchain Pi Network
  BLOCKCHAIN_TRANSACTION_FEE_PI: 0.01,

  // Valori assegnati alle azioni
  EARN_RATES: {
    // Micro-funzioni (valori ridotti per sostenibilità economica)
    QUICK_SPONSOR_AD: 4, // ~ 0.004 π
    BANNER_CLICK: 2, // ~ 0.002 π
    COMMUNITY_SHARING: 5, // ~ 0.005 π

    // Annunci Reali con valore tangibile (valori aumentati)
    REAL_LISTING_BASIC: 60, // ~ 0.06 π
    REAL_LISTING_VERIFIED: 120, // ~ 0.12 π (con foto, prezzo e geo)
    REAL_EXCHANGE_CONCLUDED: 250, // ~ 0.25 π (scambio concluso con handshake)
  }
};

const STORAGE_KEY = 'have2want_pioneer_rewards_v1';

export function getPioneerRewardsState(): PioneerRewardsState {
  if (typeof window === 'undefined') {
    return getInitialRewardsState();
  }

  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (err) {
    console.warn('Errore lettura rewards state:', err);
  }

  const initial = getInitialRewardsState();
  savePioneerRewardsState(initial);
  return initial;
}

function getInitialRewardsState(): PioneerRewardsState {
  return {
    pointsBalance: 120, // Punti di benvenuto iniziali (~0.12 π)
    totalPointsEarned: 120,
    pioneerUsername: '@pioneer_user',
    pioneerWalletAddress: '',
    history: [
      {
        id: 'tx_init_welcome',
        type: 'EARN_COMMUNITY_ENGAGE',
        description: 'Bonus di benvenuto pioniere HAVE2WANT',
        pointsDelta: 120,
        piEquivalent: 0.12,
        timestamp: Date.now() - 3600000 * 24,
        status: 'completed'
      }
    ]
  };
}

export function savePioneerRewardsState(state: PioneerRewardsState): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (err) {
    console.error('Errore salvataggio rewards state:', err);
  }
}

/**
 * Converte Punti in Pi Network equivalenti
 */
export function pointsToPi(points: number): number {
  return Number((points / REWARDS_CONFIG.POINTS_PER_PI).toFixed(4));
}

/**
 * Converte Pi in Punti equivalenti
 */
export function piToPoints(pi: number): number {
  return Math.round(pi * REWARDS_CONFIG.POINTS_PER_PI);
}

/**
 * Assegna punti per un'azione compiuta
 */
export function awardPoints(
  actionType: keyof typeof REWARDS_CONFIG.EARN_RATES,
  customDescription?: string
): { success: boolean; newBalance: number; pointsEarned: number } {
  const points = REWARDS_CONFIG.EARN_RATES[actionType] || 0;
  if (points <= 0) return { success: false, newBalance: 0, pointsEarned: 0 };

  const state = getPioneerRewardsState();
  state.pointsBalance += points;
  state.totalPointsEarned += points;

  const descMap: Record<string, string> = {
    QUICK_SPONSOR_AD: 'Visione sponsor rapido partner',
    BANNER_CLICK: 'Interazione con banner territoriale',
    COMMUNITY_SHARING: 'Condivisione con la community locale',
    REAL_LISTING_BASIC: 'Pubblicazione nuovo annuncio reale P2P',
    REAL_LISTING_VERIFIED: 'Pubblicazione annuncio reale verificato con foto e geo',
    REAL_EXCHANGE_CONCLUDED: 'Stretta di mano e scambio reale completato',
  };

  const newTx: RewardTransaction = {
    id: 'rew_' + Math.random().toString(36).substring(2, 9),
    type: actionType.startsWith('REAL_LISTING') ? 'EARN_REAL_LISTING' : (actionType === 'QUICK_SPONSOR_AD' ? 'EARN_AD_VIEW' : 'EARN_COMMUNITY_ENGAGE'),
    description: customDescription || descMap[actionType] || 'Azione comunitaria completata',
    pointsDelta: points,
    piEquivalent: pointsToPi(points),
    timestamp: Date.now(),
    status: 'completed'
  };

  state.history.unshift(newTx);
  savePioneerRewardsState(state);

  return {
    success: true,
    newBalance: state.pointsBalance,
    pointsEarned: points
  };
}

/**
 * Calcola i dettagli del prelievo rispettando la soglia minima di 0.50 π e la fee di 0.01 π
 */
export function calculateWithdrawalBreakdown(requestedPi: number) {
  const minPi = REWARDS_CONFIG.MIN_WITHDRAWAL_PI;
  const feePi = REWARDS_CONFIG.BLOCKCHAIN_TRANSACTION_FEE_PI;

  const isValidAmount = requestedPi >= minPi;
  const netReceivedPi = isValidAmount ? Number((requestedPi - feePi).toFixed(4)) : 0;
  const requiredPoints = piToPoints(requestedPi);

  return {
    requestedPi,
    feePi,
    netReceivedPi,
    requiredPoints,
    minPi,
    isValidAmount
  };
}

/**
 * Esegue la richiesta di prelievo verso il wallet esterno Pi Network
 */
export async function executePiWithdrawal(
  requestedPi: number,
  walletAddress: string,
  pioneerUsername?: string
): Promise<{
  success: boolean;
  netPiSent?: number;
  feeDeducted?: number;
  txHash?: string;
  newPointsBalance?: number;
  error?: string;
}> {
  const breakdown = calculateWithdrawalBreakdown(requestedPi);

  if (!breakdown.isValidAmount) {
    return {
      success: false,
      error: `La soglia minima di prelievo è di ${REWARDS_CONFIG.MIN_WITHDRAWAL_PI} π.`
    };
  }

  const state = getPioneerRewardsState();
  if (state.pointsBalance < breakdown.requiredPoints) {
    return {
      success: false,
      error: `Punti insufficienti. Hai ${state.pointsBalance} punti (${pointsToPi(state.pointsBalance)} π), necessari ${breakdown.requiredPoints} punti.`
    };
  }

  if (!walletAddress || walletAddress.trim().length < 6) {
    return {
      success: false,
      error: 'Inserisci un indirizzo Pi Wallet o Username Pioneer valido.'
    };
  }

  // Simula la chiamata blockchain o chiamata server Pi A2U
  await new Promise((resolve) => setTimeout(resolve, 1400));

  // Genera hash transazione Testnet Pi
  const txHash = 'pi_testnet_tx_' + Math.random().toString(36).substring(2, 12) + '_a2u';

  state.pointsBalance -= breakdown.requiredPoints;
  if (pioneerUsername) state.pioneerUsername = pioneerUsername;
  state.pioneerWalletAddress = walletAddress;

  const withdrawTx: RewardTransaction = {
    id: 'wth_' + Math.random().toString(36).substring(2, 9),
    type: 'WITHDRAW_PI',
    description: `Prelievo sul Pi Wallet esterno (${walletAddress.substring(0, 10)}...)`,
    pointsDelta: -breakdown.requiredPoints,
    piEquivalent: requestedPi,
    timestamp: Date.now(),
    txHash,
    status: 'completed'
  };

  state.history.unshift(withdrawTx);
  savePioneerRewardsState(state);

  return {
    success: true,
    netPiSent: breakdown.netReceivedPi,
    feeDeducted: breakdown.feePi,
    txHash,
    newPointsBalance: state.pointsBalance
  };
}
