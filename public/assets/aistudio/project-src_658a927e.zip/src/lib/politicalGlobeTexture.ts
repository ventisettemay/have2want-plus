// Generatore di Texture Geopolitica Completa ad Alta Risoluzione per il Globo 3D
// Mappamondo Geopolitico Reale: Oceani azzurro cielo cartografico (#1ca7ec),
// tutti i paesi del mondo con i loro confini geografici reali, colori pastello
// cartografici classici, reticolo geografico tratteggiato bianco e zero artefatti.

import * as THREE from 'three';

// Funzione di utilità: converte Lat/Lng in coordinate pixel equirettangolari X, Y sul canvas
export function geoToCanvas(lat: number, lng: number, width: number, height: number): { x: number; y: number } {
  const x = ((lng + 180) / 360) * width;
  const y = ((90 - lat) / 180) * height;
  return { x, y };
}

/**
 * Crea una texture geopolitica mondiale cartografica autentica:
 * - Basata sui confini vettoriali reali di tutti i Paesi del mondo
 * - Palette pastello cartografica classica (menta, pesca, corallo, giallo crema, lilla, azzurro)
 * - Oceani azzurro cielo vivido (#1ca7ec)
 * - Paralleli e meridiani tratteggiati bianchi
 * - Confini degli Stati nitidi
 */
export function createPoliticalGlobeTexture(): THREE.Texture {
  const width = 4096;
  const height = 2048;
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');

  if (ctx) {
    // Sfondo iniziale solido blu mare profondo (riposante per la vista)
    ctx.fillStyle = '#162e47';
    ctx.fillRect(0, 0, width, height);
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.ClampToEdgeWrapping;
  texture.needsUpdate = true;

  if (typeof window !== 'undefined' && typeof Image !== 'undefined') {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      if (ctx) {
        ctx.clearRect(0, 0, width, height);
        ctx.drawImage(img, 0, 0, width, height);
        texture.needsUpdate = true;
      }
    };
    img.src = '/textures/earth_political.svg';
  }

  return texture;
}
