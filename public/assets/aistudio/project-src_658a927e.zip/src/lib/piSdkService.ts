// Servizio di integrazione e ponte per Pi Network SDK 2.0 (Autenticazione e Pagamenti)
// Compatibile sia con Pi Browser nativo (window.Pi) sia con simulatore reattivo per anteprima web

declare global {
  interface Window {
    Pi?: {
      init: (options: { version: string; sandbox?: boolean }) => void;
      authenticate: (
        scopes: string[],
        onIncompletePaymentFound?: (payment: any) => void
      ) => Promise<{
        accessToken: string;
        user: {
          uid: string;
          username: string;
        };
      }>;
      createPayment: (
        paymentData: {
          amount: number;
          memo: string;
          metadata?: Record<string, any>;
        },
        callbacks?: {
          onReadyForServerApproval?: (paymentId: string) => void;
          onReadyForServerCompletion?: (paymentId: string, txid: string) => void;
          onCancel?: (paymentId: string) => void;
          onError?: (error: Error, payment?: any) => void;
        }
      ) => Promise<any>;
    };
  }
}

export interface PiAuthState {
  isAuthenticated: boolean;
  isPiBrowser: boolean;
  username: string | null;
  uid: string | null;
  accessToken: string | null;
  error: string | null;
  loading: boolean;
}

// Configurazione Ufficiale Pi App Wallet (Testnet)
export const PI_APP_WALLET_ADDRESS = 'GC4QNJHVWYXOJ5ZO3SDCCAITO7IE6VM22CKPPGQJL737AOWUTVLJQE7X';
export const PI_SANDBOX_APP_URL = 'https://sandbox.minepi.com/app/have2want-plus-zc2j';

// Inizializza Pi SDK in modo sicuro
export function initPiSdk(sandbox: boolean = true) {
  if (typeof window !== 'undefined' && window.Pi) {
    try {
      window.Pi.init({ version: '2.0', sandbox });
      return true;
    } catch (err) {
      console.warn('Pi.init info:', err);
      return false;
    }
  }
  return false;
}

// Verifica se stiamo girando all'interno del Pi Browser
export function checkIsPiBrowser(): boolean {
  if (typeof window === 'undefined') return false;
  const ua = navigator.userAgent || '';
  const isPiUa = /PiBrowser|PiNetwork/i.test(ua);
  return Boolean(window.Pi || isPiUa);
}

// Esegue l'autenticazione tramite Portale Pi
export async function authenticateWithPiPortal(): Promise<{
  success: boolean;
  user?: { uid: string; username: string };
  isSimulated?: boolean;
  error?: string;
}> {
  try {
    initPiSdk(true);

    if (typeof window !== 'undefined' && window.Pi && typeof window.Pi.authenticate === 'function') {
      const authResult = await window.Pi.authenticate(
        ['username', 'payments'],
        (incompletePayment) => {
          console.log('Pagamento incompleto da completare:', incompletePayment);
        }
      );

      return {
        success: true,
        user: authResult.user,
        isSimulated: false,
      };
    } else {
      // Fallback controllato per ambiente anteprima / browser standard
      // Simula il login con credenziali Pioneer salvate o generate
      const storedPioneer = localStorage.getItem('have2want_pioneer_user');
      const pioneerUsername = storedPioneer || `@pioneer_${Math.floor(1000 + Math.random() * 9000)}`;
      if (!storedPioneer) {
        localStorage.setItem('have2want_pioneer_user', pioneerUsername);
      }

      return {
        success: true,
        user: {
          uid: 'pi_uid_' + Math.random().toString(36).substring(2, 10),
          username: pioneerUsername,
        },
        isSimulated: true,
      };
    }
  } catch (err: any) {
    return {
      success: false,
      error: err.message || 'Errore durante la connessione al Portale Pi',
    };
  }
}

// Esegue un pagamento tramite funzione Pi SDK
export async function executePiSdkPayment(options: {
  amount: number;
  memo: string;
  metadata?: Record<string, any>;
}): Promise<{
  success: boolean;
  txId?: string;
  isSimulated?: boolean;
  error?: string;
}> {
  try {
    initPiSdk(true);

    if (typeof window !== 'undefined' && window.Pi && typeof window.Pi.createPayment === 'function') {
      return new Promise((resolve) => {
        window.Pi!.createPayment(
          {
            amount: options.amount,
            memo: options.memo,
            metadata: options.metadata || {},
          },
          {
            onReadyForServerApproval: (paymentId: string) => {
              console.log('Pi Payment Pronto per Approvazione:', paymentId);
            },
            onReadyForServerCompletion: (paymentId: string, txid: string) => {
              resolve({
                success: true,
                txId: txid,
                isSimulated: false,
              });
            },
            onCancel: () => {
              resolve({
                success: false,
                error: 'Pagamento Pi annullato dall\'utente.',
              });
            },
            onError: (error: Error) => {
              resolve({
                success: false,
                error: error.message || 'Errore durante la transazione Pi SDK',
              });
            },
          }
        );
      });
    } else {
      // Simulatore di transazione Pi Wallet Non-Custodial per Web Preview
      await new Promise((r) => setTimeout(r, 1200));
      const simulatedTxId = 'pi_tx_' + Math.random().toString(36).substring(2, 12) + '_verified';
      return {
        success: true,
        txId: simulatedTxId,
        isSimulated: true,
      };
    }
  } catch (err: any) {
    return {
      success: false,
      error: err.message || 'Impossibile completare il pagamento Pi SDK',
    };
  }
}
