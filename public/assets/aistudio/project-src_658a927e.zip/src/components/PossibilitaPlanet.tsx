import React, { useState, useRef } from "react";
import { HaveWantListing, InteractionIntent } from "../types";
import { fuzzyGeocode } from "../lib/fuzzyGeocoding";
import {
  Search,
  Plus,
  Sparkles,
  Heart,
  Handshake,
  HeartHandshake,
  Gift,
  Coins,
  ShieldCheck,
  MessageCircle,
  ArrowUpDown,
  MapPin,
  X,
  Layers,
  GraduationCap,
  Wrench,
  Sprout,
  Globe2,
  Bike,
  Palette,
  Sun,
  Flame,
  CheckCircle2,
  Orbit,
  Radio,
  Eye,
  ArrowRight,
  TrendingUp,
  Activity,
  Zap,
  Star,
  ChevronLeft,
  ChevronRight,
  Radar,
  Grid3X3,
  Maximize2
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { PiPaymentModal } from "./PiPaymentModal";
import { CosmicExpeditionHub } from "./CosmicExpeditionHub";
import { ListingOriginBadge } from "@/components/have2want/ListingOriginBadge";
import sun3dImg from "../assets/images/realistic_sun_3d_1788102149622.jpg";

interface PossibilitaPlanetProps {
  listings: HaveWantListing[];
  onAddListing: (listing: HaveWantListing) => void;
  onSelectListingForTrade: (listing: HaveWantListing) => void;
  currentUserBalance?: number;
}

interface CategoryDef {
  id: string;
  name: string;
  shortName: string;
  icon: React.ElementType;
  glowColor: string;
  borderColor: string;
  badgeBg: string;
  textColor: string;
  colorAccent: string;
  keywords: string[];
}

const CATEGORIES: CategoryDef[] = [
  {
    id: "cat-all",
    name: "Tutti i Rami dell'Albero",
    shortName: "Tutti i Rami",
    icon: Sun,
    glowColor: "rgba(245, 158, 11, 0.6)",
    borderColor: "border-amber-400/70",
    badgeBg: "bg-amber-500/20",
    textColor: "text-amber-300",
    colorAccent: "#f59e0b",
    keywords: [],
  },
  {
    id: "cat-competenze",
    name: "Ramo Competenze & Ingegno",
    shortName: "Competenze",
    icon: GraduationCap,
    glowColor: "rgba(59, 130, 246, 0.6)",
    borderColor: "border-blue-400/70",
    badgeBg: "bg-blue-500/20",
    textColor: "text-blue-300",
    colorAccent: "#3b82f6",
    keywords: ["competenze", "servizi", "coding", "digitale", "consulenza", "insegnamento"],
  },
  {
    id: "cat-attrezzi",
    name: "Ramo Strumenti & Attrezzi",
    shortName: "Attrezzi",
    icon: Wrench,
    glowColor: "rgba(249, 115, 22, 0.6)",
    borderColor: "border-orange-400/70",
    badgeBg: "bg-orange-500/20",
    textColor: "text-orange-300",
    colorAccent: "#f97316",
    keywords: ["strumenti", "casa", "attrezzi", "fai-da-te", "bricolage", "oggetti"],
  },
  {
    id: "cat-natura",
    name: "Ramo Terra & Nutrimento",
    shortName: "Terra & Bio",
    icon: Sprout,
    glowColor: "rgba(16, 185, 129, 0.6)",
    borderColor: "border-emerald-400/70",
    badgeBg: "bg-emerald-500/20",
    textColor: "text-emerald-300",
    colorAccent: "#10b981",
    keywords: ["natura", "alimentazione", "cibo", "bio", "orto", "frutta", "terra"],
  },
  {
    id: "cat-lingue",
    name: "Ramo Lingue & Relazioni",
    shortName: "Lingue",
    icon: Globe2,
    glowColor: "rgba(168, 85, 247, 0.6)",
    borderColor: "border-purple-400/70",
    badgeBg: "bg-purple-500/20",
    textColor: "text-purple-300",
    colorAccent: "#a855f7",
    keywords: ["lingue", "cultura", "inglese", "scambio", "lezioni", "relazioni"],
  },
  {
    id: "cat-mobilita",
    name: "Ramo Mobilità & Trasporti",
    shortName: "Mobilità",
    icon: Bike,
    glowColor: "rgba(6, 182, 212, 0.6)",
    borderColor: "border-cyan-400/70",
    badgeBg: "bg-cyan-500/20",
    textColor: "text-cyan-300",
    colorAccent: "#06b6d4",
    keywords: ["mobilità", "veicoli", "bici", "trasporti", "passaggi", "mezzi"],
  },
  {
    id: "cat-arti",
    name: "Ramo Arti & Fatto a Mano",
    shortName: "Arti & Creazioni",
    icon: Palette,
    glowColor: "rgba(244, 63, 94, 0.6)",
    borderColor: "border-rose-400/70",
    badgeBg: "bg-rose-500/20",
    textColor: "text-rose-300",
    colorAccent: "#f43f5e",
    keywords: ["arti", "creazioni", "musica", "design", "artigianato", "foto"],
  },
];

const LIVE_PULSES = [
  { id: 1, city: "Torino", action: "Marco ha scambiato 2h di Coding con Ortaggi Bio", time: "2 min fa", type: "baratto" },
  { id: 2, city: "Milano", action: "Sara ha donato un Trapano Bosch a un vicino", time: "5 min fa", type: "dono" },
  { id: 3, city: "Bologna", action: "Luca ha concordato una sessione di Inglese per 1.5 π", time: "12 min fa", type: "pi" },
  { id: 4, city: "Roma", action: "Elena ha prestato una Bici da Corsa per il weekend", time: "18 min fa", type: "prestito" },
];

export const PossibilitaPlanet: React.FC<PossibilitaPlanetProps> = ({
  listings,
  onAddListing,
  onSelectListingForTrade,
}) => {
  const [activeCategory, setActiveCategory] = useState<string>("cat-all");
  const [filterIntent, setFilterIntent] = useState<InteractionIntent | "ALL">("ALL");
  const [searchQuery, setSearchQuery] = useState("");
  const [viewMode, setViewMode] = useState<"orbit" | "bento" | "radar" | "expedition">("expedition");
  const [activeOrbitIndex, setActiveOrbitIndex] = useState(0);

  const [isPublishModalOpen, setIsPublishModalOpen] = useState(false);
  const [purchasingItem, setPurchasingItem] = useState<HaveWantListing | null>(null);
  const [inspectListing, setInspectListing] = useState<HaveWantListing | null>(null);

  // Form State
  const [newIntent, setNewIntent] = useState<InteractionIntent>("BARATTO_SCAMBIO");
  const [newTitle, setNewTitle] = useState("");
  const [newDescription, setNewDescription] = useState("");
  const [newCategory, setNewCategory] = useState("Competenze & Servizi");
  const [newPiPrice, setNewPiPrice] = useState<string>("0");
  const [newTags, setNewTags] = useState("");
  const [newCity, setNewCity] = useState("Torino");

  // Filter listings
  const filteredListings = listings.filter((item) => {
    if (filterIntent !== "ALL" && item.intent !== filterIntent) return false;

    if (activeCategory !== "cat-all") {
      const catDef = CATEGORIES.find((c) => c.id === activeCategory);
      if (catDef) {
        const itemCatLower = item.category.toLowerCase();
        const matchesCategory =
          catDef.keywords.some((kw) => itemCatLower.includes(kw)) ||
          itemCatLower.includes(catDef.shortName.toLowerCase());
        if (!matchesCategory) return false;
      }
    }

    if (searchQuery.trim() !== "") {
      const q = searchQuery.toLowerCase();
      const matchTitle = item.title.toLowerCase().includes(q);
      const matchDesc = item.description.toLowerCase().includes(q);
      const matchTags = item.tags.some((t) => t.toLowerCase().includes(q));
      const matchCat = item.category.toLowerCase().includes(q);
      const matchCity = item.author.city.toLowerCase().includes(q);
      if (!matchTitle && !matchDesc && !matchTags && !matchCat && !matchCity) return false;
    }
    return true;
  });

  const currentCategoryDef = CATEGORIES.find((c) => c.id === activeCategory) || CATEGORIES[0];

  const handlePublishSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newDescription.trim()) return;

    const parsedPrice = parseFloat(newPiPrice) || 0;
    const clampedPrice = Math.min(parsedPrice, 15);

    const geocoded = fuzzyGeocode(newCity.trim() || "Torino", false);

    const newListing: HaveWantListing = {
      id: `hw-${Date.now()}`,
      intent: newIntent,
      title: newTitle.trim(),
      description: newDescription.trim(),
      category: "casa_fai_da_te",
      subcategory: "attrezzi_lavoro_utensili",
      piPrice: newIntent === "VENDO" ? clampedPrice : 0,
      author: {
        name: "Creatore Originale",
        username: "@brandoriginal",
        avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80",
        reputation: 5.0,
        isPioneerVerified: true,
        city: geocoded.displayName,
      },
      lat: geocoded.lat,
      lng: geocoded.lng,
      locationArea: geocoded.displayName,
      isFuzzyLocation: geocoded.isFuzzyCentroid,
      createdAt: "Pochi secondi fa",
      tags: newTags
        .split(",")
        .map((t) => t.trim())
        .filter(Boolean),
      status: "active",
      planetId: "planet-possibilita",
      satelliteId: "sat-competenze",
    };

    onAddListing(newListing);
    setIsPublishModalOpen(false);
    setNewTitle("");
    setNewDescription("");
    setNewTags("");
    setNewPiPrice("0");
  };

  const getIntentBadge = (intent: InteractionIntent, piPrice?: number) => {
    switch (intent) {
      case "VENDO":
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-black bg-amber-500/25 text-amber-200 border border-amber-500/60 shadow-sm shadow-amber-950">
            <Coins className="w-3.5 h-3.5 text-amber-400" /> {piPrice && piPrice > 0 ? `VENDO • ${piPrice} π` : "VENDO"}
          </span>
        );
      case "BARATTO_SCAMBIO":
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-black bg-emerald-500/20 text-emerald-300 border border-emerald-500/50 shadow-sm shadow-emerald-950">
            <ArrowUpDown className="w-3.5 h-3.5 text-emerald-400" /> BARATTO & SCAMBIO
          </span>
        );
      case "ACQUISTO_CERCO":
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-black bg-purple-500/20 text-purple-300 border border-purple-500/50 shadow-sm shadow-purple-950">
            <Sparkles className="w-3.5 h-3.5 text-purple-400" /> ACQUISTO & CERCO
          </span>
        );
    }
  };

  return (
    <div className="space-y-8 pb-12">
      
      {/* ========================================================================= */}
      {/* 1. NUCLEO OLOGRAFICO SOLARE TRIDIMENSIONALE (SOLAR CORE ENGINE)          */}
      {/* ========================================================================= */}
      <div className="relative rounded-[36px] overflow-hidden bg-[#030712] border-2 border-amber-500/40 shadow-[0_0_80px_rgba(245,158,11,0.2)]">
        
        {/* Animated Background Rays & Nebula Depth */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,_rgba(245,158,11,0.25)_0%,_rgba(15,23,42,0.6)_45%,_rgba(2,6,23,0.95)_100%)] pointer-events-none" />
        <div className="absolute top-0 left-0 right-0 h-96 bg-[radial-gradient(ellipse_at_top,_rgba(245,158,11,0.18),transparent_70%)] pointer-events-none" />
        
        {/* Decorative Solar Rays */}
        <div className="absolute -top-32 left-1/2 -translate-x-1/2 w-[700px] h-[700px] bg-amber-500/10 rounded-full blur-3xl pointer-events-none animate-pulse" />
        
        <div className="relative p-6 sm:p-8 lg:p-10 space-y-8">
          
          {/* TOP BAR: Solar Status & Mode Switcher */}
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
            
            {/* Left: Solar Emblem & Title */}
            <div className="flex items-center gap-4 sm:gap-6">
              <div className="relative group cursor-pointer shrink-0">
                <div className="relative w-20 h-20 sm:w-24 sm:h-24 rounded-full flex items-center justify-center shadow-[0_0_50px_rgba(245,158,11,0.85)] border-2 border-amber-400 transition-transform duration-500 group-hover:scale-105">
                  <img
                    src={sun3dImg}
                    alt="Il Sole del Valore"
                    className="w-full h-full object-cover rounded-full animate-[spin_80s_linear_infinite]"
                  />
                  <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-amber-500/30 to-yellow-300/20 blur-sm pointer-events-none" />
                </div>
                <div className="absolute -bottom-2 -right-2 px-2 py-0.5 bg-amber-400 text-slate-950 rounded-full text-[10px] font-black uppercase tracking-wider shadow-md">
                  Core 3D
                </div>
              </div>

              <div>
                <div className="flex items-center gap-2 text-amber-400 text-xs sm:text-sm font-black uppercase tracking-widest">
                  <Flame className="w-4 h-4 text-amber-400 animate-bounce" />
                  La Chioma dei Valori • Matrice HAVE ↔ WANT
                </div>
                <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black text-white tracking-tight mt-1 flex items-center gap-3">
                  I Rami & le Opportunità
                  <span className="text-xs sm:text-sm font-mono px-3 py-1 rounded-full bg-amber-500/20 border border-amber-400/60 text-amber-300">
                    {filteredListings.length} Risorse Attive
                  </span>
                </h1>
                <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-xl leading-relaxed">
                  L'albero cresce grazie a ciò che offri e ciò di cui hai bisogno: esplora i rami tematici, la mappa delle connessioni o il radar di prossimità.
                </p>
              </div>
            </div>

            {/* Right: Actions & View Switcher */}
            <div className="flex flex-wrap items-center gap-3">
              
              {/* 3D View Switcher */}
              <div className="p-1 bg-slate-950/90 rounded-2xl border border-slate-800 flex items-center shadow-inner">
                <button
                  onClick={() => setViewMode("expedition")}
                  className={`px-3.5 py-2 rounded-xl text-xs font-black flex items-center gap-1.5 transition-all cursor-pointer ${
                    viewMode === "expedition"
                      ? "bg-amber-400 text-slate-950 shadow-md shadow-amber-400/20 scale-105"
                      : "text-slate-400 hover:text-white"
                  }`}
                  title="Spedizione Stellare & Oracolo Match"
                >
                  <Sparkles className="w-4 h-4 text-amber-500 fill-amber-500" />
                  <span>Spedizione ✦</span>
                </button>
                <button
                  onClick={() => setViewMode("orbit")}
                  className={`px-3.5 py-2 rounded-xl text-xs font-black flex items-center gap-1.5 transition-all cursor-pointer ${
                    viewMode === "orbit"
                      ? "bg-amber-400 text-slate-950 shadow-md shadow-amber-400/20 scale-105"
                      : "text-slate-400 hover:text-white"
                  }`}
                  title="Orbita Olografica 3D"
                >
                  <Orbit className="w-4 h-4" />
                  <span>Orbita 3D</span>
                </button>
                <button
                  onClick={() => setViewMode("bento")}
                  className={`px-3.5 py-2 rounded-xl text-xs font-black flex items-center gap-1.5 transition-all cursor-pointer ${
                    viewMode === "bento"
                      ? "bg-amber-400 text-slate-950 shadow-md shadow-amber-400/20 scale-105"
                      : "text-slate-400 hover:text-white"
                  }`}
                  title="Griglia Bento Tattile"
                >
                  <Grid3X3 className="w-4 h-4" />
                  <span>Bento Cards</span>
                </button>
                <button
                  onClick={() => setViewMode("radar")}
                  className={`px-3.5 py-2 rounded-xl text-xs font-black flex items-center gap-1.5 transition-all cursor-pointer ${
                    viewMode === "radar"
                      ? "bg-amber-400 text-slate-950 shadow-md shadow-amber-400/20 scale-105"
                      : "text-slate-400 hover:text-white"
                  }`}
                  title="Radar Territoriale"
                >
                  <Radar className="w-4 h-4" />
                  <span>Radar</span>
                </button>
              </div>

              {/* Publish CTA */}
              <button
                onClick={() => setIsPublishModalOpen(true)}
                id="open-publish-listing-modal-btn"
                className="inline-flex items-center justify-center gap-2 px-5 py-3.5 rounded-2xl bg-gradient-to-r from-amber-400 via-amber-300 to-yellow-400 hover:from-amber-300 hover:to-yellow-300 text-slate-950 font-black text-xs sm:text-sm shadow-[0_0_25px_rgba(245,158,11,0.4)] hover:scale-105 active:scale-95 transition-all cursor-pointer shrink-0"
              >
                <Plus className="w-4 h-4 stroke-[3]" />
                <span>Pubblica Annuncio</span>
              </button>

            </div>

          </div>

          {/* ======================================================================= */}
          {/* CATEGORY NODES SPHERICAL CORONA (GLOWING ORBITAL PILLS)                */}
          {/* ======================================================================= */}
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs font-bold text-slate-400 uppercase tracking-wider px-1">
              <span className="flex items-center gap-2 text-slate-300">
                <Radio className="w-4 h-4 text-amber-400 animate-pulse" />
                Frequenze Tematiche del Sole:
              </span>
              <span className="text-amber-300 font-mono font-black">
                {currentCategoryDef.name}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
              {CATEGORIES.map((cat) => {
                const IconComponent = cat.icon;
                const isActive = activeCategory === cat.id;

                const count =
                  cat.id === "cat-all"
                    ? listings.length
                    : listings.filter((l) => {
                        const lCatLower = l.category.toLowerCase();
                        return (
                          cat.keywords.some((kw) => lCatLower.includes(kw)) ||
                          lCatLower.includes(cat.shortName.toLowerCase())
                        );
                      }).length;

                return (
                  <button
                    key={cat.id}
                    onClick={() => setActiveCategory(cat.id)}
                    id={`category-pill-${cat.id}`}
                    className={`relative p-3.5 rounded-2xl border-2 transition-all duration-300 flex flex-col items-center justify-between text-center gap-2 cursor-pointer group backdrop-blur-xl ${
                      isActive
                        ? `${cat.borderColor} bg-slate-900/90 shadow-[0_0_30px_${cat.glowColor}] scale-[1.04] z-10`
                        : "bg-slate-950/70 border-slate-800 hover:border-slate-700 hover:bg-slate-900/50"
                    }`}
                  >
                    {/* Glowing Top Ring Indicator */}
                    <div
                      className={`w-10 h-10 rounded-2xl flex items-center justify-center transition-all ${
                        isActive
                          ? `${cat.badgeBg} ${cat.textColor} shadow-lg shadow-${cat.colorAccent}/40 ring-2 ring-${cat.colorAccent}`
                          : "bg-slate-900 text-slate-400 group-hover:text-slate-200"
                      }`}
                    >
                      <IconComponent className="w-5 h-5" />
                    </div>

                    <div className="space-y-0.5">
                      <div
                        className={`text-xs font-black tracking-tight leading-tight ${
                          isActive ? "text-white" : "text-slate-300 group-hover:text-white"
                        }`}
                      >
                        {cat.shortName}
                      </div>
                      <div
                        className={`text-[10px] font-mono font-bold ${
                          isActive ? cat.textColor : "text-slate-500"
                        }`}
                      >
                        {count} annunc{count === 1 ? "io" : "i"}
                      </div>
                    </div>

                    {isActive && (
                      <div
                        className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-10 h-1 rounded-full shadow-lg"
                        style={{ backgroundColor: cat.colorAccent, boxShadow: `0 0 12px ${cat.colorAccent}` }}
                      />
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* ======================================================================= */}
          {/* SEARCH & DUAL-TONE HAVE/WANT CAPSULE                                   */}
          {/* ======================================================================= */}
          <div className="pt-4 border-t border-slate-800/90 flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4">
            
            {/* 3 Rigid Action Switches: ALL / VENDO / BARATTO_SCAMBIO / ACQUISTO_CERCO */}
            <div className="flex items-center p-1.5 bg-slate-950/95 rounded-2xl border border-slate-800 text-xs sm:text-sm font-black shrink-0 shadow-inner gap-1">
              <button
                onClick={() => setFilterIntent("ALL")}
                className={`px-3 py-2 rounded-xl transition-all cursor-pointer ${
                  filterIntent === "ALL"
                    ? "bg-amber-400 text-slate-950 shadow-md font-black"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                Tutti ({listings.length})
              </button>
              <button
                onClick={() => setFilterIntent("VENDO")}
                className={`px-3 py-2 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
                  filterIntent === "VENDO"
                    ? "bg-amber-500 text-slate-950 shadow-md font-black shadow-amber-500/20"
                    : "text-slate-400 hover:text-amber-300"
                }`}
              >
                <Coins className="w-3.5 h-3.5" />
                VENDO ({listings.filter((l) => l.intent === "VENDO").length})
              </button>
              <button
                onClick={() => setFilterIntent("BARATTO_SCAMBIO")}
                className={`px-3 py-2 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
                  filterIntent === "BARATTO_SCAMBIO"
                    ? "bg-emerald-500 text-slate-950 shadow-md font-black shadow-emerald-500/20"
                    : "text-slate-400 hover:text-emerald-300"
                }`}
              >
                <ArrowUpDown className="w-3.5 h-3.5" />
                SCAMBIO ({listings.filter((l) => l.intent === "BARATTO_SCAMBIO").length})
              </button>
              <button
                onClick={() => setFilterIntent("ACQUISTO_CERCO")}
                className={`px-3 py-2 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
                  filterIntent === "ACQUISTO_CERCO"
                    ? "bg-purple-500 text-white shadow-md font-black shadow-purple-500/20"
                    : "text-slate-400 hover:text-purple-300"
                }`}
              >
                <Sparkles className="w-3.5 h-3.5" />
                ACQUISTO & CERCO ({listings.filter((l) => l.intent === "ACQUISTO_CERCO").length})
              </button>
            </div>

            {/* Keyword Search Bar */}
            <div className="relative flex-1 max-w-lg">
              <Search className="w-4 h-4 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Cerca abilità, città, tag (es: Bici, Coding, Torino, Semi)..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-11 pr-10 py-2.5 bg-slate-950/90 border border-slate-700/80 rounded-2xl text-xs sm:text-sm text-white placeholder-slate-400 focus:outline-none focus:border-amber-400 transition-colors shadow-inner"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery("")}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

          </div>

          {/* LIVE SOLAR ENERGY PULSE TICKER */}
          <div className="p-3 bg-slate-950/80 rounded-2xl border border-slate-800/80 flex items-center justify-between gap-4 overflow-hidden">
            <div className="flex items-center gap-2 shrink-0 text-xs font-black text-amber-400 uppercase tracking-wider">
              <Activity className="w-4 h-4 animate-pulse text-amber-400" />
              <span>Flusso in Tempo Reale:</span>
            </div>
            <div className="flex-1 overflow-hidden whitespace-nowrap flex items-center gap-6">
              {LIVE_PULSES.map((pulse) => (
                <div key={pulse.id} className="inline-flex items-center gap-2 text-xs text-slate-300">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
                  <span className="font-bold text-white">{pulse.city}:</span>
                  <span>{pulse.action}</span>
                  <span className="text-[10px] text-slate-500 font-mono">({pulse.time})</span>
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. MAIN VIEW MODES: (EXPEDITION / ORBIT 3D / BENTO CARDS / RADAR PIONIERI) */}
      {/* ========================================================================= */}

      {/* ------------------------------------------------------------------------- */}
      {/* 0. VISTA SPEDIZIONE STELLARE (GAMIFIED EXPEDITION & SYNCHRONICITY MACHINE) */}
      {/* ------------------------------------------------------------------------- */}
      {viewMode === "expedition" && (
        <div className="space-y-6">
          <CosmicExpeditionHub
            listings={listings}
            onOpenMatchFinder={() => {}}
            onOpenRandomDiscovery={() => {}}
            onQuickPublish={() => setIsPublishModalOpen(true)}
            onSelectListing={(item) => setInspectListing(item)}
          />
        </div>
      )}

      {/* ------------------------------------------------------------------------- */}
      {/* A. VISTA ORBITA OLOGRAFICA 3D (DYNAMIC ORBITAL CAROUSEL WITH 3D DEPTH)   */}
      {/* ------------------------------------------------------------------------- */}
      {viewMode === "orbit" && (
        <div className="space-y-6">
          
          <div className="flex items-center justify-between px-2">
            <div className="flex items-center gap-2">
              <Orbit className="w-5 h-5 text-amber-400 animate-spin" />
              <h2 className="text-lg sm:text-xl font-black text-white">Orbita Olografica delle Risorse</h2>
              <span className="text-xs text-slate-400 font-medium">| Scansiona le schede in rotazione prospettica</span>
            </div>

            {filteredListings.length > 1 && (
              <div className="flex items-center gap-2">
                <button
                  onClick={() =>
                    setActiveOrbitIndex((prev) => (prev > 0 ? prev - 1 : filteredListings.length - 1))
                  }
                  className="p-2 rounded-xl bg-slate-900 hover:bg-amber-400 hover:text-slate-950 text-white border border-slate-800 transition-colors cursor-pointer"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <span className="text-xs font-mono text-amber-300 font-bold px-2">
                  {activeOrbitIndex + 1} / {filteredListings.length}
                </span>
                <button
                  onClick={() =>
                    setActiveOrbitIndex((prev) => (prev < filteredListings.length - 1 ? prev + 1 : 0))
                  }
                  className="p-2 rounded-xl bg-slate-900 hover:bg-amber-400 hover:text-slate-950 text-white border border-slate-800 transition-colors cursor-pointer"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            )}
          </div>

          {filteredListings.length === 0 ? (
            <div className="py-16 text-center rounded-3xl bg-slate-900/60 border border-slate-800 space-y-3">
              <Sparkles className="w-10 h-10 text-slate-500 mx-auto" />
              <h3 className="text-lg font-bold text-white">Nessun annuncio nell'orbita selezionata</h3>
              <p className="text-xs sm:text-sm text-slate-400 max-w-sm mx-auto">
                Modifica i filtri di categoria o la modalità per vedere altre risorse.
              </p>
            </div>
          ) : (
            <div className="relative min-h-[460px] flex items-center justify-center p-4 rounded-[36px] bg-gradient-to-b from-slate-950 via-[#050b18] to-slate-950 border-2 border-slate-800/80 overflow-hidden shadow-2xl">
              
              {/* Planetary Orbital Background Rings */}
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-25">
                <div className="w-[300px] h-[300px] rounded-full border border-amber-400/40 animate-[spin_40s_linear_infinite]" />
                <div className="absolute w-[500px] h-[500px] rounded-full border border-dashed border-amber-400/30 animate-[spin_60s_linear_infinite]" />
                <div className="absolute w-[750px] h-[750px] rounded-full border border-slate-700/50" />
              </div>

              {/* 3D Perspective Orbital Carousel Cards */}
              <div className="relative z-10 w-full max-w-4xl flex items-center justify-center py-6">
                {filteredListings.map((item, idx) => {
                  const isHave = item.intent === "VENDO" || item.intent === "BARATTO_SCAMBIO";
                  const offset = idx - activeOrbitIndex;
                  const isCurrent = offset === 0;

                  // Render only items in view range
                  if (Math.abs(offset) > 2) return null;

                  return (
                    <motion.div
                      key={item.id}
                      initial={false}
                      animate={{
                        x: offset * 260,
                        scale: isCurrent ? 1 : 0.82 - Math.abs(offset) * 0.08,
                        opacity: isCurrent ? 1 : 0.35,
                        zIndex: isCurrent ? 30 : 20 - Math.abs(offset),
                        rotateY: offset * -18,
                      }}
                      transition={{ type: "spring", stiffness: 260, damping: 26 }}
                      onClick={() => setActiveOrbitIndex(idx)}
                      className={`absolute w-full max-w-md rounded-[30px] border-2 cursor-pointer shadow-2xl backdrop-blur-2xl transition-all duration-300 ${
                        isCurrent
                          ? isHave
                            ? "bg-gradient-to-b from-slate-900/98 via-[#06241c] to-slate-950 border-emerald-400 shadow-[0_0_50px_rgba(16,185,129,0.3)]"
                            : "bg-gradient-to-b from-slate-900/98 via-[#1f1035] to-slate-950 border-purple-400 shadow-[0_0_50px_rgba(168,85,247,0.3)]"
                          : "bg-slate-950/80 border-slate-800"
                      }`}
                    >
                      {/* Top Glowing Header Accent */}
                      <div
                        className={`h-2 w-full rounded-t-[28px] ${
                          isHave
                            ? "bg-gradient-to-r from-emerald-500 via-teal-300 to-emerald-500"
                            : "bg-gradient-to-r from-purple-500 via-pink-400 to-purple-500"
                        }`}
                      />

                      <div className="p-6 sm:p-7 space-y-4">
                        
                        {/* Type + Mode Bar */}
                        <div className="flex items-center justify-between gap-2">
                          <span
                            className={`text-xs font-black uppercase px-3 py-1 rounded-xl tracking-wider ${
                              isHave
                                ? "bg-emerald-500/30 text-emerald-200 border border-emerald-400/60"
                                : "bg-purple-500/30 text-purple-200 border border-purple-400/60"
                            }`}
                          >
                            {item.intent === "VENDO" ? "VENDO" : item.intent === "BARATTO_SCAMBIO" ? "BARATTO & SCAMBIO" : "ACQUISTO & CERCO"}
                          </span>

                          {getIntentBadge(item.intent, item.piPrice)}
                        </div>

                        {/* Category & Origin */}
                        <div className="flex items-center gap-2 flex-wrap">
                          <div className="text-xs font-black text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                            <span className="w-2 h-2 rounded-full bg-amber-400"></span>
                            <span>{item.category}</span>
                          </div>
                          <ListingOriginBadge listing={item} size="xs" />
                        </div>

                        {/* Title */}
                        <h3 className="text-xl font-black text-white leading-tight">
                          {item.title}
                        </h3>

                        {/* Description */}
                        <p className="text-xs sm:text-sm text-slate-300 line-clamp-3 leading-relaxed">
                          {item.description}
                        </p>

                        {/* Tags */}
                        <div className="flex flex-wrap gap-1.5 pt-1">
                          {item.tags.map((tag, tIdx) => (
                            <span
                              key={tIdx}
                              className="text-[11px] px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-800 text-slate-300 font-medium"
                            >
                              #{tag}
                            </span>
                          ))}
                        </div>

                        {/* Author Profile Box */}
                        <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between gap-3">
                          <div className="flex items-center gap-3">
                            <div className="relative">
                              <img
                                src={item.author.avatar}
                                alt={item.author.name}
                                className="w-11 h-11 rounded-full object-cover border-2 border-slate-700 shadow-md"
                              />
                              {item.author.isPioneerVerified && (
                                <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-amber-400 flex items-center justify-center text-slate-950 shadow-md">
                                  <CheckCircle2 className="w-3.5 h-3.5" />
                                </div>
                              )}
                            </div>
                            <div>
                              <div className="text-xs font-black text-white">{item.author.name}</div>
                              <div className="text-[11px] text-slate-400 flex items-center gap-1.5 mt-0.5">
                                <span className="text-amber-400 font-bold">★ {item.author.reputation}</span>
                                <span>•</span>
                                <span className="flex items-center gap-0.5">
                                  <MapPin className="w-3 h-3" /> {item.author.city}
                                </span>
                              </div>
                            </div>
                          </div>

                          {/* Quick Inspect Button */}
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setInspectListing(item);
                            }}
                            className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 transition-colors"
                            title="Espandi Scheda Olografica"
                          >
                            <Maximize2 className="w-4 h-4" />
                          </button>
                        </div>

                        {/* Action CTAs */}
                        <div className="pt-2 grid grid-cols-2 gap-2.5">
                          {(item.intent === "VENDO" || (item.piPrice && item.piPrice > 0)) && (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setPurchasingItem(item);
                              }}
                              className="py-3 rounded-2xl bg-gradient-to-r from-amber-400 to-yellow-400 text-slate-950 font-black text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-amber-400/20 hover:scale-105 transition-all cursor-pointer"
                            >
                              <Coins className="w-4 h-4" />
                              <span>Paga {item.piPrice ? `${item.piPrice} π` : "π"}</span>
                            </button>
                          )}

                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onSelectListingForTrade(item);
                            }}
                            className={`py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white font-black text-xs flex items-center justify-center gap-1.5 border border-slate-700 transition-all cursor-pointer ${
                              !(item.intent === "VENDO" || (item.piPrice && item.piPrice > 0))
                                ? "col-span-2 bg-gradient-to-r from-amber-400 to-yellow-400 text-slate-950 hover:from-amber-300 hover:to-yellow-300 border-none shadow-lg shadow-amber-400/20"
                                : ""
                            }`}
                            title="Baratta questo articolo o proponi una contropartita"
                          >
                            <HeartHandshake className="w-4 h-4" />
                            <span>Proponi Baratto</span>
                          </button>
                        </div>

                      </div>
                    </motion.div>
                  );
                })}
              </div>

            </div>
          )}

        </div>
      )}

      {/* ------------------------------------------------------------------------- */}
      {/* B. VISTA BENTO CARDS TATTILI (HIGH DENSITY GRID WITH 3D DEPTH)             */}
      {/* ------------------------------------------------------------------------- */}
      {viewMode === "bento" && (
        <div className="space-y-6">
          <div className="flex items-center justify-between px-2">
            <div className="flex items-center gap-2">
              <Grid3X3 className="w-5 h-5 text-amber-400" />
              <h2 className="text-lg sm:text-xl font-black text-white">Galleria Bento delle Risorse</h2>
              <span className="text-xs text-slate-400 font-medium">| Vista a schede tattili ad alta densità</span>
            </div>
            <span className="text-xs font-mono text-amber-300 font-bold">
              {filteredListings.length} Annunci Disponibili
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredListings.map((item) => {
              const isHave = item.intent === "VENDO" || item.intent === "BARATTO_SCAMBIO";

              return (
                <motion.div
                  key={item.id}
                  whileHover={{ y: -6, scale: 1.01 }}
                  transition={{ type: "spring", stiffness: 300, damping: 20 }}
                  className={`relative rounded-[28px] border-2 flex flex-col justify-between group overflow-hidden shadow-2xl backdrop-blur-xl ${
                    isHave
                      ? "bg-gradient-to-b from-slate-900/95 via-[#061d15]/90 to-slate-950 border-emerald-500/50 hover:border-emerald-400 shadow-emerald-950/40 hover:shadow-[0_15px_40px_rgba(16,185,129,0.25)]"
                      : "bg-gradient-to-b from-slate-900/95 via-[#1a0f2b]/90 to-slate-950 border-purple-500/50 hover:border-purple-400 shadow-purple-950/40 hover:shadow-[0_15px_40px_rgba(168,85,247,0.25)]"
                  }`}
                >
                  <div
                    className={`h-1.5 w-full ${
                      isHave
                        ? "bg-gradient-to-r from-emerald-400 via-teal-300 to-emerald-400"
                        : "bg-gradient-to-r from-purple-400 via-pink-300 to-purple-400"
                    }`}
                  />

                  <div className="p-6 space-y-4">
                    
                    <div className="flex items-center justify-between gap-2">
                      <span
                        className={`text-[11px] font-black uppercase tracking-wider px-3 py-1 rounded-xl ${
                          isHave
                            ? "bg-emerald-500/30 text-emerald-200 border border-emerald-400/50"
                            : "bg-purple-500/30 text-purple-200 border border-purple-400/50"
                        }`}
                      >
                        {item.intent === "VENDO" ? "VENDO" : item.intent === "BARATTO_SCAMBIO" ? "BARATTO & SCAMBIO" : "ACQUISTO & CERCO"}
                      </span>
                      {getIntentBadge(item.intent, item.piPrice)}
                    </div>

                    <div className="text-[11px] font-bold text-amber-400 uppercase tracking-wide flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
                      <span>{item.category}</span>
                    </div>

                    <h3 className="text-base sm:text-lg font-black text-white group-hover:text-amber-300 transition-colors line-clamp-2 leading-snug">
                      {item.title}
                    </h3>

                    <p className="text-xs sm:text-sm text-slate-300 line-clamp-3 leading-relaxed">
                      {item.description}
                    </p>

                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {item.tags.map((tag, idx) => (
                        <span
                          key={idx}
                          className="text-[11px] px-2.5 py-1 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-300 font-medium"
                        >
                          #{tag}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Card Bottom Bar */}
                  <div className="p-4 sm:p-5 bg-slate-950/90 border-t border-slate-800/80 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="relative shrink-0">
                        <img
                          src={item.author.avatar}
                          alt={item.author.name}
                          className="w-10 h-10 rounded-full object-cover border-2 border-slate-700 shadow-md"
                        />
                        {item.author.isPioneerVerified && (
                          <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-amber-400 flex items-center justify-center text-slate-950 shadow-md">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                          </div>
                        )}
                      </div>

                      <div className="min-w-0">
                        <div className="text-xs font-black text-white truncate">{item.author.name}</div>
                        <div className="text-[11px] text-slate-400 flex items-center gap-1 mt-0.5">
                          <span className="text-amber-400 font-bold">★ {item.author.reputation}</span>
                          <span>•</span>
                          <span className="truncate flex items-center gap-0.5">
                            <MapPin className="w-3 h-3" /> {item.author.city}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {(item.intent === "VENDO" || (item.piPrice && item.piPrice > 0)) && (
                        <button
                          onClick={() => setPurchasingItem(item)}
                          className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 text-xs font-black transition-all cursor-pointer flex items-center gap-1 shadow-lg shadow-amber-500/20 hover:scale-105"
                        >
                          <Coins className="w-3.5 h-3.5" />
                          <span>{item.piPrice ? `${item.piPrice} π` : "π"}</span>
                        </button>
                      )}

                      <button
                        onClick={() => onSelectListingForTrade(item)}
                        className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-extrabold border border-slate-700 transition-all cursor-pointer flex items-center gap-1.5 shadow"
                      >
                        <MessageCircle className="w-3.5 h-3.5 text-amber-300" />
                        <span>Contatta</span>
                      </button>
                    </div>

                  </div>

                </motion.div>
              );
            })}
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------------------- */}
      {/* C. VISTA RADAR PIONIERI (GEOSPATIAL PROXIMITY RADAR)                      */}
      {/* ------------------------------------------------------------------------- */}
      {viewMode === "radar" && (
        <div className="p-6 sm:p-8 rounded-[36px] bg-gradient-to-b from-slate-950 via-[#0a1226] to-slate-950 border-2 border-cyan-500/40 shadow-2xl space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-cyan-400 text-xs font-black uppercase tracking-wider">
                <Radar className="w-4 h-4 animate-spin text-cyan-400" />
                Radar Territoriale di Prossimità
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-white mt-1">Mappa di Risonanza del Valore</h2>
              <p className="text-xs sm:text-sm text-slate-300">Pionieri e risorse attive geolocalizzate per scambi a km 0.</p>
            </div>
            <div className="px-4 py-2 rounded-2xl bg-cyan-500/20 border border-cyan-400/50 text-cyan-300 font-black text-xs">
              Raggio: 25 km attorno a te
            </div>
          </div>

          <div className="relative h-80 rounded-3xl bg-[#020617] border border-cyan-500/30 overflow-hidden flex items-center justify-center">
            {/* Concentric Radar Rings */}
            <div className="absolute w-28 h-28 rounded-full border border-cyan-500/30" />
            <div className="absolute w-52 h-52 rounded-full border border-cyan-500/25" />
            <div className="absolute w-72 h-72 rounded-full border border-cyan-500/20" />
            <div className="absolute w-full h-[1px] bg-cyan-500/20" />
            <div className="absolute h-full w-[1px] bg-cyan-500/20" />
            
            {/* Center User Node */}
            <div className="relative z-10 w-12 h-12 rounded-full bg-cyan-500 flex items-center justify-center text-slate-950 font-black text-xs shadow-[0_0_30px_#06b6d4]">
              Tu
            </div>

            {/* Simulated Resource Nodes */}
            {filteredListings.slice(0, 6).map((item, idx) => {
              const angles = [30, 85, 140, 210, 290, 335];
              const distances = [60, 95, 120, 80, 110, 130];
              const angle = angles[idx % angles.length] * (Math.PI / 180);
              const dist = distances[idx % distances.length];
              const x = Math.cos(angle) * dist;
              const y = Math.sin(angle) * dist;

              return (
                <div
                  key={item.id}
                  style={{ transform: `translate(${x}px, ${y}px)` }}
                  onClick={() => setInspectListing(item)}
                  className="absolute z-20 cursor-pointer group"
                >
                  <div className="w-8 h-8 rounded-full bg-amber-400 border-2 border-slate-950 flex items-center justify-center text-slate-950 shadow-lg group-hover:scale-125 transition-transform">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div className="absolute -top-7 left-1/2 -translate-x-1/2 whitespace-nowrap bg-slate-950/95 border border-amber-400 px-2 py-0.5 rounded-lg text-[10px] font-bold text-amber-300 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                    {item.author.city}: {item.title.substring(0, 18)}...
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. MODAL DETTAGLIO OLOGRAFICO ISPEZIONE                                   */}
      {/* ========================================================================= */}
      {inspectListing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-xl animate-in fade-in duration-200">
          <div className="w-full max-w-2xl bg-slate-900 border-2 border-amber-400/60 rounded-[32px] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 flex flex-col">
            
            <div className="p-6 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="text-xs font-black px-3 py-1 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-400/50">
                  {inspectListing.intent === "VENDO" ? "VENDO • Risorsa Disponibile" : inspectListing.intent === "BARATTO_SCAMBIO" ? "BARATTO & SCAMBIO" : "ACQUISTO & CERCO • Bisogno Richiesto"}
                </span>
                <span className="text-xs font-bold text-slate-400">{inspectListing.category}</span>
              </div>
              <button
                onClick={() => setInspectListing(null)}
                className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 sm:p-8 space-y-6 overflow-y-auto max-h-[75vh]">
              <div>
                <h2 className="text-2xl font-black text-white">{inspectListing.title}</h2>
                <p className="text-sm text-slate-300 mt-3 leading-relaxed">{inspectListing.description}</p>
              </div>

              {/* Author & Verification Card */}
              <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <img
                    src={inspectListing.author.avatar}
                    alt={inspectListing.author.name}
                    className="w-14 h-14 rounded-full object-cover border-2 border-amber-400 shadow-md"
                  />
                  <div>
                    <div className="font-black text-white flex items-center gap-1.5">
                      <span>{inspectListing.author.name}</span>
                      <ShieldCheck className="w-4 h-4 text-amber-400" />
                    </div>
                    <div className="text-xs text-slate-400 mt-1 flex items-center gap-2">
                      <span className="text-amber-400 font-bold">★ {inspectListing.author.reputation} Pioniere</span>
                      <span>•</span>
                      <span>{inspectListing.author.city}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Formula di Baratto Integrata all'interno della Scheda */}
              <div className="p-4 rounded-2xl bg-amber-950/25 border border-amber-500/40 text-xs text-amber-200 space-y-1.5">
                <div className="flex items-center gap-2 font-black text-amber-400 uppercase tracking-wider text-[11px]">
                  <HeartHandshake className="w-4 h-4" />
                  <span>Formula di Baratto Integrata</span>
                </div>
                <p className="text-slate-300 leading-relaxed">
                  {inspectListing.concreteExchange?.wanted?.item 
                    ? `Accetta in baratto: ${inspectListing.concreteExchange.wanted.quantity || 1} ${inspectListing.concreteExchange.wanted.unit || 'unità'} di ${inspectListing.concreteExchange.wanted.item}`
                    : `Disponibile per baratto con beni o servizi di pari utilità nel territorio locale.`
                  }
                </p>
              </div>

              {/* Actions */}
              <div className="grid grid-cols-2 gap-4">
                {(inspectListing.intent === "VENDO" || (inspectListing.piPrice && inspectListing.piPrice > 0)) && (
                  <button
                    onClick={() => {
                      const item = inspectListing;
                      setInspectListing(null);
                      setPurchasingItem(item);
                    }}
                    className="py-3.5 rounded-2xl bg-gradient-to-r from-amber-400 to-yellow-400 text-slate-950 font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-amber-400/20"
                  >
                    <Coins className="w-5 h-5" />
                    <span>Paga {inspectListing.piPrice} π</span>
                  </button>
                )}

                <button
                  onClick={() => {
                    const item = inspectListing;
                    setInspectListing(null);
                    onSelectListingForTrade(item);
                  }}
                  className={`py-3.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white font-black text-sm flex items-center justify-center gap-2 border border-slate-700 transition-colors ${
                    !(inspectListing.intent === "VENDO" || (inspectListing.piPrice && inspectListing.piPrice > 0))
                      ? "col-span-2 bg-gradient-to-r from-amber-400 to-yellow-400 text-slate-950 hover:from-amber-300 hover:to-yellow-300 border-none font-black"
                      : ""
                  }`}
                  title="Baratta questo articolo o proponi una contropartita"
                >
                  <HeartHandshake className="w-5 h-5 text-amber-400" />
                  <span>Proponi Baratto</span>
                </button>
              </div>

            </div>

          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 4. MODAL PAGAMENTO ESTERNO PI WALLET                                      */}
      {/* ========================================================================= */}
      {purchasingItem && (
        <PiPaymentModal
          listing={purchasingItem}
          isOpen={!!purchasingItem}
          onClose={() => setPurchasingItem(null)}
          onPaymentSuccess={() => {}}
        />
      )}

      {/* ========================================================================= */}
      {/* 5. MODAL PUBBLICAZIONE NUOVO ANNUNCIO                                    */}
      {/* ========================================================================= */}
      {isPublishModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-150">
          <div className="w-full max-w-xl bg-slate-900 border-2 border-amber-400/50 rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-150 flex flex-col max-h-[90vh]">
            
            <div className="p-6 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-400 flex items-center justify-center text-amber-300">
                  <Plus className="w-6 h-6 stroke-[3]" />
                </div>
                <div>
                  <h3 className="text-lg font-black text-white">Nuovo Annuncio nel Sole</h3>
                  <p className="text-xs text-slate-400">Condividi un talento o richiedi un aiuto nella comunità</p>
                </div>
              </div>
              <button
                onClick={() => setIsPublishModalOpen(false)}
                className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handlePublishSubmit} className="p-6 space-y-4 overflow-y-auto">
              
              <div className="space-y-1.5">
                <label className="text-xs font-black text-slate-300 uppercase tracking-wider">Interruttore d'Azione (Intento)</label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setNewIntent("VENDO")}
                    className={`py-3 px-2 rounded-2xl border-2 font-black text-xs transition-all flex flex-col items-center justify-center gap-1.5 ${
                      newIntent === "VENDO"
                        ? "bg-amber-500/20 border-amber-400 text-amber-300 shadow-lg shadow-amber-500/10"
                        : "bg-slate-950 border-slate-800 text-slate-400 hover:text-white"
                    }`}
                  >
                    <Coins className="w-4 h-4 text-amber-400" />
                    <span>VENDO (π)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setNewIntent("BARATTO_SCAMBIO")}
                    className={`py-3 px-2 rounded-2xl border-2 font-black text-xs transition-all flex flex-col items-center justify-center gap-1.5 ${
                      newIntent === "BARATTO_SCAMBIO"
                        ? "bg-emerald-500/20 border-emerald-400 text-emerald-300 shadow-lg shadow-emerald-500/10"
                        : "bg-slate-950 border-slate-800 text-slate-400 hover:text-white"
                    }`}
                  >
                    <ArrowUpDown className="w-4 h-4 text-emerald-400" />
                    <span>BARATTO</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setNewIntent("ACQUISTO_CERCO")}
                    className={`py-3 px-2 rounded-2xl border-2 font-black text-xs transition-all flex flex-col items-center justify-center gap-1.5 ${
                      newIntent === "ACQUISTO_CERCO"
                        ? "bg-purple-500/20 border-purple-400 text-purple-300 shadow-lg shadow-purple-500/10"
                        : "bg-slate-950 border-slate-800 text-slate-400 hover:text-white"
                    }`}
                  >
                    <Sparkles className="w-4 h-4 text-purple-400" />
                    <span>CERCO</span>
                  </button>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-black text-slate-300 uppercase tracking-wider">Titolo dell'Annuncio</label>
                <input
                  type="text"
                  required
                  placeholder="Es: Offro lezioni di programmazione Web / Cerco trapano..."
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-950 border border-slate-800 rounded-2xl text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-black text-slate-300 uppercase tracking-wider">Descrizione</label>
                <textarea
                  required
                  rows={3}
                  placeholder="Spiega i dettagli della tua disponibilità o necessità..."
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-950 border border-slate-800 rounded-2xl text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 resize-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-black text-slate-300 uppercase tracking-wider">Sfera Tematica</label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-950 border border-slate-800 rounded-2xl text-xs sm:text-sm text-white focus:outline-none focus:border-amber-400"
                >
                  <option value="Competenze & Servizi">🎓 Competenze & Servizi</option>
                  <option value="Strumenti & Attrezzi Casa">🛠️ Strumenti & Attrezzi</option>
                  <option value="Alimentazione & Natura">🌿 Natura & Alimentazione</option>
                  <option value="Lingue & Cultura">🌍 Lingue & Cultura</option>
                  <option value="Mobilità & Veicoli">🚲 Mobilità & Veicoli</option>
                  <option value="Arti & Creazioni">🎨 Arti & Creazioni</option>
                </select>
              </div>

              {newIntent === "VENDO" && (
                <div className="space-y-1.5 p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/30">
                  <div className="flex items-center justify-between text-xs font-bold text-amber-300">
                    <span>Importo Simbolico Pi (Max 15 π):</span>
                    <span className="font-mono text-base font-black">{newPiPrice} π</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="15"
                    step="0.5"
                    value={newPiPrice}
                    onChange={(e) => setNewPiPrice(e.target.value)}
                    className="w-full accent-amber-400 cursor-pointer"
                  />
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-black text-slate-300 uppercase tracking-wider">Città</label>
                  <input
                    type="text"
                    placeholder="Es: Torino Centro, Milano, Asti..."
                    value={newCity}
                    onChange={(e) => setNewCity(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-950 border border-slate-800 rounded-2xl text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-black text-slate-300 uppercase tracking-wider">Tag</label>
                  <input
                    type="text"
                    placeholder="Es: Coding, Bici, Fai-da-te"
                    value={newTags}
                    onChange={(e) => setNewTags(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-950 border border-slate-800 rounded-2xl text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-slate-800 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsPublishModalOpen(false)}
                  className="px-5 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs sm:text-sm font-bold transition-all"
                >
                  Annulla
                </button>
                <button
                  type="submit"
                  className="px-6 py-3 rounded-2xl bg-gradient-to-r from-amber-400 to-yellow-400 text-slate-950 text-xs sm:text-sm font-black transition-all shadow-lg shadow-amber-500/25 cursor-pointer"
                >
                  Pubblica Annuncio
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
};
