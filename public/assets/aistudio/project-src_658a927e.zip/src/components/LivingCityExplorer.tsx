import React, { useState, useMemo } from "react";
import {
  Sparkles,
  TreeDeciduous,
  Building2,
  Users,
  Archive,
  Bot,
  AlertTriangle,
  ArrowRight,
  X,
  MessageSquare,
  PlusCircle,
  Coins,
  ShieldCheck,
  HeartHandshake,
  TrendingUp,
  Leaf,
  CheckCircle2,
  Send,
  Eye,
  Wrench,
  GraduationCap,
  Store,
  BookOpen,
  Compass,
  Search,
  Bike,
  Apple,
  Hammer,
  HelpCircle,
  MapPin,
  Clock,
  Sparkle,
  Filter,
  Check,
  PhoneCall,
  UserCheck,
  Volume2,
  Layers,
  Map
} from "lucide-react";
import {
  HaveWantListing,
  InteractionIntent,
  SalvavatuttoGuide,
  CommunityChatMessage,
  PioneerUser,
  Citizen,
  MemoryArticle,
  CommerceShop,
  CityBuildingId,
  CityStage,
  TerritoryNucleus,
  AbuseReportPayload
} from "../types";
import {
  INITIAL_CITIZENS,
  INITIAL_SHOPS,
  INITIAL_MEMORY_ARTICLES,
  INITIAL_LISTINGS,
  INITIAL_NUCLEI
} from "../data";
import { ListingOriginBadge } from "@/components/have2want/ListingOriginBadge";
import { VisualVillageView } from "./VisualVillageView";
import { VillageBuildingView } from "./VillageBuildingView";
import { MicroWorldModal } from "./MicroWorldModal";
import { GeographicMapBridge } from "./GeographicMapBridge";
import { ExchangeProposalModal } from "./ExchangeProposalModal";
import { RegisterShopModal } from "./RegisterShopModal";
import { CommunityGrowthEngine } from "./CommunityGrowthEngine";

interface LivingCityExplorerProps {
  onNavigate: (tab: "planet-possibilita" | "planet-vita" | "planet-salvavatutto" | "ai-assistant" | "emergency") => void;
  listings: HaveWantListing[];
  guides: SalvavatuttoGuide[];
  messages: CommunityChatMessage[];
  currentUser: PioneerUser;
  onAddListing: (listing: HaveWantListing) => void;
  onSelectListingForTrade: (listing: HaveWantListing) => void;
  onReportAbuse?: (payload: AbuseReportPayload) => void;
}

type ModalDetail =
  | { type: "building"; buildingId: CityBuildingId }
  | { type: "citizen"; citizen: Citizen }
  | { type: "object"; listing: HaveWantListing }
  | { type: "shop"; shop: CommerceShop }
  | { type: "memory"; article: MemoryArticle }
  | { type: "create-object" }
  | { type: "post-piazza" }
  | null;

export const LivingCityExplorer: React.FC<LivingCityExplorerProps> = ({
  onNavigate,
  listings,
  guides,
  messages,
  currentUser,
  onAddListing,
  onSelectListingForTrade,
  onReportAbuse,
}) => {
  // City Growth Stage (Starts as Paesino as requested for Fase 1 Prototype)
  const [cityStage, setCityStage] = useState<CityStage>("paesino");
  
  // Active Detail Modal
  const [activeModal, setActiveModal] = useState<ModalDetail>(null);

  // New Dedicated Modals for Territorials and Micro-Worlds
  const [showGeoMap, setShowGeoMap] = useState<boolean>(false);
  const [activeMicroWorldBuilding, setActiveMicroWorldBuilding] = useState<CityBuildingId | null>(null);
  const [activeTradeListing, setActiveTradeListing] = useState<HaveWantListing | null>(null);
  const [villageViewMode, setVillageViewMode] = useState<"panoramic" | "grid">("panoramic");

  // Filter for building category in exploratory views
  const [selectedBuildingFilter, setSelectedBuildingFilter] = useState<CityBuildingId | "all">("all");

  // AI City Connector Search & Diagnostics
  const [aiSearchQuery, setAiSearchQuery] = useState("");
  const [aiConnectionResult, setAiConnectionResult] = useState<{
    query: string;
    summary: string;
    targetBuilding: CityBuildingId;
    expertCitizen: Citizen;
    relevantListing?: HaveWantListing;
    relevantGuide?: SalvavatuttoGuide;
    relevantMemory?: MemoryArticle;
  } | null>(null);

  // Quick Piazza Post State
  const [piazzaText, setPiazzaText] = useState("");
  const [piazzaFeedback, setPiazzaFeedback] = useState<string | null>(null);

  // New Object Creation Form State
  const [newObjTitle, setNewObjTitle] = useState("");
  const [newObjIntent, setNewObjIntent] = useState<InteractionIntent>("BARATTO_SCAMBIO");
  const [newObjCategory, setNewObjCategory] = useState("Mobilità & Veicoli");
  const [newObjDesc, setNewObjDesc] = useState("");
  const [newObjPiPrice, setNewObjPiPrice] = useState(0);

  // Real Citizens and Shops in the City (Live State)
  const [citizens, setCitizens] = useState<Citizen[]>(INITIAL_CITIZENS);
  const [shops, setShops] = useState<CommerceShop[]>(INITIAL_SHOPS);
  const [nuclei, setNuclei] = useState<TerritoryNucleus[]>(INITIAL_NUCLEI);
  const [showRegisterShopModal, setShowRegisterShopModal] = useState<boolean>(false);
  const [memoryArticles] = useState<MemoryArticle[]>(INITIAL_MEMORY_ARTICLES);

  const handleRegisterShop = (newShop: CommerceShop) => {
    setShops((prev) => [newShop, ...prev]);
    // Also update nuclei progress
    setNuclei((prev) =>
      prev.map((nuc) =>
        nuc.id === "nuc-1"
          ? {
              ...nuc,
              shopsCount: nuc.shopsCount + 1,
              criticalMassPercentage: Math.min(100, nuc.criticalMassPercentage + 4),
            }
          : nuc
      )
    );
  };

  // City Stage Configurations & Visual Parameters
  const stageConfigs: Record<CityStage, {
    label: string;
    inhabitants: number;
    densityBadge: string;
    buildingsLevel: string;
    visualScale: string;
    atmosphereColor: string;
    skyGradient: string;
    description: string;
  }> = {
    paesino: {
      label: "1. Piccolo Paese Rurale",
      inhabitants: 18,
      densityBadge: "Comunità delle Origini",
      buildingsLevel: "Bottega Unica, Pozzo & Orto Familiare",
      visualScale: "scale-95",
      atmosphereColor: "from-amber-950/40 via-emerald-950/30 to-slate-950",
      skyGradient: "from-amber-400/10 via-emerald-500/10 to-transparent",
      description: "Pochi edifici essenziali e volti familiari. Tutti si conoscono, la bottega è polifunzionale e gli scambi avvengono per stretta di mano.",
    },
    borgo: {
      label: "2. Borgo Vivente & Artigiano",
      inhabitants: 75,
      densityBadge: "Sviluppo Autentico",
      buildingsLevel: "Piazza Centrale, Scuola, Ciclofficina & Casa della Memoria",
      visualScale: "scale-100",
      atmosphereColor: "from-emerald-950/50 via-slate-900 to-slate-950",
      skyGradient: "from-emerald-400/15 via-teal-500/10 to-transparent",
      description: "Le botteghe si specializzano, la scuola accoglie i primi corsi di mestiere e gli orti si collegano in una rete comunitaria viva.",
    },
    citta: {
      label: "3. Città del Valore Umano",
      inhabitants: 380,
      densityBadge: "Ecosistema Circolare Completo",
      buildingsLevel: "Bazar Espanso, Polo Tecnico, Biblioteca & Serra Pubblica",
      visualScale: "scale-105",
      atmosphereColor: "from-sky-950/50 via-slate-900 to-slate-950",
      skyGradient: "from-sky-400/15 via-emerald-500/10 to-transparent",
      description: "Una comunità vivace con decine di scambi quotidiani, servizi di quartiere, professionisti disponibili e memoria tramandata.",
    },
    grande_citta: {
      label: "4. Grande Città delle Relazioni",
      inhabitants: 1250,
      densityBadge: "Rete Distrettuale Avanzata",
      buildingsLevel: "Distretti Commerciali, Centri di Ricerca & Piazze Tematiche",
      visualScale: "scale-110",
      atmosphereColor: "from-teal-950/60 via-slate-900 to-slate-950",
      skyGradient: "from-amber-300/15 via-sky-500/10 to-transparent",
      description: "Quartieri interconnessi senza perdere la dimensione umana: ogni strada conserva botteghe indipendenti e mutuo soccorso.",
    },
    metropoli: {
      label: "5. Metropoli Sinergica Globale",
      inhabitants: 4800,
      densityBadge: "Armonia Totale di Comunità",
      buildingsLevel: "Campus Universale, Agroforeste Urbane & Borsa del Valore Reale",
      visualScale: "scale-115",
      atmosphereColor: "from-indigo-950/60 via-emerald-950/40 to-slate-950",
      skyGradient: "from-purple-400/15 via-emerald-400/10 to-transparent",
      description: "Migliaia di cittadini cooperano in tempo reale. Nessun intermediario speculativo: la città produce, rigenera e condivide.",
    },
  };

  const currentStage = stageConfigs[cityStage];

  // The 7 Core Places / Buildings in the Living City
  const cityBuildings: {
    id: CityBuildingId;
    name: string;
    category: string;
    icon: any;
    accentColor: string;
    bgGlow: string;
    borderColor: string;
    citizensInside: Citizen[];
    objectsInside: HaveWantListing[];
    shortDesc: string;
    fullDescription: string;
  }[] = [
    {
      id: "piazza",
      name: "La Piazza Comunale",
      category: "Dialogo & Incontro",
      icon: MessageSquare,
      accentColor: "text-amber-400",
      bgGlow: "rgba(245, 158, 11, 0.25)",
      borderColor: "border-amber-400/70",
      citizensInside: citizens.filter((c) => c.locationInCity === "piazza"),
      objectsInside: listings.filter((l) => l.tags.includes("Relazioni") || l.category.includes("Lingue") || l.type === "WANT"),
      shortDesc: "Il cuore parlante della comunità: persone reali discutono, chiedono consigli e si incontrano.",
      fullDescription: "Nella Piazza le persone della community si confrontano dal vivo. Ogni fumetto corrisponde a un pensiero o proposta reale. Qui si stringono accordi e nascono collaborazioni sincere.",
    },
    {
      id: "giardino",
      name: "Il Giardino & Orto Civico",
      category: "Terra, Piante & Natura",
      icon: Leaf,
      accentColor: "text-emerald-400",
      bgGlow: "rgba(16, 185, 129, 0.25)",
      borderColor: "border-emerald-400/70",
      citizensInside: citizens.filter((c) => c.locationInCity === "giardino"),
      objectsInside: listings.filter((l) => l.category.includes("Alimentazione") || l.tags.includes("Bio") || l.title.toLowerCase().includes("mela") || l.title.toLowerCase().includes("frutta")),
      shortDesc: "Alberi da frutto, ortaggi biologici, semi antichi, attrezzi e consigli di coltivatori esperti.",
      fullDescription: "Non una semplice categoria, ma un ecosistema verde esplorabile: puoi toccare gli alberi da frutto, ritirare cassette di raccolto donate, scambiare talee e chiedere consulti botanici.",
    },
    {
      id: "scuola",
      name: "La Scuola dei Saperi",
      category: "Educazione & Mentoring",
      icon: GraduationCap,
      accentColor: "text-sky-400",
      bgGlow: "rgba(56, 189, 248, 0.25)",
      borderColor: "border-sky-400/70",
      citizensInside: citizens.filter((c) => c.locationInCity === "scuola"),
      objectsInside: listings.filter((l) => l.category.includes("Conoscenza") || l.category.includes("Lingue") || l.tags.includes("Coding")),
      shortDesc: "Insegnanti, studenti, lezioni pratiche, libri condivisi e mentoring tra pari.",
      fullDescription: "La scuola aperta dove chi sa insegna e chi vuole impara: lezioni di programmazione, conversazioni in lingua, ripetizioni e scambi di competenze senza barriere economiche.",
    },
    {
      id: "officina",
      name: "L'Officina dei Mestieri & Cicli",
      category: "Riparazioni & Meccanica",
      icon: Wrench,
      accentColor: "text-amber-300",
      bgGlow: "rgba(252, 211, 77, 0.25)",
      borderColor: "border-amber-300/70",
      citizensInside: citizens.filter((c) => c.locationInCity === "officina"),
      objectsInside: listings.filter((l) => l.category.includes("Mobilità") || l.category.includes("Strumenti") || l.title.toLowerCase().includes("trapano") || l.title.toLowerCase().includes("bici")),
      shortDesc: "Meccanici, falegnami, ricambi rigenerati, trapani in prestito e guide pratiche no-spreco.",
      fullDescription: "Il tempio dell'autoriparazione: banco di lavoro con attrezzi condivisi, ciclofficina popolare e maestri artigiani pronti ad aiutarti a rimettere in funzione qualsiasi oggetto.",
    },
    {
      id: "memoria",
      name: "La Casa della Memoria",
      category: "Tradizioni & Enciclopedia",
      icon: BookOpen,
      accentColor: "text-rose-400",
      bgGlow: "rgba(251, 113, 133, 0.25)",
      borderColor: "border-rose-400/70",
      citizensInside: citizens.filter((c) => c.locationInCity === "memoria"),
      objectsInside: [],
      shortDesc: "Enciclopedia viva: antichi mestieri, fermentazioni, ricette secolari e testimonianze orali.",
      fullDescription: "La memoria della civiltà umana: raccoglie e tramanda i saperi pratici dei nonni, tecniche di costruzione senza chiodi, conservazione del cibo e usi comunitari prima che vadano perduti.",
    },
    {
      id: "commercio",
      name: "Il Bazar & Botteghe Locali",
      category: "Commercio Etico & Usato",
      icon: Store,
      accentColor: "text-purple-400",
      bgGlow: "rgba(192, 132, 252, 0.25)",
      borderColor: "border-purple-400/70",
      citizensInside: citizens.filter((c) => c.locationInCity === "commercio"),
      objectsInside: listings.filter((l) => l.mode === "vendita_pi" || l.mode === "baratto"),
      shortDesc: "Botteghe artigiane, bazar dell'usato garantito, vendita in Pi, baratto e doni liberi.",
      fullDescription: "Il commercio a misura d'uomo: cresce da piccolo negozio di paese a bazar e quartiere commerciale. Spazi reali per produttori etici, noleggio e circolarità autentica.",
    },
    {
      id: "albero",
      name: "L'Albero Millenario della Vita",
      category: "Cuore & Struttura Ecosistema",
      icon: TreeDeciduous,
      accentColor: "text-emerald-300",
      bgGlow: "rgba(52, 211, 153, 0.3)",
      borderColor: "border-emerald-300/80",
      citizensInside: citizens,
      objectsInside: listings,
      shortDesc: "La pianta maestosa che unisce cielo e terra: foglie come annunci, tronco come comunità.",
      fullDescription: "Simbolo vivente della crescita comunitaria: le radici affondano nella fiducia tra persone, il tronco cresce col numero di membri e ogni foglia rappresenta un'opportunità di scambio.",
    },
  ];

  // Live Objects scattered in the City (Direct Real Listings visually placed on streets/buildings)
  const visibleObjectsInCity = useMemo(() => {
    return listings.map((l, index) => {
      // Coordinate e icone visive per il paesaggio
      let icon = Sparkles;
      let placeHint = "Piazza Centrale";
      let colorClass = "bg-amber-400 text-slate-950";
      
      const titleLower = l.title.toLowerCase();
      if (titleLower.includes("bici") || titleLower.includes("bicicletta")) {
        icon = Bike;
        placeHint = "Davanti alla Ciclofficina";
        colorClass = "bg-sky-400 text-slate-950";
      } else if (titleLower.includes("trapano") || titleLower.includes("attrezz")) {
        icon = Hammer;
        placeHint = "Banco Lavoro Officina";
        colorClass = "bg-amber-300 text-slate-950";
      } else if (titleLower.includes("mela") || titleLower.includes("pera") || titleLower.includes("frutt") || titleLower.includes("cibo")) {
        icon = Apple;
        placeHint = "Ingresso del Giardino";
        colorClass = "bg-emerald-400 text-slate-950";
      } else if (titleLower.includes("programm") || titleLower.includes("corso") || titleLower.includes("inglese")) {
        icon = BookOpen;
        placeHint = "Tavoli della Scuola";
        colorClass = "bg-indigo-400 text-slate-950";
      }

      return {
        ...l,
        displayIcon: icon,
        placeHint,
        colorClass,
        // Visual relative position offsets based on index
        xPercent: 12 + ((index * 22) % 76),
        yPercent: 28 + ((index * 17) % 48),
      };
    });
  }, [listings]);

  // AI Omni-Connector Handler
  const handleRunAiConnection = (queryText?: string) => {
    const query = queryText || aiSearchQuery;
    if (!query.trim()) return;

    const qLower = query.toLowerCase();

    // Default connection fallback
    let targetBuilding: CityBuildingId = "giardino";
    let expert = citizens[0]; // Giuseppe Verdi
    let summary = `Ho collegato la tua richiesta all'orticoltore Giuseppe Verdi e al Giardino Civico.`;
    let relevantGuide = guides[0];
    let relevantListing = listings.find((l) => l.category.includes("Alimentazione"));
    let relevantMemory = memoryArticles[1];

    if (qLower.includes("alber") || qLower.includes("fogli") || qLower.includes("piant") || qLower.includes("orto") || qLower.includes("terra")) {
      targetBuilding = "giardino";
      expert = citizens.find((c) => c.roleCategory === "agricoltura") || citizens[0];
      summary = `L'AI della Città ha individuato il problema fitosanitario nel Giardino: ${expert.name} (${expert.role}) è attualmente 🟢 DISPONIBILE nel Giardino per consigli. Inoltre trovi cassette di frutta e guide alla potatura biologica.`;
      relevantGuide = guides.find((g) => g.category.includes("Alimentazione")) || guides[0];
      relevantListing = listings.find((l) => l.title.toLowerCase().includes("mela"));
      relevantMemory = memoryArticles[1];
    } else if (qLower.includes("bici") || qLower.includes("gomm") || qLower.includes("fren") || qLower.includes("meccanic") || qLower.includes("trapano") || qLower.includes("legno")) {
      targetBuilding = "officina";
      expert = qLower.includes("legno")
        ? (citizens.find((c) => c.roleCategory === "artigianato") || citizens[1])
        : (citizens.find((c) => c.roleCategory === "meccanica") || citizens[3]);
      summary = `Richiesta indirizzata all'Officina dei Mestieri: ${expert.name} (${expert.role}) ha a disposizione attrezzi, ricambi rigenerati e guide di autoriparazione passo-passo.`;
      relevantGuide = guides.find((g) => g.category.includes("Riparazione")) || guides[1];
      relevantListing = listings.find((l) => l.title.toLowerCase().includes("trapano") || l.title.toLowerCase().includes("bici"));
      relevantMemory = memoryArticles[0];
    } else if (qLower.includes("inglese") || qLower.includes("scuola") || qLower.includes("corso") || qLower.includes("programma") || qLower.includes("impar")) {
      targetBuilding = "scuola";
      expert = qLower.includes("inglese")
        ? (citizens.find((c) => c.roleCategory === "insegnamento") || citizens[2])
        : (citizens.find((c) => c.roleCategory === "digitale") || citizens[5]);
      summary = `Connessione con la Scuola dei Saperi: ${expert.name} (${expert.role}) è in aula aperta e offre sessioni formative e scambi culturali.`;
      relevantListing = listings.find((l) => l.category.includes("Conoscenza") || l.category.includes("Lingue"));
    } else if (qLower.includes("memoria") || qLower.includes("pane") || qLower.includes("lievito") || qLower.includes("antich") || qLower.includes("tradizion")) {
      targetBuilding = "memoria";
      expert = citizens.find((c) => c.roleCategory === "arte") || citizens[6]; // Nonna Rosa
      summary = `Consultazione della Casa della Memoria: ${expert.name} custodisce le ricette antiche del lievito madre e i segreti della lavorazione tradizionale.`;
      relevantMemory = memoryArticles[1];
    } else if (qLower.includes("compra") || qLower.includes("vendi") || qLower.includes("negozio") || qLower.includes("bazar") || qLower.includes("prezzo")) {
      targetBuilding = "commercio";
      expert = citizens.find((c) => c.roleCategory === "commercio") || citizens[7];
      summary = `Aperta la connessione con il Bazar Circolare: ${expert.name} ha catalogato oggetti testati, prodotti biologici ed empori locali che accettano Pi Network e baratto.`;
      relevantListing = listings.find((l) => l.mode === "vendita_pi");
    } else {
      targetBuilding = "piazza";
      expert = citizens.find((c) => c.roleCategory === "sanita") || citizens[4];
      summary = `Connessione generale nella Piazza Comunale con ${expert.name} (${expert.role}) per approfondire e condividere con la community.`;
      relevantListing = listings[0];
    }

    setAiConnectionResult({
      query,
      summary,
      targetBuilding,
      expertCitizen: expert,
      relevantListing,
      relevantGuide,
      relevantMemory,
    });
  };

  // Create new object visually in the city
  const handleCreateCityObject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newObjTitle.trim() || !newObjDesc.trim()) return;

    const newListing: HaveWantListing = {
      id: `obj-${Date.now()}`,
      intent: newObjIntent,
      title: newObjTitle,
      description: newObjDesc,
      category: "casa_fai_da_te",
      subcategory: "attrezzi_lavoro_utensili",
      piPrice: newObjIntent === "VENDO" ? Number(newObjPiPrice) : 0,
      author: {
        name: currentUser.name,
        username: currentUser.username,
        avatar: currentUser.avatar,
        reputation: currentUser.reputation,
        isPioneerVerified: currentUser.verifiedKYC,
        city: currentUser.city,
      },
      lat: 44.9008 + (Math.random() - 0.5) * 0.01,
      lng: 8.2065 + (Math.random() - 0.5) * 0.01,
      locationArea: "Asti (Area Comunitaria)",
      isFuzzyLocation: true,
      createdAt: "Pochi istanti fa nella Città",
      tags: [newObjCategory, newObjIntent, "Città Viva"],
      status: "active",
      planetId: "planet-possibilita",
      satelliteId: "sat-oggetti",
    };

    onAddListing(newListing);
    setActiveModal({ type: "object", listing: newListing });
    setNewObjTitle("");
    setNewObjDesc("");
  };

  // Post new conversation to Piazza
  const handlePostToPiazza = (e: React.FormEvent) => {
    e.preventDefault();
    if (!piazzaText.trim()) return;

    const newCitizenWithQuote: Citizen = {
      ...citizens[0],
      recentQuote: piazzaText,
    };
    setCitizens([newCitizenWithQuote, ...citizens.slice(1)]);
    setPiazzaFeedback("Il tuo messaggio risuona ora nella Piazza della Città Viva!");
    setPiazzaText("");
    setTimeout(() => setPiazzaFeedback(null), 3500);
    setActiveModal(null);
  };

  return (
    <div className="space-y-6 select-none font-sans">
      
      {/* ========================================================================= */}
      {/* 1. ORCHESTRATORE GEOSPAZIALE 3D — GOOGLE PHOTOREALISTIC 3D TILES */}
      {/* ========================================================================= */}
      <div className="w-full">
        {activeMicroWorldBuilding ? (
          <VillageBuildingView
            buildingId={activeMicroWorldBuilding}
            citizens={citizens}
            listings={listings}
            shops={shops}
            guides={guides}
            memories={memoryArticles}
            currentUser={currentUser}
            onBackToVillage={() => setActiveMicroWorldBuilding(null)}
            onSelectCitizen={(citizen) => setActiveModal({ type: "citizen", citizen })}
            onSelectListing={(listing) => setActiveTradeListing(listing)}
            onProposeTrade={(listing) => setActiveTradeListing(listing)}
            onOpenCreateListing={() => setActiveModal({ type: "create-object" })}
          />
        ) : (
          <div className="w-full rounded-3xl overflow-hidden border border-sky-500/40 bg-slate-950 shadow-2xl relative">
            <GeographicMapBridge
              shops={shops}
              listings={listings}
              citizens={citizens}
              currentUser={currentUser}
              onSelectShop={(s) => setActiveModal({ type: "shop", shop: s })}
              onSelectListing={(l) => setActiveTradeListing(l)}
              onRegisterNewShop={() => setShowRegisterShopModal(true)}
              onAddListing={onAddListing}
              onReportAbuse={onReportAbuse}
            />
          </div>
        )}
      </div>

        {/* ========================================================================= */}
        {/* 3. L'AI CONNETTORE TOTALE DELLA CITTÀ ("LA GUIDA DELLA CITTÀ") */}
        {/* ========================================================================= */}
        <div className="p-6 sm:p-8 bg-gradient-to-b from-[#020408] to-slate-950 border-t border-slate-800 space-y-5">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-400 via-teal-400 to-emerald-400 flex items-center justify-center text-slate-950 font-black shadow-[0_0_30px_rgba(6,182,212,0.4)] shrink-0">
                <Bot className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-black uppercase tracking-widest text-cyan-400 font-mono">
                    L'Intelligenza Connettiva
                  </span>
                  <span className="text-[9px] px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/40">
                    Collega Persone + Oggetti + Saperi + Luoghi
                  </span>
                </div>
                <h3 className="text-lg sm:text-xl font-black text-white">
                  Chiedi alla Guida della Città
                </h3>
              </div>
            </div>

            <p className="text-xs text-slate-400 max-w-md">
              L'AI non sostituisce la comunità: collega il tuo bisogno al luogo giusto, alle persone disponibili e ai manuali della memoria.
            </p>
          </div>

          {/* Prompt Chips Rapidi */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-[10px] font-bold uppercase text-slate-500">Prova subito:</span>
            {[
              "Il mio albero ha le foglie gialle",
              "Ho bucato la gomma della bicicletta",
              "Chi mi insegna la conversazione in inglese?",
              "Come si fa il pane con lievito madre?",
              "Cerco un trapano a percussione in prestito",
            ].map((chip) => (
              <button
                key={chip}
                onClick={() => {
                  setAiSearchQuery(chip);
                  handleRunAiConnection(chip);
                }}
                className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white text-xs border border-slate-800 transition-all cursor-pointer font-medium"
              >
                "{chip}"
              </button>
            ))}
          </div>

          {/* Barra di Ricerca Connettiva */}
          <div className="flex items-center gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Descrivi cosa cerchi, un problema o cosa vorresti fare nella Città..."
                value={aiSearchQuery}
                onChange={(e) => setAiSearchQuery(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleRunAiConnection()}
                className="w-full pl-11 pr-4 py-3 rounded-2xl bg-slate-900 border border-slate-800 text-white text-sm focus:outline-none focus:border-cyan-400 placeholder:text-slate-500"
              />
            </div>
            <button
              onClick={() => handleRunAiConnection()}
              className="px-6 py-3 rounded-2xl bg-gradient-to-r from-cyan-400 to-teal-300 text-slate-950 font-black text-sm flex items-center gap-2 shadow-lg hover:scale-105 transition-transform cursor-pointer shrink-0"
            >
              <Compass className="w-4 h-4" />
              <span>Collega nella Città</span>
            </button>
          </div>

          {/* RISULTATO INTELLIGENTE DEL COLLEGAMENTO */}
          {aiConnectionResult && (
            <div className="p-6 rounded-3xl bg-slate-900/90 border-2 border-cyan-400/80 shadow-2xl space-y-5 animate-in fade-in duration-300">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-cyan-400" />
                  <span className="text-xs font-black uppercase tracking-wider text-cyan-300 font-mono">
                    Connessione Completata per: "{aiConnectionResult.query}"
                  </span>
                </div>
                <button
                  onClick={() => setAiConnectionResult(null)}
                  className="text-slate-400 hover:text-white p-1"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <p className="text-sm sm:text-base text-slate-100 font-medium leading-relaxed">
                {aiConnectionResult.summary}
              </p>

              {/* Schede Connesse (Luogo + Persona + Oggetto + Guida) */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
                
                {/* 1. Persona Esperta Connessa */}
                <div
                  onClick={() => setActiveModal({ type: "citizen", citizen: aiConnectionResult.expertCitizen })}
                  className="p-4 rounded-2xl bg-slate-950 border border-emerald-500/50 hover:scale-[1.02] transition-transform cursor-pointer space-y-2"
                >
                  <span className="text-[10px] font-black uppercase text-emerald-400 font-mono block">
                    Persona Esperta Connessa
                  </span>
                  <div className="flex items-center gap-2.5">
                    <img
                      src={aiConnectionResult.expertCitizen.avatar}
                      alt={aiConnectionResult.expertCitizen.name}
                      className="w-10 h-10 rounded-full object-cover border border-emerald-400"
                    />
                    <div>
                      <h4 className="text-xs font-black text-white leading-tight">
                        {aiConnectionResult.expertCitizen.name}
                      </h4>
                      <span className="text-[10px] text-emerald-300 block">
                        {aiConnectionResult.expertCitizen.role}
                      </span>
                    </div>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold inline-block">
                    🟢 Disponibile ora
                  </span>
                </div>

                {/* 2. Luogo Fisico nella Città */}
                <div
                  onClick={() => setActiveModal({ type: "building", buildingId: aiConnectionResult.targetBuilding })}
                  className="p-4 rounded-2xl bg-slate-950 border border-sky-500/50 hover:scale-[1.02] transition-transform cursor-pointer space-y-2"
                >
                  <span className="text-[10px] font-black uppercase text-sky-400 font-mono block">
                    Luogo della Città
                  </span>
                  <h4 className="text-xs font-black text-white">
                    {cityBuildings.find((b) => b.id === aiConnectionResult.targetBuilding)?.name}
                  </h4>
                  <p className="text-[11px] text-slate-300 line-clamp-2">
                    {cityBuildings.find((b) => b.id === aiConnectionResult.targetBuilding)?.shortDesc}
                  </p>
                  <span className="text-[10px] text-sky-300 font-bold block">
                    Tocca per entrare nell'ambiente →
                  </span>
                </div>

                {/* 3. Oggetto / Sapere Collegato */}
                {aiConnectionResult.relevantListing ? (
                  <div
                    onClick={() => setActiveModal({ type: "object", listing: aiConnectionResult.relevantListing! })}
                    className="p-4 rounded-2xl bg-slate-950 border border-amber-500/50 hover:scale-[1.02] transition-transform cursor-pointer space-y-2"
                  >
                    <span className="text-[10px] font-black uppercase text-amber-400 font-mono block">
                      Oggetto / Annuncio Attivo
                    </span>
                    <h4 className="text-xs font-black text-white line-clamp-1">
                      {aiConnectionResult.relevantListing.title}
                    </h4>
                    <span className="text-[10px] text-amber-300 font-mono block uppercase">
                      Modalità: {aiConnectionResult.relevantListing.mode}
                    </span>
                    <span className="text-[10px] text-amber-300 font-bold block">
                      Tocca per iniziare lo scambio →
                    </span>
                  </div>
                ) : aiConnectionResult.relevantMemory ? (
                  <div
                    onClick={() => setActiveModal({ type: "memory", article: aiConnectionResult.relevantMemory! })}
                    className="p-4 rounded-2xl bg-slate-950 border border-rose-500/50 hover:scale-[1.02] transition-transform cursor-pointer space-y-2"
                  >
                    <span className="text-[10px] font-black uppercase text-rose-400 font-mono block">
                      Enciclopedia della Memoria
                    </span>
                    <h4 className="text-xs font-black text-white line-clamp-1">
                      {aiConnectionResult.relevantMemory.title}
                    </h4>
                    <span className="text-[10px] text-rose-300 font-bold block">
                      Leggi la testimonianza completa →
                    </span>
                  </div>
                ) : null}

              </div>
            </div>
          )}
        </div>

      {/* ========================================================================= */}
      {/* MOTORE DI CRESCITA ORGANICA DELLA COMUNITÀ: DA PAESE PRIMO AL MONDO */}
      {/* ========================================================================= */}
      <CommunityGrowthEngine
        nuclei={nuclei}
        totalCitizens={citizens.length}
        totalMessages={messages.length}
        totalListings={listings.length}
        totalShops={shops.length}
        onOpenGeographicMap={() => setShowGeoMap(true)}
        onOpenRegisterShop={() => setShowRegisterShopModal(true)}
      />

      {/* ========================================================================= */}
      {/* 4. MODALI INTERATTIVE DEI LUOGHI, PERSONE, OGGETTI & BOTTEGHE */}
      {/* ========================================================================= */}

      {/* MODALE 1: EDIFICIO / LUOGO VIVO APERTO */}
      {activeModal?.type === "building" && (() => {
        const building = cityBuildings.find((b) => b.id === activeModal.buildingId)!;
        const Icon = building.icon;
        return (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
            <div className="w-full max-w-2xl rounded-3xl bg-slate-900 border-2 border-emerald-500/80 shadow-2xl p-6 sm:p-8 space-y-6 relative max-h-[90vh] overflow-y-auto">
              <button
                onClick={() => setActiveModal(null)}
                className="absolute top-5 right-5 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="flex items-center gap-3.5">
                <div className={`w-14 h-14 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-center ${building.accentColor} shadow-lg shrink-0`}>
                  <Icon className="w-7 h-7" />
                </div>
                <div>
                  <span className="text-[10px] font-black uppercase tracking-wider text-emerald-400 font-mono block">
                    Ambiente Vivente • {building.category}
                  </span>
                  <h3 className="text-xl sm:text-2xl font-black text-white">
                    {building.name}
                  </h3>
                </div>
              </div>

              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed bg-slate-950/70 p-4 rounded-2xl border border-slate-800 font-medium">
                {building.fullDescription}
              </p>

              {/* SEZIONE 1: PERSONE ATTIVE NEL LUOGO */}
              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs font-bold text-slate-300">
                  <span className="flex items-center gap-1.5 text-emerald-400">
                    <Users className="w-4 h-4" /> Persone Presenti sul Posto ({building.citizensInside.length})
                  </span>
                  <span className="text-[10px] text-slate-500">Tocca per parlare</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {building.citizensInside.map((cit) => (
                    <div
                      key={cit.id}
                      onClick={() => setActiveModal({ type: "citizen", citizen: cit })}
                      className="p-3 rounded-2xl bg-slate-950 border border-slate-800 hover:border-emerald-400 transition-all cursor-pointer flex items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-2.5">
                        <div className="relative">
                          <img
                            src={cit.avatar}
                            alt={cit.name}
                            className="w-9 h-9 rounded-full object-cover"
                          />
                          <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-400 border-2 border-slate-950 animate-pulse" />
                        </div>
                        <div>
                          <h4 className="text-xs font-black text-white leading-tight">{cit.name}</h4>
                          <span className="text-[10px] text-slate-400 block">{cit.role}</span>
                        </div>
                      </div>
                      <span className="text-[10px] text-emerald-400 font-mono">🟢 Libero</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* SEZIONE 2: OGGETTI & RISORSE DISPONIBILI SUL POSTO */}
              {building.objectsInside.length > 0 && (
                <div className="space-y-3">
                  <span className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-amber-400" /> Risorse & Oggetti nel Luogo ({building.objectsInside.length})
                  </span>
                  <div className="space-y-2">
                    {building.objectsInside.map((obj) => (
                      <div
                        key={obj.id}
                        onClick={() => setActiveModal({ type: "object", listing: obj })}
                        className="p-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-amber-400 transition-all cursor-pointer flex items-center justify-between gap-3"
                      >
                        <div>
                          <span className="text-[9px] font-black uppercase text-amber-400 font-mono block">
                            {obj.intent} {obj.piPrice > 0 ? `• ${obj.piPrice} π` : ""}
                          </span>
                          <span className="text-xs font-bold text-white block">{obj.title}</span>
                        </div>
                        <span className="text-xs font-black text-amber-400">Dettagli →</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* AZIONI DIRETTE */}
              <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
                <button
                  onClick={() => {
                    if (building.id === "giardino" || building.id === "albero") onNavigate("planet-possibilita");
                    else if (building.id === "scuola" || building.id === "officina" || building.id === "memoria") onNavigate("planet-salvavatutto");
                    else onNavigate("planet-vita");
                    setActiveModal(null);
                  }}
                  className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-400 to-teal-300 text-slate-950 font-black text-sm flex items-center justify-center gap-2 shadow-xl hover:scale-[1.02] transition-transform cursor-pointer"
                >
                  <span>Esplora Tutte le Funzioni di Questo Luogo</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* MODALE 2: PROFILO PERSONA REALE (CITIZEN CARD) */}
      {activeModal?.type === "citizen" && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-md rounded-3xl bg-slate-900 border-2 border-emerald-400/80 shadow-2xl p-6 sm:p-7 space-y-5 relative">
            <button
              onClick={() => setActiveModal(null)}
              className="absolute top-5 right-5 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-4">
              <div className="relative">
                <img
                  src={activeModal.citizen.avatar}
                  alt={activeModal.citizen.name}
                  className="w-16 h-16 rounded-3xl object-cover border-2 border-emerald-400 shadow-lg"
                />
                <span className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-emerald-400 border-2 border-slate-950 animate-pulse" />
              </div>
              <div>
                <span className="text-[10px] font-black uppercase tracking-wider text-emerald-400 font-mono block">
                  🟢 {activeModal.citizen.availability.toUpperCase()}
                </span>
                <h3 className="text-lg font-black text-white leading-tight">
                  {activeModal.citizen.name}
                </h3>
                <span className="text-xs text-slate-300 block font-medium">
                  {activeModal.citizen.role}
                </span>
                <span className="text-[11px] text-slate-500 block">
                  {activeModal.citizen.city} • ⭐ {activeModal.citizen.reputation} / 5.0
                </span>
              </div>
            </div>

            {/* Attività Attuale nella Città */}
            <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-1">
              <span className="text-[10px] font-bold uppercase text-slate-500 block font-mono">
                Attività Attuale nella Città
              </span>
              <p className="text-xs text-slate-200 font-medium">
                {activeModal.citizen.currentActivity}
              </p>
            </div>

            {/* Competenze Condivise */}
            <div className="space-y-1.5">
              <span className="text-[10px] font-bold uppercase text-slate-400 font-mono">
                Competenze & Disponibilità
              </span>
              <div className="flex flex-wrap gap-1.5">
                {activeModal.citizen.skills.map((skill) => (
                  <span
                    key={skill}
                    className="text-[10px] px-2.5 py-1 rounded-lg bg-emerald-500/10 text-emerald-300 font-bold border border-emerald-500/20"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>

            {/* Citazione o Pensiero Recente */}
            {activeModal.citizen.recentQuote && (
              <div className="p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/30 text-xs text-emerald-200 italic">
                "{activeModal.citizen.recentQuote}"
              </div>
            )}

            <div className="pt-2 flex items-center gap-3">
              <button
                onClick={() => {
                  onNavigate("planet-vita");
                  setActiveModal(null);
                }}
                className="flex-1 py-3.5 rounded-2xl bg-gradient-to-r from-emerald-400 to-teal-300 text-slate-950 font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg hover:scale-105 transition-transform cursor-pointer"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Apri Chat Diretta</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODALE 3: OGGETTO REALE SULLA MAPPA (LISTING DETAIL) */}
      {activeModal?.type === "object" && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-lg rounded-3xl bg-slate-900 border-2 border-amber-400/80 shadow-2xl p-6 sm:p-7 space-y-5 relative">
            <button
              onClick={() => setActiveModal(null)}
              className="absolute top-5 right-5 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-2xl bg-amber-400 flex items-center justify-center text-slate-950 font-black shadow-lg shrink-0">
                <Sparkles className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2 mb-1 flex-wrap">
                  <span className="text-[10px] font-black uppercase tracking-wider text-amber-400 font-mono">
                    Oggetto Reale nella Città • {activeModal.listing.intent}
                  </span>
                  <ListingOriginBadge listing={activeModal.listing} size="xs" />
                </div>
                <h3 className="text-lg sm:text-xl font-black text-white">
                  {activeModal.listing.title}
                </h3>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed bg-slate-950/70 p-4 rounded-2xl border border-slate-800 font-medium">
              {activeModal.listing.description}
            </p>

            <div className="flex items-center justify-between text-xs font-bold text-slate-400 pt-2 border-t border-slate-800">
              <div className="flex items-center gap-2.5">
                <img
                  src={activeModal.listing.author.avatar}
                  alt={activeModal.listing.author.name}
                  className="w-8 h-8 rounded-full object-cover border border-amber-400"
                />
                <div>
                  <span className="text-white block leading-tight">{activeModal.listing.author.name}</span>
                  <span className="text-[10px] text-slate-500">{activeModal.listing.author.city}</span>
                </div>
              </div>
              <div className="text-right">
                <span className="text-[10px] text-slate-500 block uppercase">Intento</span>
                <span className="text-amber-400 font-mono uppercase font-black">
                  {activeModal.listing.intent} {activeModal.listing.piPrice > 0 ? `(${activeModal.listing.piPrice} π)` : ""}
                </span>
              </div>
            </div>

            <div className="pt-2 flex items-center gap-3">
              <button
                onClick={() => {
                  onSelectListingForTrade(activeModal.listing);
                  setActiveModal(null);
                }}
                className="flex-1 py-3.5 rounded-2xl bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-300 text-slate-950 font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-xl hover:scale-105 transition-transform cursor-pointer"
              >
                <HeartHandshake className="w-4 h-4" />
                <span>Richiedi Scambio / Dono all'Autore</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODALE 4: PUBBLICA NUOVO OGGETTO NELLA CITTÀ */}
      {activeModal?.type === "create-object" && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-xl rounded-3xl bg-slate-900 border-2 border-amber-400/80 shadow-2xl p-6 sm:p-8 space-y-5 relative max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setActiveModal(null)}
              className="absolute top-5 right-5 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-400 to-yellow-300 flex items-center justify-center text-slate-950 font-black shadow-lg">
                <PlusCircle className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[10px] font-black uppercase tracking-wider text-amber-400 font-mono block">
                  Generazione Visiva nella Città
                </span>
                <h3 className="text-lg sm:text-xl font-black text-white">
                  Fai Comparire un Oggetto o Richiesta nella Città
                </h3>
              </div>
            </div>

            <form onSubmit={handleCreateCityObject} className="space-y-4">
              {/* 3 Action Switches: VENDO / BARATTO_SCAMBIO / ACQUISTO_CERCO */}
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setNewObjIntent("VENDO")}
                  className={`py-2.5 px-1 rounded-xl font-black text-xs transition-all flex flex-col items-center justify-center gap-1 cursor-pointer ${
                    newObjIntent === "VENDO"
                      ? "bg-amber-400 text-slate-950 shadow-md"
                      : "bg-slate-950 text-slate-400 border border-slate-800"
                  }`}
                >
                  <Coins className="w-3.5 h-3.5" />
                  <span>VENDO (π)</span>
                </button>
                <button
                  type="button"
                  onClick={() => setNewObjIntent("BARATTO_SCAMBIO")}
                  className={`py-2.5 px-1 rounded-xl font-black text-xs transition-all flex flex-col items-center justify-center gap-1 cursor-pointer ${
                    newObjIntent === "BARATTO_SCAMBIO"
                      ? "bg-emerald-400 text-slate-950 shadow-md"
                      : "bg-slate-950 text-slate-400 border border-slate-800"
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>BARATTO</span>
                </button>
                <button
                  type="button"
                  onClick={() => setNewObjIntent("ACQUISTO_CERCO")}
                  className={`py-2.5 px-1 rounded-xl font-black text-xs transition-all flex flex-col items-center justify-center gap-1 cursor-pointer ${
                    newObjIntent === "ACQUISTO_CERCO"
                      ? "bg-sky-400 text-slate-950 shadow-md"
                      : "bg-slate-950 text-slate-400 border border-slate-800"
                  }`}
                >
                  <HeartHandshake className="w-3.5 h-3.5" />
                  <span>CERCO</span>
                </button>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Titolo Oggetto (Es. Bicicletta da passeggio, Trapano, Cassa di arance...)
                </label>
                <input
                  type="text"
                  required
                  placeholder="Scrivi cosa metti a disposizione o stai cercando..."
                  value={newObjTitle}
                  onChange={(e) => setNewObjTitle(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Categoria Urbana</label>
                  <select
                    value={newObjCategory}
                    onChange={(e) => setNewObjCategory(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-amber-400"
                  >
                    <option>Mobilità & Veicoli</option>
                    <option>Alimentazione & Natura</option>
                    <option>Strumenti & Casa</option>
                    <option>Conoscenza & Digitale</option>
                    <option>Artigianato & Riparazioni</option>
                  </select>
                </div>

                {newObjIntent === "VENDO" && (
                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">Prezzo Pi (π)</label>
                    <input
                      type="number"
                      min="0"
                      max="15"
                      step="0.5"
                      value={newObjPiPrice}
                      onChange={(e) => setNewObjPiPrice(Number(e.target.value))}
                      className="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-amber-400"
                    />
                  </div>
                )}
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Descrizione & Luogo di Ritiro
                </label>
                <textarea
                  required
                  rows={3}
                  placeholder="Descrivi condizioni, dettagli e dove incontrare la persona..."
                  value={newObjDesc}
                  onChange={(e) => setNewObjDesc(e.target.value)}
                  className="w-full px-4 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-amber-400"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-400 to-yellow-300 text-slate-950 font-black text-sm flex items-center justify-center gap-2 shadow-xl hover:scale-[1.02] transition-transform cursor-pointer"
              >
                <PlusCircle className="w-4 h-4" />
                <span>Posiziona Oggetto nella Città Viva</span>
              </button>
            </form>
          </div>
        </div>
      )}

      {/* MODALE 5: PARLA NELLA PIAZZA DELLA CITTÀ */}
      {activeModal?.type === "post-piazza" && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-lg rounded-3xl bg-slate-900 border-2 border-emerald-400/80 shadow-2xl p-6 sm:p-7 space-y-5 relative">
            <button
              onClick={() => setActiveModal(null)}
              className="absolute top-5 right-5 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-emerald-400 flex items-center justify-center text-slate-950 font-black shadow-lg">
                <MessageSquare className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[10px] font-black uppercase tracking-wider text-emerald-400 font-mono block">
                  La Piazza Comunale
                </span>
                <h3 className="text-lg sm:text-xl font-black text-white">
                  Fai Risuonare la Tua Voce in Piazza
                </h3>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Il tuo messaggio apparirà come fumetto visivo dal vivo sopra i cittadini riuniti nella Piazza.
            </p>

            <form onSubmit={handlePostToPiazza} className="space-y-4">
              <textarea
                required
                rows={3}
                placeholder="Scrivi una riflessione, un saluto, una richiesta di consiglio per tutti i pionieri..."
                value={piazzaText}
                onChange={(e) => setPiazzaText(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-emerald-400"
              />

              <button
                type="submit"
                className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-400 to-teal-300 text-slate-950 font-black text-sm flex items-center justify-center gap-2 shadow-xl hover:scale-[1.02] transition-transform cursor-pointer"
              >
                <Send className="w-4 h-4" />
                <span>Pubblica nella Piazza dal Vivo</span>
              </button>
            </form>
          </div>
        </div>
      )}

      {/* MODALE 6: ARTICOLO CASA DELLA MEMORIA */}
      {activeModal?.type === "memory" && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-xl rounded-3xl bg-slate-900 border-2 border-rose-400/80 shadow-2xl p-6 sm:p-8 space-y-5 relative max-h-[85vh] overflow-y-auto">
            <button
              onClick={() => setActiveModal(null)}
              className="absolute top-5 right-5 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-rose-400 flex items-center justify-center text-slate-950 font-black shadow-lg">
                <BookOpen className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[10px] font-black uppercase tracking-wider text-rose-400 font-mono block">
                  Casa della Memoria • {activeModal.article.period}
                </span>
                <h3 className="text-lg sm:text-xl font-black text-white">
                  {activeModal.article.title}
                </h3>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-slate-200 leading-relaxed bg-slate-950/70 p-4 rounded-2xl border border-slate-800">
              {activeModal.article.content}
            </p>

            <div className="space-y-2">
              <span className="text-xs font-bold text-rose-300 block">Insegnamenti Chiave:</span>
              <ul className="space-y-1.5">
                {activeModal.article.keyTeachings.map((t, idx) => (
                  <li key={idx} className="text-xs text-slate-300 flex items-start gap-2">
                    <span className="text-rose-400 font-bold">•</span>
                    <span>{t}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="flex items-center justify-between text-xs text-slate-400 pt-2 border-t border-slate-800">
              <span>Autore: {activeModal.article.author}</span>
              <span>⭐ {activeModal.article.upvotes} Apprezzamenti</span>
            </div>
          </div>
        </div>
      )}

      {/* DEDICATED MODAL 8: MAPPA GEOGRAFICA REALE (3D EARTH / BACHECA P2P) */}
      {showGeoMap && (
        <div className="fixed inset-0 z-50 flex flex-col bg-slate-950">
          <GeographicMapBridge
            shops={shops}
            listings={listings}
            citizens={citizens}
            currentUser={currentUser}
            onClose={() => setShowGeoMap(false)}
            onSelectShop={(shop) => {
              setShowGeoMap(false);
              setActiveModal({ type: "shop", shop });
            }}
            onSelectListing={(listing) => {
              setActiveModal({ type: "object", listing });
            }}
            onRegisterNewShop={() => setShowRegisterShopModal(true)}
            onAddListing={onAddListing}
          />
        </div>
      )}

      {/* DEDICATED MODAL 9: PATTO DI SCAMBIO CONCRETO & BARATTO QUANTITATIVO */}
      {activeTradeListing && (
        <ExchangeProposalModal
          listing={activeTradeListing}
          currentUser={currentUser}
          onClose={() => setActiveTradeListing(null)}
          onSubmitTrade={(proposal) => {
            console.log("Patto di scambio inviato:", proposal);
          }}
        />
      )}

      {/* DEDICATED MODAL 10: REGISTRAZIONE ATTIVITÀ / NEGOZIO / PROFESSIONE */}
      <RegisterShopModal
        isOpen={showRegisterShopModal}
        onClose={() => setShowRegisterShopModal(false)}
        onRegister={handleRegisterShop}
      />

    </div>
  );
};
