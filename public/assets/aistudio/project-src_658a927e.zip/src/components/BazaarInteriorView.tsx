import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  ArrowLeft,
  Store,
  Coins,
  ShieldCheck,
  CheckCircle2,
  Search,
  MessageSquare,
  Send,
  X,
  Package,
  MapPin,
  ExternalLink,
  GraduationCap,
  Star,
  Sparkles,
  Stethoscope,
  Brain,
  Scale
} from "lucide-react";
import { HaveWantListing, CommerceShop, PioneerUser, RealCategoryKey, DiscreetAIReviewFeedback } from "../types";
import { REAL_CATEGORIES_MATRIX, getCategoryLabel } from "../categories";
import { DiscreetAIAssistantModal } from "./DiscreetAIAssistantModal";
import { ListingOriginBadge } from "@/components/have2want/ListingOriginBadge";

interface BazaarInteriorViewProps {
  shop?: CommerceShop;
  listings: HaveWantListing[];
  currentUser: PioneerUser;
  onBackToMap: () => void;
  onSelectListing?: (listing: HaveWantListing) => void;
  onOpenExternalRedirect?: (shop: CommerceShop) => void;
}

export const BazaarInteriorView: React.FC<BazaarInteriorViewProps> = ({
  shop,
  listings,
  currentUser,
  onBackToMap,
  onSelectListing,
  onOpenExternalRedirect,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<RealCategoryKey | "ALL">("ALL");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [activeItemForChat, setActiveItemForChat] = useState<HaveWantListing | null>(null);
  const [chatMessage, setChatMessage] = useState<string>("");
  const [chatSentFeedback, setChatSentFeedback] = useState<string | null>(null);

  // Review modal state
  const [reviewItem, setReviewItem] = useState<HaveWantListing | null>(null);
  const [reviewToast, setReviewToast] = useState<string | null>(null);

  // Filter listings according to category and search
  const shelfItems = listings.filter((item) => {
    // Match Strict Category
    if (selectedCategory !== "ALL") {
      if (item.category !== selectedCategory) return false;
    }

    // Match Search Query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = item.title.toLowerCase().includes(q);
      const matchDesc = item.description.toLowerCase().includes(q);
      const matchTag = item.tags.some((t) => t.toLowerCase().includes(q));
      if (!matchTitle && !matchDesc && !matchTag) return false;
    }

    return true;
  });

  const handleSendPrivateChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatMessage.trim() || !activeItemForChat) return;

    setChatSentFeedback(`Messaggio inviato a ${activeItemForChat.author.name}! Ti risponderà nella messaggistica standard.`);
    setChatMessage("");
    setTimeout(() => {
      setChatSentFeedback(null);
      setActiveItemForChat(null);
    }, 2400);
  };

  const handleReviewSubmitted = (feedback: DiscreetAIReviewFeedback) => {
    setReviewToast(`Valutazione per ${feedback.targetName} (${feedback.stars}★) registrata con successo!`);
    setTimeout(() => setReviewToast(null), 4000);
  };

  // High-Resolution real images for products across the real categories
  const getItemImage = (item: HaveWantListing) => {
    const title = item.title.toLowerCase();
    const cat = item.category;

    if (cat === "rete_specialisti_supporto") {
      if (title.includes("medico") || title.includes("salute")) {
        return "https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=700&auto=format&fit=crop&q=80";
      }
      if (title.includes("psicolog") || title.includes("ascolto")) {
        return "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=700&auto=format&fit=crop&q=80";
      }
      return "https://images.unsplash.com/photo-1556157382-97eda2d62296?w=700&auto=format&fit=crop&q=80";
    }

    if (cat === "libri_scuola_cultura" || title.includes("libro") || title.includes("testo") || title.includes("manuale")) {
      return "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=700&auto=format&fit=crop&q=80";
    }

    if (cat === "elettronica_informatica" || title.includes("smartphone") || title.includes("laptop") || title.includes("notebook")) {
      if (title.includes("laptop") || title.includes("notebook")) {
        return "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=700&auto=format&fit=crop&q=80";
      }
      return "https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=700&auto=format&fit=crop&q=80";
    }

    if (cat === "abbigliamento_accessori" || title.includes("giaccone") || title.includes("maglione") || title.includes("lana")) {
      if (title.includes("maglione")) {
        return "https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=700&auto=format&fit=crop&q=80";
      }
      return "https://images.unsplash.com/photo-1548883354-7622d03aca27?w=700&auto=format&fit=crop&q=80";
    }

    if (cat === "casa_fai_da_te" || title.includes("trapano") || title.includes("tavolo") || title.includes("attrezzi")) {
      if (title.includes("trapano")) {
        return "https://images.unsplash.com/photo-1504148455328-c376907d081c?w=700&auto=format&fit=crop&q=80";
      }
      return "https://images.unsplash.com/photo-1538688525198-9b88f6f53126?w=700&auto=format&fit=crop&q=80";
    }

    if (cat === "auto_moto_veicoli" || title.includes("pneumatici") || title.includes("bici") || title.includes("ricambi")) {
      return "https://images.unsplash.com/photo-1486006920555-c77dce18193b?w=700&auto=format&fit=crop&q=80";
    }

    return "https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?w=700&auto=format&fit=crop&q=80";
  };

  return (
    <div className="w-full bg-[#030712] text-slate-100 min-h-screen flex flex-col font-sans">
      
      {/* Top Header / Breadcrumb */}
      <div className="px-4 sm:px-8 py-4 bg-slate-950/95 border-b border-slate-800 sticky top-0 z-40 backdrop-blur-md flex flex-wrap items-center justify-between gap-4">
        
        <div className="flex items-center gap-3">
          <button
            onClick={onBackToMap}
            className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-sky-400 font-black text-xs sm:text-sm border border-slate-700 flex items-center gap-2 transition-all cursor-pointer shadow-sm hover:scale-105"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>← Ritorna a Google Earth 3D</span>
          </button>

          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-black text-white">
                {shop ? shop.name : "Scaffali Digitali Bazar • Bacheca Prodotti & Specialisti"}
              </h2>
              <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold uppercase font-mono">
                P2P Diretto
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Visualizzazione lineare: tocca l'articolo per vedere la foto reale, la descrizione e attivare la chat diretta.
            </p>
          </div>
        </div>

        {/* Quick Search */}
        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cerca negli scaffali..."
            className="w-full pl-9 pr-4 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
          />
        </div>
      </div>

      {reviewToast && (
        <div className="mx-4 sm:mx-8 mt-3 p-3 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold text-center">
          {reviewToast}
        </div>
      )}

      {/* Category Pills Bar */}
      <div className="px-4 sm:px-8 py-3 bg-slate-950 border-b border-slate-800/80 flex items-center gap-2 overflow-x-auto">
        <span className="text-xs font-bold text-slate-400 mr-2 shrink-0">Categorie:</span>
        <button
          onClick={() => setSelectedCategory("ALL")}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer ${
            selectedCategory === "ALL"
              ? "bg-purple-500 text-white shadow-md shadow-purple-500/30 font-black"
              : "bg-slate-900 text-slate-400 hover:bg-slate-800 border border-slate-800"
          }`}
        >
          Tutte le Categorie ({listings.length})
        </button>

        {REAL_CATEGORIES_MATRIX.map((cat) => {
          const isSelected = selectedCategory === cat.key;
          const count = listings.filter((l) => l.category === cat.key).length;
          const isSpecialist = cat.key === "rete_specialisti_supporto";

          return (
            <button
              key={cat.key}
              onClick={() => setSelectedCategory(cat.key)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer flex items-center gap-1.5 ${
                isSelected
                  ? isSpecialist
                    ? "bg-gradient-to-r from-teal-500 to-emerald-500 text-slate-950 shadow-md shadow-teal-500/30 font-black"
                    : "bg-purple-500 text-white shadow-md shadow-purple-500/30 font-black"
                  : isSpecialist
                  ? "bg-teal-950/40 text-teal-300 hover:bg-teal-900/40 border border-teal-500/40"
                  : "bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-800"
              }`}
            >
              {isSpecialist && <Sparkles className="w-3.5 h-3.5 text-teal-300" />}
              <span>{cat.label}</span>
              <span className="text-[10px] opacity-75 font-mono">({count})</span>
            </button>
          );
        })}
      </div>

      {/* Main Grid: Shelf Items */}
      <div className="p-4 sm:p-8 flex-1 overflow-y-auto">
        {shelfItems.length === 0 ? (
          <div className="max-w-md mx-auto p-8 rounded-3xl bg-slate-900/60 border border-slate-800 text-center space-y-3 mt-12">
            <Package className="w-10 h-10 text-purple-400 mx-auto" />
            <h3 className="text-sm font-bold text-white">Nessun oggetto in questo scaffale</h3>
            <p className="text-xs text-slate-400">
              Al momento non sono presenti articoli per questa specifica categoria nel territorio selezionato.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {shelfItems.map((item) => {
              const imageSrc = getItemImage(item);
              const isSchoolPriority = item.category === "libri_scuola_cultura";
              const isSpecialist = item.category === "rete_specialisti_supporto";

              return (
                <motion.div
                  key={item.id}
                  whileHover={{ scale: 1.02, y: -4 }}
                  className={`bg-slate-900 border rounded-2xl overflow-hidden flex flex-col shadow-lg transition-all ${
                    isSpecialist 
                      ? "border-teal-500/40 hover:border-teal-400 shadow-teal-500/10" 
                      : "border-slate-800 hover:border-purple-500/50"
                  }`}
                >
                  {/* Real Product Image (JPEG/PNG) */}
                  <div className="h-48 w-full relative bg-slate-950 overflow-hidden">
                    <img
                      src={imageSrc}
                      alt={item.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute top-2 left-2 flex flex-col gap-1 items-start">
                      <ListingOriginBadge listing={item} size="xs" />
                      <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded backdrop-blur-md border font-mono ${
                        isSpecialist 
                          ? "bg-teal-950/80 text-teal-300 border-teal-500/40" 
                          : "bg-slate-950/80 text-purple-300 border-purple-500/30"
                      }`}>
                        {getCategoryLabel(item.category)}
                      </span>
                      {isSpecialist && (
                        <span className="text-[9px] font-black uppercase px-2 py-0.5 rounded bg-teal-400 text-slate-950 font-mono shadow-sm">
                          ✨ Vetrina Sponsorizzata Gratuita
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Body Content */}
                  <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] text-slate-400 font-mono flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-rose-400 shrink-0" />
                          {item.author.city} ({item.author.province || "IT"})
                        </span>
                        <span className="text-xs font-bold text-amber-400 flex items-center gap-1">
                          <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                          <span>{item.author.reputation}</span>
                        </span>
                      </div>
                      
                      <h4 className="text-sm font-bold text-white line-clamp-2 leading-snug">{item.title}</h4>
                      <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                        {item.description}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-slate-800/80 space-y-2">
                      <div className="flex items-center justify-between">
                        <div>
                          <span className="text-[10px] text-slate-400 block font-mono">
                            {isSpecialist ? "Supporto Solidale" : "Valore / Modalità"}
                          </span>
                          <span className="text-xs font-black text-amber-400 font-mono">
                            {isSpecialist ? "Orientamento Gratuito" : item.piPrice && item.piPrice > 0 ? `${item.piPrice} π` : "Baratto Diretto"}
                          </span>
                        </div>

                        {/* Open Chat */}
                        <button
                          onClick={() => setActiveItemForChat(item)}
                          className={`px-3 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-md transition-all cursor-pointer ${
                            isSpecialist
                              ? "bg-teal-500 hover:bg-teal-400 text-slate-950 shadow-teal-500/20"
                              : "bg-purple-600 hover:bg-purple-500 text-white shadow-purple-600/30"
                          }`}
                        >
                          <MessageSquare className="w-3.5 h-3.5" />
                          <span>{isSpecialist ? "Chat Solidale" : "Attiva Chat"}</span>
                        </button>
                      </div>

                      {/* Review Trigger Button */}
                      <button
                        onClick={() => setReviewItem(item)}
                        className="w-full py-1 rounded-lg bg-slate-800/80 hover:bg-slate-800 text-slate-300 hover:text-white text-[11px] font-semibold border border-slate-700 flex items-center justify-center gap-1.5 transition-all"
                      >
                        <Star className="w-3 h-3 text-amber-400" />
                        <span>Valuta Esperienza (1-5★)</span>
                      </button>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>

      {/* Direct Messaging / Private Chat Modal */}
      <AnimatePresence>
        {activeItemForChat && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-md bg-slate-950 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-2xl relative"
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <MessageSquare className="w-5 h-5 text-purple-400" />
                  <h3 className="text-sm font-bold text-white">Canale di Messaggistica Diretto</h3>
                </div>
                <button
                  onClick={() => setActiveItemForChat(null)}
                  className="p-1 rounded-lg text-slate-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center gap-3">
                <img
                  src={getItemImage(activeItemForChat)}
                  alt={activeItemForChat.title}
                  className="w-12 h-12 rounded-lg object-cover"
                />
                <div>
                  <div className="flex items-center gap-2 mb-0.5">
                    <h5 className="text-xs font-bold text-white">{activeItemForChat.title}</h5>
                    <ListingOriginBadge listing={activeItemForChat} size="xs" compact={true} />
                  </div>
                  <span className="text-[11px] text-purple-300 font-mono">
                    Referente: {activeItemForChat.author.name}
                  </span>
                </div>
              </div>

              <form onSubmit={handleSendPrivateChat} className="space-y-3">
                <textarea
                  value={chatMessage}
                  onChange={(e) => setChatMessage(e.target.value)}
                  placeholder="Scrivi il tuo messaggio per accordarti..."
                  rows={4}
                  className="w-full p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                />

                {chatSentFeedback ? (
                  <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-300 text-xs font-bold text-center border border-emerald-500/30">
                    {chatSentFeedback}
                  </div>
                ) : (
                  <button
                    type="submit"
                    className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer"
                  >
                    <Send className="w-4 h-4" />
                    <span>Invia Messaggio</span>
                  </button>
                )}
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Discreet AI Feedback / Star Rating Modal */}
      {reviewItem && (
        <DiscreetAIAssistantModal
          isOpen={!!reviewItem}
          onClose={() => setReviewItem(null)}
          targetId={reviewItem.id}
          targetName={reviewItem.author.name}
          targetType={reviewItem.category === "rete_specialisti_supporto" ? "specialist" : "listing"}
          isFinancialLocked={true}
          onReviewSubmitted={handleReviewSubmitted}
        />
      )}

    </div>
  );
};
