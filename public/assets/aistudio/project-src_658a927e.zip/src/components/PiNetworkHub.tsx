import React, { useState } from "react";
import { PioneerUser, HaveWantListing } from "../types";
import {
  Coins,
  Send,
  ShieldCheck,
  CheckCircle2,
  ArrowRight,
  Sparkles,
  Lock,
  Wallet,
  History,
  QrCode,
  AlertCircle
} from "lucide-react";

interface PiNetworkHubProps {
  currentUser: PioneerUser;
  onUpdateBalance: (newBalance: number) => void;
  selectedTradeListing?: HaveWantListing | null;
  onCloseTrade?: () => void;
}

export const PiNetworkHub: React.FC<PiNetworkHubProps> = ({
  currentUser,
  onUpdateBalance,
  selectedTradeListing,
  onCloseTrade,
}) => {
  const [recipient, setRecipient] = useState(
    selectedTradeListing ? selectedTradeListing.author.username : "@marcopi"
  );
  const [amount, setAmount] = useState<string>(
    selectedTradeListing && selectedTradeListing.piPrice ? selectedTradeListing.piPrice.toString() : "1.0"
  );
  const [memo, setMemo] = useState<string>(
    selectedTradeListing ? `Contributo per: ${selectedTradeListing.title}` : "Scambio di valore umano HAVE2WANT"
  );
  const [txStatus, setTxStatus] = useState<"idle" | "processing" | "success" | "error">("idle");
  const [txHash, setTxHash] = useState<string>("");
  const [errorMessage, setErrorMessage] = useState<string>("");

  const [history, setHistory] = useState([
    {
      id: "tx-1",
      type: "received",
      counterpart: "@peppe_orto",
      amount: 2.0,
      memo: "Condivisione frutta km0",
      date: "Oggi 09:30",
    },
    {
      id: "tx-2",
      type: "sent",
      counterpart: "@lucavelo",
      amount: 1.5,
      memo: "Riparazione catena bici",
      date: "Ieri 16:45",
    },
  ]);

  const handleSendTransaction = (e: React.FormEvent) => {
    e.preventDefault();
    const sendAmount = parseFloat(amount);

    if (isNaN(sendAmount) || sendAmount <= 0) {
      setErrorMessage("Inserisci un importo valido in π");
      return;
    }

    if (sendAmount > 15) {
      setErrorMessage("Il valore supera il tetto massimo etico di 15 π definito nel Master Spec v1.0.");
      return;
    }

    if (sendAmount > currentUser.piBalance) {
      setErrorMessage("Saldo Pi insufficiente nel tuo wallet Pioneer.");
      return;
    }

    setErrorMessage("");
    setTxStatus("processing");

    // Simulate Pi SDK Blockchain Confirmation
    setTimeout(() => {
      const generatedHash = `0x${Array.from({ length: 32 }, () =>
        Math.floor(Math.random() * 16).toString(16)
      ).join("")}`;

      const newBalance = currentUser.piBalance - sendAmount;
      onUpdateBalance(newBalance);

      setHistory([
        {
          id: `tx-${Date.now()}`,
          type: "sent",
          counterpart: recipient,
          amount: sendAmount,
          memo,
          date: "Adesso",
        },
        ...history,
      ]);

      setTxHash(generatedHash);
      setTxStatus("success");
    }, 1200);
  };

  return (
    <div className="space-y-6">
      {/* Wallet Balance Hero Card */}
      <div className="p-6 rounded-2xl bg-gradient-to-br from-amber-950/60 via-slate-900 to-purple-950/40 border border-amber-500/30 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shadow-inner">
              <Coins className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">
                  Pi Network Testnet / Mainnet Ready
                </span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3" /> KYC Verificato
                </span>
              </div>
              <h2 className="text-3xl font-extrabold text-slate-100 font-mono tracking-tight mt-0.5">
                {currentUser.piBalance.toFixed(2)} <span className="text-amber-400 font-sans">π</span>
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Account Pioneer: <span className="text-slate-200 font-mono font-semibold">{currentUser.username}</span> ({currentUser.name})
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 bg-slate-950/80 p-3 rounded-xl border border-slate-800 text-xs">
            <div className="text-right">
              <div className="text-slate-400 font-medium">Cap Massimo HAVE2WANT:</div>
              <div className="text-amber-300 font-bold font-mono">15.00 π per transazione</div>
            </div>
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 flex items-center justify-center text-amber-400">
              <Lock className="w-4 h-4" />
            </div>
          </div>
        </div>
      </div>

      {/* Grid: Transaction Engine & Tokenomics Principles */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Send / Transfer Module */}
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <Send className="w-4 h-4 text-amber-400" />
              Invia Contributo in Pi (π)
            </h3>
            {selectedTradeListing && (
              <span className="text-[10px] px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30">
                Transazione Collegata
              </span>
            )}
          </div>

          {txStatus === "success" ? (
            <div className="p-5 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-center space-y-3 animate-in fade-in duration-200">
              <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto" />
              <div>
                <h4 className="text-sm font-bold text-emerald-300">Transazione Pi Confermata con Successo!</h4>
                <p className="text-xs text-slate-300 mt-1">
                  {amount} π trasferiti a <span className="font-mono text-amber-300">{recipient}</span>
                </p>
                <div className="mt-2 p-2 rounded bg-slate-950 border border-slate-800 font-mono text-[10px] text-slate-400 truncate">
                  Hash: {txHash}
                </div>
              </div>
              <button
                onClick={() => {
                  setTxStatus("idle");
                  if (onCloseTrade) onCloseTrade();
                }}
                className="px-4 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs"
              >
                Nuova Operazione
              </button>
            </div>
          ) : (
            <form onSubmit={handleSendTransaction} className="space-y-4 text-xs">
              {errorMessage && (
                <div className="p-3 rounded-xl bg-rose-950/50 border border-rose-800 text-rose-200 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>{errorMessage}</span>
                </div>
              )}

              <div>
                <label className="block font-semibold text-slate-300 mb-1">Destinatario Pioneer</label>
                <input
                  type="text"
                  required
                  placeholder="@username o Indirizzo Wallet"
                  value={recipient}
                  onChange={(e) => setRecipient(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-amber-500 font-mono"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="font-semibold text-slate-300">Importo in Pi (π)</label>
                  <span className="text-[10px] text-slate-500">Max 15 π</span>
                </div>
                <div className="relative">
                  <input
                    type="number"
                    required
                    min="0.01"
                    max="15"
                    step="0.01"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-amber-500 font-mono text-base font-bold pr-10"
                  />
                  <span className="absolute right-3.5 top-1/2 -translate-y-1/2 font-bold text-amber-400 text-sm">
                    π
                  </span>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">Causale / Scopo</label>
                <input
                  type="text"
                  placeholder="Es: Contributo per scambio corso di programmazione"
                  value={memo}
                  onChange={(e) => setMemo(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-amber-500"
                />
              </div>

              <button
                type="submit"
                disabled={txStatus === "processing"}
                id="submit-pi-transaction-btn"
                className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {txStatus === "processing" ? (
                  <span>Convalida Pi Network in corso...</span>
                ) : (
                  <>
                    <Coins className="w-4 h-4" />
                    <span>Conferma e Invia {amount} π</span>
                  </>
                )}
              </button>
            </form>
          )}
        </div>

        {/* Historic Transactions List */}
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <History className="w-4 h-4 text-amber-400" />
              Registro Operazioni Recenti
            </h3>
            <span className="text-[11px] text-slate-500">{history.length} transazioni</span>
          </div>

          <div className="space-y-3">
            {history.map((tx) => (
              <div
                key={tx.id}
                className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 flex items-center justify-between gap-3 text-xs"
              >
                <div>
                  <div className="font-bold text-slate-200 flex items-center gap-1.5">
                    <span className={tx.type === "received" ? "text-emerald-400" : "text-rose-400"}>
                      {tx.type === "received" ? "Ricevuto da" : "Inviato a"}
                    </span>
                    <span className="font-mono text-slate-300">{tx.counterpart}</span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">{tx.memo}</div>
                  <div className="text-[10px] text-slate-500">{tx.date}</div>
                </div>

                <div
                  className={`font-mono font-bold text-sm ${
                    tx.type === "received" ? "text-emerald-400" : "text-slate-200"
                  }`}
                >
                  {tx.type === "received" ? "+" : "-"}
                  {tx.amount.toFixed(2)} π
                </div>
              </div>
            ))}
          </div>

          {/* Master Spec Tokenomics Rule box */}
          <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800/80 text-[11px] text-slate-400 space-y-1.5">
            <div className="font-bold text-amber-400">Architettura dei 4 Flussi HAVE2WANT:</div>
            <div>• 95% del valore trasferito direttamente al Pioneer fornitore</div>
            <div>• 5% destinato alla manutenzione dell'ecosistema e tutela del Creatore</div>
            <div>• Assenza totale di speculazione o commissioni opache</div>
          </div>
        </div>
      </div>
    </div>
  );
};
