import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  ShieldCheck,
  MapPin,
  Clock,
  Building2,
  CheckCircle2,
  X,
  Compass,
  AlertCircle,
  Sparkles,
  ExternalLink
} from "lucide-react";
import { CertifiedMeetingPoint } from "../types";
import { INITIAL_CERTIFIED_MEETING_POINTS } from "../data";

interface CertifiedMeetingPointsModalProps {
  city: string;
  onSelectMeetingPoint: (point: CertifiedMeetingPoint) => void;
  onClose: () => void;
}

export const CertifiedMeetingPointsModal: React.FC<CertifiedMeetingPointsModalProps> = ({
  city,
  onSelectMeetingPoint,
  onClose,
}) => {
  const normalizedCity = (city || "Asti").toLowerCase();
  const availablePoints = INITIAL_CERTIFIED_MEETING_POINTS.filter((p) =>
    p.city.toLowerCase().includes(normalizedCity)
  );

  // Fallback to all if none in specific city
  const displayPoints = availablePoints.length > 0 ? availablePoints : INITIAL_CERTIFIED_MEETING_POINTS;

  const [selectedPointId, setSelectedPointId] = useState<string>(displayPoints[0]?.id || "");

  const activePoint = displayPoints.find((p) => p.id === selectedPointId) || displayPoints[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn font-sans">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        className="bg-slate-950 border border-slate-800 w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
      >
        {/* Modal Header */}
        <div className="p-5 sm:p-6 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black text-white flex items-center gap-2">
                <span>Punti di Incontro Certificati</span>
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">
                  Sicurezza 3D
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Nodi pubblici e neutri mappati su Google Earth per lo scambio fisico protetto
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-5">
          {/* Information Notice */}
          <div className="p-4 rounded-2xl bg-sky-950/30 border border-sky-500/30 flex items-start gap-3">
            <Sparkles className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
            <div className="text-xs text-sky-200 leading-relaxed">
              Tutti i nodi sono geolocalizzati in spazi ad alta frequentazione o videosorvegliati. La scelta di un punto certificato aumenta la fiducia reciproca e abilita la <b>Stretta di Mano Digitale</b>.
            </div>
          </div>

          {/* List of Meeting Points */}
          <div className="space-y-3">
            <span className="text-xs font-mono font-bold uppercase text-slate-400">
              Punti disponibili per {city || "il territorio"}:
            </span>

            <div className="grid grid-cols-1 gap-3">
              {displayPoints.map((point) => {
                const isSelected = point.id === selectedPointId;
                return (
                  <div
                    key={point.id}
                    onClick={() => setSelectedPointId(point.id)}
                    className={`p-4 rounded-2xl border-2 transition-all cursor-pointer ${
                      isSelected
                        ? "bg-slate-900 border-emerald-400 shadow-lg shadow-emerald-500/10 ring-1 ring-emerald-400"
                        : "bg-slate-900/60 border-slate-800 hover:border-slate-700"
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <MapPin className="w-4 h-4 text-rose-400 shrink-0" />
                          <h4 className="text-sm font-bold text-white">{point.name}</h4>
                        </div>
                        <p className="text-xs text-slate-400 font-mono pl-6">
                          {point.address} ({point.city}, {point.province})
                        </p>
                        <p className="text-xs text-slate-300 pl-6 pt-1 leading-relaxed">
                          {point.description}
                        </p>
                      </div>

                      <div className="shrink-0 flex items-center">
                        <span className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                          isSelected ? "border-emerald-400 bg-emerald-400 text-slate-950" : "border-slate-700"
                        }`}>
                          {isSelected && <CheckCircle2 className="w-3.5 h-3.5 stroke-[3]" />}
                        </span>
                      </div>
                    </div>

                    {/* Features Badges */}
                    <div className="mt-3 pl-6 flex flex-wrap items-center gap-2">
                      <span className="px-2 py-0.5 rounded-lg bg-slate-800 text-[10px] font-mono text-slate-300 flex items-center gap-1">
                        <Clock className="w-3 h-3 text-amber-400" />
                        <span>Orari: {point.recommendedHours}</span>
                      </span>
                      {point.securityFeatures.map((sec, idx) => (
                        <span
                          key={idx}
                          className="px-2 py-0.5 rounded-lg bg-emerald-950/40 text-emerald-300 border border-emerald-500/30 text-[10px] font-mono font-medium"
                        >
                          ✓ {sec}
                        </span>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-5 sm:p-6 bg-slate-900/90 border-t border-slate-800 flex items-center justify-between gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl bg-slate-800 text-slate-300 font-bold text-xs hover:bg-slate-700 transition-colors cursor-pointer"
          >
            Annulla
          </button>

          <button
            onClick={() => {
              if (activePoint) {
                onSelectMeetingPoint(activePoint);
                onClose();
              }
            }}
            className="px-6 py-2.5 rounded-xl bg-emerald-400 hover:bg-emerald-300 text-slate-950 font-black text-xs sm:text-sm flex items-center gap-2 shadow-lg shadow-emerald-400/20 transition-all cursor-pointer"
          >
            <ShieldCheck className="w-4 h-4" />
            <span>Fissa Punto d'Incontro Protetto</span>
          </button>
        </div>
      </motion.div>
    </div>
  );
};
