import React, { useState } from "react";
import {
  Coins,
  ShieldCheck,
  Smartphone,
  CheckCircle2,
  Lock,
  ArrowRight,
  Sparkles,
  ExternalLink
} from "lucide-react";
import { HaveWantListing } from "../types";

interface PiOfficialBridgeProps {
  selectedListing?: HaveWantListing | null;
  onClearSelectedListing?: () => void;
}

export const PiOfficialBridge: React.FC<PiOfficialBridgeProps> = ({
  selectedListing,
  onClearSelectedListing,
}) => {
  const [bridgeStatus, setBridgeStatus] = useState<"idle" | "requesting" | "ready">("idle");

  const handleOpenOfficialPiWallet = () => {
    setBridgeStatus("requesting");
    setTimeout(() => {
      setBridgeStatus("ready");
    }, 900);
  };

  return (
    <div className="space-y-6">
      {/* Banner: Non-Custodial & Libertà Finanziaria */}
      <div className="p-6 rounded-2xl bg-gradient-to-br from-amber-950/40 via-slate-900 to-slate-900 border border-amber-500/30 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Coins className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-slate-100">Collegamento Opzionale Pi Network</h2>
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3" /> 100% Non-Custodial
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                HAVE2WANT non ha wallet interno e non gestisce né trattiene i tuoi Pi. Il wallet appartiene unicamente a te.
              </p>
            </div>
          </div>

          <div className="flex flex-col gap-1.5 bg-slate-950 px-3.5 py-2 rounded-xl border border-slate-800 text-xs">
            <div className="flex items-center gap-2">
              <Lock className="w-4 h-4 text-amber-400 shrink-0" />
              <div className="text-slate-300">
                <span className="text-amber-400 font-bold font-mono">Pi Wallet Ufficiale:</span> Esterno & Diretto
              </div>
            </div>
            <div className="text-[10px] font-mono text-slate-400 break-all">
              App Wallet: <span className="text-amber-300">GC4QNJHVWYXOJ5ZO3SDCCAITO7IE6VM22CKPPGQJL737AOWUTVLJQE7X</span>
            </div>
          </div>
        </div>
      </div>

      {/* Selected Trade Context (if user clicked from an item) */}
      {selectedListing && (
        <div className="p-5 rounded-2xl bg-slate-900 border border-amber-500/40 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">
              Scambio Selezionato nel Pianeta Possibilità
            </span>
            <button
              onClick={onClearSelectedListing}
              className="text-xs text-slate-400 hover:text-slate-200 underline cursor-pointer"
            >
              Deseleziona
            </button>
          </div>

          <div className="flex items-start justify-between gap-4">
            <div>
              <h4 className="text-sm font-bold text-slate-100">{selectedListing.title}</h4>
              <p className="text-xs text-slate-400 mt-0.5">
                Controparte: <span className="font-mono text-slate-200">{selectedListing.author.username}</span> ({selectedListing.author.name})
              </p>
            </div>
            <div className="text-right shrink-0">
              <div className="text-xs text-slate-400">Valore concordato:</div>
              <div className="text-base font-bold font-mono text-amber-400">
                {selectedListing.piPrice && selectedListing.piPrice > 0 ? `${selectedListing.piPrice} π` : "Simbolico"}
              </div>
            </div>
          </div>

          {bridgeStatus === "ready" ? (
            <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-500/30 flex items-center justify-between text-xs text-emerald-200">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Pronto per l'apertura tramite Pi Browser (Pi SDK nativo)</span>
              </div>
              <span className="font-mono text-amber-300 font-bold">Autorizzazione sicura</span>
            </div>
          ) : (
            <button
              onClick={handleOpenOfficialPiWallet}
              disabled={bridgeStatus === "requesting"}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md"
            >
              <Smartphone className="w-4 h-4" />
              <span>
                {bridgeStatus === "requesting"
                  ? "Connessione al Pi Browser in corso..."
                  : "Procedi con il Pi Wallet Ufficiale Esterno"}
              </span>
            </button>
          )}
        </div>
      )}

      {/* Guide & Non-Custodial Manifesto */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
          <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center font-bold">
            1
          </div>
          <h4 className="font-bold text-slate-100">Nessun Wallet Interno</h4>
          <p className="text-slate-400 leading-relaxed">
            HAVE2WANT non è una banca né un intermediario finanziario. I tuoi $\pi$ rimangono sempre custoditi unicamente nel tuo Pi Wallet ufficiale.
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
          <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center font-bold">
            2
          </div>
          <h4 className="font-bold text-slate-100">Opzione Libera per Scambi</h4>
          <p className="text-slate-400 leading-relaxed">
            Pi Network è solo una delle 9 forme di scambio disponibili. Puoi sempre scegliere il dono puro, il baratto di oggetti o il prestito fiduciario a costo zero.
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
          <div className="w-8 h-8 rounded-lg bg-sky-500/10 text-sky-400 flex items-center justify-center font-bold">
            3
          </div>
          <h4 className="font-bold text-slate-100">Accesso tramite Pi Browser</h4>
          <p className="text-slate-400 leading-relaxed">
            Quando l'app è aperta all'interno del Pi Browser, il Pi SDK si collegherà in modo sicuro all'identità Pioneer dell'utente per confermare gli scambi.
          </p>
        </div>
      </div>
    </div>
  );
};
