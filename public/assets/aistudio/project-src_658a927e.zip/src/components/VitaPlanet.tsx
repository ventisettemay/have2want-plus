import React, { useState } from "react";
import { CommunityChatMessage, PioneerUser, AbuseReportPayload, ReportTargetType } from "../types";
import {
  Users,
  Send,
  Globe2,
  Heart,
  Radio,
  MessageCircle,
  ShieldCheck,
  UserCheck,
  ShieldAlert,
  Flag,
  CheckCircle2
} from "lucide-react";
import { AbuseReportModal } from "./AbuseReportModal";

interface VitaPlanetProps {
  currentUser: PioneerUser;
  messages: CommunityChatMessage[];
  onSendMessage: (msg: CommunityChatMessage) => void;
  onReportAbuse?: (payload: AbuseReportPayload) => void;
}

export const VitaPlanet: React.FC<VitaPlanetProps> = ({
  currentUser,
  messages,
  onSendMessage,
  onReportAbuse,
}) => {
  const [activeRoom, setActiveRoom] = useState<CommunityChatMessage["room"]>("piazza-generale");
  const [inputText, setInputText] = useState("");
  const [privateRecipient, setPrivateRecipient] = useState<string | null>(null);
  const [privateText, setPrivateText] = useState("");
  const [privateHistory, setPrivateHistory] = useState<Array<{ sender: string; text: string; time: string }>>([
    { sender: "Elena Bianchi", text: "Ciao! Ho visto il tuo annuncio, sono disponibile per accordarci direttamente.", time: "11:22" }
  ]);
  const [reportTarget, setReportTarget] = useState<{
    id: string;
    username: string;
    type: ReportTargetType;
  } | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const filteredMessages = messages.filter((m) => m.room === activeRoom);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    const newMsg: CommunityChatMessage = {
      id: `msg-${Date.now()}`,
      author: {
        name: currentUser.name,
        username: currentUser.username,
        avatar: currentUser.avatar,
      },
      text: inputText.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      room: activeRoom,
      likes: 0,
    };

    onSendMessage(newMsg);
    setInputText("");
  };

  const handleSendPrivate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!privateText.trim()) return;
    setPrivateHistory([
      ...privateHistory,
      {
        sender: currentUser.name,
        text: privateText.trim(),
        time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      },
    ]);
    setPrivateText("");
  };

  return (
    <div className="space-y-6">
      {/* Luminous Header Banner */}
      <div className="p-6 sm:p-7 rounded-3xl bg-gradient-to-r from-emerald-950/70 via-slate-900/90 to-emerald-900/40 border border-emerald-400/40 shadow-[0_0_40px_rgba(16,185,129,0.15)]">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div>
            <div className="flex items-center gap-2 text-emerald-400 text-xs sm:text-sm font-bold uppercase tracking-wider mb-1.5">
              <Users className="w-4 h-4" />
              Pianeta Vita • Terra &amp; Relazioni
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">La Piazza delle Relazioni</h2>
            <p className="text-sm sm:text-base text-slate-300 mt-2 max-w-2xl leading-relaxed">
              Lo spazio d'incontro umano e vicinanza autentica. 3 sole stanze pubbliche, senza titoli artificiosi, e contatto diretto 1-a-1 quando HAVE e WANT si incontrano.
            </p>
          </div>

          {/* User Profile Pill */}
          <div className="p-3.5 rounded-2xl bg-slate-950/90 border border-emerald-400/40 flex items-center gap-3.5 shrink-0 shadow-lg">
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-12 h-12 rounded-full object-cover border-2 border-emerald-400/60"
            />
            <div>
              <div className="text-sm font-bold text-white flex items-center gap-1.5">
                <span>{currentUser.name}</span>
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="text-xs text-emerald-300 font-semibold mt-0.5">
                {currentUser.city}
              </div>
            </div>
          </div>
        </div>

        {/* The 3 Only Public Rooms */}
        <div className="mt-6 pt-5 border-t border-emerald-500/20 grid grid-cols-1 sm:grid-cols-3 gap-2 sm:gap-3">
          <button
            onClick={() => { setActiveRoom("piazza-generale"); setPrivateRecipient(null); }}
            className={`px-4 py-3 rounded-2xl text-xs sm:text-sm font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
              activeRoom === "piazza-generale" && !privateRecipient
                ? "bg-emerald-500 text-slate-950 shadow-lg shadow-emerald-500/30 scale-[1.02]"
                : "bg-slate-950/90 text-slate-300 hover:text-white border border-slate-800 hover:border-emerald-500/40"
            }`}
          >
            <Globe2 className="w-4 h-4" />
            <span>HAVE2WANT Community</span>
          </button>
          
          <button
            onClick={() => { setActiveRoom("aiuto-reciproco"); setPrivateRecipient(null); }}
            className={`px-4 py-3 rounded-2xl text-xs sm:text-sm font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
              activeRoom === "aiuto-reciproco" && !privateRecipient
                ? "bg-emerald-500 text-slate-950 shadow-lg shadow-emerald-500/30 scale-[1.02]"
                : "bg-slate-950/90 text-slate-300 hover:text-white border border-slate-800 hover:border-emerald-500/40"
            }`}
          >
            <Heart className="w-4 h-4" />
            <span>HAVE (Offerte &amp; Dono)</span>
          </button>
          
          <button
            onClick={() => { setActiveRoom("baratto-pi"); setPrivateRecipient(null); }}
            className={`px-4 py-3 rounded-2xl text-xs sm:text-sm font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
              activeRoom === "baratto-pi" && !privateRecipient
                ? "bg-emerald-500 text-slate-950 shadow-lg shadow-emerald-500/30 scale-[1.02]"
                : "bg-slate-950/90 text-slate-300 hover:text-white border border-slate-800 hover:border-emerald-500/40"
            }`}
          >
            <Radio className="w-4 h-4" />
            <span>WANT (Bisogni &amp; Ricerche)</span>
          </button>
        </div>
      </div>

      {/* Main Chat Box */}
      {!privateRecipient ? (
        <div className="p-6 sm:p-7 rounded-3xl bg-slate-900/90 border border-slate-800 flex flex-col h-[560px] shadow-2xl backdrop-blur-sm">
          {/* Header of the Room */}
          <div className="pb-4 mb-4 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-emerald-400 animate-pulse"></span>
              <span className="text-base sm:text-lg font-extrabold text-white">
                {activeRoom === "piazza-generale" && "Chat 1: HAVE2WANT Community"}
                {activeRoom === "aiuto-reciproco" && "Chat 2: HAVE (Offerte, Aiuto & Dono)"}
                {activeRoom === "baratto-pi" && "Chat 3: WANT (Bisogni, Scambi & Ricerche)"}
              </span>
            </div>
            
            <div className="flex items-center gap-3">
              <span className="text-xs text-slate-400 hidden sm:inline">Tutti i messaggi sono visibili alla comunità</span>
              <button
                onClick={() => setReportTarget({
                  id: `chat-${activeRoom}`,
                  username: `@moderazione_${activeRoom}`,
                  type: "user",
                })}
                className="px-2.5 py-1 rounded-xl bg-rose-950/40 hover:bg-rose-900/60 border border-rose-500/30 text-rose-300 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer"
                title="Segnala un comportamento illecito in questa stanza"
              >
                <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
                <span>Segnala Abuso</span>
              </button>
            </div>
          </div>

          {/* Messages Feed */}
          <div className="flex-1 overflow-y-auto space-y-4 pr-2">
            {filteredMessages.map((msg) => {
              const isMe = msg.author.username === currentUser.username;
              return (
                <div
                  key={msg.id}
                  className={`flex items-start gap-3.5 ${isMe ? "flex-row-reverse" : "flex-row"}`}
                >
                  <img
                    src={msg.author.avatar}
                    alt={msg.author.name}
                    className="w-10 h-10 rounded-full object-cover border-2 border-slate-700 shrink-0"
                  />
                  <div
                    className={`max-w-[78%] rounded-2xl p-4 text-sm sm:text-base ${
                      isMe
                        ? "bg-gradient-to-br from-emerald-500 to-teal-600 text-slate-950 font-medium rounded-tr-none shadow-lg"
                        : "bg-slate-950/95 border border-slate-800 text-slate-100 rounded-tl-none shadow"
                    }`}
                  >
                    <div className="flex items-center justify-between gap-4 mb-1.5">
                      <span className={`font-extrabold text-sm ${isMe ? "text-slate-950" : "text-emerald-400"}`}>
                        {msg.author.name}
                      </span>
                      <span className={`text-xs ${isMe ? "text-slate-900/80 font-medium" : "text-slate-500"}`}>
                        {msg.timestamp}
                      </span>
                    </div>

                    <p className="leading-relaxed whitespace-pre-wrap">{msg.text}</p>

                    {!isMe && (
                      <div className="mt-2.5 pt-2 border-t border-slate-800/80 flex items-center justify-end">
                        <button
                          onClick={() => setPrivateRecipient(msg.author.name)}
                          className="text-xs font-bold text-emerald-400 hover:text-emerald-300 flex items-center gap-1 cursor-pointer"
                        >
                          <MessageCircle className="w-3.5 h-3.5" />
                          <span>Contatto Diretto Privato 1-a-1</span>
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Form */}
          <form onSubmit={handleSend} className="mt-4 pt-4 border-t border-slate-800 flex items-center gap-3">
            <input
              type="text"
              placeholder="Scrivi un pensiero o messaggio chiaro nella comunità..."
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              className="flex-1 px-5 py-3.5 bg-slate-950 border border-slate-700/80 rounded-2xl text-sm sm:text-base text-white placeholder-slate-500 focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400"
            />
            <button
              type="submit"
              id="send-community-message-btn"
              className="px-6 py-3.5 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold text-sm sm:text-base transition-all shadow-lg shadow-emerald-500/20 flex items-center gap-2 cursor-pointer shrink-0"
            >
              <Send className="w-4 h-4" />
              <span>Invia</span>
            </button>
          </form>
        </div>
      ) : (
        /* 1-to-1 Private Direct Contact (When HAVE and WANT match) */
        <div className="p-6 sm:p-7 rounded-3xl bg-slate-900 border border-emerald-500/40 flex flex-col h-[560px] shadow-2xl">
          <div className="pb-4 mb-4 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-400">
                <UserCheck className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-extrabold text-white">Contatto Privato Diretto 1-a-1 con {privateRecipient}</h3>
                <p className="text-xs text-slate-400">Accordo riservato HAVE ↔ WANT (Nessuna quarta chat pubblica creata)</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setReportTarget({
                  id: `p2p-${privateRecipient}`,
                  username: privateRecipient || "@utente",
                  type: "user",
                })}
                className="px-3 py-2 rounded-xl bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-500/30 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                title="Segnala utente o richiesta illecita di denaro contante"
              >
                <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
                <span>Segnala Abuso</span>
              </button>

              <button
                onClick={() => setPrivateRecipient(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold"
              >
                Torna alle 3 Chat Pubbliche
              </button>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto space-y-4 pr-2">
            {privateHistory.map((m, idx) => {
              const isMe = m.sender === currentUser.name;
              return (
                <div key={idx} className={`flex ${isMe ? "justify-end" : "justify-start"}`}>
                  <div
                    className={`max-w-[75%] rounded-2xl p-4 text-sm ${
                      isMe
                        ? "bg-emerald-500 text-slate-950 font-medium rounded-tr-none"
                        : "bg-slate-950 border border-slate-800 text-slate-100 rounded-tl-none"
                    }`}
                  >
                    <div className="flex items-center justify-between gap-3 mb-1">
                      <span className="font-bold text-xs">{m.sender}</span>
                      <span className="text-[11px] opacity-75">{m.time}</span>
                    </div>
                    <p>{m.text}</p>
                  </div>
                </div>
              );
            })}
          </div>

          <form onSubmit={handleSendPrivate} className="mt-4 pt-4 border-t border-slate-800 flex items-center gap-3">
            <input
              type="text"
              placeholder={`Scrivi un messaggio privato a ${privateRecipient}...`}
              value={privateText}
              onChange={(e) => setPrivateText(e.target.value)}
              className="flex-1 px-5 py-3.5 bg-slate-950 border border-slate-700 rounded-2xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-400"
            />
            <button
              type="submit"
              className="px-6 py-3.5 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold text-sm flex items-center gap-2 cursor-pointer shrink-0"
            >
              <Send className="w-4 h-4" />
              <span>Invia Privato</span>
            </button>
          </form>
        </div>
      )}

      {/* Toast Feedback */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 p-4 rounded-2xl bg-emerald-950/90 border border-emerald-500/50 text-emerald-300 text-xs font-bold flex items-center gap-2 shadow-2xl animate-in fade-in slide-in-from-bottom duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Abuse Report & Moderation Modal */}
      {reportTarget && (
        <AbuseReportModal
          targetId={reportTarget.id}
          targetUsername={reportTarget.username}
          targetType={reportTarget.type}
          reporterUsername={currentUser.username}
          onReportSubmitted={(payload) => {
            onReportAbuse?.(payload);
            setReportTarget(null);
            setToastMessage(`Segnalazione inviata per ${payload.targetUsername}. Moderazione registrata.`);
            setTimeout(() => setToastMessage(null), 4500);
          }}
          onClose={() => setReportTarget(null)}
        />
      )}
    </div>
  );
};
