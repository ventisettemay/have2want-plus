import React, { useState, useEffect } from "react";
import {
  Sparkles,
  Trophy,
  Zap,
  Target,
  Gift,
  Compass,
  Star,
  Flame,
  Award,
  ChevronRight,
  RefreshCw,
  CheckCircle2,
  Lock,
  ArrowRight,
  Coins,
  PartyPopper
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { HaveWantListing } from "../types";

interface CosmicExpeditionHubProps {
  listings: HaveWantListing[];
  onOpenMatchFinder: () => void;
  onOpenRandomDiscovery: () => void;
  onQuickPublish: () => void;
  onSelectListing: (listing: HaveWantListing) => void;
}

interface ConstellationMission {
  id: string;
  title: string;
  subtitle: string;
  category: string;
  rewardExp: number;
  rewardPiBadge: string;
  iconName: string;
  progress: number;
  maxProgress: number;
  isCompleted: boolean;
  flavorText: string;
}

export const CosmicExpeditionHub: React.FC<CosmicExpeditionHubProps> = ({
  listings,
  onOpenMatchFinder,
  onOpenRandomDiscovery,
  onQuickPublish,
  onSelectListing,
}) => {
  const [level, setLevel] = useState(3);
  const [stardust, setStardust] = useState(420);
  const [activeSlotMachine, setActiveSlotMachine] = useState(false);
  const [slotResult, setSlotResult] = useState<{ have: HaveWantListing; want: HaveWantListing } | null>(null);
  const [showCelebration, setShowCelebration] = useState(false);

  // Gamified daily missions
  const [missions, setMissions] = useState<ConstellationMission[]>([
    {
      id: "m-1",
      title: "Esploratore delle Competenze",
      subtitle: "Trova un Pioniere con abilità di coding, artigianato o insegnamento",
      category: "Competenze",
      rewardExp: 50,
      rewardPiBadge: "Badge Saper Fare",
      iconName: "Zap",
      progress: 1,
      maxProgress: 1,
      isCompleted: true,
      flavorText: "Hai consultato il ramo delle competenze con successo.",
    },
    {
      id: "m-2",
      title: "Incrocio del Baratto Etico ↔",
      subtitle: "Trova un'intesa naturale tra ciò che offri e ciò che cerchi",
      category: "Baratto",
      rewardExp: 100,
      rewardPiBadge: "Nodo di Rete",
      iconName: "Target",
      progress: 2,
      maxProgress: 3,
      isCompleted: false,
      flavorText: "Attiva l'incrociatore di sincronicità per scoprire nuove corrispondenze.",
    },
    {
      id: "m-3",
      title: "Dono del Ramo Solidale",
      subtitle: "Scopri una risorsa a costo 0 nel ramo Terra o Strumenti",
      category: "Dono",
      rewardExp: 75,
      rewardPiBadge: "Foglia Solidale",
      iconName: "Gift",
      progress: 1,
      maxProgress: 2,
      isCompleted: false,
      flavorText: "La generosità senza intermediari rafforza le radici della comunità.",
    },
  ]);

  // Spin Cosmic Slot / Match Machine
  const spinCosmicWheel = () => {
    setActiveSlotMachine(true);
    setSlotResult(null);

    setTimeout(() => {
      const haveList = listings.filter((l) => l.type === "HAVE");
      const wantList = listings.filter((l) => l.type === "WANT");

      const randomHave = haveList[Math.floor(Math.random() * haveList.length)] || listings[0];
      const randomWant = wantList[Math.floor(Math.random() * wantList.length)] || listings[1] || listings[0];

      setSlotResult({ have: randomHave, want: randomWant });
      setActiveSlotMachine(false);
      setShowCelebration(true);
      setStardust((prev) => prev + 35);
      setTimeout(() => setShowCelebration(false), 4000);
    }, 1200);
  };

  return (
    <div className="relative rounded-[36px] overflow-hidden bg-gradient-to-b from-[#090b16] via-[#050811] to-[#02040a] border-2 border-emerald-500/50 shadow-[0_0_90px_rgba(16,185,129,0.2)] p-6 sm:p-8 space-y-8">
      
      {/* Background starlight & nebula effect */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_rgba(245,158,11,0.15),transparent_60%)] pointer-events-none" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_left,_rgba(16,185,129,0.15),transparent_60%)] pointer-events-none" />

      {/* Header Expedition Banner */}
      <div className="relative flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-slate-800/80">
        
        {/* Left: Avatar & Cosmic Level */}
        <div className="flex items-center gap-4">
          <div className="relative">
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-3xl bg-gradient-to-tr from-emerald-500 via-teal-400 to-amber-300 p-1 shadow-[0_0_35px_rgba(16,185,129,0.5)]">
              <div className="w-full h-full rounded-[22px] bg-slate-950 flex flex-col items-center justify-center text-center p-1">
                <span className="text-[10px] font-black uppercase tracking-widest text-emerald-400">Reputazione</span>
                <span className="text-xl sm:text-2xl font-black text-white font-mono leading-none">{level}★</span>
                <span className="text-[9px] font-bold text-slate-400">Pioniere</span>
              </div>
            </div>
            <div className="absolute -bottom-2 -right-1 px-2 py-0.5 rounded-full bg-emerald-400 text-slate-950 text-[10px] font-black shadow-md flex items-center gap-0.5">
              <CheckCircle2 className="w-3 h-3 fill-slate-950" /> Verificato
            </div>
          </div>

          <div>
            <div className="flex items-center gap-2 text-emerald-400 text-xs font-black uppercase tracking-widest">
              <Sparkles className="w-4 h-4 text-emerald-400" />
              Sincronicità & Incontri di Valore
            </div>
            <h2 className="text-xl sm:text-2xl lg:text-3xl font-black text-white tracking-tight mt-0.5">
              Incrocio Intelligente HAVE ↔ WANT
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-lg mt-0.5">
              Scopri corrispondenze inaspettate e crea collaborazioni dirette tra bisogni e risorse offerte dalla comunità dei Pionieri.
            </p>
          </div>
        </div>

        {/* Right: Cosmic Resources & Level Progress */}
        <div className="flex items-center gap-3 bg-slate-950/90 p-3 rounded-2xl border border-emerald-500/40 shadow-inner shrink-0">
          <div className="px-3 py-1.5 rounded-xl bg-amber-500/20 border border-amber-400/50 flex items-center gap-2">
            <Coins className="w-4 h-4 text-amber-400" />
            <div>
              <div className="text-[10px] uppercase font-bold text-amber-300">Punti Partecipazione</div>
              <div className="text-sm font-black text-white font-mono">{stardust} ✦</div>
            </div>
          </div>

          <div className="px-3 py-1.5 rounded-xl bg-emerald-500/20 border border-emerald-400/50 flex items-center gap-2">
            <Trophy className="w-4 h-4 text-emerald-300" />
            <div>
              <div className="text-[10px] uppercase font-bold text-emerald-300">Fiducia Rete</div>
              <div className="text-sm font-black text-white font-mono">100% Etico</div>
            </div>
          </div>
        </div>

      </div>

      {/* ========================================================================= */}
      {/* 2. L'ORACOLO DEI MATCH COSMICI (THE SYNCHRONICITY MACHINE)                */}
      {/* ========================================================================= */}
      <div className="relative rounded-3xl bg-gradient-to-r from-emerald-500/15 via-teal-600/15 to-amber-500/15 border-2 border-emerald-500/50 p-6 space-y-6 shadow-2xl backdrop-blur-md">
        
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-black text-emerald-400 uppercase tracking-wider">
              <Compass className="w-4 h-4 animate-spin text-emerald-400" />
              Incrociatore di Corrispondenze HAVE ↔ WANT
            </div>
            <h3 className="text-lg sm:text-xl font-black text-white mt-1">
              Calcola Sincronia tra Offerte e Richieste
            </h3>
            <p className="text-xs text-slate-300">
              Genera una combinazione ponderata tra un annuncio di offerta ed uno di ricerca per creare un'opportunità reale di scambio o baratto.
            </p>
          </div>

          <button
            onClick={spinCosmicWheel}
            disabled={activeSlotMachine}
            className={`px-6 py-3.5 rounded-2xl bg-gradient-to-r from-emerald-400 via-teal-400 to-amber-300 hover:from-emerald-300 hover:to-teal-300 text-slate-950 font-black text-sm shadow-[0_0_35px_rgba(16,185,129,0.4)] hover:scale-105 active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-2 shrink-0 ${
              activeSlotMachine ? "opacity-75 cursor-not-allowed animate-pulse" : ""
            }`}
          >
            <RefreshCw className={`w-4 h-4 stroke-[3] ${activeSlotMachine ? "animate-spin" : ""}`} />
            <span>{activeSlotMachine ? "Analisi Corrispondenze..." : "Incrocia Domanda & Offerta"}</span>
          </button>
        </div>

        {/* Dynamic Match Result Slot Box */}
        {slotResult && !activeSlotMachine && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            className="p-5 rounded-2xl bg-slate-950/90 border-2 border-amber-400/80 shadow-2xl space-y-4"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-amber-300 uppercase tracking-widest flex items-center gap-1.5">
                <PartyPopper className="w-4 h-4 text-amber-400" />
                Incrocio Magico Sincronizzato!
              </span>
              <span className="text-xs text-emerald-400 font-bold font-mono">Affinità Potenziale: 94%</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              
              {/* HAVE Slot */}
              <div
                onClick={() => onSelectListing(slotResult.have)}
                className="p-4 rounded-xl bg-emerald-500/15 border border-emerald-400/60 hover:border-emerald-300 transition-all cursor-pointer space-y-2 group"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black uppercase px-2.5 py-0.5 rounded-lg bg-emerald-500/30 text-emerald-300 border border-emerald-400/50">
                    HAVE • {slotResult.have.author.name} Offre
                  </span>
                  <span className="text-xs text-slate-400 font-bold">{slotResult.have.author.city}</span>
                </div>
                <div className="text-sm font-black text-white group-hover:text-emerald-300 transition-colors">
                  {slotResult.have.title}
                </div>
                <p className="text-xs text-slate-300 line-clamp-2">{slotResult.have.description}</p>
              </div>

              {/* WANT Slot */}
              <div
                onClick={() => onSelectListing(slotResult.want)}
                className="p-4 rounded-xl bg-purple-500/15 border border-purple-400/60 hover:border-purple-300 transition-all cursor-pointer space-y-2 group"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black uppercase px-2.5 py-0.5 rounded-lg bg-purple-500/30 text-purple-300 border border-purple-400/50">
                    WANT • {slotResult.want.author.name} Cerca
                  </span>
                  <span className="text-xs text-slate-400 font-bold">{slotResult.want.author.city}</span>
                </div>
                <div className="text-sm font-black text-white group-hover:text-purple-300 transition-colors">
                  {slotResult.want.title}
                </div>
                <p className="text-xs text-slate-300 line-clamp-2">{slotResult.want.description}</p>
              </div>

            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => onSelectListing(slotResult.have)}
                className="px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs flex items-center gap-1.5 transition-all shadow-md cursor-pointer"
              >
                <span>Esamina e Connetti</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

          </motion.div>
        )}

      </div>

      {/* ========================================================================= */}
      {/* 3. COSTELLAZIONI DELLE MISSIONI GIORNALIERE (MISSION CARDS)              */}
      {/* ========================================================================= */}
      <div className="space-y-4">
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-400" />
            <h3 className="text-base sm:text-lg font-black text-white">Missioni di Esplorazione Stellare</h3>
          </div>
          <span className="text-xs font-mono text-amber-300 font-bold">1 / 3 Completate</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {missions.map((mission) => (
            <div
              key={mission.id}
              className={`p-5 rounded-2xl border-2 transition-all flex flex-col justify-between space-y-4 ${
                mission.isCompleted
                  ? "bg-slate-950/80 border-emerald-400/60 shadow-lg shadow-emerald-500/10"
                  : "bg-slate-900/60 border-slate-800 hover:border-slate-700"
              }`}
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-md bg-slate-800 text-slate-300">
                    {mission.category}
                  </span>
                  {mission.isCompleted ? (
                    <span className="flex items-center gap-1 text-xs font-black text-emerald-400">
                      <CheckCircle2 className="w-4 h-4" /> Completata
                    </span>
                  ) : (
                    <span className="text-xs font-black text-amber-400">+{mission.rewardExp} EXP</span>
                  )}
                </div>

                <h4 className="text-sm font-black text-white">{mission.title}</h4>
                <p className="text-xs text-slate-400 leading-relaxed">{mission.subtitle}</p>
              </div>

              <div className="space-y-2 pt-2 border-t border-slate-800/80">
                {/* Progress bar */}
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all ${
                      mission.isCompleted ? "bg-emerald-400" : "bg-amber-400"
                    }`}
                    style={{ width: `${(mission.progress / mission.maxProgress) * 100}%` }}
                  />
                </div>
                <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
                  <span>Ricompensa: {mission.rewardPiBadge}</span>
                  <span className="font-bold text-white">
                    {mission.progress}/{mission.maxProgress}
                  </span>
                </div>
              </div>

            </div>
          ))}
        </div>

      </div>

    </div>
  );
};
