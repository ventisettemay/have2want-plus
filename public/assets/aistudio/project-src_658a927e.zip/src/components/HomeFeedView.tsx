import React, { useState, useMemo } from "react";
import {
  Search,
  Plus,
  MapPin,
  Sparkles,
  Coins,
  HeartHandshake,
  ShoppingBag,
  ArrowRight,
  ArrowLeft,
  X,
  Mic,
  MicOff,
  GraduationCap,
  Wrench,
  Car,
  Home,
  Laptop,
  Shirt,
  MessageSquare,
  Globe,
  ChevronDown,
  FlaskConical,
  CheckCircle2,
  Filter,
  Image as ImageIcon
} from "lucide-react";
import { Image as ImageIcon } from 'lucide-react';
import ecosystemPreviewImg from '@/assets/images/have2want_ecosystem_preview_1790282388717.jpg';
import { toast } from "sonner";
import { motion, AnimatePresence } from "motion/react";
import {
  HaveWantListing,
  InteractionIntent,
  RealCategoryKey,
  RealSubcategoryKey,
  PioneerUser,
  AbuseReportPayload
} from "../types";
import { REAL_CATEGORIES_MATRIX } from "../categories";
import { Country, COUNTRIES, getCountryForListing } from "@/data/countries";
import { ListingOriginBadge } from "@/components/have2want/ListingOriginBadge";
import { getListingOriginBadge } from "@/lib/listingOrigin";
import { PioneerRewardsHubModal } from "@/components/have2want/PioneerRewardsHubModal";
import { TerritorialAdBanner } from "@/components/have2want/TerritorialAdBanner";
import { ListingDetailModal } from "@/components/have2want/ListingDetailModal";

export type SectionKey = 'VENDO' | 'SCAMBIO' | 'CERCO' | 'TRASFERTE' | 'SERVIZI' | 'LIBRI' | 'ESTERNI' | 'ALL';

interface HomeFeedViewProps {
  listings: HaveWantListing[];
  currentUser: PioneerUser;
  onAddListing: (listing: HaveWantListing) => void;
  onSelectListingForTrade: (listing: HaveWantListing) => void;
  onNavigate?: (tab: string) => void;
  onReportAbuse?: (payload: AbuseReportPayload) => void;
  initialFilter?: string | null;
  onSectionSelect?: (section: string | null) => void;
  onOpenCarpoolModal?: () => void;
  onBackToMap?: () => void;
  selectedCountry?: Country | null;
  onSelectCountry?: (country: Country | null) => void;
  onOpenCountrySelector?: () => void;
}

export const HomeFeedView: React.FC<HomeFeedViewProps> = ({
  listings,
  currentUser,
  onAddListing,
  onSelectListingForTrade,
  onNavigate,
  initialFilter,
  onSectionSelect,
  onOpenCarpoolModal,
  onBackToMap,
  selectedCountry,
  onSelectCountry,
  onOpenCountrySelector
}) => {
  // Search & Filter States
  const [searchQuery, setSearchQuery] = useState("");
  const [isVoiceListening, setIsVoiceListening] = useState(false);
  const voiceRecRef = React.useRef<any>(null);
  const [dictatingField, setDictatingField] = useState<"title" | "description" | "exchange" | null>(null);

  // Auto-scroll morbido per le categorie della bacheca (rotazione continua)
  const sectionsBarRef = React.useRef<HTMLDivElement>(null);
  const [isSectionsHovered, setIsSectionsHovered] = useState(false);
  const sectionsDirectionRef = React.useRef(1);
  const sectionsPauseRef = React.useRef<any>(null);
  const sectionsIsPausedRef = React.useRef(false);

  React.useEffect(() => {
    if (isSectionsHovered) return;

    let animId: number;
    const runScroll = () => {
      const el = sectionsBarRef.current;
      if (el && !sectionsIsPausedRef.current) {
        const maxScroll = el.scrollWidth - el.clientWidth;
        if (maxScroll > 10) {
          if (sectionsDirectionRef.current === 1) {
            el.scrollLeft += 0.45;
            if (el.scrollLeft >= maxScroll - 2) {
              sectionsIsPausedRef.current = true;
              sectionsPauseRef.current = setTimeout(() => {
                sectionsDirectionRef.current = -1;
                sectionsIsPausedRef.current = false;
              }, 2500);
            }
          } else {
            el.scrollLeft -= 0.55;
            if (el.scrollLeft <= 2) {
              sectionsIsPausedRef.current = true;
              sectionsPauseRef.current = setTimeout(() => {
                sectionsDirectionRef.current = 1;
                sectionsIsPausedRef.current = false;
              }, 2500);
            }
          }
        }
      }
      animId = requestAnimationFrame(runScroll);
    };

    animId = requestAnimationFrame(runScroll);
    return () => {
      cancelAnimationFrame(animId);
      if (sectionsPauseRef.current) clearTimeout(sectionsPauseRef.current);
    };
  }, [isSectionsHovered]);

  const toggleVoiceSearch = () => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      toast.error("Riconoscimento vocale non supportato da questo browser.");
      return;
    }

    if (isVoiceListening) {
      if (voiceRecRef.current) {
        try {
          voiceRecRef.current.stop();
        } catch (e) {}
      }
      setIsVoiceListening(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = "it-IT";
      recognition.continuous = false;
      recognition.interimResults = false;

      recognition.onstart = () => setIsVoiceListening(true);
      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setSearchQuery(transcript);
        setIsVoiceListening(false);
        toast.success(`Ricerca vocale: "${transcript}"`);
      };
      recognition.onerror = () => setIsVoiceListening(false);
      recognition.onend = () => setIsVoiceListening(false);

      voiceRecRef.current = recognition;
      recognition.start();
    } catch (err) {
      setIsVoiceListening(false);
    }
  };

  const startVoiceDictation = (field: "title" | "description" | "exchange") => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      toast.error("Riconoscimento vocale non supportato.");
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = "it-IT";
      recognition.continuous = false;
      recognition.interimResults = false;

      recognition.onstart = () => setDictatingField(field);
      recognition.onresult = (event: any) => {
        const text = event.results[0][0].transcript;
        if (field === "title") setNewTitle(text);
        else if (field === "description") setNewDescription(text);
        else if (field === "exchange") setNewDesiredExchange(text);
        setDictatingField(null);
        toast.success("Dettatura acquisita!");
      };
      recognition.onerror = () => setDictatingField(null);
      recognition.onend = () => setDictatingField(null);

      recognition.start();
    } catch (err) {
      setDictatingField(null);
    }
  };

  // Sections & Categories
  const [selectedSection, setSelectedSection] = useState<SectionKey | null>(() => {
    if (!initialFilter) return null;
    const f = initialFilter.toUpperCase();
    if (f === 'VENDO') return 'VENDO';
    if (f === 'SCAMBIO' || f === 'BARATTO') return 'SCAMBIO';
    if (f === 'CERCO') return 'CERCO';
    if (f === 'TRASFERTE') return 'TRASFERTE';
    if (f === 'SERVIZI') return 'SERVIZI';
    if (f === 'LIBRI') return 'LIBRI';
    return null;
  });

  const handleSelectSection = (sec: SectionKey | null) => {
    setSelectedSection(sec);
    if (onSectionSelect) onSectionSelect(sec);
  };

  const [activeCategory, setActiveCategory] = useState<RealCategoryKey | "ALL">("ALL");
  const [activeProvince, setActiveProvince] = useState<string>("ALL");
  const [activeOriginFilter, setActiveOriginFilter] = useState<"ALL" | "REAL_ONLY" | "EXTERNAL_ONLY" | "DEMO_ONLY">("ALL");

  // Modals
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showRewardsHub, setShowRewardsHub] = useState(false);
  const [selectedListingForDetail, setSelectedListingForDetail] = useState<HaveWantListing | null>(null);
  const [quickContactListing, setQuickContactListing] = useState<HaveWantListing | null>(null);
  const [contactMessage, setContactMessage] = useState("");
  const [messageSentToast, setMessageSentToast] = useState(false);

  // New Listing Form State
  const [newTitle, setNewTitle] = useState("");
  const [newIntent, setNewIntent] = useState<InteractionIntent>("BARATTO_SCAMBIO");
  const [newCategory, setNewCategory] = useState<RealCategoryKey>("casa_fai_da_te");
  const [newSubcategory, setNewSubcategory] = useState<RealSubcategoryKey>("arredamento_mobili");
  const [newDescription, setNewDescription] = useState("");
  const [newPiPrice, setNewPiPrice] = useState<number>(0);
  const [newDesiredExchange, setNewDesiredExchange] = useState("");
  const [newCity, setNewCity] = useState(currentUser.city || "Asti");
  const [newProvince, setNewProvince] = useState(currentUser.province || "AT");
  const [newImageUrl, setNewImageUrl] = useState("");

  const getCategoryIcon = (catKey: RealCategoryKey) => {
    switch (catKey) {
      case "auto_moto_veicoli":
        return Car;
      case "casa_fai_da_te":
        return Home;
      case "elettronica_informatica":
        return Laptop;
      case "libri_scuola_cultura":
        return GraduationCap;
      case "servizi_lavoro_buoni":
        return Wrench;
      case "abbigliamento_accessori":
        return Shirt;
      case "rete_specialisti_supporto":
        return Sparkles;
      default:
        return ShoppingBag;
    }
  };

  // Section Counts
  const sectionCounts = useMemo(() => {
    const isVendo = (l: any) => l.intent === 'VENDO' || l.action_type === 'vendo';
    const isScambio = (l: any) => l.intent === 'BARATTO_SCAMBIO' || l.action_type === 'baratto' || l.action_type === 'baratto_scambio';
    const isCerco = (l: any) => l.intent === 'ACQUISTO_CERCO' || l.intent === 'CERCO' || l.action_type === 'acquisto_cerco';
    const isTrasferte = (l: any) =>
      (l.category === 'auto_moto_veicoli' && (l.subcategory === 'trasferte_passaggi_carpool' || l.tags?.includes('trasferte') || l.tags?.includes('carpool'))) ||
      (l.title && /trasfert|carpool|passagg/i.test(l.title));
    const isServizi = (l: any) =>
      l.category === 'servizi_lavoro_buoni' || l.category === 'rete_specialisti_supporto' || l.intent === 'OFFRO_SERVIZIO' ||
      (l.title && /serviz|lezion|riparaz|manodop/i.test(l.title));
    const isLibri = (l: any) =>
      l.category === 'libri_scuola_cultura' || (l.title && /libr|scuol|testi|manual/i.test(l.title));
    const isEsterni = (l: any) =>
      Boolean(l.isExternal || l.externalPortal || l.source_type === 'external');

    return {
      VENDO: listings.filter(isVendo).length,
      SCAMBIO: listings.filter(isScambio).length,
      CERCO: listings.filter(isCerco).length,
      TRASFERTE: listings.filter(isTrasferte).length,
      SERVIZI: listings.filter(isServizi).length,
      LIBRI: listings.filter(isLibri).length,
      ESTERNI: listings.filter(isEsterni).length,
      ALL: listings.length,
    };
  }, [listings]);

  // Filtered Listings
  const filteredListings = useMemo(() => {
    return listings.filter((listing: any) => {
      // 1. Section filter
      if (selectedSection === 'VENDO') {
        if (listing.intent !== 'VENDO' && listing.action_type !== 'vendo') return false;
      } else if (selectedSection === 'SCAMBIO') {
        if (listing.intent !== 'BARATTO_SCAMBIO' && listing.action_type !== 'baratto' && listing.action_type !== 'baratto_scambio') return false;
      } else if (selectedSection === 'CERCO') {
        if (listing.intent !== 'ACQUISTO_CERCO' && listing.intent !== 'CERCO' && listing.action_type !== 'acquisto_cerco') return false;
      } else if (selectedSection === 'TRASFERTE') {
        const isCarpool = (listing.category === 'auto_moto_veicoli' && (listing.subcategory === 'trasferte_passaggi_carpool' || listing.tags?.includes('trasferte') || listing.tags?.includes('carpool'))) ||
          (listing.title && /trasfert|carpool|passagg/i.test(listing.title));
        if (!isCarpool) return false;
      } else if (selectedSection === 'SERVIZI') {
        const isServizio = listing.category === 'servizi_lavoro_buoni' || listing.category === 'rete_specialisti_supporto' || listing.intent === 'OFFRO_SERVIZIO' ||
          (listing.title && /serviz|lezion|riparaz|manodop/i.test(listing.title));
        if (!isServizio) return false;
      } else if (selectedSection === 'LIBRI') {
        const isLibro = listing.category === 'libri_scuola_cultura' || (listing.title && /libr|scuol|testi|manual/i.test(listing.title));
        if (!isLibro) return false;
      } else if (selectedSection === 'ESTERNI') {
        const isExt = Boolean(listing.isExternal || listing.externalPortal || listing.source_type === 'external');
        if (!isExt) return false;
      }

      // 2. Category filter
      if (activeCategory !== "ALL" && listing.category !== activeCategory) {
        return false;
      }

      // 3. Province filter
      if (activeProvince !== "ALL" && listing.author?.province) {
        if (listing.author.province.toUpperCase() !== activeProvince.toUpperCase()) return false;
      }

      // 3.5. Country filter (selezionabile liberamente, non bloccato su Italia)
      if (selectedCountry && selectedCountry.id) {
        const itemCountry = getCountryForListing(listing, COUNTRIES);
        if (itemCountry && itemCountry.id && itemCountry.id.toLowerCase() !== selectedCountry.id.toLowerCase()) {
          return false;
        }
      }

      // 3.6. Filtro Origine/Provenienza (Tutti / Solo Reali / Solo Esterni / Solo Di Prova)
      if (activeOriginFilter !== "ALL") {
        const origin = getListingOriginBadge(listing);
        if (activeOriginFilter === "REAL_ONLY" && (origin.isExternal || origin.isDemo)) return false;
        if (activeOriginFilter === "EXTERNAL_ONLY" && !origin.isExternal) return false;
        if (activeOriginFilter === "DEMO_ONLY" && !origin.isDemo) return false;
      }

      // 4. Search query
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesTitle = (listing.title || "").toLowerCase().includes(query);
        const matchesDesc = (listing.description || "").toLowerCase().includes(query);
        const matchesAuthor = (listing.author?.name || "").toLowerCase().includes(query);
        const matchesTags = (listing.tags || []).some((t: string) => t.toLowerCase().includes(query));
        if (!matchesTitle && !matchesDesc && !matchesAuthor && !matchesTags) return false;
      }

      return true;
    });
  }, [listings, selectedSection, activeCategory, activeProvince, searchQuery, selectedCountry]);

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newDescription.trim()) return;

    const defaultImages: Record<string, string> = {
      casa_fai_da_te: "https://images.unsplash.com/photo-1581783342308-f792dbdd27c5?w=600&auto=format&fit=crop&q=80",
      auto_moto_veicoli: "https://images.unsplash.com/photo-1485965120184-e220f721d03e?w=600&auto=format&fit=crop&q=80",
      elettronica_informatica: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=600&auto=format&fit=crop&q=80",
      libri_scuola_cultura: "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=600&auto=format&fit=crop&q=80",
      servizi_lavoro_buoni: "https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=600&auto=format&fit=crop&q=80",
      abbigliamento_accessori: "https://images.unsplash.com/photo-1489987707025-afc232f7ea0f?w=600&auto=format&fit=crop&q=80",
      rete_specialisti_supporto: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=600&auto=format&fit=crop&q=80",
    };

    const created: HaveWantListing = {
      id: `listing-${Date.now()}`,
      intent: newIntent,
      title: newTitle.trim(),
      description: newDescription.trim(),
      category: newCategory,
      subcategory: newSubcategory,
      piPrice: newIntent === "VENDO" ? Number(newPiPrice) : 0,
      concreteExchange: newIntent !== "VENDO" && newDesiredExchange.trim() ? {
        offer: {
          item: newTitle.trim(),
          quantity: 1,
          unit: "pezzi",
          condition: "usato_ottimo",
        },
        wanted: {
          item: newDesiredExchange.trim(),
          quantity: 1,
          unit: "pezzi",
        },
        territorialScope: "citta_area",
      } : undefined,
      author: {
        name: currentUser.name,
        username: currentUser.username,
        avatar: currentUser.avatar,
        reputation: currentUser.reputationStars || 4.95,
        isPioneerVerified: true,
        city: newCity || "Asti",
        province: newProvince || "AT",
      },
      lat: 44.9008 + (Math.random() - 0.5) * 0.04,
      lng: 8.2065 + (Math.random() - 0.5) * 0.04,
      locationArea: `${newCity} (${newProvince})`,
      isFuzzyLocation: true,
      imageUrl: newImageUrl.trim() || defaultImages[newCategory] || defaultImages.casa_fai_da_te,
      createdAt: "Pochi istanti fa",
      tags: [newCategory, newIntent, newCity],
      status: "active",
      planetId: "planet-possibilita",
      satelliteId: "sat-oggetti",
    };

    onAddListing(created);
    setShowCreateModal(false);
    setNewTitle("");
    setNewDescription("");
    setNewDesiredExchange("");
    setNewPiPrice(0);
    setNewImageUrl("");
    toast.success("Annuncio pubblicato!");
  };

  const handleSendQuickMessage = () => {
    if (!quickContactListing || !contactMessage.trim()) return;
    setMessageSentToast(true);
    setTimeout(() => {
      setMessageSentToast(false);
      setQuickContactListing(null);
      setContactMessage("");
    }, 1500);
  };

  const SECTIONS_CATALOG = [
    {
      key: 'VENDO' as SectionKey,
      title: 'VENDO con Pi',
      subtitle: 'Beni, tecnologia, oggetti per la casa con pagamenti diretti.',
      count: sectionCounts.VENDO,
      icon: Coins,
    },
    {
      key: 'SCAMBIO' as SectionKey,
      title: 'SCAMBIO',
      subtitle: 'Scambio diretto senza denaro: proponi quello che hai in cambio.',
      count: sectionCounts.SCAMBIO,
      icon: HeartHandshake,
    },
    {
      key: 'CERCO' as SectionKey,
      title: 'CERCO',
      subtitle: 'Richieste e bisogni specifici inseriti dalla comunità.',
      count: sectionCounts.CERCO,
      icon: Sparkles,
    },
    {
      key: 'TRASFERTE' as SectionKey,
      title: 'TRASFERTE & CARPOOL',
      subtitle: 'Passaggi condivisi da città a città a zero commissioni.',
      count: sectionCounts.TRASFERTE,
      icon: Car,
    },
    {
      key: 'SERVIZI' as SectionKey,
      title: 'SERVIZI & COMPETENZE',
      subtitle: 'Manodopera, lezioni, riparazioni pratiche e supporto.',
      count: sectionCounts.SERVIZI,
      icon: Wrench,
    },
    {
      key: 'LIBRI' as SectionKey,
      title: 'LIBRI & SCUOLA',
      subtitle: 'Scambio e donazione testi scolastici, saggi e manuali.',
      count: sectionCounts.LIBRI,
      icon: GraduationCap,
    },
    {
      key: 'ESTERNI' as SectionKey,
      title: 'ESTERNI (Portali Terzi)',
      subtitle: 'Annunci sincronizzati da portali esterni (Subito, eBay, ecc.).',
      count: sectionCounts.ESTERNI,
      icon: Globe,
    },
    {
      key: 'ALL' as SectionKey,
      title: 'TUTTI GLI ANNUNCI',
      subtitle: 'Tutte le categorie e proposte attive in bacheca.',
      count: sectionCounts.ALL,
      icon: ShoppingBag,
    },
  ];

  return (
    <div className="w-full min-h-screen bg-black text-white flex flex-col selection:bg-[#00ff66] selection:text-black">
      
      {/* 1. TOP BAR INTEGRATA (SOLO NERO, NEON, BIANCO - SENZA CORNICETTE) */}
      <header className="sticky top-0 z-30 w-full bg-black/95 backdrop-blur-md px-4 sm:px-8 py-3.5 flex flex-col md:flex-row items-center justify-between gap-3 border-b border-zinc-900">
        
        {/* Sinistra: Ritorno Mappa & Brand */}
        <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-start">
          {onBackToMap && (
            <button
              onClick={onBackToMap}
              className="px-3 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-[#00ff66] text-xs font-black flex items-center gap-2 transition-all cursor-pointer"
              title="Torna alla Mappa 3D"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Mappa 3D</span>
            </button>
          )}

          <div className="flex items-center gap-2">
            <span className="text-sm sm:text-base font-black tracking-tight text-white">
              HAVE2WANT <span className="text-[#00ff66]">ANNUNCI</span>
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setShowRewardsHub(true)}
              className="md:hidden px-2.5 py-1.5 rounded-xl bg-amber-400/20 border border-amber-400/40 text-amber-300 font-black text-xs flex items-center gap-1 transition-transform active:scale-95 cursor-pointer"
              title="Hub Punti Comunitari e Prelievo Pi"
            >
              <Coins className="w-3.5 h-3.5 text-amber-400" />
              <span>π Hub</span>
            </button>
            <button
              onClick={() => setShowCreateModal(true)}
              className="md:hidden px-3 py-2 rounded-xl bg-[#00ff66] text-black font-black text-xs flex items-center gap-1.5 transition-transform active:scale-95 cursor-pointer"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <span>Pubblica</span>
            </button>
          </div>
        </div>

        {/* Centro: Barra Ricerca Grande, Visibile e Voce */}
        <div className="relative w-full md:max-w-xl flex items-center rounded-2xl border-2 border-zinc-700 focus-within:border-[#00ff66] bg-zinc-900 transition-all shadow-md">
          <Search className="w-4 h-4 text-[#00ff66] absolute left-3.5 pointer-events-none stroke-[2.5]" />
          <input
            type="text"
            placeholder="Cerca cosa ti serve (es. libro, bicicletta, riparazione...)"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-24 py-2.5 rounded-2xl bg-transparent text-white text-xs sm:text-sm font-medium placeholder-zinc-400 focus:outline-none transition-all"
          />
          <div className="absolute right-2 flex items-center gap-1.5">
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery("")}
                className="p-1 text-zinc-400 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
            <button
              type="button"
              onClick={toggleVoiceSearch}
              className={`p-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                isVoiceListening
                  ? "bg-[#00ff66] text-black animate-pulse"
                  : "text-zinc-400 hover:text-[#00ff66]"
              }`}
              title="Ricerca Vocale"
            >
              {isVoiceListening ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        {/* Destra: Desktop Pubblica Annuncio & Hub Pi Network */}
        <div className="hidden md:flex items-center gap-2.5">
          <button
            onClick={() => setShowRewardsHub(true)}
            className="px-3.5 py-2 rounded-xl bg-amber-400/15 hover:bg-amber-400/25 border border-amber-400/40 text-amber-300 font-black text-xs flex items-center gap-2 transition-transform active:scale-95 cursor-pointer shadow-sm"
            title="Hub Punti Comunitari & Prelievo Pi su Wallet"
          >
            <Coins className="w-4 h-4 text-amber-400" />
            <span>π Punti & Prelievo (0.50 π)</span>
          </button>
          <button
            onClick={() => setShowCreateModal(true)}
            className="px-4 py-2 rounded-xl bg-[#00ff66] hover:bg-[#00e65c] text-black font-black text-xs flex items-center gap-2 transition-transform active:scale-95 cursor-pointer shadow-sm"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>Pubblica Annuncio</span>
          </button>
        </div>
      </header>

      {/* Banner Ecosistema HAVE2WANT */}
      <div className="w-full px-4 sm:px-8 pb-6">
        <div className="max-w-7xl mx-auto">
          <div className="relative rounded-3xl overflow-hidden border border-amber-500/30 bg-gradient-to-br from-amber-950/20 via-slate-900/50 to-slate-900">
            <img
              src={ecosystemPreviewImg}
              alt="HAVE2WANT Ecosystem Preview"
              className="w-full h-48 sm:h-64 md:h-80 object-cover opacity-90"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
            <div className="absolute bottom-4 left-4 right-4 text-center">
              <h2 className="text-lg sm:text-2xl font-black text-white mb-1">HAVE2WANT ECOSYSTEM</h2>
              <p className="text-xs sm:text-sm text-amber-300/90 max-w-2xl mx-auto">
                L'ecosistema dove le persone si scambiano valore reale: beni, servizi, competenze e tempo. Tutto in π, niente euro.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* 2. CORPO PRINCIPALE: O LE SEZIONI/CATEGORIE O GLI ANNUNCI FILTRATI */}
      <main className="flex-1 w-full px-4 sm:px-8 py-6 max-w-none">

        {/* CASO A: NESSUNA SEZIONE SELEZIONATA E NESSUNA RICERCA ATTIVA -> 3 SCHEDE CHIAVE CHIARE E INTUITIVE */}
        {selectedSection === null && !searchQuery.trim() ? (
          <div className="w-full space-y-8 animate-in fade-in duration-200 max-w-6xl mx-auto">
            
            <div className="space-y-1 text-center sm:text-left">
              <h1 className="text-xl sm:text-3xl font-black tracking-tight text-white">
                Cosa vuoi fare oggi?
              </h1>
              <p className="text-xs sm:text-sm text-zinc-400">
                Scegli tra le 3 opzioni principali per entrare subito a vedere gli annunci.
              </p>
            </div>

            {/* LE 3 GRANDI SCHEDE REGINE: VENDO • SCAMBIO • CERCO */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6">
              {/* 1. VENDO */}
              <button
                onClick={() => handleSelectSection('VENDO')}
                className="p-6 sm:p-7 rounded-3xl bg-zinc-950 hover:bg-[#0c1f13] border-2 border-emerald-500/40 hover:border-[#00ff66] transition-all text-left flex flex-col justify-between gap-6 cursor-pointer group shadow-xl hover:shadow-[#00ff66]/10"
              >
                <div className="flex items-center justify-between">
                  <div className="w-12 h-12 rounded-2xl bg-emerald-950 border border-emerald-500/40 text-[#00ff66] flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Coins className="w-6 h-6 stroke-[2.5]" />
                  </div>
                  <span className="text-xs font-mono font-black px-3 py-1.5 rounded-full bg-emerald-950/80 border border-emerald-500/50 text-[#00ff66]">
                    {sectionCounts.VENDO} annunci
                  </span>
                </div>

                <div className="space-y-1.5">
                  <div className="flex items-center gap-2">
                    <span className="w-3.5 h-3.5 rounded-full bg-[#00ff66]" />
                    <h2 className="text-xl sm:text-2xl font-black text-white group-hover:text-[#00ff66] transition-colors">
                      VENDO
                    </h2>
                  </div>
                  <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed">
                    Cosa offrono gli utenti: beni, oggetti, artigianato e prodotti locali disponibili subito.
                  </p>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-zinc-800">
                  <span className="text-xs font-black text-[#00ff66] group-hover:underline">
                    Entra e vedi annunci
                  </span>
                  <ArrowRight className="w-4 h-4 text-[#00ff66] group-hover:translate-x-1.5 transition-transform" />
                </div>
              </button>

              {/* 2. SCAMBIO */}
              <button
                onClick={() => handleSelectSection('SCAMBIO')}
                className="p-6 sm:p-7 rounded-3xl bg-zinc-950 hover:bg-[#1f190a] border-2 border-amber-500/40 hover:border-amber-400 transition-all text-left flex flex-col justify-between gap-6 cursor-pointer group shadow-xl hover:shadow-amber-400/10"
              >
                <div className="flex items-center justify-between">
                  <div className="w-12 h-12 rounded-2xl bg-amber-950 border border-amber-500/40 text-amber-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <HeartHandshake className="w-6 h-6 stroke-[2.5]" />
                  </div>
                  <span className="text-xs font-mono font-black px-3 py-1.5 rounded-full bg-amber-950/80 border border-amber-500/50 text-amber-400">
                    {sectionCounts.SCAMBIO} annunci
                  </span>
                </div>

                <div className="space-y-1.5">
                  <div className="flex items-center gap-2">
                    <span className="w-3.5 h-3.5 rounded-full bg-amber-400" />
                    <h2 className="text-xl sm:text-2xl font-black text-white group-hover:text-amber-400 transition-colors">
                      SCAMBIO
                    </h2>
                  </div>
                  <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed">
                    Scambi diretti senza denaro: proponi ciò che hai in cambio di ciò che ti serve.
                  </p>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-zinc-800">
                  <span className="text-xs font-black text-amber-400 group-hover:underline">
                    Entra e vedi annunci
                  </span>
                  <ArrowRight className="w-4 h-4 text-amber-400 group-hover:translate-x-1.5 transition-transform" />
                </div>
              </button>

              {/* 3. CERCO */}
              <button
                onClick={() => handleSelectSection('CERCO')}
                className="p-6 sm:p-7 rounded-3xl bg-zinc-950 hover:bg-[#0a1526] border-2 border-blue-500/40 hover:border-blue-400 transition-all text-left flex flex-col justify-between gap-6 cursor-pointer group shadow-xl hover:shadow-blue-400/10"
              >
                <div className="flex items-center justify-between">
                  <div className="w-12 h-12 rounded-2xl bg-blue-950 border border-blue-500/40 text-blue-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Sparkles className="w-6 h-6 stroke-[2.5]" />
                  </div>
                  <span className="text-xs font-mono font-black px-3 py-1.5 rounded-full bg-blue-950/80 border border-blue-500/50 text-blue-400">
                    {sectionCounts.CERCO} annunci
                  </span>
                </div>

                <div className="space-y-1.5">
                  <div className="flex items-center gap-2">
                    <span className="w-3.5 h-3.5 rounded-full bg-blue-400" />
                    <h2 className="text-xl sm:text-2xl font-black text-white group-hover:text-blue-400 transition-colors">
                      CERCO
                    </h2>
                  </div>
                  <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed">
                    Richieste e bisogni specifici inseriti dalle persone della tua zona da soddisfare.
                  </p>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-zinc-800">
                  <span className="text-xs font-black text-blue-400 group-hover:underline">
                    Entra e vedi annunci
                  </span>
                  <ArrowRight className="w-4 h-4 text-blue-400 group-hover:translate-x-1.5 transition-transform" />
                </div>
              </button>
            </div>

            {/* SEZIONI SPECIALI RAPIDE (LIBRI, TRASFERTE, SERVIZI) */}
            <div className="pt-4 space-y-3">
              <h3 className="text-xs font-black uppercase tracking-wider text-zinc-400">
                Sezioni Speciali della Comunità
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <button
                  onClick={() => handleSelectSection('LIBRI')}
                  className="p-4 rounded-2xl bg-zinc-900/80 hover:bg-zinc-850 border border-zinc-800 hover:border-zinc-700 transition-all text-left flex items-center justify-between cursor-pointer group"
                >
                  <div className="flex items-center gap-3">
                    <GraduationCap className="w-5 h-5 text-purple-400 group-hover:scale-110 transition-transform" />
                    <div>
                      <h4 className="text-sm font-bold text-white">📚 Libri & Testi Scolastici</h4>
                      <p className="text-[11px] text-zinc-400">Scambio e adozione testi usati</p>
                    </div>
                  </div>
                  <span className="text-xs font-mono font-bold text-zinc-400">{sectionCounts.LIBRI}</span>
                </button>

                <button
                  onClick={() => handleSelectSection('TRASFERTE')}
                  className="p-4 rounded-2xl bg-zinc-900/80 hover:bg-zinc-850 border border-zinc-800 hover:border-zinc-700 transition-all text-left flex items-center justify-between cursor-pointer group"
                >
                  <div className="flex items-center gap-3">
                    <Car className="w-5 h-5 text-emerald-400 group-hover:scale-110 transition-transform" />
                    <div>
                      <h4 className="text-sm font-bold text-white">🚗 Passaggi Auto & Viaggi</h4>
                      <p className="text-[11px] text-zinc-400">Carpooling tra città e borghi</p>
                    </div>
                  </div>
                  <span className="text-xs font-mono font-bold text-zinc-400">{sectionCounts.TRASFERTE}</span>
                </button>

                <button
                  onClick={() => handleSelectSection('SERVIZI')}
                  className="p-4 rounded-2xl bg-zinc-900/80 hover:bg-zinc-850 border border-zinc-800 hover:border-zinc-700 transition-all text-left flex items-center justify-between cursor-pointer group"
                >
                  <div className="flex items-center gap-3">
                    <Wrench className="w-5 h-5 text-orange-400 group-hover:scale-110 transition-transform" />
                    <div>
                      <h4 className="text-sm font-bold text-white">🛠️ Servizi & Riparazioni</h4>
                      <p className="text-[11px] text-zinc-400">Manodopera, lezioni e assistenza</p>
                    </div>
                  </div>
                  <span className="text-xs font-mono font-bold text-zinc-400">{sectionCounts.SERVIZI}</span>
                </button>
              </div>
            </div>

            {/* Catalogo Categorie Merceologiche Dirette */}
            <div className="space-y-3 pt-4">
              <h2 className="text-sm font-bold uppercase tracking-wider text-zinc-400">
                Oppure sfoglia per Categoria Merceologica
              </h2>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7 gap-2.5">
                {REAL_CATEGORIES_MATRIX.map((cat) => {
                  const Icon = getCategoryIcon(cat.key);
                  return (
                    <button
                      key={cat.key}
                      onClick={() => {
                        setActiveCategory(cat.key);
                        handleSelectSection('ALL');
                      }}
                      className="p-4 rounded-xl bg-[#0e0e11] hover:bg-[#16161b] transition-colors text-left flex flex-col items-start gap-2 cursor-pointer group"
                    >
                      <Icon className="w-5 h-5 text-zinc-400 group-hover:text-[#00ff66] transition-colors" />
                      <span className="text-xs font-bold text-white group-hover:text-[#00ff66] transition-colors line-clamp-1">
                        {cat.label}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

          </div>
        ) : (
          /* CASO B: SEZIONE O RICERCA ATTIVA -> ELENCO ANNUNCI PULITO CON FILTRI */
          <div className="w-full space-y-6 animate-in fade-in duration-200">
            
            {/* Barra Superiore di Navigazione e Filtri */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-2xl bg-[#0e0e11]">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => {
                    handleSelectSection(null);
                    setActiveCategory("ALL");
                    setSearchQuery("");
                  }}
                  className="px-3.5 py-2 rounded-xl bg-black hover:bg-zinc-900 text-[#00ff66] text-xs font-black flex items-center gap-2 transition-colors cursor-pointer shrink-0"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Tutte le Categorie</span>
                </button>

                <div>
                  <span className="text-xs text-zinc-400 block font-medium">Visualizzando:</span>
                  <span className="text-sm sm:text-base font-black text-white">
                    {selectedSection === 'VENDO' && 'VENDO con Pi Coin'}
                    {selectedSection === 'SCAMBIO' && 'SCAMBIO & BARATTO'}
                    {selectedSection === 'CERCO' && 'CERCO'}
                    {selectedSection === 'TRASFERTE' && 'TRASFERTE & PASSAGGI'}
                    {selectedSection === 'SERVIZI' && 'SERVIZI & COMPETENZE'}
                    {selectedSection === 'LIBRI' && 'LIBRI & SCUOLA'}
                    {selectedSection === 'ALL' && 'TUTTI GLI ANNUNCI'}
                    {!selectedSection && searchQuery && `Ricerca: "${searchQuery}"`}
                  </span>
                </div>
              </div>

              {/* Filtri Nazione, Provincia e Reset */}
              <div className="flex items-center gap-2 self-end sm:self-center flex-wrap">
                {onOpenCountrySelector && (
                  <button
                    onClick={onOpenCountrySelector}
                    className="px-3 py-2 rounded-xl bg-black hover:bg-zinc-900 text-white text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer border-0"
                    title="Cambia Paese / Nazione"
                  >
                    <span>{selectedCountry ? selectedCountry.flag : '🌍'}</span>
                    <span className="uppercase">{selectedCountry ? selectedCountry.name : 'Tutti i Paesi'}</span>
                    <ChevronDown className="w-3.5 h-3.5 text-[#00ff66]" />
                  </button>
                )}

                <select
                  value={activeProvince}
                  onChange={(e) => setActiveProvince(e.target.value)}
                  className="px-3 py-2 rounded-xl bg-black text-white text-xs font-bold focus:outline-none cursor-pointer border-0"
                >
                  <option value="ALL">Tutte le Province</option>
                  <option value="AT">Asti (AT)</option>
                  <option value="TO">Torino (TO)</option>
                  <option value="CN">Cuneo (CN)</option>
                  <option value="AL">Alessandria (AL)</option>
                  <option value="MI">Milano (MI)</option>
                  <option value="RM">Roma (RM)</option>
                  <option value="BO">Bologna (BO)</option>
                  <option value="FI">Firenze (FI)</option>
                </select>

                <button
                  onClick={() => {
                    handleSelectSection(null);
                    setActiveCategory("ALL");
                    setActiveProvince("ALL");
                    setSearchQuery("");
                    if (onSelectCountry) onSelectCountry(null);
                  }}
                  className="px-3 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 text-xs font-bold transition-colors cursor-pointer"
                >
                  Azzera
                </button>
              </div>
            </div>

            {/* Quick Pills di Switch Sezione (Rotazione Morbida Automatica con Pausa al Tocco) */}
            <div
              ref={sectionsBarRef}
              onMouseEnter={() => setIsSectionsHovered(true)}
              onMouseLeave={() => setIsSectionsHovered(false)}
              onTouchStart={() => setIsSectionsHovered(true)}
              onTouchEnd={() => setTimeout(() => setIsSectionsHovered(false), 2000)}
              className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none touch-pan-x"
            >
              {SECTIONS_CATALOG.map((sec) => (
                <button
                  key={sec.key}
                  onClick={() => handleSelectSection(sec.key)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold shrink-0 transition-all cursor-pointer ${
                    selectedSection === sec.key
                      ? "bg-[#00ff66] text-black font-black shadow-[0_0_12px_rgba(0,255,102,0.3)]"
                      : "bg-[#0e0e11] text-zinc-300 hover:text-white hover:bg-zinc-900 border border-zinc-900"
                  }`}
                >
                  {sec.title} ({sec.count})
                </button>
              ))}
            </div>

            {/* SELETTORE RAPIDO: FONTE & NATURA ANNUNCIO (TUTTI / REALI P2P / ESTERNI / DI PROVA) */}
            <div className="flex flex-wrap items-center justify-between gap-2 px-3 py-2 rounded-xl bg-[#0a0a0d] border border-zinc-900 text-xs">
              <div className="flex items-center gap-2 text-zinc-400 font-bold shrink-0">
                <Filter className="w-3.5 h-3.5 text-[#00ff66]" />
                <span>Filtra per Fonte:</span>
              </div>
              <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none">
                <button
                  onClick={() => setActiveOriginFilter("ALL")}
                  className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-colors cursor-pointer ${
                    activeOriginFilter === "ALL"
                      ? "bg-white text-black font-black"
                      : "bg-zinc-900 text-zinc-400 hover:text-white"
                  }`}
                >
                  Tutte le fonti
                </button>
                <button
                  onClick={() => setActiveOriginFilter("REAL_ONLY")}
                  className={`px-2.5 py-1 rounded-lg font-bold text-[11px] flex items-center gap-1 transition-colors cursor-pointer ${
                    activeOriginFilter === "REAL_ONLY"
                      ? "bg-emerald-500 text-black font-black"
                      : "bg-zinc-900 text-emerald-400 hover:bg-zinc-800"
                  }`}
                >
                  <CheckCircle2 className="w-3 h-3" />
                  <span>Solo Reali P2P</span>
                </button>
                <button
                  onClick={() => setActiveOriginFilter("EXTERNAL_ONLY")}
                  className={`px-2.5 py-1 rounded-lg font-bold text-[11px] flex items-center gap-1 transition-colors cursor-pointer ${
                    activeOriginFilter === "EXTERNAL_ONLY"
                      ? "bg-amber-400 text-black font-black"
                      : "bg-zinc-900 text-amber-300 hover:bg-zinc-800"
                  }`}
                >
                  <Globe className="w-3 h-3" />
                  <span>Solo Esterni</span>
                </button>
                <button
                  onClick={() => setActiveOriginFilter("DEMO_ONLY")}
                  className={`px-2.5 py-1 rounded-lg font-bold text-[11px] flex items-center gap-1 transition-colors cursor-pointer ${
                    activeOriginFilter === "DEMO_ONLY"
                      ? "bg-sky-400 text-black font-black"
                      : "bg-zinc-900 text-sky-300 hover:bg-zinc-800"
                  }`}
                >
                  <FlaskConical className="w-3 h-3" />
                  <span>Solo Di Prova</span>
                </button>
              </div>
            </div>

            {/* BANNER PUBBLICITARIO TERRITORIALE & REWARD PI */}
            <TerritorialAdBanner
              onOpenRewardsHub={() => setShowRewardsHub(true)}
              variant="feed_inline"
            />

            {/* Griglia Annunci (Nero, Neon, Bianco - NO cornicette) */}
            {filteredListings.length === 0 ? (
              <div className="p-12 rounded-2xl bg-[#0e0e11] text-center space-y-3">
                <ShoppingBag className="w-10 h-10 text-zinc-600 mx-auto" />
                <h3 className="text-base font-bold text-white">Nessun annuncio presente per questi parametri</h3>
                <p className="text-xs text-zinc-400">
                  Vuoi essere il primo a pubblicare in questa categoria?
                </p>
                <button
                  onClick={() => setShowCreateModal(true)}
                  className="px-4 py-2 rounded-xl bg-[#00ff66] text-black font-black text-xs"
                >
                  Pubblica Annuncio Ora
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {filteredListings.map((item) => {
                  const isVendo = item.intent === "VENDO";
                  const isBaratto = item.intent === "BARATTO_SCAMBIO";
                  return (
                    <div
                      key={item.id}
                      onClick={() => setSelectedListingForDetail(item)}
                      className="rounded-2xl bg-[#0e0e11] hover:bg-[#15151a] overflow-hidden transition-all flex flex-col justify-between group cursor-pointer border border-zinc-900 hover:border-zinc-700"
                    >
                      {/* Immagine con badge neon */}
                      <div className="relative h-44 w-full bg-black overflow-hidden shrink-0">
                        <img
                          src={item.imageUrl || "https://images.unsplash.com/photo-1581783342308-f792dbdd27c5?w=600&auto=format&fit=crop&q=80"}
                          alt={item.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                        <div className="absolute top-2.5 left-2.5 right-2.5 flex items-center justify-between gap-2">
                          <span className="text-[10px] font-black uppercase px-2.5 py-1 rounded-md bg-[#00ff66] text-black">
                            {isVendo ? `VENDO • ${item.piPrice} π` : isBaratto ? "SCAMBIO" : "CERCO"}
                          </span>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-black/80 text-white backdrop-blur-md">
                            {item.author.city || "Asti"}
                          </span>
                        </div>
                      </div>

                      {/* Informazioni Annuncio */}
                      <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                        <div className="space-y-1.5">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <ListingOriginBadge listing={item} size="xs" />
                            {item.category && (
                              <span className="text-[10px] text-zinc-500 font-mono">
                                {item.category.replace(/_/g, ' ')}
                              </span>
                            )}
                          </div>
                          <h3 className="text-sm sm:text-base font-bold text-white line-clamp-1 group-hover:text-[#00ff66] transition-colors">
                            {item.title}
                          </h3>
                          <p className="text-xs text-zinc-400 line-clamp-2 leading-relaxed">
                            {item.description}
                          </p>
                        </div>

                        {item.concreteExchange?.itemOrServiceAccepted && (
                          <div className="p-2.5 rounded-xl bg-black text-xs text-[#00ff66]">
                            <span className="font-bold text-white block text-[10px] mb-0.5">Accetta in baratto:</span>
                            <span className="line-clamp-1">{item.concreteExchange.itemOrServiceAccepted}</span>
                          </div>
                        )}

                        {/* Autore e Azioni (Nero, Neon, Bianco) */}
                        <div className="pt-3 border-t border-zinc-900 space-y-3">
                          <div className="flex items-center justify-between text-xs text-zinc-400">
                            <span>{item.author.name}</span>
                            <span className="text-[10px]">{item.createdAt}</span>
                          </div>

                          <div className="grid grid-cols-2 gap-2">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                onSelectListingForTrade(item);
                              }}
                              className="py-2 px-3 rounded-xl bg-[#00ff66] hover:bg-[#00e65c] text-black font-black text-xs text-center transition-colors cursor-pointer"
                            >
                              Proponi Baratto
                            </button>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setQuickContactListing(item);
                              }}
                              className="py-2 px-3 rounded-xl bg-white hover:bg-zinc-200 text-black font-bold text-xs text-center transition-colors cursor-pointer"
                            >
                              Contatta
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

          </div>
        )}

      </main>

      {/* 3. MODAL: CREA NUOVO ANNUNCIO (NERO, NEON, BIANCO - SENZA CORNICETTE) */}
      <AnimatePresence>
        {showCreateModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-lg bg-[#0e0e11] rounded-2xl p-6 space-y-5 text-white my-8 relative shadow-2xl"
            >
              <div className="flex items-center justify-between pb-3 border-b border-zinc-900">
                <div>
                  <h3 className="text-base font-black text-white">Pubblica Nuovo Annuncio</h3>
                  <p className="text-xs text-zinc-400">Zero commissioni bancarie • P2P Diretto</p>
                </div>
                <button
                  onClick={() => setShowCreateModal(false)}
                  className="p-1.5 rounded-lg bg-black text-zinc-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleCreateSubmit} className="space-y-4">
                
                {/* 3 Intenti Principali */}
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setNewIntent("VENDO")}
                    className={`py-2.5 px-2 rounded-xl font-black text-xs transition-colors cursor-pointer ${
                      newIntent === "VENDO"
                        ? "bg-[#00ff66] text-black"
                        : "bg-black text-zinc-400 hover:text-white"
                    }`}
                  >
                    VENDO (Pi)
                  </button>
                  <button
                    type="button"
                    onClick={() => setNewIntent("BARATTO_SCAMBIO")}
                    className={`py-2.5 px-2 rounded-xl font-black text-xs transition-colors cursor-pointer ${
                      newIntent === "BARATTO_SCAMBIO"
                        ? "bg-[#00ff66] text-black"
                        : "bg-black text-zinc-400 hover:text-white"
                    }`}
                  >
                    SCAMBIO
                  </button>
                  <button
                    type="button"
                    onClick={() => setNewIntent("ACQUISTO_CERCO")}
                    className={`py-2.5 px-2 rounded-xl font-black text-xs transition-colors cursor-pointer ${
                      newIntent === "ACQUISTO_CERCO"
                        ? "bg-[#00ff66] text-black"
                        : "bg-black text-zinc-400 hover:text-white"
                    }`}
                  >
                    CERCO
                  </button>
                </div>

                {/* Titolo */}
                <div>
                  <div className="flex items-center justify-between mb-1 text-xs font-bold text-zinc-300">
                    <span>Titolo</span>
                    <button
                      type="button"
                      onClick={() => startVoiceDictation("title")}
                      className="text-[10px] text-[#00ff66] hover:underline"
                    >
                      {dictatingField === "title" ? "Ascolto..." : "Dettatura Vocale"}
                    </button>
                  </div>
                  <input
                    type="text"
                    required
                    placeholder="Es: Bicicletta da città, Lezioni di Chitarra, Trapano..."
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-black text-white text-xs sm:text-sm focus:outline-none focus:ring-1 focus:ring-[#00ff66]"
                  />
                </div>

                {/* Categoria & Prezzo/Scambio */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-zinc-300 mb-1">Categoria</label>
                    <select
                      value={newCategory}
                      onChange={(e) => {
                        const catKey = e.target.value as RealCategoryKey;
                        setNewCategory(catKey);
                        const catObj = REAL_CATEGORIES_MATRIX.find((c) => c.key === catKey);
                        if (catObj && catObj.subcategories[0]) {
                          setNewSubcategory(catObj.subcategories[0].key as RealSubcategoryKey);
                        }
                      }}
                      className="w-full px-3 py-2.5 rounded-xl bg-black text-white text-xs focus:outline-none cursor-pointer"
                    >
                      {REAL_CATEGORIES_MATRIX.map((c) => (
                        <option key={c.key} value={c.key}>{c.label}</option>
                      ))}
                    </select>
                  </div>

                  {newIntent === "VENDO" ? (
                    <div>
                      <label className="block text-xs font-bold text-zinc-300 mb-1">Prezzo Pi Coin (π)</label>
                      <input
                        type="number"
                        min="0"
                        step="0.5"
                        required
                        value={newPiPrice}
                        onChange={(e) => setNewPiPrice(Number(e.target.value))}
                        className="w-full px-3 py-2.5 rounded-xl bg-black text-[#00ff66] font-mono font-bold text-xs focus:outline-none"
                      />
                    </div>
                  ) : (
                    <div>
                      <label className="block text-xs font-bold text-zinc-300 mb-1">Cosa accetti in cambio</label>
                      <input
                        type="text"
                        placeholder="Es: Altri attrezzi, libri, aiuto..."
                        value={newDesiredExchange}
                        onChange={(e) => setNewDesiredExchange(e.target.value)}
                        className="w-full px-3 py-2.5 rounded-xl bg-black text-white text-xs focus:outline-none focus:ring-1 focus:ring-[#00ff66]"
                      />
                    </div>
                  )}
                </div>

                {/* Descrizione */}
                <div>
                  <div className="flex items-center justify-between mb-1 text-xs font-bold text-zinc-300">
                    <span>Descrizione</span>
                    <button
                      type="button"
                      onClick={() => startVoiceDictation("description")}
                      className="text-[10px] text-[#00ff66] hover:underline"
                    >
                      {dictatingField === "description" ? "Ascolto..." : "Dettatura Vocale"}
                    </button>
                  </div>
                  <textarea
                    rows={3}
                    required
                    placeholder="Descrivi lo stato dell'oggetto, caratteristiche o dettagli..."
                    value={newDescription}
                    onChange={(e) => setNewDescription(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-black text-white text-xs sm:text-sm focus:outline-none focus:ring-1 focus:ring-[#00ff66]"
                  />
                </div>

                {/* Città */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-zinc-300 mb-1">Città</label>
                    <input
                      type="text"
                      value={newCity}
                      onChange={(e) => setNewCity(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-black text-white text-xs focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-zinc-300 mb-1">Provincia</label>
                    <input
                      type="text"
                      maxLength={2}
                      value={newProvince}
                      onChange={(e) => setNewProvince(e.target.value.toUpperCase())}
                      className="w-full px-3 py-2 rounded-xl bg-black text-white text-xs uppercase focus:outline-none"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowCreateModal(false)}
                    className="px-4 py-2.5 rounded-xl bg-black hover:bg-zinc-900 text-zinc-400 text-xs font-bold"
                  >
                    Annulla
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2.5 rounded-xl bg-[#00ff66] hover:bg-[#00e65c] text-black text-xs font-black"
                  >
                    Pubblica Ora
                  </button>
                </div>

              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 4. MODAL: CONTATTO RAPIDO CHAT */}
      <AnimatePresence>
        {quickContactListing && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-md bg-[#0e0e11] rounded-2xl p-6 space-y-4 text-white relative shadow-2xl"
            >
              <div className="flex items-center justify-between pb-3 border-b border-zinc-900">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-black text-white">Contatta {quickContactListing.author.name}</h3>
                    <ListingOriginBadge listing={quickContactListing} size="xs" />
                  </div>
                  <p className="text-xs text-zinc-400 truncate">{quickContactListing.title}</p>
                </div>
                <button
                  onClick={() => setQuickContactListing(null)}
                  className="p-1.5 rounded-lg bg-black text-zinc-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {messageSentToast ? (
                <div className="p-6 text-center space-y-2">
                  <span className="text-2xl">✓</span>
                  <p className="text-sm font-bold text-[#00ff66]">Messaggio inviato con successo!</p>
                </div>
              ) : (
                <div className="space-y-3">
                  <textarea
                    rows={4}
                    placeholder="Scrivi il tuo messaggio o accordo diretto..."
                    value={contactMessage}
                    onChange={(e) => setContactMessage(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-black text-white text-xs sm:text-sm focus:outline-none focus:ring-1 focus:ring-[#00ff66]"
                  />
                  <div className="flex items-center justify-end gap-2">
                    <button
                      onClick={() => setQuickContactListing(null)}
                      className="px-4 py-2 rounded-xl bg-black text-zinc-400 text-xs font-bold"
                    >
                      Annulla
                    </button>
                    <button
                      onClick={handleSendQuickMessage}
                      className="px-4 py-2 rounded-xl bg-[#00ff66] text-black text-xs font-black"
                    >
                      Invia Messaggio
                    </button>
                  </div>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* HUB DEDICATO PUNTI COMUNITARI & PRELIEVO PI NETWORK (0.50 Pi SOGLIA) */}
      <PioneerRewardsHubModal
        isOpen={showRewardsHub}
        onClose={() => setShowRewardsHub(false)}
        onOpenCreateListing={() => setShowCreateModal(true)}
      />

      {/* SCHEDA DETTAGLIO COMPLETA DELL'ANNUNCIO (DENTRO L'OFFERTA) */}
      {selectedListingForDetail && (
        <ListingDetailModal
          isOpen={!!selectedListingForDetail}
          listing={{
            id: selectedListingForDetail.id,
            title: selectedListingForDetail.title,
            description: selectedListingForDetail.description,
            category: selectedListingForDetail.category || 'Generale',
            price: selectedListingForDetail.price,
            currency: '€',
            imageUrl: selectedListingForDetail.imageUrl,
            images: selectedListingForDetail.images || [],
            city: selectedListingForDetail.author?.city || 'Territorio Locale',
            authorName: selectedListingForDetail.author?.name,
            authorUsername: selectedListingForDetail.author?.username,
            originType: selectedListingForDetail.originType,
            piPrice: selectedListingForDetail.piPrice,
            wantsInExchange: selectedListingForDetail.concreteExchange?.itemOrServiceAccepted,
          }}
          onClose={() => setSelectedListingForDetail(null)}
          onProposeBarter={() => {
            if (selectedListingForDetail) {
              onSelectListingForTrade(selectedListingForDetail);
            }
          }}
          onContactSeller={() => {
            if (selectedListingForDetail) {
              setQuickContactListing(selectedListingForDetail);
            }
          }}
        />
      )}

    </div>
  );
};
