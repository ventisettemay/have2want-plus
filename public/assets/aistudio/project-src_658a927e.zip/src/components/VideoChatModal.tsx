import React, { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  X, Video, Mic, MicOff, Settings, Minimize, Maximize2, 
  Volume2, VolumeX, Users, MoreHorizontal, Monitor, PhoneOff,
  Wifi, WifiOff, AlertCircle, CheckCircle2
} from "lucide-react";

interface VideoChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  listingId: string;
  otherUserName: string;
  otherUserAvatar?: string;
  currentUserId: string;
}

interface SignalingMessage {
  type: 'offer' | 'answer' | 'ice-candidate' | 'join' | 'leave' | 'user-joined' | 'user-left';
  payload: any;
  from: string;
  to: string;
  listingId: string;
}

export function VideoChatModal({ 
  isOpen, 
  onClose, 
  listingId, 
  otherUserName, 
  otherUserAvatar,
  currentUserId 
}: VideoChatModalProps) {
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [connectionState, setConnectionState] = useState<'connecting' | 'connected' | 'disconnected' | 'failed'>('connecting');
  const [peerConnection, setPeerConnection] = useState<RTCPeerConnection | null>(null);
  const [signalingConnected, setSignalingConnected] = useState(false);
  const [remoteUserId, setRemoteUserId] = useState<string | null>(null);
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  const websocketRef = useRef<WebSocket | null>(null);
  const iceCandidatesQueueRef = useRef<RTCIceCandidate[]>([]);

  const ICE_SERVERS = {
    iceServers: [
      { urls: 'stun:stun.l.google.com:19302' },
      { urls: 'stun:stun1.l.google.com:19302' },
      { urls: 'stun:stun2.l.google.com:19302' },
    ]
  };

  // URL del signaling server (in produzione usa WSS)
  const SIGNALING_SERVER_URL = typeof window !== 'undefined' 
    ? `wss://${window.location.hostname}:8443/signaling` 
    : 'wss://localhost:8443/signaling';

  // Inizializza connessione WebSocket per signaling
  const initializeSignaling = useCallback(() => {
    if (websocketRef.current?.readyState === WebSocket.OPEN) return;

    try {
      const ws = new WebSocket(SIGNALING_SERVER_URL);
      websocketRef.current = ws;

      ws.onopen = () => {
        console.log('[Signaling] Connesso al server');
        setSignalingConnected(true);
        setConnectionState('connecting');
        
        // Unisciti alla stanza del listing
        ws.send(JSON.stringify({
          type: 'join',
          payload: { listingId },
          from: currentUserId,
          to: '',
          listingId
        } as SignalingMessage));
      };

      ws.onmessage = async (event) => {
        try {
          const message: SignalingMessage = JSON.parse(event.data);
          await handleSignalingMessage(message);
        } catch (err) {
          console.error('[Signaling] Errore parsing messaggio:', err);
        }
      };

      ws.onclose = () => {
        console.log('[Signaling] Disconnesso dal server');
        setSignalingConnected(false);
        if (connectionState !== 'disconnected') {
          setConnectionState('failed');
        }
      };

      ws.onerror = (error) => {
        console.error('[Signaling] Errore WebSocket:', error);
        setSignalingConnected(false);
        setConnectionState('failed');
      };
    } catch (err) {
      console.error('[Signaling] Impossibile connettersi:', err);
      setConnectionState('failed');
    }
  }, [currentUserId, listingId]);

  // Gestisce i messaggi di signaling ricevuti
  const handleSignalingMessage = useCallback(async (message: SignalingMessage) => {
    const pc = peerConnection;
    if (!pc) return;

    switch (message.type) {
      case 'user-joined':
        console.log('[Signaling] Utente unito:', message.from);
        setRemoteUserId(message.from);
        // Se siamo l'iniziatore, creiamo l'offer
        if (message.from !== currentUserId) {
          await createAndSendOffer();
        }
        break;

      case 'offer':
        console.log('[Signaling] Ricevuto offer da:', message.from);
        setRemoteUserId(message.from);
        await pc.setRemoteDescription(new RTCSessionDescription(message.payload));
        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);
        sendSignalingMessage('answer', answer, message.from);
        break;

      case 'answer':
        console.log('[Signaling] Ricevuto answer da:', message.from);
        await pc.setRemoteDescription(new RTCSessionDescription(message.payload));
        setConnectionState('connected');
        // Processa eventuali ICE candidates in coda
        processIceCandidatesQueue();
        break;

      case 'ice-candidate':
        console.log('[Signaling] Ricevuto ICE candidate da:', message.from);
        const candidate = new RTCIceCandidate(message.payload);
        if (pc.remoteDescription) {
          await pc.addIceCandidate(candidate);
        } else {
          iceCandidatesQueueRef.current.push(candidate);
        }
        break;

      case 'user-left':
        console.log('[Signaling] Utente disconnesso:', message.from);
        if (message.from === remoteUserId) {
          handleRemoteDisconnect();
        }
        break;
    }
  }, [peerConnection, currentUserId]);

  // Crea e invia l'offer SDP
  const createAndSendOffer = async () => {
    const pc = peerConnection;
    if (!pc || !remoteUserId) return;

    try {
      const offer = await pc.createOffer({
        offerToReceiveAudio: true,
        offerToReceiveVideo: true
      });
      await pc.setLocalDescription(offer);
      sendSignalingMessage('offer', offer, remoteUserId);
    } catch (err) {
      console.error('[WebRTC] Errore creazione offer:', err);
      setConnectionState('failed');
    }
  };

  // Processa la coda di ICE candidates
  const processIceCandidatesQueue = async () => {
    const pc = peerConnection;
    if (!pc) return;

    while (iceCandidatesQueueRef.current.length > 0) {
      const candidate = iceCandidatesQueueRef.current.shift()!;
      try {
        await pc.addIceCandidate(candidate);
      } catch (err) {
        console.error('[WebRTC] Errore aggiunta ICE candidate:', err);
      }
    }
  };

  // Invia messaggio tramite WebSocket
  const sendSignalingMessage = useCallback((type: SignalingMessage['type'], payload: any, to: string) => {
    const ws = websocketRef.current;
    if (ws?.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({
        type,
        payload,
        from: currentUserId,
        to,
        listingId
      } as SignalingMessage));
    }
  }, [currentUserId, listingId]);

  // Inizializza media (camera/microfono)
  const initializeMedia = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { 
          width: { ideal: 1280 }, 
          height: { ideal: 720 }, 
          facingMode: 'user' 
        },
        audio: { 
          echoCancellation: true, 
          noiseSuppression: true, 
          autoGainControl: true 
        }
      });
      setLocalStream(stream);
      if (localVideoRef.current) {
        localVideoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.error('[WebRTC] Errore accesso media:', err);
      setConnectionState('failed');
    }
  };

  // Inizializza RTCPeerConnection
  const initializePeerConnection = () => {
    const pc = new RTCPeerConnection(ICE_SERVERS);
    setPeerConnection(pc);

    // Aggiungi tracce locali
    if (localStream) {
      localStream.getTracks().forEach(track => {
        pc.addTrack(track, localStream);
      });
    }

    // Gestisci stream remoto
    pc.ontrack = (event) => {
      console.log('[WebRTC] Ricevuto stream remoto');
      const [remoteStream] = event.streams;
      setRemoteStream(remoteStream);
      if (remoteVideoRef.current) {
        remoteVideoRef.current.srcObject = remoteStream;
      }
      setConnectionState('connected');
    };

    // Gestisci ICE candidates
    pc.onicecandidate = (event) => {
      if (event.candidate && remoteUserId) {
        sendSignalingMessage('ice-candidate', event.candidate.toJSON(), remoteUserId);
      }
    };

    // Monitora stato connessione
    pc.onconnectionstatechange = () => {
      console.log('[WebRTC] Stato connessione:', pc.connectionState);
      switch (pc.connectionState) {
        case 'connected':
          setConnectionState('connected');
          break;
        case 'disconnected':
        case 'failed':
          setConnectionState('failed');
          break;
        case 'closed':
          setConnectionState('disconnected');
          break;
      }
    };

    pc.oniceconnectionstatechange = () => {
      console.log('[WebRTC] ICE connection state:', pc.iceConnectionState);
    };
  };

  // Gestisce disconnessione remota
  const handleRemoteDisconnect = () => {
    setRemoteStream(null);
    setRemoteUserId(null);
    if (remoteVideoRef.current) {
      remoteVideoRef.current.srcObject = null;
    }
    setConnectionState('disconnected');
  };

  // Cleanup completo
  const cleanup = useCallback(() => {
    // Chiudi WebSocket
    if (websocketRef.current) {
      websocketRef.current.send(JSON.stringify({
        type: 'leave',
        payload: { listingId },
        from: currentUserId,
        to: remoteUserId || '',
        listingId
      } as SignalingMessage));
      websocketRef.current.close();
      websocketRef.current = null;
    }
    setSignalingConnected(false);

    // Ferma stream locali
    if (localStream) {
      localStream.getTracks().forEach(track => track.stop());
      setLocalStream(null);
    }

    // Chiudi peer connection
    if (peerConnection) {
      peerConnection.close();
      setPeerConnection(null);
    }

    setRemoteStream(null);
    setRemoteUserId(null);
    iceCandidatesQueueRef.current = [];
    setConnectionState('connecting');
  }, [localStream, peerConnection, currentUserId, listingId, remoteUserId]);

  // Effect principale
  useEffect(() => {
    if (isOpen) {
      initializeMedia();
      initializePeerConnection();
      // Aspetta un po' che il peer connection sia pronto, poi connetti signaling
      setTimeout(initializeSignaling, 100);
    } else {
      cleanup();
    }
    return () => cleanup();
  }, [isOpen, initializeSignaling, cleanup]);

  // Toggle audio
  const toggleMute = () => {
    if (localStream) {
      const audioTrack = localStream.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = !audioTrack.enabled;
        setIsMuted(!audioTrack.enabled);
      }
    }
  };

  // Toggle video
  const toggleVideo = () => {
    if (localStream) {
      const videoTrack = localStream.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.enabled = !videoTrack.enabled;
        setIsVideoOff(!videoTrack.enabled);
      }
    }
  };

  // Condivisione schermo
  const toggleScreenShare = async () => {
    const pc = peerConnection;
    if (!pc) return;

    try {
      if (!isScreenSharing) {
        const screenStream = await navigator.mediaDevices.getDisplayMedia({
          video: { cursor: 'always' },
          audio: true
        });
        
        const screenTrack = screenStream.getVideoTracks()[0];
        const sender = pc.getSenders().find(s => s.track?.kind === 'video');
        
        if (sender) {
          await sender.replaceTrack(screenTrack);
        }
        
        screenTrack.onended = () => {
          toggleScreenShare(); // Torna alla camera quando l'utente ferma la condivisione
        };
        
        setIsScreenSharing(true);
      } else {
        // Torna alla camera
        if (localStream) {
          const videoTrack = localStream.getVideoTracks()[0];
          const sender = pc.getSenders().find(s => s.track?.kind === 'video');
          if (sender && videoTrack) {
            await sender.replaceTrack(videoTrack);
          }
        }
        setIsScreenSharing(false);
      }
    } catch (err) {
      console.error('[WebRTC] Errore screen share:', err);
      setIsScreenSharing(false);
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-sm p-2"
        role="dialog"
        aria-modal="true"
        aria-label="Videochiamata"
      >
        <motion.div
          className="w-full max-w-4xl h-[90vh] max-h-[90vh] rounded-2xl bg-slate-950 border border-slate-800 overflow-hidden flex flex-col relative"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 20, opacity: 0 }}
        >
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-900/50 backdrop-blur-sm">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center">
                {otherUserAvatar ? (
                  <img src={otherUserAvatar} alt={otherUserName} className="w-10 h-10 rounded-xl object-cover" />
                ) : (
                  <span className="text-xl font-bold text-white">{otherUserName.charAt(0)}</span>
                )}
              </div>
              <div>
                <h3 className="font-bold text-white">{otherUserName}</h3>
                <div className="flex items-center gap-2 text-xs">
                  <span className={`flex items-center gap-1 ${
                    connectionState === 'connected' ? 'text-emerald-400' :
                    connectionState === 'connecting' ? 'text-amber-400' :
                    'text-red-400'
                  }`}>
                    {connectionState === 'connected' && <CheckCircle2 className="w-3 h-3" />}
                    {connectionState === 'connecting' && <Wifi className="w-3 h-3 animate-pulse" />}
                    {connectionState === 'failed' && <AlertCircle className="w-3 h-3" />}
                    {connectionState === 'disconnected' && <WifiOff className="w-3 h-3" />}
                    <span className="capitalize">
                      {connectionState === 'connected' ? 'Connesso' :
                       connectionState === 'connecting' ? 'Connessione...' :
                       connectionState === 'failed' ? 'Fallita' : 'Disconnesso'}
                    </span>
                  </span>
                  {signalingConnected && (
                    <span className="text-sky-400 flex items-center gap-1">
                      <Wifi className="w-3 h-3" />
                      Signaling
                    </span>
                  )}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={onClose}
                className="p-3 rounded-xl bg-red-500/20 hover:bg-red-500/30 text-red-400 hover:text-red-300 transition-colors"
                title="Chiudi chiamata"
                aria-label="Chiudi chiamata"
              >
                <PhoneOff className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Area Video */}
          <div className="flex-1 flex relative overflow-hidden">
            {/* Video remoto (principale) */}
            <div className="flex-1 w-full relative bg-black">
              <video
                ref={remoteVideoRef}
                autoPlay
                playsInline
                className="w-full h-full object-cover"
                style={{ 
                  transform: 'scaleX(-1)', // Specchia per sembrare uno specchio
                  opacity: remoteStream ? 1 : 0,
                  transition: 'opacity 0.3s ease'
                }}
              />
              {!remoteStream && (
                <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-500 bg-slate-900/50">
                  <Users className="w-16 h-16 mb-4 opacity-50" />
                  <p className="text-lg font-medium">In attesa di {otherUserName}...</p>
                  <p className="text-sm mt-2">La videochiamata inizierà quando entrambi sarete connessi</p>
                  {connectionState === 'failed' && (
                    <div className="mt-4 p-4 bg-red-500/10 border border-red-500/30 rounded-xl text-red-400 text-center max-w-xs">
                      <AlertCircle className="w-5 h-5 mx-auto mb-2" />
                      <p>Connessione fallita. Verifica la rete e riprova.</p>
                    </div>
                  )}
                </div>
              )}
              
              {/* Indicatore recording/streaming */}
              {isScreenSharing && (
                <div className="absolute top-4 left-4 flex items-center gap-2 bg-sky-500/20 border border-sky-500/50 text-sky-400 px-3 py-1.5 rounded-xl text-xs font-medium backdrop-blur">
                  <Monitor className="w-4 h-4" />
                  <span>Condivisione schermo attiva</span>
                </div>
              )}
            </div>

            {/* Video locale (picture-in-picture) */}
            <div className="absolute bottom-4 right-4 w-48 h-36 md:w-64 md:h-48 rounded-xl overflow-hidden border-2 border-slate-700 bg-black z-10 shadow-2xl">
              <video
                ref={localVideoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover"
                style={{ transform: 'scaleX(-1)' }}
              />
              {isVideoOff && (
                <div className="absolute inset-0 flex items-center justify-center bg-black/70">
                  <Video className="w-8 h-8 text-red-400" />
                </div>
              )}
            </div>
          </div>

          {/* Controlli */}
          <div className="flex items-center justify-center gap-3 p-4 border-t border-slate-800 bg-slate-900/50 backdrop-blur-sm">
            <button
              onClick={toggleMute}
              className={`p-3 rounded-xl transition-colors ${
                isMuted
                  ? 'bg-red-500/20 text-red-400 border border-red-500/50'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
              }`}
              title={isMuted ? 'Attiva microfono' : 'Disattiva microfono'}
              aria-label={isMuted ? 'Attiva microfono' : 'Disattiva microfono'}
            >
              {isMuted ? <MicOff className="w-5 h-5 text-red-400" /> : <Mic className="w-5 h-5" />}
            </button>

            <button
              onClick={toggleVideo}
              className={`p-3 rounded-xl transition-colors ${
                isVideoOff
                  ? 'bg-red-500/20 text-red-400 border border-red-500/50'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
              }`}
              title={isVideoOff ? 'Attiva video' : 'Disattiva video'}
              aria-label={isVideoOff ? 'Attiva video' : 'Disattiva video'}
            >
              {isVideoOff ? <Video className="w-5 h-5 text-red-400" /> : <Video className="w-5 h-5" />}
            </button>

            <button
              onClick={toggleScreenShare}
              className={`p-3 rounded-xl transition-colors ${
                isScreenSharing
                  ? 'bg-sky-500/20 text-sky-400 border border-sky-500/50'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
              }`}
              title={isScreenSharing ? 'Stop condivisione schermo' : 'Condividi schermo'}
              aria-label={isScreenSharing ? 'Stop condivisione schermo' : 'Condividi schermo'}
            >
              {isScreenSharing ? (
                <span className="flex items-center gap-1.5 text-sm font-medium">
                  <Monitor className="w-4 h-4" />
                  <span>Condivisione</span>
                </span>
              ) : (
                <Monitor className="w-5 h-5" />
              )}
            </button>

            <button
              onClick={onClose}
              className="p-3 rounded-xl bg-red-500/20 hover:bg-red-500/30 text-red-400 hover:text-red-300 transition-colors"
              title="Chiudi chiamata"
              aria-label="Chiudi chiamata"
            >
              <PhoneOff className="w-5 h-5" />
            </button>
          </div>
        </motion.div>
      </AnimatePresence>
    </AnimatePresence>
  );
}

export default VideoChatModal;
