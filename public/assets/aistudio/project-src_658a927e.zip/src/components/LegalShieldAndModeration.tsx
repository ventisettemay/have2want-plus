import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  ShieldAlert,
  ShieldCheck,
  Scale,
  Stethoscope,
  Lock,
  Globe2,
  CheckCircle2,
  AlertTriangle,
  FileCheck,
  Sparkles,
  ArrowRight,
  Ban,
  UserX,
  X,
  Send
} from "lucide-react";
import {
  LegalShieldAgreement,
  AbuseReportPayload,
  AbuseReportReason,
  BannedAccountRecord,
  PioneerUser
} from "../types";
import { LegalWelcomeShield } from "./LegalWelcomeShield";
import { AbuseReportModal } from "./AbuseReportModal";

interface LegalShieldAndModerationProps {
  currentUser: PioneerUser;
  isAgreementAccepted: boolean;
  onAcceptAgreement: (agreement: LegalShieldAgreement) => void;
  onBanUserTriggered?: (record: BannedAccountRecord) => void;
}

export const LegalShieldAndModeration: React.FC<LegalShieldAndModerationProps> = ({
  currentUser,
  isAgreementAccepted,
  onAcceptAgreement,
  onBanUserTriggered,
}) => {
  const [showLegalDetails, setShowLegalDetails] = useState<boolean>(false);
  const [activeReportTarget, setActiveReportTarget] = useState<{
    id: string;
    username: string;
    type: "listing" | "specialist" | "chat_user";
    title?: string;
  } | null>(null);

  const [bannedRecords, setBannedRecords] = useState<BannedAccountRecord[]>([
    {
      username: "@spammer_bot_fake",
      reason: "Richiesta indebita di valuta fiat (Euro) e spam ripetuto",
      bannedAt: new Date(Date.now() - 86400000).toISOString(),
      reportCount: 4,
      averageRating: 2.1,
      purgedListingIds: ["list-spam-001", "list-spam-002"],
    },
  ]);

  const handleProcessAbuseReport = (payload: AbuseReportPayload) => {
    // Check if auto-ban condition is met (Critical violation or multiple complaints)
    const isCritical =
      payload.reason === "richiesta_valuta_fiat_euro" ||
      payload.reason === "categoria_illegale_proibita" ||
      payload.reason === "molestie_comportamento_inappropriato";

    if (isCritical) {
      const banRecord: BannedAccountRecord = {
        username: payload.targetUsername,
        reason: payload.reasonLabel,
        bannedAt: new Date().toISOString(),
        reportCount: 1,
        averageRating: 2.5,
        purgedListingIds: [payload.targetId],
      };

      setBannedRecords((prev) => [banRecord, ...prev]);
      onBanUserTriggered?.(banRecord);
    }
  };

  return (
    <div className="w-full space-y-6 font-sans">
      {/* Top Banner: Status of Legal Shield & Moderation Engine */}
      <div className="p-6 rounded-3xl bg-slate-950 border border-slate-800 shadow-2xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center shadow-inner">
              <Scale className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black text-white">
                  Scudo Legale, Privacy GDPR & Moderazione P2P
                </h3>
                <span className="text-[10px] uppercase font-mono font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Attivo • v2.4 PROD
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Presidio normativo di non-responsabilità, tutela sanitaria solidale e auto-ban a difesa della mappa 3D.
              </p>
            </div>
          </div>

          <button
            onClick={() => setShowLegalDetails(true)}
            className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-emerald-300 text-xs font-bold border border-emerald-500/30 flex items-center gap-2 transition-all cursor-pointer shadow-sm self-start sm:self-auto"
          >
            <FileCheck className="w-4 h-4" />
            <span>Riesamina Termini & Clausole</span>
          </button>
        </div>

        {/* 3 Pillars Summary Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          
          {/* Pillar 1: Esonero P2P */}
          <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2">
            <div className="flex items-center gap-2 text-amber-400 font-bold">
              <ShieldAlert className="w-4 h-4" />
              <span>Bacheca P2P Neutra</span>
            </div>
            <p className="text-slate-400 leading-relaxed">
              Esonero totale da responsabilità civile/penale per usura, difformità o liceità dei beni scambiati tra utenti.
            </p>
          </div>

          {/* Pillar 2: Scudo Sanitario */}
          <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2">
            <div className="flex items-center gap-2 text-teal-300 font-bold">
              <Stethoscope className="w-4 h-4" />
              <span>Scudo Specialisti Solidali</span>
            </div>
            <p className="text-slate-400 leading-relaxed">
              Consigli e orientamenti di primo ascolto che non costituiscono e non sostituiscono in alcun modo diagnosi cliniche o ricette.
            </p>
          </div>

          {/* Pillar 3: Privacy Fuzzy */}
          <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2">
            <div className="flex items-center gap-2 text-sky-400 font-bold">
              <Lock className="w-4 h-4" />
              <span>Privacy Territoriale GDPR</span>
            </div>
            <p className="text-slate-400 leading-relaxed">
              Divieto di tracciamento di indirizzi civici privati. Geocoding municipale basato solo su gerarchia testuale reale.
            </p>
          </div>

        </div>

        {/* Moderation & Banned Accounts Log */}
        <div className="p-4 rounded-2xl bg-slate-900/40 border border-rose-500/20 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-rose-300 font-bold text-xs">
              <Ban className="w-4 h-4 text-rose-400" />
              <span>Registro Auto-Ban & Purga Marker 3D</span>
            </div>
            <span className="text-[10px] font-mono text-slate-400">
              Soglia critica: Rating &lt; 3.8★ o infrazione grave
            </span>
          </div>

          <div className="space-y-2">
            {bannedRecords.map((record) => (
              <div
                key={record.username}
                className="p-3 rounded-xl bg-slate-950 border border-rose-500/30 flex items-center justify-between text-xs"
              >
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-white">{record.username}</span>
                    <span className="text-[9px] uppercase px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-300 font-mono font-bold">
                      Bannato
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400">{record.reason}</p>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-500 font-mono block">
                    Marker revocati: {record.purgedListingIds.length}
                  </span>
                  <span className="text-[10px] text-amber-400 font-mono font-bold">
                    Rating: {record.averageRating}★
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Entry Gate / Legal Welcome Shield Modal */}
      {(!isAgreementAccepted || showLegalDetails) && (
        <LegalWelcomeShield
          onAcceptTerms={(agreement) => {
            onAcceptAgreement(agreement);
            setShowLegalDetails(false);
          }}
        />
      )}

      {/* Abuse Report Modal */}
      {activeReportTarget && (
        <AbuseReportModal
          targetId={activeReportTarget.id}
          targetUsername={activeReportTarget.username}
          targetType={activeReportTarget.type}
          targetTitle={activeReportTarget.title}
          reporterUsername={currentUser.username}
          onReportSubmitted={(payload) => {
            handleProcessAbuseReport(payload);
            setActiveReportTarget(null);
          }}
          onClose={() => setActiveReportTarget(null)}
        />
      )}
    </div>
  );
};
