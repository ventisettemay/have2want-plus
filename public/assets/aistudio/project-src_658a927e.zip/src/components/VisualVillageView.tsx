import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  MessageSquare,
  Leaf,
  GraduationCap,
  Wrench,
  BookOpen,
  Store,
  TreeDeciduous,
  Stethoscope,
  Sparkles,
  Bike,
  Apple,
  Hammer,
  ArrowRight,
  ShieldCheck,
  MapPin,
  Compass,
  CheckCircle2,
  Send,
  Eye,
  Info,
  Maximize2,
  RefreshCw
} from "lucide-react";
import {
  CityBuildingId,
  Citizen,
  HaveWantListing,
  CommerceShop,
  MemoryArticle,
  SalvavatuttoGuide
} from "../types";

interface VisualVillageViewProps {
  citizens: Citizen[];
  listings: HaveWantListing[];
  shops: CommerceShop[];
  guides: SalvavatuttoGuide[];
  memories: MemoryArticle[];
  onEnterBuilding: (buildingId: CityBuildingId) => void;
  onSelectCitizen: (citizen: Citizen) => void;
  onSelectListing: (listing: HaveWantListing) => void;
  onOpenGeographicMap: () => void;
  onOpenPostPiazza: () => void;
  onOpenCreateObject: () => void;
}

export const VisualVillageView: React.FC<VisualVillageViewProps> = ({
  citizens,
  listings,
  shops,
  guides,
  memories,
  onEnterBuilding,
  onSelectCitizen,
  onSelectListing,
  onOpenGeographicMap,
  onOpenPostPiazza,
  onOpenCreateObject,
}) => {
  const [hoveredElement, setHoveredElement] = useState<string | null>(null);

  // Specific key elements positioned organically in the village
  const gardenShearsListing = listings.find((l) => l.id === "listing-5") || listings[0];
  const applesListing = listings.find((l) => l.id === "listing-2") || listings[1];
  const bikeListing = listings.find((l) => l.id === "listing-1") || listings[0];
  const drillListing = listings.find((l) => l.id === "listing-3") || listings[2];
  const tomatoesListing = listings.find((l) => l.id === "listing-4") || listings[3];

  const giuseppeCitizen = citizens.find((c) => c.id === "cit-1") || citizens[0];
  const antonioCitizen = citizens.find((c) => c.id === "cit-2") || citizens[1];
  const elenaCitizen = citizens.find((c) => c.id === "cit-3") || citizens[2];
  const lucaCitizen = citizens.find((c) => c.id === "cit-4") || citizens[3];
  const claraCitizen = citizens.find((c) => c.id === "cit-5") || citizens[4];

  return (
    <div className="w-full bg-slate-950 rounded-[32px] border-2 border-emerald-500/40 overflow-hidden shadow-[0_0_80px_rgba(16,185,129,0.2)] select-none">
      
      {/* Top Territorial Status Bar */}
      <div className="px-4 sm:px-6 py-2.5 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 text-slate-300 font-mono text-[11px]">
          <span className="text-emerald-400 font-black">PAESE PRIMO</span>
          <span className="text-slate-600">/</span>
          <span className="text-slate-400">Piazza & Luoghi Vivi</span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenPostPiazza}
            className="px-3 py-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-300 font-bold text-xs flex items-center gap-1.5 border border-slate-700 cursor-pointer"
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Chat di Piazza</span>
          </button>
          
          <button
            onClick={onOpenCreateObject}
            className="px-3 py-1 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs flex items-center gap-1.5 shadow cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Aggiungi nel Paese</span>
          </button>
        </div>
      </div>

      {/* Panoramic 2.5D Visual Village Stage */}
      <div className="relative w-full aspect-[16/10] sm:aspect-[16/9] min-h-[560px] md:min-h-[640px] bg-gradient-to-b from-slate-900 via-[#07131e] to-[#041c14] overflow-hidden p-4 sm:p-8">
        
        {/* Atmosphere & Sky Layer */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-amber-200/10 via-emerald-500/5 to-transparent pointer-events-none" />
        
        {/* Organic Hills & Background Terrain Lines */}
        <svg
          className="absolute inset-0 w-full h-full pointer-events-none opacity-40"
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 1000 600"
          preserveAspectRatio="none"
        >
          <path
            d="M 0 350 Q 250 280 500 330 T 1000 300 L 1000 600 L 0 600 Z"
            fill="#062e20"
          />
          <path
            d="M 0 410 Q 300 360 650 420 T 1000 390 L 1000 600 L 0 600 Z"
            fill="#052419"
          />
          {/* Cobblestone Village Path connecting the buildings */}
          <path
            d="M 120 540 Q 300 510 480 530 T 880 510"
            stroke="#475569"
            strokeWidth="28"
            strokeLinecap="round"
            strokeDasharray="4 8"
            fill="none"
            opacity="0.3"
          />
          <path
            d="M 480 530 Q 500 390 520 280 T 560 160"
            stroke="#475569"
            strokeWidth="20"
            strokeLinecap="round"
            strokeDasharray="4 8"
            fill="none"
            opacity="0.25"
          />
          <path
            d="M 280 430 Q 380 470 480 530"
            stroke="#475569"
            strokeWidth="16"
            strokeLinecap="round"
            strokeDasharray="4 8"
            fill="none"
            opacity="0.2"
          />
          {/* Village Stream (Water) */}
          <path
            d="M 0 570 Q 350 550 700 580 T 1000 560"
            stroke="#0284c7"
            strokeWidth="12"
            fill="none"
            opacity="0.4"
          />
        </svg>

        {/* ------------------------------------------------------------- */}
        {/* 1. PARCO & AREA VERDE                                         */}
        {/* ------------------------------------------------------------- */}
        <motion.div
          whileHover={{ scale: 1.05 }}
          onClick={() => onEnterBuilding("albero")}
          onMouseEnter={() => setHoveredElement("albero")}
          onMouseLeave={() => setHoveredElement(null)}
          className="absolute left-1/2 -translate-x-1/2 top-[4%] cursor-pointer z-20 flex flex-col items-center group"
          id="village-parco-area-verde"
        >
          <div className="relative">
            <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-full bg-gradient-to-t from-emerald-600/40 via-teal-400/30 to-amber-300/30 border-2 border-emerald-400/80 shadow-[0_0_40px_rgba(52,211,153,0.6)] flex items-center justify-center backdrop-blur-md">
              <TreeDeciduous className="w-14 h-14 sm:w-16 sm:h-16 text-emerald-300 group-hover:text-amber-200 transition-colors drop-shadow" />
            </div>
            <span className="absolute -top-1 -right-1 px-2 py-0.5 rounded-full bg-amber-400 text-slate-950 font-black text-[9px] shadow animate-bounce">
              Area Verde
            </span>
          </div>
          <div className="mt-1.5 px-3 py-1 rounded-full bg-slate-950/90 border border-emerald-500/50 text-center backdrop-blur-md shadow-lg">
            <span className="text-xs font-black text-emerald-300 block leading-tight">
              PARCO & AREA VERDE
            </span>
            <span className="text-[9px] text-slate-400 font-mono">
              Piante & Relax
            </span>
          </div>
        </motion.div>

        {/* ------------------------------------------------------------- */}
        {/* 2. FRUTTA & VERDURA                                           */}
        {/* ------------------------------------------------------------- */}
        <motion.div
          whileHover={{ scale: 1.04 }}
          onClick={() => onEnterBuilding("giardino")}
          onMouseEnter={() => setHoveredElement("giardino")}
          onMouseLeave={() => setHoveredElement(null)}
          className="absolute left-[3%] sm:left-[6%] top-[14%] cursor-pointer z-20 group max-w-[210px] sm:max-w-[250px]"
          id="village-frutta-verdura"
        >
          <div className="p-3.5 sm:p-4 rounded-3xl bg-slate-950/90 border-2 border-emerald-500/70 hover:border-emerald-400 shadow-[0_0_30px_rgba(16,185,129,0.3)] backdrop-blur-md transition-all">
            <div className="flex items-center gap-2.5 mb-2">
              <div className="w-10 h-10 rounded-2xl bg-emerald-950 border border-emerald-500/50 flex items-center justify-center text-emerald-400 group-hover:scale-110 transition-transform">
                <Leaf className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[9px] font-black uppercase tracking-wider text-emerald-400 font-mono">
                  Alimentari & Bio
                </span>
                <h4 className="text-xs sm:text-sm font-black text-white group-hover:text-emerald-300 transition-colors">
                  FRUTTA & VERDURA
                </h4>
              </div>
            </div>

            <p className="text-[10px] text-slate-300 leading-snug line-clamp-2">
              Frutta di stagione, pomodori bio, cassette di verdure fresche e sementi.
            </p>

            {/* Inhabitants & live objects embedded right in the garden badge */}
            <div className="mt-2.5 pt-2 border-t border-slate-800 flex items-center justify-between text-[10px]">
              <div
                onClick={(e) => {
                  e.stopPropagation();
                  onSelectCitizen(giuseppeCitizen);
                }}
                className="flex items-center gap-1.5 hover:text-emerald-300 cursor-pointer"
                title="Peppe (Fruttivendolo) - 🟢 Aperto"
              >
                <div className="relative">
                  <img
                    src={giuseppeCitizen.avatar}
                    alt={giuseppeCitizen.name}
                    className="w-5 h-5 rounded-full object-cover border border-emerald-400"
                  />
                  <span className="absolute -bottom-0.5 -right-0.5 w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                </div>
                <span className="font-bold text-white text-[10px]">Peppe Orto</span>
              </div>

              <span className="text-[9px] text-amber-300 font-mono font-bold bg-amber-950/60 px-1.5 py-0.5 rounded">
                Pomodori ⇄ Pasta
              </span>
            </div>
          </div>
        </motion.div>

        {/* ------------------------------------------------------------- */}
        {/* 3. FALEGNAMERIA & MOBILI                                      */}
        {/* ------------------------------------------------------------- */}
        <motion.div
          whileHover={{ scale: 1.04 }}
          onClick={() => onEnterBuilding("officina")}
          onMouseEnter={() => setHoveredElement("officina")}
          onMouseLeave={() => setHoveredElement(null)}
          className="absolute right-[3%] sm:right-[6%] top-[14%] cursor-pointer z-20 group max-w-[210px] sm:max-w-[250px]"
          id="village-falegnameria-mobili"
        >
          <div className="p-3.5 sm:p-4 rounded-3xl bg-slate-950/90 border-2 border-amber-400/70 hover:border-amber-300 shadow-[0_0_30px_rgba(245,158,11,0.3)] backdrop-blur-md transition-all">
            <div className="flex items-center gap-2.5 mb-2">
              <div className="w-10 h-10 rounded-2xl bg-amber-950/80 border border-amber-400/50 flex items-center justify-center text-amber-400 group-hover:scale-110 transition-transform">
                <Wrench className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[9px] font-black uppercase tracking-wider text-amber-400 font-mono">
                  Legno & Restauro
                </span>
                <h4 className="text-xs sm:text-sm font-black text-white group-hover:text-amber-300 transition-colors">
                  FALEGNAMERIA
                </h4>
              </div>
            </div>

            <p className="text-[10px] text-slate-300 leading-snug line-clamp-2">
              Mobili in legno massello su misura, banco da lavoro e noleggio attrezzi.
            </p>

            <div className="mt-2.5 pt-2 border-t border-slate-800 flex items-center justify-between text-[10px]">
              <div
                onClick={(e) => {
                  e.stopPropagation();
                  onSelectCitizen(antonioCitizen);
                }}
                className="flex items-center gap-1.5 hover:text-amber-300 cursor-pointer"
              >
                <img
                  src={antonioCitizen.avatar}
                  alt={antonioCitizen.name}
                  className="w-5 h-5 rounded-full object-cover border border-amber-400"
                />
                <span className="font-bold text-white text-[10px]">Mastro Antonio</span>
              </div>

              <span className="text-[9px] text-sky-300 font-mono font-bold bg-sky-950/60 px-1.5 py-0.5 rounded">
                Trapano in Prestito
              </span>
            </div>
          </div>
        </motion.div>

        {/* ------------------------------------------------------------- */}
        {/* 4. BAR & CAFFÈ (Piazza Centrale)                              */}
        {/* ------------------------------------------------------------- */}
        <motion.div
          whileHover={{ scale: 1.03 }}
          onClick={() => onEnterBuilding("piazza")}
          onMouseEnter={() => setHoveredElement("piazza")}
          onMouseLeave={() => setHoveredElement(null)}
          className="absolute left-1/2 -translate-x-1/2 top-[42%] sm:top-[44%] cursor-pointer z-30 group w-[90%] max-w-[340px] sm:max-w-[400px]"
          id="village-bar-caffe"
        >
          <div className="p-4 sm:p-5 rounded-3xl bg-slate-950/95 border-2 border-amber-400 shadow-[0_0_40px_rgba(245,158,11,0.4)] backdrop-blur-md transition-all space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-11 h-11 rounded-2xl bg-amber-400 text-slate-950 flex items-center justify-center font-black group-hover:scale-110 transition-transform shadow-md">
                  <MessageSquare className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-[9px] font-black uppercase tracking-wider text-amber-400 font-mono">
                    Caffetteria & Incontri
                  </span>
                  <h3 className="text-sm sm:text-base font-black text-white group-hover:text-amber-300 transition-colors">
                    BAR & CAFFÈ
                  </h3>
                </div>
              </div>

              <span className="text-[9px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold">
                Bacheca Aperta
              </span>
            </div>

            {/* Real speech bubble from citizens sitting on the bench */}
            <div className="p-2.5 rounded-2xl bg-slate-900 border border-slate-800 text-[11px] text-amber-200 italic flex items-start gap-2">
              <div className="relative shrink-0">
                <img
                  src={claraCitizen.avatar}
                  alt={claraCitizen.name}
                  className="w-6 h-6 rounded-full object-cover border border-emerald-400"
                />
                <span className="absolute -bottom-0.5 -right-0.5 w-2 h-2 rounded-full bg-emerald-400" />
              </div>
              <p className="line-clamp-2">
                "Caffè caldo, cornetti e bacheca avvisi attiva per tutti i compaesani!"
              </p>
            </div>

            <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1">
              <span className="flex items-center gap-1 text-emerald-300 font-bold">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                Marco & Cittadini al Bar
              </span>
              <span className="text-amber-400 font-bold flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                Entra nel Bar →
              </span>
            </div>
          </div>
        </motion.div>

        {/* ------------------------------------------------------------- */}
        {/* 5. BAZAR & TELEFONIA                                          */}
        {/* ------------------------------------------------------------- */}
        <motion.div
          whileHover={{ scale: 1.04 }}
          onClick={() => onEnterBuilding("commercio")}
          onMouseEnter={() => setHoveredElement("commercio")}
          onMouseLeave={() => setHoveredElement(null)}
          className="absolute left-[3%] sm:left-[5%] bottom-[5%] cursor-pointer z-20 group max-w-[210px] sm:max-w-[260px]"
          id="village-bazar-telefonia"
        >
          <div className="p-3.5 sm:p-4 rounded-3xl bg-slate-950/90 border-2 border-purple-400/70 hover:border-purple-300 shadow-[0_0_30px_rgba(192,132,252,0.3)] backdrop-blur-md transition-all">
            <div className="flex items-center gap-2.5 mb-2">
              <div className="w-10 h-10 rounded-2xl bg-purple-950 border border-purple-400/50 flex items-center justify-center text-purple-300 group-hover:scale-110 transition-transform">
                <Store className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[9px] font-black uppercase tracking-wider text-purple-400 font-mono">
                  Telefonia & Usato
                </span>
                <h4 className="text-xs sm:text-sm font-black text-white group-hover:text-purple-300 transition-colors">
                  BAZAR & TELEFONIA
                </h4>
              </div>
            </div>

            <p className="text-[10px] text-slate-300 leading-snug line-clamp-2">
              Smartphone garantiti, ricondizionati, elettronica, pannelli solari e articoli vari.
            </p>

            <div className="mt-2.5 pt-2 border-t border-slate-800 flex items-center justify-between text-[10px]">
              <span className="text-purple-300 font-bold">Silvia</span>
              <span className="text-[9px] px-2 py-0.5 rounded bg-purple-500/20 text-purple-200 font-mono">
                Pi + Euro + Baratto
              </span>
            </div>
          </div>
        </motion.div>

        {/* ------------------------------------------------------------- */}
        {/* 6. LABORATORI & CORSI                                         */}
        {/* ------------------------------------------------------------- */}
        <motion.div
          whileHover={{ scale: 1.04 }}
          onClick={() => onEnterBuilding("scuola")}
          onMouseEnter={() => setHoveredElement("scuola")}
          onMouseLeave={() => setHoveredElement(null)}
          className="absolute left-[38%] sm:left-[36%] bottom-[4%] cursor-pointer z-20 group max-w-[190px] sm:max-w-[230px]"
          id="village-laboratori-corsi"
        >
          <div className="p-3 sm:p-3.5 rounded-3xl bg-slate-950/90 border-2 border-sky-400/70 hover:border-sky-300 shadow-[0_0_25px_rgba(56,189,248,0.3)] backdrop-blur-md transition-all">
            <div className="flex items-center gap-2 mb-1.5">
              <div className="w-8 h-8 rounded-xl bg-sky-950 border border-sky-400/50 flex items-center justify-center text-sky-400">
                <GraduationCap className="w-4 h-4" />
              </div>
              <div>
                <span className="text-[8px] font-black uppercase text-sky-400 font-mono">Corsi Pratici</span>
                <h4 className="text-xs font-black text-white group-hover:text-sky-300">LABORATORI & CORSI</h4>
              </div>
            </div>
            <p className="text-[10px] text-slate-300 leading-tight">
              Falegnameria pratica, lingue, lezioni tra pari.
            </p>
          </div>
        </motion.div>

        {/* ------------------------------------------------------------- */}
        {/* 7. PANETTERIA & FORNO                                         */}
        {/* ------------------------------------------------------------- */}
        <motion.div
          whileHover={{ scale: 1.04 }}
          onClick={() => onEnterBuilding("memoria")}
          onMouseEnter={() => setHoveredElement("memoria")}
          onMouseLeave={() => setHoveredElement(null)}
          className="absolute right-[3%] sm:right-[5%] bottom-[5%] cursor-pointer z-20 group max-w-[210px] sm:max-w-[260px]"
          id="village-panetteria-forno"
        >
          <div className="p-3.5 sm:p-4 rounded-3xl bg-slate-950/90 border-2 border-rose-400/70 hover:border-rose-300 shadow-[0_0_30px_rgba(251,113,133,0.3)] backdrop-blur-md transition-all">
            <div className="flex items-center gap-2.5 mb-2">
              <div className="w-10 h-10 rounded-2xl bg-rose-950 border border-rose-400/50 flex items-center justify-center text-rose-300 group-hover:scale-110 transition-transform">
                <BookOpen className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[9px] font-black uppercase tracking-wider text-rose-400 font-mono">
                  Pane & Farine
                </span>
                <h4 className="text-xs sm:text-sm font-black text-white group-hover:text-rose-300 transition-colors">
                  PANETTERIA & FORNO
                </h4>
              </div>
            </div>

            <p className="text-[10px] text-slate-300 leading-snug line-clamp-2">
              Pane rustico cotto a legna, lievito madre, focacce e farine macinate a pietra.
            </p>

            <div className="mt-2.5 pt-2 border-t border-slate-800 flex items-center justify-between text-[10px]">
              <span className="text-rose-300 font-bold">Nonna Rosa</span>
              <span className="text-[9px] px-2 py-0.5 rounded bg-rose-500/20 text-rose-200 font-mono">
                Forno a Legna
              </span>
            </div>
          </div>
        </motion.div>

        {/* ------------------------------------------------------------- */}
        {/* REAL VISIBLE OBJECTS ON THE COBBLESTONE & FENCES ("TOCCA CIÒ CHE VEDI") */}
        {/* ------------------------------------------------------------- */}
        
        {/* A. La Cassetta di Mele di Giuseppe (davanti all'Orto) */}
        <motion.div
          whileHover={{ scale: 1.15, y: -4 }}
          onClick={() => onSelectListing(applesListing)}
          className="absolute left-[24%] top-[28%] z-30 cursor-pointer flex items-center gap-1.5 p-1.5 rounded-2xl bg-emerald-950/90 border-2 border-emerald-400 shadow-lg group backdrop-blur-sm"
          title="Tocca per ritirare la cassetta di mele biologiche di Giuseppe (Dono)"
        >
          <div className="w-7 h-7 rounded-xl bg-emerald-400 text-slate-950 flex items-center justify-center font-black">
            <Apple className="w-4 h-4" />
          </div>
          <div className="hidden sm:block pr-1">
            <span className="text-[8px] font-black uppercase text-emerald-300 block font-mono">Dono Libero</span>
            <span className="text-[10px] font-black text-white">Mele Bio (5kg)</span>
          </div>
        </motion.div>

        {/* B. Le Cesoie Professionali appese alla staccionata */}
        <motion.div
          whileHover={{ scale: 1.15, y: -4 }}
          onClick={() => onSelectListing(gardenShearsListing)}
          className="absolute left-[20%] top-[42%] z-30 cursor-pointer flex items-center gap-1.5 p-1.5 rounded-2xl bg-amber-950/90 border-2 border-amber-400 shadow-lg group backdrop-blur-sm"
          title="Cesoie Professionali Felco — Baratto con 2 vasi terracotta o 2.5 Pi"
        >
          <div className="w-7 h-7 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-black">
            <Hammer className="w-4 h-4" />
          </div>
          <div className="hidden sm:block pr-1">
            <span className="text-[8px] font-black uppercase text-amber-300 block font-mono">Baratto Diretto</span>
            <span className="text-[10px] font-black text-white">Cesoie Felco</span>
          </div>
        </motion.div>

        {/* C. La Bicicletta Rigenerata di Marco (appoggiata fuori dall'officina) */}
        <motion.div
          whileHover={{ scale: 1.15, y: -4 }}
          onClick={() => onSelectListing(bikeListing)}
          className="absolute right-[24%] top-[28%] z-30 cursor-pointer flex items-center gap-1.5 p-1.5 rounded-2xl bg-sky-950/90 border-2 border-sky-400 shadow-lg group backdrop-blur-sm"
          title="Bicicletta Vintage Revisionata — Scambio con compressore o 12.5 Pi o €65"
        >
          <div className="w-7 h-7 rounded-xl bg-sky-400 text-slate-950 flex items-center justify-center font-black">
            <Bike className="w-4 h-4" />
          </div>
          <div className="hidden sm:block pr-1">
            <span className="text-[8px] font-black uppercase text-sky-300 block font-mono">Baratto / Vendita</span>
            <span className="text-[10px] font-black text-white">Bici Vintage</span>
          </div>
        </motion.div>

        {/* D. Pomodori dell'Orto (1kg Pomodori ⇄ 2kg Pasta) */}
        <motion.div
          whileHover={{ scale: 1.15, y: -4 }}
          onClick={() => onSelectListing(tomatoesListing)}
          className="absolute left-[14%] top-[34%] z-30 cursor-pointer flex items-center gap-1.5 p-1.5 rounded-2xl bg-rose-950/90 border-2 border-rose-400 shadow-lg group backdrop-blur-sm"
          title="1 kg Pomodori Cuore di Bue ⇄ 2 kg Pasta"
        >
          <div className="w-7 h-7 rounded-xl bg-rose-500 text-white flex items-center justify-center font-black">
            <Leaf className="w-4 h-4" />
          </div>
          <div className="hidden sm:block pr-1">
            <span className="text-[8px] font-black uppercase text-rose-300 block font-mono">Scambio Concreto</span>
            <span className="text-[10px] font-black text-white">1kg Pomodori ⇄ 2kg Pasta</span>
          </div>
        </motion.div>

      </div>

      {/* Interactive Legend and Direct Action Explainer */}
      <div className="p-4 sm:p-5 bg-slate-900/95 border-t border-slate-800 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-4 text-xs">
          <span className="text-slate-400 font-bold">Principio "Tocca ciò che vedi":</span>
          <span className="flex items-center gap-1.5 text-emerald-300">
            <Leaf className="w-3.5 h-3.5 text-emerald-400" />
            Tocca l'Orto per entrare nel frutteto
          </span>
          <span className="flex items-center gap-1.5 text-amber-300">
            <Wrench className="w-3.5 h-3.5 text-amber-400" />
            Tocca l'Officina per gli attrezzi in prestito
          </span>
          <span className="flex items-center gap-1.5 text-purple-300">
            <Store className="w-3.5 h-3.5 text-purple-400" />
            Tocca il Bazar per i prodotti nuovi/usati
          </span>
        </div>

        <button
          onClick={() => onEnterBuilding("giardino")}
          className="px-4 py-2 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs flex items-center gap-2 shadow-lg hover:scale-105 transition-all cursor-pointer shrink-0"
        >
          <span>Esplora il Giardino & Orto Civico</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

    </div>
  );
};
