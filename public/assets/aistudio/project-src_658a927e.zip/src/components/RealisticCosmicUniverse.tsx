import React, { useState } from "react";
import {
  Sparkles,
  Layers,
  Users,
  Archive,
  Bot,
  AlertTriangle,
  Orbit,
  Compass,
  ArrowRight,
  X,
  Info,
  Maximize2
} from "lucide-react";

// Generated Photorealistic 3D Assets
import pureSpaceBg from "../assets/images/pure_cosmic_nebula_1788102700555.jpg";
import sun3dImg from "../assets/images/realistic_sun_3d_1788102149622.jpg";
import jupiter3dImg from "../assets/images/realistic_jupiter_3d_1788102169020.jpg";
import earthMoon3dImg from "../assets/images/realistic_earth_moon_1788102184726.jpg";
import neptune3dImg from "../assets/images/realistic_neptune_3d_1788102221223.jpg";
import aiSphere3dImg from "../assets/images/ai_sphere_3d_1788102235543.jpg";

interface RealisticCosmicUniverseProps {
  onNavigate: (tab: "planet-possibilita" | "planet-vita" | "planet-salvavatutto" | "ai-assistant" | "emergency") => void;
  listingsCount: number;
  guidesCount: number;
  messagesCount: number;
}

interface PlanetDetail {
  id: string;
  tabKey: "planet-possibilita" | "planet-vita" | "planet-salvavatutto" | "ai-assistant" | "emergency";
  name: string;
  subtitle: string;
  celestialName: string;
  themeColor: string;
  borderColor: string;
  glowColor: string;
  image: string;
  description: string;
  keyFeature: string;
  stats: string;
  badgeLabel: string;
  accentBg: string;
}

export const RealisticCosmicUniverse: React.FC<RealisticCosmicUniverseProps> = ({
  onNavigate,
  listingsCount,
  guidesCount,
  messagesCount,
}) => {
  const [selectedPlanetModal, setSelectedPlanetModal] = useState<PlanetDetail | null>(null);
  const [activeViewMode, setActiveViewMode] = useState<"orbit" | "grid">("orbit");

  const planets: PlanetDetail[] = [
    {
      id: "sun",
      tabKey: "planet-possibilita",
      name: "Il Sole • HAVE2WANT",
      subtitle: "Centro del Valore & Matrice Umana",
      celestialName: "Stella Primaria",
      themeColor: "text-amber-400",
      borderColor: "border-amber-400",
      glowColor: "rgba(245, 158, 11, 0.7)",
      accentBg: "from-amber-500/20 to-orange-600/20",
      image: sun3dImg,
      description: "Il cuore gravitazionale ed energetico dell'ecosistema. Dove ogni persona apporta valore reale e scambia capacità autentiche.",
      keyFeature: "What you have → What you want",
      stats: `${listingsCount} Annunci Attivi`,
      badgeLabel: "IL SOLE",
    },
    {
      id: "ai",
      tabKey: "ai-assistant",
      name: "Sfera Luminosa (AI)",
      subtitle: "Intelligenza Discreta a Chiamata",
      celestialName: "Pulsar Ciano",
      themeColor: "text-cyan-300",
      borderColor: "border-cyan-400",
      glowColor: "rgba(6, 182, 212, 0.75)",
      accentBg: "from-cyan-500/20 to-blue-600/20",
      image: aiSphere3dImg,
      description: "Un'intelligenza artificiale discreta che non si impone: compare solo quando la convochi per assisterti nelle offerte o chiarimenti.",
      keyFeature: "Silenziosa di default • A Chiamata",
      stats: "Pronta & Discreta",
      badgeLabel: "AI DISCRETO",
    },
    {
      id: "jupiter",
      tabKey: "planet-possibilita",
      name: "Pianeta Possibilità",
      subtitle: "HAVE & WANT • 9 Modalità di Scambio",
      celestialName: "Giove Dorato",
      themeColor: "text-amber-300",
      borderColor: "border-amber-500",
      glowColor: "rgba(245, 158, 11, 0.6)",
      accentBg: "from-amber-600/20 to-yellow-600/20",
      image: jupiter3dImg,
      description: "Il gigante delle opportunità: dona, baratta, presta, offri competenze o acquista in π con un tetto simbolico massimo di 15 π.",
      keyFeature: "Dono, Baratto, Prestito, Servizio, π",
      stats: `${listingsCount} Opportunità`,
      badgeLabel: "GIOVE",
    },
    {
      id: "earth",
      tabKey: "planet-vita",
      name: "Pianeta Vita (La Terra)",
      subtitle: "Relazioni Autentiche & 3 Chat Pubbliche",
      celestialName: "Terra & Luna",
      themeColor: "text-emerald-400",
      borderColor: "border-emerald-400",
      glowColor: "rgba(16, 185, 129, 0.7)",
      accentBg: "from-emerald-500/20 to-teal-600/20",
      image: earthMoon3dImg,
      description: "Lo spazio d'incontro comunitario con 3 stanze pubbliche chiare e contatto privato 1-a-1 quando HAVE e WANT trovano un'intesa.",
      keyFeature: "HAVE2WANT Community • HAVE • WANT",
      stats: `${messagesCount} Messaggi in Piazza`,
      badgeLabel: "TERRA (VITA)",
    },
    {
      id: "moon-sos",
      tabKey: "emergency",
      name: "La Luna • Faro SOS",
      subtitle: "Soccorso di Vicinato & Rete d'Emergenza",
      celestialName: "Satellite Naturale",
      themeColor: "text-rose-400",
      borderColor: "border-rose-500",
      glowColor: "rgba(244, 63, 94, 0.9)",
      accentBg: "from-rose-500/20 to-red-600/20",
      image: earthMoon3dImg,
      description: "Un pulsante d'aiuto per allertare i vicini fidati in tempo reale in caso di urgenze mediche, guasti o necessità impreviste.",
      keyFeature: "Allerta Immediata Vicinato",
      stats: "Attivo 24/7",
      badgeLabel: "SOS LUNA",
    },
    {
      id: "neptune",
      tabKey: "planet-salvavatutto",
      name: "Pianeta Salvavatutto",
      subtitle: "L'Arca dei Saperi Pratici & Autonomia",
      celestialName: "Nettuno Blu Cobalto",
      themeColor: "text-sky-300",
      borderColor: "border-sky-400",
      glowColor: "rgba(56, 189, 248, 0.7)",
      accentBg: "from-sky-500/20 to-indigo-600/20",
      image: neptune3dImg,
      description: "Memoria permanente per la resilienza comunitaria: guide pratiche, conserve senza sprechi, riparazioni fai-da-te e nozioni salvavita.",
      keyFeature: "Conoscenza Pratica Incorruttibile",
      stats: `${guidesCount} Guide Preservate`,
      badgeLabel: "NETTUNO",
    },
  ];

  return (
    <div className="space-y-6">
      {/* 1. MAIN COSMIC CANVAS CONTAINER */}
      <div className="relative w-full rounded-3xl overflow-hidden border-2 border-cyan-400/40 shadow-[0_0_80px_rgba(34,211,238,0.25)] bg-[#020512]">
        
        {/* Deep Pure Space Nebula Background */}
        <div
          className="absolute inset-0 w-full h-full bg-cover bg-center pointer-events-none"
          style={{
            backgroundImage: `url(${pureSpaceBg})`,
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-[#020617]/50 via-transparent to-[#020617]/90" />
        </div>

        {/* Top Control Bar HUD */}
        <div className="relative z-20 p-4 sm:p-5 flex items-center justify-between border-b border-slate-800/80 bg-slate-950/70 backdrop-blur-md">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-cyan-500/20 border border-cyan-400/50 flex items-center justify-center text-cyan-300 shadow-lg">
              <Orbit className="w-5 h-5 animate-spin" style={{ animationDuration: "25s" }} />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-black text-white tracking-wide uppercase flex items-center gap-2">
                <span>UNIVERSO COSMICO 3D</span>
                <span className="text-[10px] sm:text-xs px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-400/40 font-mono">
                  GRAVITÀ REALE
                </span>
              </h2>
              <p className="text-xs text-slate-300 hidden sm:block">
                Tocca qualsiasi pianeta per esplorare o accedere direttamente
              </p>
            </div>
          </div>

          {/* View Toggle */}
          <div className="flex items-center p-1 bg-slate-900 rounded-xl border border-slate-800 text-xs font-bold">
            <button
              onClick={() => setActiveViewMode("orbit")}
              className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
                activeViewMode === "orbit"
                  ? "bg-cyan-500 text-slate-950 shadow-md font-black"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              <Compass className="w-3.5 h-3.5" />
              <span>Spazio 3D</span>
            </button>
            <button
              onClick={() => setActiveViewMode("grid")}
              className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
                activeViewMode === "grid"
                  ? "bg-cyan-500 text-slate-950 shadow-md font-black"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Schede</span>
            </button>
          </div>
        </div>

        {/* ---------------------------------------------------- */}
        {/* VIEW A: COSMIC ORBITAL 3D CANVAS */}
        {/* ---------------------------------------------------- */}
        {activeViewMode === "orbit" ? (
          <div className="relative w-full select-none">
            
            {/* ==================================================== */}
            {/* DESKTOP / TABLET LANDSCAPE VIEW (WIDE 3D INCLINED ORBIT) */}
            {/* ==================================================== */}
            <div className="hidden md:block relative w-full h-[640px] overflow-hidden">
              
              {/* Elliptical 3D Inclinato Orbital Paths */}
              <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 1100 640" preserveAspectRatio="none">
                <defs>
                  <linearGradient id="orbGrad1" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.8" />
                    <stop offset="100%" stopColor="#06b6d4" stopOpacity="0.1" />
                  </linearGradient>
                  <linearGradient id="orbGrad2" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#f59e0b" stopOpacity="0.8" />
                    <stop offset="100%" stopColor="#f59e0b" stopOpacity="0.1" />
                  </linearGradient>
                  <linearGradient id="orbGrad3" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#10b981" stopOpacity="0.8" />
                    <stop offset="100%" stopColor="#10b981" stopOpacity="0.1" />
                  </linearGradient>
                  <linearGradient id="orbGrad4" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.8" />
                    <stop offset="100%" stopColor="#38bdf8" stopOpacity="0.1" />
                  </linearGradient>
                  <linearGradient id="orbGrad5" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#fde047" stopOpacity="0.8" />
                    <stop offset="100%" stopColor="#fde047" stopOpacity="0.1" />
                  </linearGradient>
                </defs>
                <ellipse cx="60" cy="320" rx="300" ry="140" fill="none" stroke="url(#orbGrad1)" strokeWidth="2" strokeDasharray="6 6" />
                <ellipse cx="60" cy="320" rx="470" ry="195" fill="none" stroke="url(#orbGrad2)" strokeWidth="2.5" strokeDasharray="8 8" />
                <ellipse cx="60" cy="320" rx="650" ry="245" fill="none" stroke="url(#orbGrad3)" strokeWidth="2.5" strokeDasharray="8 8" />
                <ellipse cx="60" cy="320" rx="830" ry="285" fill="none" stroke="url(#orbGrad4)" strokeWidth="2" strokeDasharray="7 7" />
                <ellipse cx="60" cy="320" rx="990" ry="325" fill="none" stroke="url(#orbGrad5)" strokeWidth="2" strokeDasharray="6 6" />
              </svg>

              {/* 1. IL SOLE (Centro Energetico Sinistra) */}
              <div
                onClick={() => setSelectedPlanetModal(planets[0])}
                className="absolute left-[-20px] top-[48%] -translate-y-1/2 cursor-pointer group z-10 transition-transform duration-300 hover:scale-105"
              >
                <div className="relative w-56 h-56 rounded-full flex items-center justify-center">
                  <div className="absolute inset-0 rounded-full bg-amber-500/30 blur-2xl animate-pulse" />
                  <img
                    src={sun3dImg}
                    alt="Il Sole"
                    className="w-full h-full object-cover rounded-full shadow-[0_0_60px_rgba(245,158,11,0.95)] border-2 border-amber-300"
                  />
                  <div className="absolute -bottom-4 left-16 bg-slate-950/95 border border-amber-400 px-3.5 py-1.5 rounded-xl shadow-xl backdrop-blur-md group-hover:bg-amber-400 group-hover:text-slate-950 transition-all text-center">
                    <div className="text-xs font-black text-amber-300 group-hover:text-slate-950 uppercase flex items-center justify-center gap-1">
                      <Sparkles className="w-3.5 h-3.5" /> IL SOLE
                    </div>
                    <div className="text-[10px] font-bold text-amber-100 group-hover:text-slate-900">{listingsCount} Annunci Attivi</div>
                  </div>
                </div>
              </div>

              {/* 2. SFERA LUMINOSA AI (Orbita 1 Alta) */}
              <div
                onClick={() => setSelectedPlanetModal(planets[1])}
                className="absolute left-[24%] top-[12%] cursor-pointer group z-10 transition-transform duration-300 hover:scale-110"
              >
                <div className="relative w-24 h-24 flex items-center justify-center">
                  <div className="absolute inset-0 rounded-full bg-cyan-400/40 blur-xl animate-ping" style={{ animationDuration: "3s" }} />
                  <img
                    src={aiSphere3dImg}
                    alt="Sfera AI"
                    className="w-full h-full object-cover rounded-full shadow-[0_0_35px_rgba(6,182,212,0.9)] border-2 border-cyan-300"
                  />
                  <div className="absolute -bottom-8 left-1/2 -translate-x-1/2 whitespace-nowrap bg-slate-950/95 border border-cyan-400 px-3 py-1 rounded-xl shadow-xl text-center group-hover:bg-cyan-400 group-hover:text-slate-950 transition-all">
                    <div className="text-xs font-black text-cyan-300 group-hover:text-slate-950 flex items-center justify-center gap-1">
                      <Bot className="w-3 h-3" /> Sfera AI
                    </div>
                    <div className="text-[10px] text-slate-300 group-hover:text-slate-900 font-semibold">A Chiamata</div>
                  </div>
                </div>
              </div>

              {/* 3. GIOVE (Pianeta Possibilità - Orbita 2 Bassa) */}
              <div
                onClick={() => setSelectedPlanetModal(planets[2])}
                className="absolute left-[38%] top-[56%] cursor-pointer group z-10 transition-transform duration-300 hover:scale-105"
              >
                <div className="relative w-40 h-40 flex items-center justify-center">
                  <div className="absolute inset-0 rounded-full bg-amber-500/20 blur-xl" />
                  <img
                    src={jupiter3dImg}
                    alt="Giove Possibilità"
                    className="w-full h-full object-cover rounded-full shadow-[0_0_45px_rgba(245,158,11,0.65)] border-2 border-amber-400/80"
                  />
                  <div className="absolute -bottom-9 left-1/2 -translate-x-1/2 whitespace-nowrap bg-slate-950/95 border border-amber-400 px-3.5 py-1.5 rounded-xl shadow-xl text-center group-hover:bg-amber-400 group-hover:text-slate-950 transition-all">
                    <div className="text-xs font-black text-amber-300 group-hover:text-slate-950 flex items-center justify-center gap-1">
                      <Layers className="w-3 h-3" /> Pianeta Possibilità
                    </div>
                    <div className="text-[10px] text-amber-200 group-hover:text-slate-900 font-bold">9 Modalità Scambio</div>
                  </div>
                </div>
              </div>

              {/* 4. LA TERRA & LUNA (Pianeta Vita - Orbita 3 Centro) */}
              <div
                onClick={() => setSelectedPlanetModal(planets[3])}
                className="absolute left-[56%] top-[22%] cursor-pointer group z-10 transition-transform duration-300 hover:scale-105"
              >
                <div className="relative w-36 h-36 flex items-center justify-center">
                  <div className="absolute inset-0 rounded-full bg-emerald-500/25 blur-xl" />
                  <img
                    src={earthMoon3dImg}
                    alt="Terra Vita"
                    className="w-full h-full object-cover rounded-full shadow-[0_0_40px_rgba(16,185,129,0.7)] border-2 border-emerald-400/80"
                  />
                  {/* SOS Moon Beacon */}
                  <div
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedPlanetModal(planets[4]);
                    }}
                    className="absolute -top-2 -right-2 w-9 h-9 rounded-full bg-rose-600 border-2 border-white flex items-center justify-center shadow-[0_0_20px_rgba(244,63,94,0.9)] animate-bounce cursor-pointer z-20"
                    title="SOS Vicinato"
                  >
                    <span className="text-[10px] font-black text-white">SOS</span>
                  </div>
                  <div className="absolute -bottom-9 left-1/2 -translate-x-1/2 whitespace-nowrap bg-slate-950/95 border border-emerald-400 px-3.5 py-1.5 rounded-xl shadow-xl text-center group-hover:bg-emerald-400 group-hover:text-slate-950 transition-all">
                    <div className="text-xs font-black text-emerald-300 group-hover:text-slate-950 flex items-center justify-center gap-1">
                      <Users className="w-3 h-3" /> Pianeta Vita (Terra)
                    </div>
                    <div className="text-[10px] text-emerald-200 group-hover:text-slate-900 font-bold">3 Chat Pubbliche</div>
                  </div>
                </div>
              </div>

              {/* 5. NETTUNO (Salvavatutto - Orbita 4 Destra) */}
              <div
                onClick={() => setSelectedPlanetModal(planets[5])}
                className="absolute left-[78%] top-[46%] cursor-pointer group z-10 transition-transform duration-300 hover:scale-105"
              >
                <div className="relative w-36 h-36 flex items-center justify-center">
                  <div className="absolute inset-0 rounded-full bg-sky-500/25 blur-xl" />
                  <img
                    src={neptune3dImg}
                    alt="Salvavatutto"
                    className="w-full h-full object-cover rounded-full shadow-[0_0_35px_rgba(56,189,248,0.7)] border-2 border-sky-400"
                  />
                  <div className="absolute -bottom-9 left-1/2 -translate-x-1/2 whitespace-nowrap bg-slate-950/95 border border-sky-400 px-3.5 py-1.5 rounded-xl shadow-xl text-center group-hover:bg-sky-400 group-hover:text-slate-950 transition-all">
                    <div className="text-xs font-black text-sky-300 group-hover:text-slate-950 flex items-center justify-center gap-1">
                      <Archive className="w-3 h-3" /> Salvavatutto (Nettuno)
                    </div>
                    <div className="text-[10px] text-sky-200 group-hover:text-slate-900 font-bold">{guidesCount} Guide Preservate</div>
                  </div>
                </div>
              </div>

            </div>

            {/* ==================================================== */}
            {/* MOBILE & VERTICAL VIEW: 3D ORGANIC CONSTELLATION MAP */}
            {/* (Sinuous Orbiting Path, Staggered Left/Right with Natural Atmosphere) */}
            {/* ==================================================== */}
            <div className="md:hidden relative w-full py-10 px-4 overflow-hidden min-h-[920px]">
              
              {/* Sinuous 3D Orbital Trajectory Curved SVG */}
              <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 380 920" preserveAspectRatio="none">
                <defs>
                  <linearGradient id="mobGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stopColor="#f59e0b" stopOpacity="0.9" />
                    <stop offset="25%" stopColor="#06b6d4" stopOpacity="0.9" />
                    <stop offset="50%" stopColor="#10b981" stopOpacity="0.9" />
                    <stop offset="75%" stopColor="#38bdf8" stopOpacity="0.9" />
                    <stop offset="100%" stopColor="#fde047" stopOpacity="0.9" />
                  </linearGradient>
                </defs>
                {/* Sinuous Curved Orbit linking all planets dynamically */}
                <path
                  d="M 190 60 Q 280 180, 190 280 T 110 440 T 270 590 T 110 740 T 200 860"
                  fill="none"
                  stroke="url(#mobGrad)"
                  strokeWidth="2.5"
                  strokeDasharray="6 6"
                />
              </svg>

              {/* Dynamic Planet Nodes on Mobile */}
              <div className="relative z-10 space-y-12">
                
                {/* 1. IL SOLE (Top Center Grand Origin) */}
                <div className="flex flex-col items-center">
                  <div
                    onClick={() => setSelectedPlanetModal(planets[0])}
                    className="relative cursor-pointer group flex flex-col items-center"
                  >
                    <div className="relative w-36 h-36 flex items-center justify-center">
                      <div className="absolute inset-0 rounded-full bg-amber-500/35 blur-2xl animate-pulse" />
                      <img
                        src={sun3dImg}
                        alt="Il Sole"
                        className="w-full h-full object-cover rounded-full shadow-[0_0_45px_rgba(245,158,11,0.9)] border-2 border-amber-300"
                      />
                    </div>
                    <div className="mt-2.5 bg-slate-950/95 border border-amber-400 px-3.5 py-1.5 rounded-xl shadow-xl backdrop-blur-md text-center">
                      <div className="text-xs font-black text-amber-300 flex items-center justify-center gap-1 uppercase">
                        <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                        IL SOLE • HAVE2WANT
                      </div>
                      <div className="text-[10px] text-amber-100 font-bold">{listingsCount} Annunci Attivi</div>
                    </div>
                  </div>
                </div>

                {/* 2. SFERA AI LUMINOSA (Shifted to Right Orbit) */}
                <div className="flex justify-end pr-4">
                  <div
                    onClick={() => setSelectedPlanetModal(planets[1])}
                    className="relative cursor-pointer group flex flex-col items-center max-w-[160px]"
                  >
                    <div className="relative w-22 h-22 flex items-center justify-center">
                      <div className="absolute inset-0 rounded-full bg-cyan-400/40 blur-xl animate-ping" style={{ animationDuration: "3s" }} />
                      <img
                        src={aiSphere3dImg}
                        alt="Sfera AI"
                        className="w-full h-full object-cover rounded-full shadow-[0_0_30px_rgba(6,182,212,0.9)] border-2 border-cyan-300"
                      />
                    </div>
                    <div className="mt-2 bg-slate-950/95 border border-cyan-400 px-3 py-1 rounded-xl shadow-xl backdrop-blur-md text-center">
                      <div className="text-[11px] font-black text-cyan-300 flex items-center justify-center gap-1">
                        <Bot className="w-3 h-3 text-cyan-400" />
                        Sfera AI
                      </div>
                      <div className="text-[9px] text-slate-300 font-semibold">A Chiamata</div>
                    </div>
                  </div>
                </div>

                {/* 3. GIOVE (Pianeta Possibilità - Shifted to Left Orbit) */}
                <div className="flex justify-start pl-2">
                  <div
                    onClick={() => setSelectedPlanetModal(planets[2])}
                    className="relative cursor-pointer group flex flex-col items-center max-w-[180px]"
                  >
                    <div className="relative w-32 h-32 flex items-center justify-center">
                      <div className="absolute inset-0 rounded-full bg-amber-500/25 blur-xl" />
                      <img
                        src={jupiter3dImg}
                        alt="Giove Possibilità"
                        className="w-full h-full object-cover rounded-full shadow-[0_0_35px_rgba(245,158,11,0.7)] border-2 border-amber-400/80"
                      />
                    </div>
                    <div className="mt-2 bg-slate-950/95 border border-amber-400 px-3 py-1.5 rounded-xl shadow-xl backdrop-blur-md text-center">
                      <div className="text-[11px] font-black text-amber-300 flex items-center justify-center gap-1 uppercase">
                        <Layers className="w-3 h-3 text-amber-400" />
                        Possibilità (Giove)
                      </div>
                      <div className="text-[9px] text-amber-100 font-bold">9 Modalità di Scambio</div>
                    </div>
                  </div>
                </div>

                {/* 4. LA TERRA & LUNA (Pianeta Vita & SOS - Shifted to Right Orbit) */}
                <div className="flex justify-end pr-2">
                  <div
                    onClick={() => setSelectedPlanetModal(planets[3])}
                    className="relative cursor-pointer group flex flex-col items-center max-w-[190px]"
                  >
                    <div className="relative w-32 h-32 flex items-center justify-center">
                      <div className="absolute inset-0 rounded-full bg-emerald-500/25 blur-xl" />
                      <img
                        src={earthMoon3dImg}
                        alt="Terra Vita"
                        className="w-full h-full object-cover rounded-full shadow-[0_0_35px_rgba(16,185,129,0.7)] border-2 border-emerald-400/80"
                      />
                      {/* SOS Moon Beacon */}
                      <div
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedPlanetModal(planets[4]);
                        }}
                        className="absolute -top-1 -right-1 w-8 h-8 rounded-full bg-rose-600 border-2 border-white flex items-center justify-center shadow-[0_0_15px_rgba(244,63,94,0.9)] animate-bounce z-20 cursor-pointer"
                      >
                        <span className="text-[9px] font-black text-white">SOS</span>
                      </div>
                    </div>
                    <div className="mt-2 bg-slate-950/95 border border-emerald-400 px-3 py-1.5 rounded-xl shadow-xl backdrop-blur-md text-center">
                      <div className="text-[11px] font-black text-emerald-300 flex items-center justify-center gap-1 uppercase">
                        <Users className="w-3 h-3 text-emerald-400" />
                        Vita (Terra)
                      </div>
                      <div className="text-[9px] text-emerald-100 font-bold">3 Chat Pubbliche</div>
                    </div>
                  </div>
                </div>

                {/* 5. NETTUNO (Salvavatutto - Center Base Harmony) */}
                <div className="flex flex-col items-center">
                  <div
                    onClick={() => setSelectedPlanetModal(planets[5])}
                    className="relative cursor-pointer group flex flex-col items-center max-w-[190px]"
                  >
                    <div className="relative w-30 h-30 flex items-center justify-center">
                      <div className="absolute inset-0 rounded-full bg-sky-500/25 blur-xl" />
                      <img
                        src={neptune3dImg}
                        alt="Nettuno Salvavatutto"
                        className="w-full h-full object-cover rounded-full shadow-[0_0_30px_rgba(56,189,248,0.7)] border-2 border-sky-400"
                      />
                    </div>
                    <div className="mt-2 bg-slate-950/95 border border-sky-400 px-3.5 py-1.5 rounded-xl shadow-xl backdrop-blur-md text-center">
                      <div className="text-[11px] font-black text-sky-300 flex items-center justify-center gap-1 uppercase">
                        <Archive className="w-3 h-3 text-sky-400" />
                        Salvavatutto
                      </div>
                      <div className="text-[9px] text-sky-100 font-bold">{guidesCount} Guide Preservate</div>
                    </div>
                  </div>
                </div>

              </div>
            </div>

          </div>
        ) : (
          /* ==================================================== */
          /* VIEW B: HIGH-DETAIL PLANETARY TILES GRID */
          /* ==================================================== */
          <div className="p-5 sm:p-7 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {planets.map((planet) => (
              <div
                key={planet.id}
                onClick={() => setSelectedPlanetModal(planet)}
                className={`p-5 rounded-3xl bg-slate-950/90 border ${planet.borderColor}/40 hover:${planet.borderColor} transition-all cursor-pointer flex flex-col justify-between group shadow-xl backdrop-blur-md hover:scale-[1.01]`}
              >
                <div>
                  <div className="flex items-center justify-between gap-3 mb-4">
                    <div className="flex items-center gap-3">
                      <div className="relative w-12 h-12 rounded-full overflow-hidden border border-slate-700 shrink-0">
                        <img src={planet.image} alt={planet.name} className="w-full h-full object-cover" />
                      </div>
                      <div>
                        <h3 className={`text-base font-extrabold ${planet.themeColor}`}>{planet.name}</h3>
                        <span className="text-xs text-slate-400 font-mono">{planet.celestialName}</span>
                      </div>
                    </div>
                    <span className="text-xs font-bold px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-slate-200">
                      {planet.stats}
                    </span>
                  </div>

                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-4">
                    {planet.description}
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between">
                  <span className="text-xs text-slate-400 font-medium truncate">{planet.keyFeature}</span>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onNavigate(planet.tabKey);
                    }}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-cyan-500 hover:text-slate-950 text-white text-xs font-extrabold transition-all flex items-center gap-1 cursor-pointer"
                  >
                    <span>Entra</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* 2. LOWER HUD FAST ACCESS TILES */}
        <div className="p-4 sm:p-6 bg-gradient-to-t from-[#020617] via-[#020617]/98 to-transparent border-t border-slate-800 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5 sm:gap-3.5">
          <button
            onClick={() => onNavigate("planet-possibilita")}
            className="p-3.5 rounded-2xl bg-slate-900/90 hover:bg-amber-400 hover:text-slate-950 border border-slate-800 hover:border-amber-400 transition-all text-left group cursor-pointer shadow-lg"
          >
            <div className="font-extrabold flex items-center gap-1.5 text-amber-400 group-hover:text-slate-950 text-xs sm:text-sm">
              <Layers className="w-4 h-4" />
              <span>Possibilità</span>
            </div>
            <p className="text-[11px] sm:text-xs text-slate-300 group-hover:text-slate-900 truncate mt-1">HAVE/WANT ({listingsCount})</p>
          </button>

          <button
            onClick={() => onNavigate("planet-vita")}
            className="p-3.5 rounded-2xl bg-slate-900/90 hover:bg-emerald-400 hover:text-slate-950 border border-slate-800 hover:border-emerald-400 transition-all text-left group cursor-pointer shadow-lg"
          >
            <div className="font-extrabold flex items-center gap-1.5 text-emerald-400 group-hover:text-slate-950 text-xs sm:text-sm">
              <Users className="w-4 h-4" />
              <span>Vita (Terra)</span>
            </div>
            <p className="text-[11px] sm:text-xs text-slate-300 group-hover:text-slate-900 truncate mt-1">3 Chat Pubbliche</p>
          </button>

          <button
            onClick={() => onNavigate("planet-salvavatutto")}
            className="p-3.5 rounded-2xl bg-slate-900/90 hover:bg-sky-400 hover:text-slate-950 border border-slate-800 hover:border-sky-400 transition-all text-left group cursor-pointer shadow-lg"
          >
            <div className="font-extrabold flex items-center gap-1.5 text-sky-400 group-hover:text-slate-950 text-xs sm:text-sm">
              <Archive className="w-4 h-4" />
              <span>Salvavatutto</span>
            </div>
            <p className="text-[11px] sm:text-xs text-slate-300 group-hover:text-slate-900 truncate mt-1">Guide ({guidesCount})</p>
          </button>

          <button
            onClick={() => onNavigate("ai-assistant")}
            className="p-3.5 rounded-2xl bg-slate-900/90 hover:bg-cyan-400 hover:text-slate-950 border border-slate-800 hover:border-cyan-300 transition-all text-left group cursor-pointer shadow-lg"
          >
            <div className="font-extrabold flex items-center gap-1.5 text-cyan-300 group-hover:text-slate-950 text-xs sm:text-sm">
              <Bot className="w-4 h-4" />
              <span>AI Discreto</span>
            </div>
            <p className="text-[11px] sm:text-xs text-slate-300 group-hover:text-slate-900 truncate mt-1">Simply Discreet</p>
          </button>

          <button
            onClick={() => onNavigate("emergency")}
            className="p-3.5 rounded-2xl bg-slate-900/90 hover:bg-rose-500 hover:text-white border border-slate-800 hover:border-rose-400 transition-all text-left group cursor-pointer shadow-lg"
          >
            <div className="font-extrabold flex items-center gap-1.5 text-rose-400 group-hover:text-white text-xs sm:text-sm">
              <AlertTriangle className="w-4 h-4" />
              <span>La Luna (SOS)</span>
            </div>
            <p className="text-[11px] sm:text-xs text-slate-300 group-hover:text-slate-100 truncate mt-1">Soccorso Vicini</p>
          </button>
        </div>

      </div>

      {/* 3. INTERACTIVE PLANET SPOTLIGHT MODAL / DRAWER */}
      {selectedPlanetModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-150">
          <div className="w-full max-w-lg bg-slate-900 border-2 border-slate-700 rounded-3xl shadow-2xl overflow-hidden">
            <div className="relative p-6 sm:p-7 bg-gradient-to-b from-slate-950 to-slate-900">
              <button
                onClick={() => setSelectedPlanetModal(null)}
                className="absolute top-4 right-4 p-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="flex items-center gap-4 mb-4">
                <div className="relative w-20 h-20 rounded-full overflow-hidden border-2 border-white/20 shadow-xl shrink-0">
                  <img src={selectedPlanetModal.image} alt={selectedPlanetModal.name} className="w-full h-full object-cover" />
                </div>
                <div>
                  <span className={`text-xs font-black uppercase tracking-widest ${selectedPlanetModal.themeColor}`}>
                    {selectedPlanetModal.celestialName}
                  </span>
                  <h3 className="text-xl sm:text-2xl font-black text-white leading-tight">
                    {selectedPlanetModal.name}
                  </h3>
                  <p className="text-xs text-slate-300 mt-0.5">{selectedPlanetModal.subtitle}</p>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 text-xs sm:text-sm text-slate-200 leading-relaxed mb-4">
                {selectedPlanetModal.description}
              </div>

              <div className="space-y-2 mb-6 text-xs sm:text-sm">
                <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950/70 border border-slate-800">
                  <span className="text-slate-400 font-medium">Funzione Principale:</span>
                  <span className="font-bold text-white">{selectedPlanetModal.keyFeature}</span>
                </div>
                <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950/70 border border-slate-800">
                  <span className="text-slate-400 font-medium">Stato Attuale:</span>
                  <span className={`font-bold ${selectedPlanetModal.themeColor}`}>{selectedPlanetModal.stats}</span>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={() => setSelectedPlanetModal(null)}
                  className="flex-1 py-3.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-sm transition-all"
                >
                  Chiudi
                </button>
                <button
                  onClick={() => {
                    const tab = selectedPlanetModal.tabKey;
                    setSelectedPlanetModal(null);
                    onNavigate(tab);
                  }}
                  className="flex-1 py-3.5 rounded-2xl bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-slate-950 font-black text-sm transition-all shadow-lg flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span>Entra nel Pianeta</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
