import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Star,
  ShieldAlert,
  Bot,
  CheckCircle2,
  AlertTriangle,
  X,
  Send,
  MessageSquare,
  Lock,
  RotateCcw,
  Sparkles,
  Info
} from "lucide-react";
import { DiscreetAIReviewFeedback, UserTrustRating } from "../types";

interface DiscreetAIAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetId: string;
  targetName: string;
  targetType: "listing" | "specialist" | "shop";
  onReviewSubmitted: (feedback: DiscreetAIReviewFeedback) => void;
  isFinancialLocked?: boolean; // True if quota X has been paid & validated by Pi SDK
}

export const DiscreetAIAssistantModal: React.FC<DiscreetAIAssistantModalProps> = ({
  isOpen,
  onClose,
  targetId,
  targetName,
  targetType,
  onReviewSubmitted,
  isFinancialLocked = false,
}) => {
  const [selectedStars, setSelectedStars] = useState<number>(5);
  const [positiveComment, setPositiveComment] = useState<string>("");
  
  // Deterministic issues for 1-3 stars
  const [selectedIssues, setSelectedIssues] = useState<string[]>([]);
  const [aiComposedText, setAiComposedText] = useState<string>("");
  const [isAiGenerating, setIsAiGenerating] = useState<boolean>(false);
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);

  // Issues Catalog according to entity type
  const ISSUES_CATALOG = targetType === "specialist" ? [
    "Orientamento non conforme o inadeguato al caso",
    "Mancata risposta o ritardo oltre i tempi dichiarati",
    "Mancato rispetto dello spirito di supporto solidale gratuito",
    "Comunicazione poco chiara o poco collaborativa",
    "Richiesta indebita di compensi fuori piattaforma"
  ] : [
    "Difformità qualitativa o difetto non dichiarato dell'oggetto",
    "Mancato incontro / assenza non comunicata",
    "Mancata risposta dopo accordo preliminare in chat",
    "Condizioni di baratto o prezzo modificate all'ultimo momento",
    "Comportamento non cooperativo o poco trasparente"
  ];

  const handleStarClick = (stars: number) => {
    setSelectedStars(stars);
    if (stars <= 3) {
      // Inhibit free-form, prepare deterministic AI mode
      setPositiveComment("");
    }
  };

  const toggleIssue = (issue: string) => {
    const next = selectedIssues.includes(issue)
      ? selectedIssues.filter((i) => i !== issue)
      : [...selectedIssues, issue];
    setSelectedIssues(next);

    // Dynamic deterministic AI composition
    if (next.length > 0) {
      composeCivilText(selectedStars, next);
    } else {
      setAiComposedText("");
    }
  };

  const composeCivilText = (stars: number, issues: string[]) => {
    setIsAiGenerating(true);
    setTimeout(() => {
      let text = `Valutazione Formale di Sistema (${stars}/5 Stelle):\n`;
      text += `L'utente ha rilevato le seguenti non conformità oggettive durante l'interazione:\n`;
      issues.forEach((iss) => {
        text += `• ${iss}\n`;
      });
      if (stars === 1) {
        text += `Rilievo critico: l'esperienza ha compromesso gli standard di affidabilità della comunità. Viene registrata segnalazione per revisione della priorità visiva.`;
      } else if (stars === 2) {
        text += `Rilievo medio: si sollecita una maggiore cura negli accordi e nella puntualità per le future interazioni.`;
      } else {
        text += `Rilievo lieve: si invitano le parti a chiarire le lievi divergenze riscontrate nel pieno spirito di mutuo rispetto.`;
      }
      setAiComposedText(text);
      setIsAiGenerating(false);
    }, 400);
  };

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    
    const finalCivilText = selectedStars <= 3 
      ? aiComposedText || "Segnalazione di disservizio elaborata dall'Assistente IA."
      : (positiveComment.trim() || "Interazione positiva, transazione conclusa con soddisfazione reciproca.");

    const feedback: DiscreetAIReviewFeedback = {
      id: `rev-${Date.now()}`,
      authorUsername: "@pioneer_verificato",
      authorName: "Pioniere Verificato",
      targetId,
      targetName,
      stars: selectedStars,
      interactionQuotaPiPaid: 0.15,
      isAIGeneratedCivilText: selectedStars <= 3,
      selectedIssues: selectedStars <= 3 ? selectedIssues : [],
      civilReviewText: finalCivilText,
      publishedAt: "Adesso",
      status: "pubblicata",
    };

    onReviewSubmitted(feedback);
    setIsSubmitted(true);
    setTimeout(() => {
      setIsSubmitted(false);
      onClose();
      setSelectedIssues([]);
      setAiComposedText("");
      setPositiveComment("");
    }, 2200);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        className="w-full max-w-lg bg-slate-950 border border-slate-800 rounded-3xl p-6 space-y-5 shadow-2xl relative text-slate-100 max-h-[90vh] overflow-y-auto"
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-amber-500/20 border border-amber-500/30 text-amber-400">
              <Star className="w-5 h-5 fill-amber-400" />
            </div>
            <div>
              <h3 className="text-base font-black text-white">Valutazione di Affidabilità P2P</h3>
              <p className="text-xs text-slate-400">Feedback garantito da Scudo Anti-AutoSponsorizzazione</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Financial Lock & Hardware IP Shield Verification Box */}
        <div className="p-3.5 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 flex items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="text-emerald-200">
              <b>Trigger Sbloccato:</b> Quota interazione (0.15 π / Ad-Reward) verificata a sistema via Pi SDK.
            </span>
          </div>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30 shrink-0">
            IP Shield: Attivo
          </span>
        </div>

        {/* Target Profile Info */}
        <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between text-xs">
          <span className="text-slate-400">Valutazione per:</span>
          <span className="font-bold text-white font-mono">{targetName}</span>
        </div>

        <form onSubmit={handleSubmitReview} className="space-y-4">
          {/* Star Selection (1-5) */}
          <div className="space-y-1.5 text-center">
            <label className="text-xs font-bold text-slate-300">
              Seleziona il punteggio da 1 a 5 Stelle:
            </label>
            <div className="flex items-center justify-center gap-2 py-2">
              {[1, 2, 3, 4, 5].map((star) => {
                const isSelected = star <= selectedStars;
                return (
                  <button
                    key={star}
                    type="button"
                    onClick={() => handleStarClick(star)}
                    className="p-1.5 transition-transform hover:scale-125 cursor-pointer"
                  >
                    <Star
                      className={`w-8 h-8 ${
                        isSelected
                          ? selectedStars <= 3
                            ? "text-amber-500 fill-amber-500"
                            : "text-amber-400 fill-amber-400"
                          : "text-slate-700"
                      }`}
                    />
                  </button>
                );
              })}
            </div>
            <div className="text-xs font-black font-mono">
              {selectedStars === 5 && <span className="text-emerald-400">5/5 • Eccellente & Esemplare</span>}
              {selectedStars === 4 && <span className="text-sky-400">4/5 • Molto Positivo & Affidabile</span>}
              {selectedStars === 3 && <span className="text-amber-400">3/5 • Con Riserva (Attivazione IA Discreta)</span>}
              {selectedStars === 2 && <span className="text-orange-400">2/5 • Insoddisfacente (Attivazione IA Discreta)</span>}
              {selectedStars === 1 && <span className="text-rose-400">1/5 • Grave Non Conformità (Attivazione IA Discreta)</span>}
            </div>
          </div>

          {/* Conditional Flow: High Rating (4-5) vs Low Rating (1-3) */}
          {selectedStars >= 4 ? (
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-300 flex items-center justify-between">
                <span>Commento di apprezzamento (opzionale):</span>
                <span className="text-[10px] text-emerald-400 font-mono">Feedback Diretto</span>
              </label>
              <textarea
                value={positiveComment}
                onChange={(e) => setPositiveComment(e.target.value)}
                placeholder="Condividi la tua esperienza positiva con la comunità..."
                rows={3}
                className="w-full p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />
            </div>
          ) : (
            /* Low Rating Mode (1-3 stars): FREE-FORM INPUT INHIBITED + DISCREET AI ENGAGED */
            <div className="space-y-3 p-4 rounded-2xl bg-gradient-to-b from-amber-950/30 to-slate-900 border border-amber-500/40">
              
              {/* IA Banner */}
              <div className="flex items-start gap-2.5">
                <Bot className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-black text-amber-300">Assistente IA Discreto Attivo</span>
                    <span className="text-[9px] px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 font-bold border border-rose-500/30">
                      Testo Libero Inibito
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-300 leading-relaxed">
                    Per garantire una bacheca civile ed evitare insulti, l'IA compone un resoconto oggettivo e formale basato sulle opzioni selezionate qui sotto.
                  </p>
                </div>
              </div>

              {/* Deterministic Quick-Tap Questionnaire */}
              <div className="space-y-1.5 pt-2">
                <span className="text-[11px] font-bold text-slate-300 block">
                  Tocca i motivi del disservizio riscontrato:
                </span>
                <div className="flex flex-col gap-1.5">
                  {ISSUES_CATALOG.map((issue) => {
                    const isChecked = selectedIssues.includes(issue);
                    return (
                      <button
                        key={issue}
                        type="button"
                        onClick={() => toggleIssue(issue)}
                        className={`p-2.5 rounded-xl text-left text-xs font-semibold transition-all flex items-center justify-between cursor-pointer ${
                          isChecked
                            ? "bg-amber-500/25 text-amber-200 border border-amber-500/50 shadow-sm"
                            : "bg-slate-900/80 text-slate-400 hover:bg-slate-800 border border-slate-800"
                        }`}
                      >
                        <span>{issue}</span>
                        {isChecked && <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Live AI Composed Text Display */}
              {selectedIssues.length > 0 && (
                <div className="space-y-1 pt-2">
                  <span className="text-[10px] font-mono uppercase text-sky-400 font-bold flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-sky-400" />
                    Bozza Recensione Oggettiva IA:
                  </span>
                  <div className="p-3 rounded-xl bg-slate-950 border border-sky-500/30 text-xs text-slate-200 font-sans leading-relaxed whitespace-pre-line">
                    {aiComposedText}
                  </div>
                  <span className="text-[10px] text-slate-400 italic block">
                    * Il destinatario riceverà notifica con <b>Diritto di Replica Integrato</b>.
                  </span>
                </div>
              )}

              {/* Penalization Notice */}
              <div className="p-2.5 rounded-xl bg-rose-950/30 border border-rose-500/30 text-[10px] text-rose-300 flex items-center gap-2">
                <AlertTriangle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                <span>
                  <b>Penalizzazione di Sistema:</b> Se la media scende sotto 3.8/5, l'account o lo specialista perde la priorità visiva e la vetrina sponsorizzata su Google Earth 3D.
                </span>
              </div>

            </div>
          )}

          {/* Submit Button */}
          {isSubmitted ? (
            <div className="p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold text-center flex items-center justify-center gap-2">
              <CheckCircle2 className="w-4 h-4" />
              <span>Valutazione validata e pubblicata nel feed di sistema!</span>
            </div>
          ) : (
            <button
              type="submit"
              disabled={selectedStars <= 3 && selectedIssues.length === 0}
              className={`w-full py-3 rounded-xl font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg transition-all ${
                selectedStars <= 3 && selectedIssues.length === 0
                  ? "bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700"
                  : selectedStars <= 3
                  ? "bg-amber-500 hover:bg-amber-400 text-slate-950 cursor-pointer shadow-amber-500/20"
                  : "bg-emerald-400 hover:bg-emerald-300 text-slate-950 cursor-pointer shadow-emerald-400/20"
              }`}
            >
              <Send className="w-4 h-4" />
              <span>
                {selectedStars <= 3
                  ? "Pubblica Segnalazione Oggettiva con IA"
                  : "Pubblica Valutazione a 5 Stelle"}
              </span>
            </button>
          )}
        </form>

      </motion.div>
    </div>
  );
};
