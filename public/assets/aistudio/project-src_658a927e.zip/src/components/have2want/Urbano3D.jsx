import React, { useEffect, useRef, useState } from 'react';
import * as maplibregl from 'maplibre-gl';
import 'maplibre-gl/dist/maplibre-gl.css';
import { Compass, Building, RotateCw, Layers, Navigation, Coins, X, MapPin } from 'lucide-react';
import toast from 'react-hot-toast';

// Stile raster OSM diretto e infallibile per azzerare qualsiasi schermo bianco o vuoto
const DIRECT_RASTER_OSM_STYLE = {
  version: 8,
  sources: {
    'osm-tiles': {
      type: 'raster',
      tiles: [
        'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
        'https://a.tile.openstreetmap.org/{z}/{x}/{y}.png',
        'https://b.tile.openstreetmap.org/{z}/{x}/{y}.png',
        'https://c.tile.openstreetmap.org/{z}/{x}/{y}.png',
      ],
      tileSize: 256,
      attribution: '© OpenStreetMap contributors',
    },
  },
  layers: [
    {
      id: 'osm-tiles-layer',
      type: 'raster',
      source: 'osm-tiles',
      minzoom: 0,
      maxzoom: 19,
    },
  ],
};

export default function Urbano3D({
  centroLat,
  centroLng,
  lat,
  lng,
  userLocation,
  countryName,
  placeData,
  onLocationChange,
  filter,
  filteredListings = [],
  onSelectListing,
  selectedListing,
  onBackToGlobe,
  sponsoredBusinesses = [],
  openPiHubTrigger,
  onOpenPiHub,
  openAdModalTrigger,
  onOpenAdModal,
  openVoiceChatTrigger,
  onOpenVoiceChat,
  onSelectExternalPlace,
}) {
  const mapContainerRef = useRef(null);
  const mapRef = useRef(null);
  const [bearing, setBearing] = useState(0);
  const [pitch, setPitch] = useState(0);
  const [isRotating, setIsRotating] = useState(false);
  const orbitIntervalRef = useRef(null);

  const [showSearchBox, setShowSearchBox] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [isSearching, setIsSearching] = useState(false);

  const [activeLayer, setActiveLayer] = useState('OSM');

  const initialLat = Number(lat ?? centroLat ?? placeData?.lat ?? userLocation?.lat ?? 30.0444);
  const initialLng = Number(lng ?? centroLng ?? placeData?.lng ?? userLocation?.lng ?? 31.2357);

  const [effectiveLat, setEffectiveLat] = useState(initialLat);
  const [effectiveLng, setEffectiveLng] = useState(initialLng);

  const [currentPlace, setCurrentPlace] = useState({
    name: placeData?.name || countryName || userLocation?.name || 'Il Cairo',
    country: { code: placeData?.countryCode || userLocation?.countryCode || 'EG', flag: placeData?.flag || '🇪🇬' },
    currency: placeData?.currency || { code: 'EGP', symbol: '£E' },
    timezone: { name: placeData?.timezone || 'Africa/Cairo', time: '12:00' },
  });

  // Aggiornamento coordinate e posizione mappa
  useEffect(() => {
    const targetLat = Number(lat ?? centroLat ?? placeData?.lat ?? userLocation?.lat);
    const targetLng = Number(lng ?? centroLng ?? placeData?.lng ?? userLocation?.lng);

    if (!isNaN(targetLat) && !isNaN(targetLng) && (targetLat !== 0 || targetLng !== 0)) {
      setEffectiveLat(targetLat);
      setEffectiveLng(targetLng);

      if (placeData) {
        setCurrentPlace({
          name: placeData.name || countryName || 'Località',
          country: { code: placeData.countryCode || 'INT', flag: placeData.flag || '🌐' },
          currency: placeData.currency || { code: 'EUR', symbol: '€' },
          timezone: { name: placeData.timezone || 'UTC', time: '12:00' },
        });
      }

      if (mapRef.current) {
        mapRef.current.flyTo({
          center: [targetLng, targetLat],
          zoom: 14,
          pitch: 0,
          duration: 1200,
          essential: true,
        });
        mapRef.current.resize();
      }
    }
  }, [lat, centroLat, lng, centroLng, placeData, countryName, userLocation]);

  // Inizializzazione della mappa con tile raster dirette
  useEffect(() => {
    if (!mapContainerRef.current) return;
    if (mapRef.current) {
      mapRef.current.resize();
      return;
    }

    const startLng = !isNaN(effectiveLng) && effectiveLng !== 0 ? effectiveLng : 31.2357;
    const startLat = !isNaN(effectiveLat) && effectiveLat !== 0 ? effectiveLat : 30.0444;

    let mapInstance = null;

    try {
      mapInstance = new maplibregl.Map({
        container: mapContainerRef.current,
        style: DIRECT_RASTER_OSM_STYLE,
        center: [startLng, startLat],
        zoom: 14,
        pitch: pitch,
        bearing: bearing,
        antialias: true,
      });
    } catch (err) {
      console.error("Errore inizializzazione mappa:", err);
    }

    mapRef.current = mapInstance;

    mapInstance.on('rotate', () => {
      setBearing(Math.round(mapInstance.getBearing()));
    });

    mapInstance.on('pitch', () => {
      setPitch(Math.round(mapInstance.getPitch()));
    });

    mapInstance.on('load', () => {
      mapInstance.resize();
    });

    const t1 = setTimeout(() => mapInstance?.resize(), 100);
    const t2 = setTimeout(() => mapInstance?.resize(), 300);
    const t3 = setTimeout(() => mapInstance?.resize(), 800);

    const resizeObserver = new ResizeObserver(() => {
      if (mapRef.current) {
        mapRef.current.resize();
      }
    });
    resizeObserver.observe(mapContainerRef.current);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
      resizeObserver.disconnect();
      if (orbitIntervalRef.current) clearInterval(orbitIntervalRef.current);
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
      }
    };
  }, []);

  return (
    <div className="relative w-full h-full overflow-hidden select-none bg-slate-950 font-sans">
      <div ref={mapContainerRef} className="absolute inset-0 w-full h-full z-0" />
    </div>
  );
}
