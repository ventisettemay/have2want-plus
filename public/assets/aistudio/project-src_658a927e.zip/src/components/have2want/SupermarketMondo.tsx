import React, { useState, useEffect } from 'react';
import { useH2W } from '../../lib/h2wContext';
import VideoChatModal from './VideoChatModal';

export default function SupermarketMondo({ currentUser, onOpenChat }) {
  const { merchantPiBalance, deductMerchantSubscription } = useH2W();
  const [isB2B, setIsB2B] = useState(false);
  const [acceptsPi, setAcceptsPi] = useState(false);
  const [shareLocation, setShareLocation] = useState(() => localStorage.getItem('h2w_share_location') === 'true');
  const [showUploadForm, setShowUploadForm] = useState(false);
  const [selectedVideoProduct, setSelectedVideoProduct] = useState(null);

  const [newProduct, setNewProduct] = useState({ name: '', description: '', imageUrl: '', category: 'FORNO', location: '', pricePi: '', b2bPricePi: '', moq: '' });
  const [products, setProducts] = useState([
    { id: 1, name: "Biscotti Artigianali Secchi", description: "Specialità prodotta al forno, spedibile ovunque.", imageUrl: "", category: "FORNO", location: "Prato", pricePi: 8, b2bPricePi: 6, moq: 10, merchantId: "m_forno" }
  ]);

  useEffect(() => { localStorage.setItem('h2w_share_location', shareLocation); }, [shareLocation]);

  const handlePayAndPublish = (e) => {
    e.preventDefault();
    const success = deductMerchantSubscription(acceptsPi ? "DAILY_SCONTO" : "DAILY");
    if (!success) { alert("Saldo Pi insufficiente."); return; }
    const productToAdd = { ...newProduct, id: Date.now(), pricePi: parseFloat(newProduct.pricePi), b2bPricePi: parseFloat(newProduct.b2bPricePi || newProduct.pricePi), moq: parseInt(newProduct.moq || 1), merchantId: currentUser?.id || "m_mondo" };
    setProducts([productToAdd, ...products]);
    setShowUploadForm(false);
    alert("Abbonamento saldato e inserito in Magazzino Internazionale!");
  };

  return (
    <div className="min-h-screen bg-slate-900 text-white p-4">
      <div className="flex justify-between items-center border-b border-slate-700 pb-4 mb-6">
        <div>
          <h1 className="text-2xl font-black text-amber-500">🌍 SUPERMARKET MONDO & MAGAZZINO</h1>
          <p className="text-slate-400 text-xs">Forno, Biscotti, Salumi stagionati, Formaggi rari, Dispensa & Miele, Cantina</p>
        </div>
        <div className="flex items-center gap-3">
          <button onClick={() => setIsB2B(!isB2B)} className="bg-indigo-600 text-white font-bold text-xs px-3 py-2 rounded-xl">{isB2B ? '🏭 VISTA: INGROSSO B2B' : '🛒 VISTA: DETTAGLIO B2C'}</button>
          <label className="flex items-center gap-2 bg-slate-800 px-3 py-1.5 rounded-xl border border-slate-700 text-xs font-bold cursor-pointer">
            📡 Georadar di Zona:
            <input type="checkbox" checked={shareLocation} onChange={(e) => setShareLocation(e.target.checked)} className="sr-only peer" />
            <div className="w-8 h-4 bg-slate-600 rounded-full peer peer-checked:bg-emerald-500 relative after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-3 after:w-3 after:transition-all peer-checked:after:translate-x-full"></div>
          </label>
          <button onClick={() => setShowUploadForm(!showUploadForm)} className="bg-emerald-500 text-slate-950 font-black px-4 py-2 rounded-xl text-xs uppercase">➕ GENERATORE LOCANDINE</button>
        </div>
      </div>

      {showUploadForm && (
        <form onSubmit={handlePayAndPublish} className="bg-slate-800 p-5 rounded-2xl border border-slate-700 mb-6 max-w-xl mx-auto space-y-4">
          <h3 className="text-sm font-black text-amber-400 uppercase">Nuova Locandina Specialità Artigianale</h3>
          <div className="grid grid-cols-2 gap-3 text-slate-900">
            <input type="text" placeholder="Nome Specialità" required value={newProduct.name} onChange={e => setNewProduct({...newProduct, name: e.target.value})} className="p-2 rounded-xl text-sm" />
            <input type="text" placeholder="Città/Paese di Origine" required value={newProduct.location} onChange={e => setNewProduct({...newProduct, location: e.target.value})} className="p-2 rounded-xl text-sm" />
            <input type="number" placeholder="Prezzo B2C (π)" required value={newProduct.pricePi} onChange={e => setNewProduct({...newProduct, pricePi: e.target.value})} className="p-2 rounded-xl text-sm" />
            <input type="number" placeholder="Prezzo B2B (π)" value={newProduct.b2bPricePi} onChange={e => setNewProduct({...newProduct, b2bPricePi: e.target.value})} className="p-2 rounded-xl text-sm" />
            <input type="number" placeholder="Minimo Ordine MOQ" value={newProduct.moq} onChange={e => setNewProduct({...newProduct, moq: e.target.value})} className="p-2 rounded-xl text-sm col-span-2" />
          </div>
          <label className="flex items-center justify-between bg-slate-900/60 p-3 rounded-xl cursor-pointer">
            <span className="text-xs font-bold text-slate-300">🤝 Accetti Pi Coin? (Sconto 50% Tariffa)</span>
            <input type="checkbox" checked={acceptsPi} onChange={(e) => setAcceptsPi(e.target.checked)} className="bg-emerald-500" />
          </label>
          <div className="flex justify-end gap-2 text-xs font-bold">
            <button type="button" onClick={() => setShowUploadForm(false)} className="bg-slate-700 px-4 py-2 rounded-xl">Annulla</button>
            <button type="submit" className="bg-emerald-500 text-slate-950 px-4 py-2 rounded-xl uppercase">Paga ed Inserisci (20π/10π)</button>
          </div>
        </form>
      )}

      <div className="space-y-6">
        {products.map(product => (
          <div key={product.id} className="bg-slate-800 border border-slate-700 p-4 rounded-xl flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-slate-950 rounded-lg flex items-center justify-center font-bold text-slate-500">HD</div>
              <div>
                <h4 className="font-black text-slate-100">{product.name}</h4>
                <p className="text-xs text-slate-400">🌍 Origine: {product.location} • {isB2B ? `MOQ: ${product.moq} pz` : 'Dettaglio B2C'}</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-lg font-black text-amber-400">{isB2B ? `${product.b2bPricePi} π` : `${product.pricePi} π`}</span>
              <button onClick={() => onOpenChat && onOpenChat(product.merchantId)} className="bg-slate-700 text-xs font-black px-3 py-2 rounded-lg">💬 Chat</button>
              <button onClick={() => setSelectedVideoProduct(product)} className="bg-slate-700 text-xs font-black px-3 py-2 rounded-lg text-sky-400">📹 Ispezione</button>
              <button onClick={() => shareLocation ? alert(`Verifica logistica di zona per ${product.location}`) : alert("Spedizione standard")} className={`text-xs font-black px-3 py-2 rounded-lg ${shareLocation ? 'bg-emerald-500 text-slate-950' : 'bg-slate-950 text-sky-400'}`}>
                {shareLocation ? '🗺️ Georadar Zona' : '✈️ Spedibile'}
              </button>
            </div>
          </div>
        ))}
      </div>
      {selectedVideoProduct && <VideoChatModal currentUserId={currentUser?.id || "u1"} listingId={`mondo_${selectedVideoProduct.id}`} onClose={() => setSelectedVideoProduct(null)} />}
    </div>
  );
}
