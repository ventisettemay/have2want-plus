import React, { useState, useEffect, useMemo, useCallback } from 'react';
import Globo3D from './Globo3D';
import Urbano3D from './Urbano3D';
import VoiceNoteChat from './VoiceNoteChat';
import PiNetworkHub from './PiNetworkHub';
import { PioneerRewardsHubModal } from './PioneerRewardsHubModal';
import BusinessSponsorModal from './BusinessSponsorModal';
import WorldEmergencyModal from './WorldEmergencyModal';
import GlobalCarpoolModal from './GlobalCarpoolModal';
import CraftMemoryModal from './CraftMemoryModal';
import ExternalPlaceDetailModal from './ExternalPlaceDetailModal';
import CountryTerritorySheet from './CountryTerritorySheet';
import { ListingDetailModal } from './ListingDetailModal';
import { COUNTRIES } from '@/data/countries';
import { SPONSORED_BUSINESSES, ITALIAN_REGIONS } from '@/data/regions';
import { getHierarchyForCountry } from '@/lib/territoryHierarchy';
import { WORLD_COUNTRIES, formatLocalPrice } from '@/lib/worldAtlas';
import { getDisplayCoordinates, filterVisibleListings, applyGeoPrivacy } from '@/lib/geoPrivacy';
import WeatherAtmosphereOverlay from './WeatherAtmosphereOverlay';
import StrettaDiMano from './StrettaDiMano';
import { toast } from 'sonner';
import {
  Globe2,
  Building2,
  Sparkles,
  ChevronUp,
  ChevronDown,
  X,
  Zap,
  MapPin,
  MessageCircle,
  Handshake,
  CheckCircle2,
  ShieldCheck,
  EyeOff,
  Eye,
  Compass,
  Mic,
  Store,
  Megaphone,
  Car,
  BookOpen,
  GraduationCap,
} from 'lucide-react';

// Helper di risoluzione geografica ad altissima precisione (Atlante Mondiale + Regioni)
function resolveCountryData(countryData) {
  if (!countryData) return null;

  const rawId = (countryData.id || countryData.code || '').toString().toLowerCase().trim();
  const rawName = (countryData.name || '').toString().toLowerCase().trim();
  const rawCountry = (countryData.countryName || countryData.country || '').toString().toLowerCase().trim();
  const rawCapital = (countryData.capital || '').toString().toLowerCase().trim();

  // 1. Cerca in WORLD_COUNTRIES (195+ nazioni del pianeta: Giappone, Marocco, Francia, USA, ecc.)
  const worldMatch = WORLD_COUNTRIES.find((c) => {
    const cCode = c.code.toLowerCase();
    const cCode3 = (c.code3 || '').toLowerCase();
    const cName = c.name.toLowerCase();
    const cNative = (c.nativeName || '').toLowerCase();
    const cCapital = (c.capital || '').toLowerCase();

    return (
      cCode === rawId ||
      cCode3 === rawId ||
      cName === rawName ||
      cName === rawCountry ||
      cNative === rawName ||
      (rawCapital && cCapital === rawCapital) ||
      (rawName.length >= 3 && cName.includes(rawName)) ||
      (rawName.length >= 3 && rawName.includes(cName))
    );
  });

  if (worldMatch) {
    return {
      id: worldMatch.code.toLowerCase(),
      code: worldMatch.code,
      name: worldMatch.name,
      countryName: worldMatch.name,
      capital: worldMatch.capital,
      flag: worldMatch.flag,
      lat: worldMatch.lat,
      lng: worldMatch.lng,
      lang: worldMatch.language?.name || 'Lingua Locale',
      currency: `${worldMatch.currency?.code || 'EUR'} (${worldMatch.currency?.symbol || '€'})`,
      language: worldMatch.language,
      currencyData: worldMatch.currency,
      timezone: worldMatch.timezone,
    };
  }

  // 2. Cerca nelle 20 Regioni Italiane
  const regMatch = ITALIAN_REGIONS.find((r) => {
    const rId = (r.id || '').toLowerCase();
    const rName = (r.name || '').toLowerCase();
    const rCap = (r.capital || '').toLowerCase();
    return rId === rawId || rName === rawName || (rawCapital && rCap === rawCapital);
  });

  if (regMatch) {
    return {
      id: regMatch.id || 'it-reg',
      code: 'IT',
      name: regMatch.name,
      countryName: 'Italia',
      capital: regMatch.capital || '',
      flag: '🇮🇹',
      lat: regMatch.lat,
      lng: regMatch.lng,
      lang: 'Italiano',
      currency: 'EUR (€)',
      language: { code: 'it-IT', name: 'Italiano' },
      currencyData: { code: 'EUR', symbol: '€', name: 'Euro', piRate: 31.41 },
      timezone: 'Europe/Rome',
    };
  }

  // 3. Cerca in COUNTRIES (database storico)
  const countryMatch = COUNTRIES.find((c) => {
    const cId = (c.id || '').toLowerCase();
    const cName = (c.name || '').toLowerCase();
    return cId === rawId || cName === rawName;
  });

  if (countryMatch) {
    return {
      id: countryMatch.id,
      code: countryMatch.id.toUpperCase(),
      name: countryMatch.name,
      countryName: countryMatch.name,
      capital: countryMatch.capital,
      flag: countryMatch.flag,
      lat: countryMatch.lat,
      lng: countryMatch.lng,
      lang: countryMatch.lang || 'Lingua Locale',
      currency: countryMatch.currency || 'EUR (€)',
      language: { name: countryMatch.lang || 'Italiano' },
      currencyData: { code: countryMatch.currency || 'EUR', symbol: '€' },
      timezone: 'UTC',
    };
  }

  // 4. Fallback sicuro mantenendo intatti i dati reali ricevuti
  return {
    id: countryData.id || 'custom',
    code: countryData.code || 'GLOBO',
    name: countryData.name || 'Territorio',
    countryName: countryData.countryName || countryData.name || 'Territorio',
    capital: countryData.capital || '',
    flag: countryData.flag || '🌍',
    lat: countryData.lat ?? (userLocation?.lat || 0),
    lng: countryData.lng ?? (userLocation?.lng || 0),
    lang: countryData.lang || 'Lingua Locale',
    currency: countryData.currency || 'EUR (€)',
    language: countryData.language || { name: countryData.lang || 'Lingua Locale' },
    currencyData: countryData.currencyData || { code: countryData.currency || 'EUR', symbol: '€' },
    timezone: countryData.timezone || 'UTC',
  };
}

export default function MapView3DContainer({
  listings = [],
  currentProfile,
  userLocation,
  onSelectListing,
  onOpenAdHub,
  filter = null, // null = nessun filtro cliccato ('La mappa è pulita')
  searchQuery = '', // Ricerca per esigenza libera
  viewMode = 'GLOBO',
  onViewModeChange,
  onResetFilter,
  resetWorldTrigger = 0,
  focusItalyTrigger = 0,
  selectedCountryId = null,
  countrySelectTrigger = 0,
  openPiHubTrigger = 0,
  openAdModalTrigger = 0,
  openVoiceChatTrigger = 0,
  onResetToWorld,
  isDiscreetMode = false,
  onToggleDiscreetMode,
  proximityPreference = 'EVERYWHERE',
  onProximityPreferenceChange,
  onTriggerHandshake,
  onOpenCreateListing,
  onOpenGuides,
  onOpenTutor,
  globeSubMode: externalGlobeSubMode,
  onGlobeSubModeChange,
}) {
  const [internalLodLevel, setInternalLodLevel] = useState('GLOBO');
  const lodLevel = viewMode || internalLodLevel;
  const setLodLevel = (lvl) => {
    setInternalLodLevel(lvl);
    if (onViewModeChange) onViewModeChange(lvl);
  };

  // Sottomodalità per il Globo: '3D' (Fotografico) o 'GEO' (Geopolitico)
  const [internalGlobeSubMode, setInternalGlobeSubMode] = useState('3D');
  const globeSubMode = externalGlobeSubMode || internalGlobeSubMode;
  const setGlobeSubMode = (mode) => {
    setInternalGlobeSubMode(mode);
    if (onGlobeSubModeChange) onGlobeSubModeChange(mode);
  };

  const handleSelectGlobe3D = () => {
    setLodLevel('GLOBO');
    setGlobeSubMode('3D');
  };

  const handleSelectGlobeGeo = () => {
    setLodLevel('GLOBO');
    setGlobeSubMode('GEO');
    toast.info("🗺️ Modalità Geopolitica attiva: confini e territori");
  };

  const [internalResetTrigger, setInternalResetTrigger] = useState(0);
  const [zoomMode, setZoomMode] = useState('MACRO');
  const [globeWeather, setGlobeWeather] = useState(null);

  const [targetCoords, setTargetCoords] = useState({
    lat: userLocation?.lat || 0,
    lng: userLocation?.lng || 0
  });

  const [currentPlace, setCurrentPlace] = useState({
    name: userLocation?.name || 'Seleziona Luogo',
    country: { code: userLocation?.countryCode || '', flag: '🌍' },
    currency: { code: 'EUR', symbol: '€' },
    timezone: { name: 'CET', time: '12:00' }
  });

  useEffect(() => {
    if (userLocation?.lat !== undefined && userLocation?.lng !== undefined && (userLocation.lat !== 0 || userLocation.lng !== 0)) {
      setTargetCoords({ lat: userLocation.lat, lng: userLocation.lng });
      setCurrentPlace((prev) => ({
        ...prev,
        name: userLocation.name || prev.name,
        country: { code: userLocation.countryCode || prev.country.code, flag: prev.country.flag }
      }));
    }
  }, [userLocation]);

  const [isBottomSheetOpen, setIsBottomSheetOpen] = useState(false);
  const [selectedListing, setSelectedListing] = useState(null);
  const [handshakeListing, setHandshakeListing] = useState(null);

  // Modulo Geografico: Paese selezionato per il popup informativo (null di default per non aprire finestre all'avvio)
  const [selectedCountry, setSelectedCountry] = useState(null);
  const [activeRegion, setActiveRegion] = useState(null);
  const [identifiedZone, setIdentifiedZone] = useState(null);
  const [isZoomingToZone, setIsZoomingToZone] = useState(false);

  // Inserzionisti & Sponsor Mappa 3D, Hub Pi Network e Note Vocali
  const [sponsoredBusinesses, setSponsoredBusinesses] = useState(SPONSORED_BUSINESSES);
  const [isPiHubOpen, setIsPiHubOpen] = useState(false);
  const [isRewardsHubOpen, setIsRewardsHubOpen] = useState(false);
  const [isAdModalOpen, setIsAdModalOpen] = useState(false);
  const [isVoiceChatOpen, setIsVoiceChatOpen] = useState(false);

  // Modali Servizi Diretti & Utilità Globali (Zero spese, zero database interno)
  const [isEmergencyModalOpen, setIsEmergencyModalOpen] = useState(false);
  const [isCarpoolModalOpen, setIsCarpoolModalOpen] = useState(false);
  const [isCraftMemoryOpen, setIsCraftMemoryOpen] = useState(false);
  const [selectedExternalPlace, setSelectedExternalPlace] = useState(null);

  useEffect(() => {
    if (selectedCountryId) {
      const match = resolveCountryData({ id: selectedCountryId });
      if (match) setSelectedCountry(match);
    } else if (selectedCountryId === null && resetWorldTrigger > 0) {
      setSelectedCountry(null);
    }
  }, [selectedCountryId, countrySelectTrigger]);

  useEffect(() => {
    if (openPiHubTrigger > 0) setIsPiHubOpen(true);
  }, [openPiHubTrigger]);

  useEffect(() => {
    if (openAdModalTrigger > 0) setIsAdModalOpen(true);
  }, [openAdModalTrigger]);

  useEffect(() => {
    if (openVoiceChatTrigger > 0) setIsVoiceChatOpen(true);
  }, [openVoiceChatTrigger]);
  const [voiceChatRecipient, setVoiceChatRecipient] = useState({
    name: 'Inserzionista / Negozio Pi',
    role: 'Pi Merchant Gold',
    intro: 'Ciao! Benvenuto sulla mappa 3D Have2Want. Lascia una nota vocale per chiedere informazioni su prodotti, sconti Pi Coin o concordare uno scambio!',
  });

  const handleOpenVoiceChatForStore = (store) => {
    setVoiceChatRecipient({
      name: store?.name || 'Inserzionista Pi',
      role: store?.badge || 'Negozio Verificato',
      intro: store?.voiceIntro || `Ciao! Benvenuti da ${store?.name || 'la nostra attività'}. Come possiamo aiutarti? Lasciaci una nota vocale!`,
    });
    setIsVoiceChatOpen(true);
  };

  const handleAddSponsoredBusiness = (newBiz) => {
    setSponsoredBusinesses((prev) => [newBiz, ...prev]);
  };

  // Stato compattamento barra comandi inferiore (per lasciare il globo visibile al 100%)
  const [isBottomBarCollapsed, setIsBottomBarCollapsed] = useState(false);

  // Handler globale per il pulsante Mondo
  const handleResetToWorld = () => {
    if (lodLevel !== 'GLOBO') {
      setLodLevel('GLOBO');
    }
    setSelectedCountry(null);
    setIdentifiedZone(null);
    setIsZoomingToZone(false);
    setInternalResetTrigger(prev => prev + 1);
    if (onResetToWorld) onResetToWorld();
  };

  // 2. VISIBILITY MANAGER & FILTRI:
  // Combina filtro categoria/richiesta specifica, query di ricerca, moderazione, vicinanza e geoPrivacy
  const filteredListings = useMemo(() => {
    return filterVisibleListings({
      listings,
      activeFilter: filter,
      searchQuery,
      userLocation: targetCoords,
      proximityPreference,
      isDiscreetMode
    });
  }, [listings, filter, searchQuery, targetCoords, proximityPreference, isDiscreetMode]);

  // Gerarchia territoriale dinamica per lo stato selezionato (Italia, Spagna, Francia, USA, ecc.)
  const currentTerritoryHierarchy = useMemo(() => {
    const countryKey = selectedCountry?.name || selectedCountry?.countryName || selectedCountry?.code || 'Italia';
    return getHierarchyForCountry(countryKey);
  }, [selectedCountry]);

  // 1. Individuazione della zona (dal tap sul marker 3D o dalla barra rapida)
  const handleZoneIdentified = (countryData) => {
    if (!countryData) return;
    const matched = resolveCountryData(countryData);
    setIdentifiedZone(matched);
    setIsZoomingToZone(true);
    setSelectedCountry(matched);
  };

  // 2. Solo dopo l'arrivo dello zoom completiamo l'allineamento (SENZA aprire schede o toast invasivi)
  const handleZoneZoomArrived = (countryData) => {
    if (!countryData) return;
    const matched = resolveCountryData(countryData);
    setIsZoomingToZone(false);
    setSelectedCountry(matched);
    setTargetCoords({ lat: matched.lat, lng: matched.lng });
  };

  const handleExploreUrban3D = (country) => {
    const matched = resolveCountryData(country) || selectedCountry;
    if (matched) {
      setTargetCoords({ lat: matched.lat, lng: matched.lng });
      setSelectedCountry(matched);
    }
    setLodLevel('URBANO_3D');
  };

  // Weather data handler from Globo3D
  const handleGlobeWeatherUpdate = useCallback((weather) => {
    setGlobeWeather(weather);
  }, []);

  const handleBuildingSelect = (item) => {
    setSelectedListing(item);
    setIsBottomSheetOpen(false); // Nessun cassetto o mezza scheda che copre la cartina!
    if (onSelectListing) {
      onSelectListing(item);
    }
  };

  return (
    <div className="relative w-full h-full flex-1 min-h-0 bg-black overflow-hidden select-none flex flex-col text-white">
      {/* 3D Scene Container: situato nell'area visibile sopra il footer (flex-1 min-h-0), così il globo è intero e mai coperto dai comandi */}
      <div className="w-full flex-1 relative z-0 overflow-hidden min-h-0">
        {lodLevel === 'GLOBO' ? (
          <>
            <Globo3D
              listings={filteredListings}
              allListings={listings}
              onSelectListing={handleBuildingSelect}
              onCountrySelect={(country) => {
                const matched = resolveCountryData(country);
                setSelectedCountry(matched);
                setActiveRegion(null);
                setIsZoomingToZone(false);
              }}
              onZoneIdentified={handleZoneIdentified}
              onZoneZoomArrived={handleZoneZoomArrived}
              selectedCountryId={selectedCountryId || selectedCountry?.id || identifiedZone?.id}
              resetWorldTrigger={resetWorldTrigger + internalResetTrigger}
              focusItalyTrigger={focusItalyTrigger}
              onZoomModeChange={setZoomMode}
              onEnterUrban3D={handleExploreUrban3D}
              isGeoMode={globeSubMode === 'GEO'}
              onWeatherUpdate={handleGlobeWeatherUpdate}
            />
            {globeWeather && (
              <WeatherAtmosphereOverlay 
                weather={globeWeather} 
                enabled={true} 
              />
            )}
          </>
        ) : (
          <Urbano3D
            centroLat={targetCoords.lat}
            centroLng={targetCoords.lng}
            lat={targetCoords.lat}
            lng={targetCoords.lng}
            onBazarSelect={handleBuildingSelect}
            countryName={selectedCountry?.name || currentTerritoryHierarchy?.name || 'Italia'}
            placeData={activeRegion ? {
              name: activeRegion.capital || activeRegion.name,
              displayName: `${selectedCountry?.flag || currentTerritoryHierarchy?.flag || '📍'} ${activeRegion.capital ? `${activeRegion.capital} (${activeRegion.name})` : activeRegion.name}, ${selectedCountry?.name || currentTerritoryHierarchy?.name || ''}`,
              countryName: selectedCountry?.name || currentTerritoryHierarchy?.name || 'Stato',
              countryCode: selectedCountry?.code || currentTerritoryHierarchy?.code || 'GL',
              stateOrRegion: activeRegion.name,
              flag: selectedCountry?.flag || currentTerritoryHierarchy?.flag || '📍',
              language: selectedCountry?.language || { name: selectedCountry?.lang || currentTerritoryHierarchy?.lang || 'Italiano' },
              currency: selectedCountry?.currencyData || currentTerritoryHierarchy?.currency || { code: 'EUR', symbol: '€' },
              lat: activeRegion.lat,
              lng: activeRegion.lng,
              timezone: selectedCountry?.timezone || 'UTC',
            } : (selectedCountry ? {
              name: selectedCountry.capital || selectedCountry.name,
              displayName: selectedCountry.capital ? `${selectedCountry.capital}, ${selectedCountry.name}` : selectedCountry.name,
              countryName: selectedCountry.name,
              countryCode: selectedCountry.code || 'GLOBO',
              flag: selectedCountry.flag,
              language: selectedCountry.language || { name: selectedCountry.lang || 'Italiano' },
              currency: selectedCountry.currencyData || { code: selectedCountry.currency || 'EUR', symbol: '€' },
              lat: selectedCountry.lat,
              lng: selectedCountry.lng,
              timezone: selectedCountry.timezone,
            } : null)}
            onLocationChange={(place) => {
              if (place) {
                setTargetCoords({ lat: place.lat, lng: place.lng });
              }
            }}
            filter={filter}
            filteredListings={filteredListings}
            onSelectListing={handleBuildingSelect}
            selectedListing={selectedListing}
            onBackToGlobe={() => setLodLevel('GLOBO')}
            sponsoredBusinesses={sponsoredBusinesses}
            onOpenVoiceChat={handleOpenVoiceChatForStore}
            onSelectExternalPlace={(place) => setSelectedExternalPlace(place)}
          />
        )}
      </div>

      {/* 3B. STATUS DISCRETO INDIVIDUAZIONE ZONA (TEMPORANEO, NON COPRE LA MAPPA) */}
      {isZoomingToZone && identifiedZone && (
        <div className="absolute top-3 left-1/2 -translate-x-1/2 z-30 pointer-events-none animate-in fade-in zoom-in duration-300">
          <div className="px-4 py-2 rounded-xl bg-black border border-zinc-800 shadow-2xl flex items-center gap-2.5 text-white">
            <span className="text-xl animate-bounce">{identifiedZone.flag}</span>
            <div className="text-left">
              <div className="text-xs font-black text-white flex items-center gap-1.5">
                <span className="text-[#00ff66]">{identifiedZone.name}</span>
                {identifiedZone.capital && (
                  <span className="text-[10px] text-zinc-400 font-normal">({identifiedZone.capital})</span>
                )}
              </div>
              <div className="text-[9px] text-zinc-300 font-mono flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-[#00ff66] animate-ping" />
                <span>Allineamento telecamera...</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Vista pulita senza overlay o testi invasivi sul globo */}

      {/* Nessuna cartella o badge a comparsa sul globo */}

      {/* Digital Handshake Modal */}
      {handshakeListing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm">
          <div className="relative">
            <button
              onClick={() => setHandshakeListing(null)}
              className="absolute -top-3 -right-3 z-10 p-2 rounded-full bg-[#070b19] hover:bg-slate-800 text-slate-200 border border-slate-700 shadow-xl cursor-pointer"
            >
              ✕
            </button>
            <StrettaDiMano
              listing={handshakeListing}
              currentProfile={currentProfile || { id: "pioneer_001", trust_rating: 4.9 }}
              onVerificationSuccess={() => {
                toast.success("Stretta di mano registrata con successo!");
                setHandshakeListing(null);
              }}
              onClose={() => setHandshakeListing(null)}
            />
          </div>
        </div>
      )}

      {/* MODALI PI NETWORK HUB, INSERZIONISTI & CHAT VOCALE */}
      <PiNetworkHub
        isOpen={isPiHubOpen}
        onClose={() => setIsPiHubOpen(false)}
        onOpenAdModal={() => setIsAdModalOpen(true)}
        onOpenRewardsHub={() => setIsRewardsHubOpen(true)}
      />

      <PioneerRewardsHubModal
        isOpen={isRewardsHubOpen}
        onClose={() => setIsRewardsHubOpen(false)}
      />

      <BusinessSponsorModal
        isOpen={isAdModalOpen}
        onClose={() => setIsAdModalOpen(false)}
        onAddSponsoredBusiness={handleAddSponsoredBusiness}
        currentLocation={{
          lat: targetCoords.lat,
          lng: targetCoords.lng,
          city: selectedCountry?.name || currentPlace?.name || '',
          region: selectedCountry?.name || '',
          countryCode: selectedCountry?.code || currentPlace?.country?.code || '',
        }}
      />

      <VoiceNoteChat
        isOpen={isVoiceChatOpen}
        onClose={() => setIsVoiceChatOpen(false)}
        recipientName={voiceChatRecipient.name}
        recipientRole={voiceChatRecipient.role}
        initialVoiceIntro={voiceChatRecipient.intro}
      />

      {/* MODALI EMERGENZE, TRASFERTE E MEMORIA STORICA (Zero spese, Zero server) */}
      <WorldEmergencyModal
        isOpen={isEmergencyModalOpen}
        onClose={() => setIsEmergencyModalOpen(false)}
        defaultCountryCode={selectedCountry?.id || 'IT'}
      />

      <GlobalCarpoolModal
        isOpen={isCarpoolModalOpen}
        onClose={() => setIsCarpoolModalOpen(false)}
      />

      <CraftMemoryModal
        isOpen={isCraftMemoryOpen}
        onClose={() => setIsCraftMemoryOpen(false)}
      />

      <ExternalPlaceDetailModal
        place={selectedExternalPlace}
        isOpen={Boolean(selectedExternalPlace)}
        onClose={() => setSelectedExternalPlace(null)}
      />

      {/* SCHEDA DETTAGLIO COMPLETA DELL'ANNUNCIO (Aperta al click dal pallino della mappa, con tasto 'Torna alla Mappa') */}
      {selectedListing && (
        <ListingDetailModal
          isOpen={Boolean(selectedListing)}
          listing={{
            id: selectedListing.id,
            title: selectedListing.title || selectedListing.have_description || 'Annuncio',
            description: selectedListing.description || selectedListing.have_description || '',
            category: selectedListing.category || 'Generale',
            price: typeof selectedListing.price === 'number' ? selectedListing.price : parseFloat(selectedListing.price) || 0,
            currency: '€',
            imageUrl: selectedListing.imageUrl,
            images: selectedListing.images || (selectedListing.photos ? selectedListing.photos : []),
            city: selectedListing.city || selectedListing.author?.city || selectedCountry?.name || 'Mondo',
            region: selectedListing.stateOrRegion || activeRegion?.name,
            authorName: selectedListing.author?.name || selectedListing.owner_name || selectedListing.author,
            authorUsername: selectedListing.author?.username,
            originType: selectedListing.originType || (selectedListing.isSample ? 'SAMPLE' : 'REAL_P2P'),
            piPrice: selectedListing.piPrice,
            condition: selectedListing.condition || 'Ottimo stato',
            wantsInExchange: selectedListing.wantsInExchange || selectedListing.want_description || selectedListing.concreteExchange?.itemOrServiceAccepted || 'Scambio alla pari o Pi Coin',
          }}
          onClose={() => setSelectedListing(null)}
          returnToLabel="Torna alla Mappa 🗺️"
          onProposeBarter={(item) => {
            setSelectedListing(null);
            if (onTriggerHandshake) onTriggerHandshake(selectedListing);
          }}
          onContactSeller={(item) => {
            toast.info(`Messaggio diretto per ${item.title}: contatta l'utente per organizzare lo scambio.`);
          }}
        />
      )}
    </div>
  );
}
