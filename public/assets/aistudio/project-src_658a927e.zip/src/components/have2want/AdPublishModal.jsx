import React from 'react';
import { CreateListingModal } from '../CreateListingModal';

/**
 * AdPublishModal alias for CreateListingModal.
 * Ensures backward-compatibility and zero breakages.
 */
export const AdPublishModal = (props) => {
  return <CreateListingModal {...props} />;
};

export default AdPublishModal;
