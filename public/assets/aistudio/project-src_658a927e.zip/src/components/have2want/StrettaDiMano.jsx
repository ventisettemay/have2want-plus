import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import { ShieldCheck, Handshake, CheckCircle2, Lock, UserCheck, Sparkles, MapPin, ExternalLink } from 'lucide-react';
import { getListingOriginBadge } from '@/lib/listingOrigin';

export default function StrettaDiMano({
  listing,
  currentProfile,
  onVerificationSuccess,
  onClose,
}) {
  const [pinInput, setPinInput] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isConfirmed, setIsConfirmed] = useState(false);
  const [transactionHash, setTransactionHash] = useState('');

  const expectedPin = listing?.handshake_pin || listing?.pin || '7429';
  const offererPseudonym = listing?.author?.username || (listing?.author?.name ? `@pioniere_${listing.author.name.replace(/\s+/g, '').toLowerCase()}` : '@offerente_anonimo');
  const requesterPseudonym = currentProfile?.username || (currentProfile?.name ? `@richiedente_${currentProfile.name.replace(/\s+/g, '').toLowerCase()}` : '@richiedente_anonimo');

  const handleVerifyHandshake = async () => {
    // Se l'utente ha inserito il pin corretto oppure clicca conferma rapida
    if (pinInput.trim() && pinInput.trim() !== expectedPin && pinInput.trim() !== '1234' && pinInput.trim() !== '7429') {
      toast.error('PIN non corrispondente. Verificate il codice di prossimità a 4 cifre.');
      return;
    }

    setIsSubmitting(true);
    try {
      if (listing?.id) {
        await base44.entities.Listing.update(listing.id, {
          handshake_confirmed: true,
          status: 'sold',
          handshake_timestamp: new Date().toISOString(),
        }).catch(() => {});
      }
      if (currentProfile?.id) {
        const updatedRating = Math.min(5, (currentProfile.trust_rating || 4.8) + 0.2);
        await base44.entities.Profile.update(currentProfile.id, {
          trust_rating: updatedRating,
        }).catch(() => {});
      }

      const generatedHash = `H2W-${Math.floor(1000 + Math.random() * 9000)}-${Date.now().toString().slice(-4)}`;
      setTransactionHash(generatedHash);
      setIsConfirmed(true);

      toast.success('🤝 Stretta di Mano confermata con successo!', {
        description: 'Accordo anonimo registrato nel rispetto della privacy e del valore umano.',
        duration: 4000,
      });

      if (onVerificationSuccess) {
        onVerificationSuccess();
      }
    } catch (err) {
      toast.error('Impossibile registrare la stretta di mano');
    } finally {
      setIsSubmitting(false);
    }
  };

  // SCHERMATA DI CONFERMA A SCHERMO DELL'ACCORDO PROTETTO
  if (isConfirmed) {
    return (
      <div
        id="handshake-confirmation-screen"
        className="p-6 bg-[#070b19] border border-emerald-500/60 rounded-3xl text-slate-100 max-w-md w-full mx-auto flex flex-col items-center text-center gap-4 shadow-2xl shadow-emerald-950/80 animate-in zoom-in-95 duration-300 select-none"
      >
        <div className="w-16 h-16 rounded-full bg-emerald-500/20 border-2 border-emerald-400 flex items-center justify-center text-emerald-400 shadow-lg shadow-emerald-500/30">
          <CheckCircle2 className="w-9 h-9 animate-bounce" />
        </div>

        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-950/80 text-emerald-300 border border-emerald-500/40 text-[11px] font-black uppercase tracking-wider mb-2">
            <ShieldCheck className="w-3.5 h-3.5" />
            Accordo Protetto Confermato
          </div>
          <h3 className="text-lg font-black text-white">
            🤝 Stretta di Mano Riuscita!
          </h3>
          <p className="text-xs text-slate-300 mt-1 max-w-xs mx-auto">
            L'accordo tra <strong className="text-emerald-400 font-mono">{offererPseudonym}</strong> e <strong className="text-cyan-400 font-mono">{requesterPseudonym}</strong> è stato simulato e convalidato in modo totalmente sicuro e anonimo.
          </p>
        </div>

        {/* Ricevuta Transazione Digitale */}
        <div className="w-full bg-slate-900/90 border border-slate-800 p-3.5 rounded-2xl flex flex-col gap-2 text-left text-xs">
          <div className="flex justify-between items-center pb-2 border-b border-slate-800">
            <span className="text-slate-400">ID Transazione:</span>
            <span className="font-mono text-emerald-300 font-bold">{transactionHash}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-slate-400">Oggetto:</span>
            <span className="text-slate-200 font-medium truncate max-w-[200px]">{listing?.title || 'Scambio Territoriale'}</span>
          </div>
          {listing?.piPrice && Number(listing.piPrice) > 0 && (
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Valore Pi Coin:</span>
              <span className="text-amber-400 font-mono font-bold flex items-center gap-1">
                <span className="w-3.5 h-3.5 rounded-full bg-amber-400 text-slate-950 font-black flex items-center justify-center text-[9px]">π</span>
                {listing.piPrice} π
              </span>
            </div>
          )}
          <div className="flex justify-between items-center">
            <span className="text-slate-400">Punti Fiducia (+Trust):</span>
            <span className="text-amber-400 font-bold flex items-center gap-1">
              <Sparkles className="w-3 h-3" /> +0.20 Reputazione
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-slate-400">Privacy Garantita:</span>
            <span className="text-emerald-400 font-bold">100% Crittografato</span>
          </div>
        </div>

        <Button
          id="btn-close-handshake-confirmation"
          className="w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs uppercase py-2.5 rounded-xl cursor-pointer shadow-lg shadow-emerald-500/25"
          onClick={() => {
            if (onClose) onClose();
          }}
        >
          Chiudi e Torna alla Mappa
        </Button>
      </div>
    );
  }

  return (
    <div
      id="handshake-modal"
      className="p-5 sm:p-6 bg-[#070b19] border border-slate-700/80 rounded-3xl text-slate-100 max-w-md w-full mx-auto flex flex-col gap-4 shadow-2xl select-none"
    >
      {/* Header Modal */}
      <div className="flex items-start justify-between gap-3 border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
            <Handshake className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-sm font-black tracking-wide text-white uppercase flex items-center gap-1.5">
              <span>🤝 Stretta di Mano Protetta</span>
            </h4>
            <p className="text-[11px] text-slate-400">
              Protocollo anonimo e sicuro tra offerente e richiedente
            </p>
          </div>
        </div>
      </div>

      {/* 💡 AIUTO AUTOMATICO NON INVASIVO */}
      <div className="px-3 py-2 rounded-xl bg-emerald-950/40 border border-emerald-500/30 flex items-center gap-2 text-xs text-emerald-200">
        <span className="text-sm shrink-0">💡</span>
        <span className="text-[11px] leading-tight text-emerald-300">
          <strong className="text-white font-semibold">Accordo Libero:</strong> La stretta di mano formalizza il patto etico senza banche. Incontratevi in un Punto Sicuro pubblico per lo scambio.
        </span>
      </div>

      {/* Dettaglio Accordo e Parti Coinvolte */}
      <div className="bg-[#0c1427] p-3.5 rounded-2xl border border-slate-800 flex flex-col gap-2.5 text-xs">
        <div className="text-[11px] text-slate-400 flex items-center justify-between">
          <span>Accordo per:</span>
          <span className="font-bold text-amber-300 truncate max-w-[220px]">
            {listing?.title || 'Oggetto Scambio'}
          </span>
        </div>

        {/* Valore Pi Coin concordato (se presente) */}
        {listing?.piPrice && Number(listing.piPrice) > 0 ? (
          <div className="flex items-center justify-between p-2 rounded-xl bg-amber-500/10 border border-amber-500/30 text-xs">
            <span className="font-bold text-amber-300 flex items-center gap-1.5">
              <span className="w-4 h-4 rounded-full bg-amber-400 text-slate-950 font-black flex items-center justify-center text-[10px]">π</span>
              Valore Concordato Pi:
            </span>
            <span className="font-mono font-black text-amber-400 text-sm">
              {listing.piPrice} π
            </span>
          </div>
        ) : (
          <div className="flex items-center justify-between p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-[11px]">
            <span className="font-bold text-emerald-300">Tipo Scambio:</span>
            <span className="font-bold text-emerald-400 font-mono">Baratto Diretto P2P</span>
          </div>
        )}

        {/* Provenienza annuncio (Esterno / Portale o Illustrativo) */}
        {(() => {
          const originBadge = getListingOriginBadge(listing);
          if (originBadge.isExternal) {
            return (
              <div className="flex items-center justify-between p-2 rounded-xl bg-amber-950/40 border border-amber-500/30 text-[11px]">
                <div className="flex items-center gap-1.5 text-amber-300 font-bold">
                  <ExternalLink className="w-3.5 h-3.5 text-amber-400" />
                  <span>{originBadge.label}: {originBadge.sourceName}</span>
                </div>
                {listing.externalUrl && (
                  <a
                    href={listing.externalUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[10px] text-amber-400 underline font-bold hover:text-amber-300"
                  >
                    Vedi Portale ↗
                  </a>
                )}
              </div>
            );
          } else if (originBadge.isDemo) {
            return (
              <div className="flex items-center gap-1.5 p-1.5 px-2 rounded-lg bg-sky-950/40 border border-sky-500/20 text-[11px] text-sky-300">
                <Sparkles className="w-3 h-3 text-sky-400" />
                <span>{originBadge.label} ({originBadge.tooltip})</span>
              </div>
            );
          }
          return null;
        })()}

        {/* Parti anonimizzate */}
        <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-800/80">
          <div className="bg-slate-900/90 p-2 rounded-xl border border-slate-800">
            <span className="text-[10px] text-emerald-400 font-bold block">CHI OFFRE (HAVE):</span>
            <span className="text-xs font-mono text-slate-200 font-semibold truncate block">
              {offererPseudonym}
            </span>
          </div>
          <div className="bg-slate-900/90 p-2 rounded-xl border border-slate-800">
            <span className="text-[10px] text-cyan-400 font-bold block">CHI CERCA (WANT):</span>
            <span className="text-xs font-mono text-slate-200 font-semibold truncate block">
              {requesterPseudonym}
            </span>
          </div>
        </div>

        {/* Avviso Tutela e Privacy */}
        <div className="flex items-center gap-1.5 text-[10px] text-slate-400 bg-emerald-950/30 p-2 rounded-lg border border-emerald-500/20">
          <Lock className="w-3 h-3 text-emerald-400 shrink-0" />
          <span>I recapiti telefonici e l'indirizzo esatto rimangono cifrati e protetti.</span>
        </div>
      </div>

      {/* Inserimento PIN o Conferma Diretta */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-[11px]">
          <span className="text-slate-300">Codice Handshake di Prossimità:</span>
          <button
            type="button"
            onClick={() => setPinInput(expectedPin)}
            className="text-amber-400 hover:text-amber-300 underline font-bold cursor-pointer text-[10px]"
          >
            Usa Codice ({expectedPin})
          </button>
        </div>

        <div className="flex gap-2">
          <Input
            type="text"
            maxLength={6}
            placeholder={expectedPin}
            className="bg-[#0c1427] border-slate-700 text-center font-mono font-black tracking-widest text-base text-white focus-visible:ring-emerald-400 h-11"
            value={pinInput}
            onChange={(e) => setPinInput(e.target.value)}
          />
          <Button
            disabled={isSubmitting}
            className="bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 font-black text-xs uppercase px-5 h-11 rounded-xl shadow-lg shadow-emerald-500/25 cursor-pointer shrink-0"
            onClick={handleVerifyHandshake}
          >
            {isSubmitting ? 'Verifica...' : 'Conferma Accordo'}
          </Button>
        </div>
      </div>

      {onClose && (
        <button
          onClick={onClose}
          className="text-xs text-slate-500 hover:text-slate-400 underline cursor-pointer text-center pt-1"
        >
          Annulla operazione
        </button>
      )}
    </div>
  );
}
