import React, { useState, useEffect } from 'react';
import { useH2W } from '../../lib/h2wContext';
import VideoChatModal from './VideoChatModal';

export default function VetrinaKmZero({ currentUser, onOpenChat }) {
  const { merchantPiBalance, deductMerchantSubscription } = useH2W();
  const [acceptsPi, setAcceptsPi] = useState(false);
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [shareLocation, setShareLocation] = useState(() => localStorage.getItem('h2w_share_location') === 'true');
  const [showUploadForm, setShowUploadForm] = useState(false);
  const [selectedVideoProduct, setSelectedVideoProduct] = useState(null);
  
  const [newProduct, setNewProduct] = useState({ name: '', description: '', imageUrl: '', category: 'ORTOFRUTTA', location: '', pricePi: '' });
  const [products, setProducts] = useState([
    { id: 1, name: "Arance Rosse Fresche", description: "Raccolte direttamente dal campo al mattino.", imageUrl: "", category: "ORTOFRUTTA", location: "Lentini", pricePi: 5, merchantId: "m_orto" },
    { id: 2, name: "Pescato del Giorno", description: "Sbarcato freschissimo al porto canale.", imageUrl: "", category: "PESCHERIA", location: "Porto di Mazara del Vallo", pricePi: 15, merchantId: "m_porto" }
  ]);

  useEffect(() => { localStorage.setItem('h2w_share_location', shareLocation); }, [shareLocation]);

  const handlePayAndPublish = (e) => {
    e.preventDefault();
    const success = deductMerchantSubscription(acceptsPi ? "DAILY_SCONTO" : "DAILY");
    if (!success && merchantPiBalance < (acceptsPi ? 10 : 20)) {
      alert("Saldo Pi insufficiente per pubblicare la locandina.");
      return;
    }
    const productToAdd = { ...newProduct, id: Date.now(), pricePi: parseFloat(newProduct.pricePi), merchantId: currentUser?.id || "m_local" };
    setProducts([productToAdd, ...products]);
    setShowUploadForm(false);
    setIsSubscribed(true);
    alert("Abbonamento saldato e Locandina Pubblicitaria inserita nello scaffale!");
  };

  return (
    <div className="min-h-screen bg-slate-900 text-white p-4">
      <div className="flex justify-between items-center border-b border-slate-700 pb-4 mb-6">
        <div>
          <h1 className="text-2xl font-black text-amber-500">🥦 VETRINA KM ZERO (PRODOTTI FRESCHI)</h1>
          <p className="text-slate-400 text-xs">Ortofrutta dal campo, Pescheria dal porto/mare, Macelleria</p>
        </div>
        <div className="flex items-center gap-3">
          <label className="flex items-center gap-2 bg-slate-800 px-3 py-1.5 rounded-xl border border-slate-700 text-xs font-bold cursor-pointer">
            📡 Georadar Privacy:
            <input type="checkbox" checked={shareLocation} onChange={(e) => setShareLocation(e.target.checked)} className="sr-only peer" />
            <div className="w-8 h-4 bg-slate-600 rounded-full peer peer-checked:bg-emerald-500 relative after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-3 after:w-3 after:transition-all peer-checked:after:translate-x-full"></div>
          </label>
          <button onClick={() => setShowUploadForm(!showUploadForm)} className="bg-emerald-500 text-slate-950 font-black px-4 py-2 rounded-xl text-xs uppercase">➕ GENERATORE LOCANDINE</button>
        </div>
      </div>

      {showUploadForm && (
        <form onSubmit={handlePayAndPublish} className="bg-slate-800 p-5 rounded-2xl border border-slate-700 mb-6 max-w-xl mx-auto space-y-4">
          <h3 className="text-sm font-black text-amber-400 uppercase">Crea l'Anteprima della tua Locandina Pubblicitaria</h3>
          <div className="grid grid-cols-2 gap-3 text-slate-900">
            <input type="text" placeholder="Nome Prodotto" required value={newProduct.name} onChange={e => setNewProduct({...newProduct, name: e.target.value})} className="p-2.5 rounded-xl text-sm" />
            <select value={newProduct.category} onChange={e => setNewProduct({...newProduct, category: e.target.value})} className="p-2.5 rounded-xl text-sm">
              <option value="ORTOFRUTTA">🥦 Ortofrutta (Campo)</option>
              <option value="PESCHERIA">🐟 Pescheria (Porto/Mare)</option>
              <option value="MACELLERIA">🥩 Macelleria & Salumi</option>
            </select>
            <input type="text" placeholder="Località Esatta (per Georadar)" required value={newProduct.location} onChange={e => setNewProduct({...newProduct, location: e.target.value})} className="p-2.5 rounded-xl text-sm" />
            <input type="number" placeholder="Prezzo Inserzione (π)" required value={newProduct.pricePi} onChange={e => setNewProduct({...newProduct, pricePi: e.target.value})} className="p-2.5 rounded-xl text-sm" />
          </div>
          <label className="flex items-center justify-between bg-slate-900/60 p-3 rounded-xl cursor-pointer">
            <span className="text-xs font-bold text-slate-300">🤝 Accetti pagamenti in Pi Coin? (Sconto 50% Tariffa)</span>
            <input type="checkbox" checked={acceptsPi} onChange={(e) => setAcceptsPi(e.target.checked)} className="bg-emerald-500" />
          </label>
          <div className="bg-slate-950 p-3 rounded-xl border border-slate-700 text-center">
            <span className="text-xs text-slate-400 block font-bold">COSTO ABBONAMENTO INSERZIONE:</span>
            <span className="text-lg font-black text-amber-400">{acceptsPi ? '10 π (Scontato)' : '20 π (Intero)'}</span>
          </div>
          <div className="flex justify-end gap-2 text-xs font-bold">
            <button type="button" onClick={() => setShowUploadForm(false)} className="bg-slate-700 px-4 py-2 rounded-xl">Annulla</button>
            <button type="submit" className="bg-emerald-500 text-slate-950 px-4 py-2 rounded-xl uppercase">Paga ed Inserisci</button>
          </div>
        </form>
      )}

      <div className="space-y-6">
        {products.map(product => (
          <div key={product.id} className="bg-slate-800 border border-slate-700 p-4 rounded-xl flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-slate-950 rounded-lg flex items-center justify-center font-bold text-slate-500">HD</div>
              <div>
                <h4 className="font-black text-slate-100">{product.name}</h4>
                <p className="text-xs text-slate-400">📍 {product.location} • {product.category}</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-lg font-black text-amber-400">{product.pricePi} π</span>
              <button onClick={() => onOpenChat && onOpenChat(product.merchantId)} className="bg-slate-700 text-xs font-black px-3 py-2 rounded-lg">💬 Chat (0.25π)</button>
              <button onClick={() => setSelectedVideoProduct(product)} className="bg-slate-700 text-xs font-black px-3 py-2 rounded-lg text-sky-400">📹 Video Live</button>
              <button onClick={() => shareLocation ? alert(`Navigazione avviata verso ${product.location}`) : alert("Attiva il Georadar")} className={`text-xs font-black px-3 py-2 rounded-lg ${shareLocation ? 'bg-emerald-500 text-slate-950' : 'bg-slate-800 text-slate-500'}`}>🗺️ Georadar</button>
            </div>
          </div>
        ))}
      </div>
      {selectedVideoProduct && <VideoChatModal currentUserId={currentUser?.id || "u1"} listingId={`km0_${selectedVideoProduct.id}`} onClose={() => setSelectedVideoProduct(null)} />}
    </div>
  );
}
