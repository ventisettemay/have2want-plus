import React from 'react';
import {
  CloudSun,
  X,
  Wind,
  Droplets,
  CloudRain,
  Eye,
  Clock,
  Sparkles,
  Thermometer,
  Compass,
  Check,
  ToggleLeft,
  ToggleRight
} from 'lucide-react';
import { getLocalTimeString } from '@/lib/worldAtlas';

export default function LiveWeatherModal({
  isOpen,
  onClose,
  weather,
  place,
  weatherEffectsEnabled = true,
  onToggleWeatherEffects
}) {
  if (!isOpen || !weather) return null;

  const localTime = getLocalTimeString(place?.timezone || weather.timezone || 'UTC');
  const cond = weather.condition || {};

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg rounded-3xl bg-slate-900/98 border border-slate-700/80 shadow-2xl p-6 text-slate-100 overflow-hidden flex flex-col gap-4">
        {/* Glow di sfondo */}
        <div className="absolute -top-20 -right-20 w-48 h-48 bg-sky-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-20 -left-20 w-48 h-48 bg-amber-500/15 rounded-full blur-3xl pointer-events-none" />

        {/* Header Modale */}
        <div className="flex items-start justify-between relative z-10 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-3">
            <span className="text-3xl p-2 rounded-2xl bg-slate-800/80 border border-slate-700/60 shadow-inner">
              {cond.icon || '🌤️'}
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black text-white">{place?.name || 'Località'}</h3>
                <span className="text-xs text-slate-400 font-medium">({place?.countryName || 'Mondo'})</span>
              </div>
              <p className="text-xs text-sky-400 font-bold flex items-center gap-1.5 mt-0.5">
                <span>Meteo in Tempo Reale & Fuso Orario</span>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer border border-slate-700"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Temperatura Principale & Condizione */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-800/90 to-slate-900/90 border border-slate-700/80 flex items-center justify-between shadow-inner">
          <div>
            <div className="text-4xl font-black text-white tracking-tight flex items-baseline gap-1">
              <span>{weather.temperature}</span>
              <span className="text-xl font-bold text-sky-400">°C</span>
            </div>
            <div className="text-sm font-bold text-slate-200 mt-1 flex items-center gap-1.5">
              <span>{cond.label}</span>
              <span className="text-xs text-slate-400 font-normal">• Percepita {weather.apparentTemperature}°C</span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">{cond.description}</p>
          </div>

          <div className="text-right flex flex-col items-end gap-1">
            <span className="px-2.5 py-1 rounded-full text-xs font-black uppercase tracking-wider bg-slate-800 border border-slate-700 text-sky-300">
              {weather.isDay ? '☀️ Giorno' : '🌙 Notte'}
            </span>
            <div className="flex items-center gap-1 text-xs text-emerald-400 font-mono font-bold mt-1">
              <Clock className="w-3.5 h-3.5 text-indigo-400" />
              <span>{localTime}</span>
            </div>
          </div>
        </div>

        {/* Griglia Metriche: Vento, Umidità, Nubi, Precipitazioni */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 flex flex-col gap-1">
            <div className="flex items-center gap-1.5 text-[10px] font-black text-slate-400 uppercase">
              <Wind className="w-3.5 h-3.5 text-sky-400" />
              <span>Vento</span>
            </div>
            <div className="text-sm font-black text-white">
              {weather.windSpeed} <span className="text-xs font-normal text-slate-400">km/h</span>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 flex flex-col gap-1">
            <div className="flex items-center gap-1.5 text-[10px] font-black text-slate-400 uppercase">
              <Droplets className="w-3.5 h-3.5 text-emerald-400" />
              <span>Umidità</span>
            </div>
            <div className="text-sm font-black text-white">
              {weather.humidity} <span className="text-xs font-normal text-slate-400">%</span>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 flex flex-col gap-1">
            <div className="flex items-center gap-1.5 text-[10px] font-black text-slate-400 uppercase">
              <CloudSun className="w-3.5 h-3.5 text-amber-400" />
              <span>Copertura</span>
            </div>
            <div className="text-sm font-black text-white">
              {weather.cloudCover} <span className="text-xs font-normal text-slate-400">%</span>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 flex flex-col gap-1">
            <div className="flex items-center gap-1.5 text-[10px] font-black text-slate-400 uppercase">
              <CloudRain className="w-3.5 h-3.5 text-indigo-400" />
              <span>Precipitaz.</span>
            </div>
            <div className="text-sm font-black text-white">
              {weather.precipitation} <span className="text-xs font-normal text-slate-400">mm</span>
            </div>
          </div>
        </div>

        {/* Previsioni Orarie Prossime Ore */}
        {weather.hourlyForecast && weather.hourlyForecast.length > 0 && (
          <div className="rounded-2xl bg-slate-800/50 border border-slate-700/60 p-3 flex flex-col gap-2">
            <div className="text-[11px] font-black text-slate-300 uppercase tracking-wider flex items-center justify-between">
              <span>Previsione Oraria nel Territorio</span>
              <span className="text-[10px] text-sky-400 font-normal">Fuso: {weather.timezone}</span>
            </div>

            <div className="grid grid-cols-6 gap-1 text-center pt-1">
              {weather.hourlyForecast.map((h, i) => (
                <div key={i} className="p-1.5 rounded-lg bg-slate-900/60 border border-slate-800 flex flex-col items-center gap-0.5">
                  <span className="text-[10px] text-slate-400 font-mono">{h.time}</span>
                  <span className="text-sm">{h.condition?.icon || '☀️'}</span>
                  <span className="text-xs font-black text-white">{h.temp}°</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Switcher Effetti Fenomeni Reali Overlay 3D */}
        <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-400" />
            <div>
              <div className="font-bold text-white">Fenomeni Atmosferici Reali 3D</div>
              <div className="text-[10px] text-slate-400">
                Pioggia, neve o nuvole trasparenti senza oscurare il territorio
              </div>
            </div>
          </div>

          <button
            onClick={() => onToggleWeatherEffects && onToggleWeatherEffects(!weatherEffectsEnabled)}
            className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-bold cursor-pointer transition-colors"
          >
            {weatherEffectsEnabled ? (
              <>
                <span className="text-emerald-400 font-black">Attivi</span>
                <ToggleRight className="w-5 h-5 text-emerald-400" />
              </>
            ) : (
              <>
                <span className="text-slate-400">Spenti</span>
                <ToggleLeft className="w-5 h-5 text-slate-500" />
              </>
            )}
          </button>
        </div>

        {/* Footer Con Azione */}
        <div className="flex items-center justify-end pt-1 border-t border-slate-800">
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-black text-xs uppercase tracking-wider cursor-pointer transition-all shadow-lg shadow-sky-500/25 active:scale-95 flex items-center justify-center gap-2"
          >
            <Check className="w-4 h-4" />
            <span>Chiudi Scheda Meteo</span>
          </button>
        </div>
      </div>
    </div>
  );
}
