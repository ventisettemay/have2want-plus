import React, { useState, useEffect } from 'react';
import { useH2W } from '../../lib/h2wContext';
import VideoChatModal from './VideoChatModal';

export default function SupermarketGlobaleH2W({ currentUser, onOpenChat, isOpen, onClose }) {
  if (!isOpen) return null;

  const [isB2B, setIsB2B] = useState(false);
  const [activeReparto, setActiveReparto] = useState('ALL');
  const [shareLocation, setShareLocation] = useState(() => {
    return localStorage.getItem('h2w_share_location') === 'true';
  });
  
  // Modulo inserimento dati fornitore (Merchant Upload Form)
  const [showUploadForm, setShowUploadForm] = useState(false);
  const [newProduct, setNewProduct] = useState({
    name: '', description: '', imageUrl: '', category: 'MACELLERIA',
    country: '', location: '', pricePi: '', b2bPricePi: '', type: 'LOCALE', stockAvailable: '', moq: ''
  });

  // Schema dati dinamico (Predisposto per caricamento da tutto il mondo)
  const [products, setProducts] = useState([
    {
      id: 1, name: "Specialità Salumeria Artigianale", description: "Prodotto d'eccellenza stagionato secondo tradizione, spedibile in lotti.",
      imageUrl: "", category: "MACELLERIA", country: "Spagna", location: "Guijuelo", 
      pricePi: 120, b2bPricePi: 95, type: "MONDO", stockAvailable: 30, moq: 3, merchantId: "m_salumi"
    },
    {
      id: 2, name: "Pescato del Giorno Fresco", description: "Selezionato direttamente al porto di sbarco, richiede ritiro sul posto.",
      imageUrl: "", category: "PESCHERIA", country: "Italia", location: "Porto di Mazara del Vallo", 
      pricePi: 40, b2bPricePi: 30, type: "LOCALE", stockAvailable: 50, moq: 5, merchantId: "m_pesce"
    }
  ]);

  const [selectedVideoProduct, setSelectedVideoProduct] = useState(null);

  useEffect(() => {
    localStorage.setItem('h2w_share_location', shareLocation);
  }, [shareLocation]);

  const handleUploadProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProduct.name || !newProduct.pricePi) return;
    const productToAdd = {
      ...newProduct,
      id: Date.now(),
      pricePi: parseFloat(newProduct.pricePi),
      b2bPricePi: parseFloat(newProduct.b2bPricePi || newProduct.pricePi),
      stockAvailable: parseInt(newProduct.stockAvailable || '0'),
      moq: parseInt(newProduct.moq || '1'),
      merchantId: currentUser?.id || "merchant_dinamico"
    };
    setProducts([productToAdd, ...products]);
    setShowUploadForm(false);
    setNewProduct({ name: '', description: '', imageUrl: '', category: 'MACELLERIA', country: '', location: '', pricePi: '', b2bPricePi: '', type: 'LOCALE', stockAvailable: '', moq: '' });
  };

  const startRouting = (product: any) => {
    if (!shareLocation) {
      alert("Attiva l'interruttore della privacy per condividere la geolocalizzazione e calcolare la rotta.");
      return;
    }
    alert(`Calcolo rotta stradale avviato tramite Georadar verso la location di vendita: ${product.location}, ${product.country}.`);
  };

  const triggerChatHandshake = (product: any) => {
    alert(`Handshake chat avviato. Verrà applicata la micro-fee in Pi Coin (π) per connettersi direttamente con il fornitore.`);
    if (onOpenChat) onOpenChat(product.merchantId);
  };

  const reparti = [
    { id: 'ALL', name: 'Corsia Intera' },
    { id: 'MACELLERIA', name: '🥩 Macelleria & Salumi' },
    { id: 'CHEESE', name: '🧀 Formaggi & Latticini' },
    { id: 'FORNO', name: '🥖 Forno & Pasticceria' },
    { id: 'ORTO', name: '🥦 Ortofrutta' },
    { id: 'PESCHERIA', name: '🐟 Pescheria' },
    { id: 'DISPENSA', name: '🥫 Dispensa & Miele' },
    { id: 'CANTINA', name: '🍾 Cantina & Oleificio' }
  ];

  return (
    <div className="min-h-screen bg-slate-900 text-white p-4 font-sans">
      {/* Intestazione Supermercato Realistico */}
      <div className="flex flex-col md:flex-row justify-between items-center border-b border-slate-700 pb-4 mb-6 gap-4">
        <div>
          <h1 className="text-3xl font-black bg-gradient-to-r from-amber-400 to-orange-500 bg-clip-text text-transparent">
            SUPERMARKET GLOBALE & MAGAZZINO H2W
          </h1>
          <p className="text-slate-400 text-sm">Corsie Espositive ad Impatto Fotografico per Privati (B2C) e Commercianti (B2B)</p>
        </div>

        <div className="flex flex-wrap items-center gap-4">
          {/* Interruttore Privacy Geolocalizzazione Unificato */}
          <label className="flex items-center gap-2 bg-slate-800 px-3 py-2 rounded-xl border border-slate-700 cursor-pointer select-none">
            <span className="text-xs font-bold text-slate-300">📡 Condividi Posizione (Georadar):</span>
            <input type="checkbox" checked={shareLocation} onChange={(e) => setShareLocation(e.target.checked)} className="sr-only peer" />
            <div className="w-9 h-5 bg-slate-600 rounded-full peer peer-checked:bg-emerald-500 relative after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:after:translate-x-full"></div>
          </label>

          {/* Switch di conversione fluida Supermarket / Magazzino */}
          <button onClick={() => setIsB2B(!isB2B)} className={`px-4 py-2 rounded-xl font-black transition-all duration-300 shadow-md ${isB2B ? 'bg-indigo-600 text-white border border-indigo-400' : 'bg-amber-500 text-slate-950'}`}>
            {isB2B ? '🏭 STILE: RACK / MAGAZZINO INGROSSO' : '🛒 STILE: CORSIA / SUPERMERCATO VETRINA'}
          </button>

          {currentUser?.isExerciser && (
            <button onClick={() => setShowUploadForm(!showUploadForm)} className="bg-emerald-500 text-slate-950 font-black px-4 py-2 rounded-xl hover:bg-emerald-400 text-sm">
              ➕ CARICA SCHEDA PRODOTTO
            </button>
          )}
        </div>
      </div>

      {/* Merchant Upload Form */}
      {showUploadForm && (
        <form onSubmit={handleUploadProduct} className="bg-slate-800 border border-slate-700 p-6 rounded-2xl mb-8 max-w-2xl mx-auto shadow-2xl">
          <h3 className="text-lg font-black text-amber-400 mb-4 uppercase tracking-wide">Pannello Caricamento Nuova Specialità Artigianale</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input type="text" placeholder="Nome Prodotto/Articolo" required value={newProduct.name} onChange={e => setNewProduct({...newProduct, name: e.target.value})} className="bg-slate-900 border border-slate-700 p-3 rounded-xl w-full text-white text-sm" />
            <select value={newProduct.category} onChange={e => setNewProduct({...newProduct, category: e.target.value})} className="bg-slate-900 border border-slate-700 p-3 rounded-xl w-full text-white text-sm">
              {reparti.filter(r => r.id !== 'ALL').map(r => <option key={r.id} value={r.id}>{r.name}</option>)}
            </select>
            <input type="text" placeholder="Paese di Origine" value={newProduct.country} onChange={e => setNewProduct({...newProduct, country: e.target.value})} className="bg-slate-900 border border-slate-700 p-3 rounded-xl w-full text-white text-sm" />
            <input type="text" placeholder="Località / Porto Specifico per Georadar" value={newProduct.location} onChange={e => setNewProduct({...newProduct, location: e.target.value})} className="bg-slate-900 border border-slate-700 p-3 rounded-xl w-full text-white text-sm" />
            <input type="number" step="0.01" placeholder="Prezzo al Dettaglio B2C (π)" required value={newProduct.pricePi} onChange={e => setNewProduct({...newProduct, pricePi: e.target.value})} className="bg-slate-900 border border-slate-700 p-3 rounded-xl w-full text-white text-sm" />
            <input type="number" step="0.01" placeholder="Prezzo all'Ingrosso B2B (π)" value={newProduct.b2bPricePi} onChange={e => setNewProduct({...newProduct, b2bPricePi: e.target.value})} className="bg-slate-900 border border-slate-700 p-3 rounded-xl w-full text-white text-sm" />
            <select value={newProduct.type} onChange={e => setNewProduct({...newProduct, type: e.target.value})} className="bg-slate-900 border border-slate-700 p-3 rounded-xl w-full text-white text-sm">
              <option value="LOCALE">LOCALE (Ritiro sul posto / Navigazione Itinerante)</option>
              <option value="MONDO">MONDO (Spedibile ovunque via Corriere)</option>
            </select>
            <input type="number" placeholder="Stock Giacenza Magazzino" value={newProduct.stockAvailable} onChange={e => setNewProduct({...newProduct, stockAvailable: e.target.value})} className="bg-slate-900 border border-slate-700 p-3 rounded-xl w-full text-white text-sm" />
            <input type="number" placeholder="Quantità Minima Ordine MOQ (Lotti B2B)" value={newProduct.moq} onChange={e => setNewProduct({...newProduct, moq: e.target.value})} className="bg-slate-900 border border-slate-700 p-3 rounded-xl w-full text-white text-sm" />
            <input type="text" placeholder="URL Immagine Fotografica Prodotto" value={newProduct.imageUrl} onChange={e => setNewProduct({...newProduct, imageUrl: e.target.value})} className="bg-slate-900 border border-slate-700 p-3 rounded-xl w-full text-white text-sm col-span-1 md:col-span-2" />
          </div>
          <textarea placeholder="Descrizione dettagliata delle materie prime, lavorazione, tracciabilità o orari di sbarco..." value={newProduct.description} onChange={e => setNewProduct({...newProduct, description: e.target.value})} className="bg-slate-900 border border-slate-700 p-3 rounded-xl w-full text-white mt-4 h-20 text-sm" />
          <div className="flex justify-end gap-2 mt-4">
            <button type="button" onClick={() => setShowUploadForm(false)} className="bg-slate-700 px-4 py-2 rounded-xl text-xs font-bold">Annulla</button>
            <button type="submit" className="bg-emerald-500 text-slate-950 font-black px-4 py-2 rounded-xl hover:bg-emerald-400 text-xs">Posiziona nello Scaffale</button>
          </div>
        </form>
      )}

      {/* Navigazione tra le Corsie Principali */}
      <div className="flex flex-wrap gap-2 mb-6 overflow-x-auto pb-2">
        {reparti.map(rep => (
          <button key={rep.id} onClick={() => setActiveReparto(rep.id)} className={`px-4 py-2 rounded-xl font-black text-xs whitespace-nowrap transition-all duration-200 ${activeReparto === rep.id ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 shadow-md scale-105' : 'bg-slate-800 border border-slate-700 text-slate-300'}`}>
            {rep.name}
          </button>
        ))}
      </div>

      {/* Rendering Corsie e Scaffali Prospettici */}
      {reparti.filter(r => r.id !== 'ALL' && (activeReparto === 'ALL' || activeReparto === r.id)).map(reparto => {
        const filteredProducts = products.filter(p => p.category === reparto.id);
        if (filteredProducts.length === 0) return null;
        return (
          <div key={reparto.id} className="mb-10">
            {/* Effetto Profondità Visiva Finale Scaffale */}
            <div className="flex items-center gap-2 mb-3 px-2">
              <div className="w-8 h-0.5 bg-gradient-to-r from-transparent via-amber-500 to-transparent" />
              <span className="text-lg font-black text-amber-400 tracking-wider">{reparto.name}</span>
              <div className="w-8 h-0.5 bg-gradient-to-l from-transparent via-amber-500 to-transparent" />
            </div>
            {/* Contenitore Scaffale ad Orientamento Orizzontale */}
            <div className="flex gap-3 overflow-x-auto pb-4 snap-x">
              {filteredProducts.map(product => (
                <div key={product.id} className={`w-64 bg-slate-900 rounded-xl border flex flex-col justify-between snap-start transition-all duration-300 ${isB2B ? 'border-indigo-500/50 shadow-indigo-950/30' : 'border-slate-700 shadow-black/40'} hover:scale-[1.01]`}>
                  {/* Immagine con Bandierina Tipo e Localizzazione */}
                  <div className="relative h-40 bg-slate-800 rounded-t-xl overflow-hidden flex items-center justify-center">
                    {product.imageUrl ? (
                      <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover" />
                    ) : (
                      <span className="text-slate-500 text-sm">Foto Prodotto Artigianale</span>
                    )}
                    <span className={`absolute top-2 left-2 text-[9px] font-black px-1.5 py-0.5 rounded uppercase tracking-wider text-white ${product.type === 'LOCALE' ? 'bg-emerald-600' : 'bg-sky-600'}`}>
                      {product.type === 'LOCALE' ? '📍 Ritiro sul Posto' : '🌍 Spedibile'}
                    </span>
                    <span className="absolute bottom-2 left-2 right-2 text-[10px] text-slate-300 bg-black/50 px-1 py-0.5 rounded text-center truncate">
                      {product.location} ({product.country})
                    </span>
                  </div>
                  {/* Contenuto Scheda e Logica Prezzi Dettaglio/Ingrosso */}
                  <div className="p-4 flex-1 flex flex-col justify-between">
                    <div>
                      <h4 className="font-bold text-white mb-1 line-clamp-2">{product.name}</h4>
                      <p className="text-slate-400 text-[11px] line-clamp-3 mb-3">{product.description}</p>
                      <div className="flex items-baseline gap-2 mb-3">
                        <span className="text-[10px] text-slate-500">{isB2B ? 'Prezzo Lotto B2B' : 'Valore Dettaglio'}</span>
                        <span className={`text-xl font-black ${isB2B ? 'text-indigo-400' : 'text-amber-400'}`}>
                          {isB2B ? `${product.b2bPricePi} π` : `${product.pricePi} π`}
                        </span>
                      </div>
                      {isB2B && (
                        <p className="text-[10px] text-slate-500">MOQ / Stock: Min: {product.moq} / Disp: {product.stockAvailable}</p>
                      )}
                    </div>
                    {/* Moduli e Bottoni per Interazione P2P e Navigazione */}
                    <div className="space-y-2 pt-3 border-t border-slate-800">
                      <button onClick={() => triggerChatHandshake(product)} className="w-full bg-slate-800 hover:bg-slate-750 border border-slate-700 rounded-lg py-1.5 text-[10px] font-black uppercase text-center transition-all">
                        💬 Chat (0.25π)
                      </button>
                      <button onClick={() => setSelectedVideoProduct(product)} className="w-full bg-slate-800 hover:bg-slate-750 border border-slate-700 rounded-lg py-1.5 text-[10px] font-black uppercase text-center transition-all text-sky-400">
                        📹 Ispezione Live
                      </button>
                      {product.type === 'LOCALE' ? (
                        <button onClick={() => startRouting(product)} className={`w-full font-black py-1.5 rounded-lg text-[10px] uppercase transition-all text-center ${shareLocation ? 'bg-emerald-500 text-slate-950 hover:bg-emerald-400' : 'bg-slate-800 text-slate-500 border border-slate-700/50 cursor-not-allowed'}`}>
                          {shareLocation ? `📍 Calcola Rotta per ${product.location}` : '📡 Attiva Georadar per Guidare'}
                        </button>
                      ) : (
                        <span className="w-full bg-slate-800 border border-slate-700 rounded-lg py-1.5 text-[10px] font-medium text-center text-sky-400">
                          ✈️ Spedizione Internazionale Garantita
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      })}

      {/* Modal Video Chat Integrato */}
      {selectedVideoProduct && (
        <VideoChatModal 
          currentUserId={currentUser?.id || "utente_generico"} 
          listingId={`supermarket_${selectedVideoProduct.id}`} 
          onClose={() => setSelectedVideoProduct(null)} 
        />
      )}
    </div>
  );
}
