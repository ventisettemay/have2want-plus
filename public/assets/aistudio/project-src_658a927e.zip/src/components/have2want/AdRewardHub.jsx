import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner';
import { Zap, Sparkles, Video, CheckCircle2, Info } from 'lucide-react';

export default function AdRewardHub() {
  const { user } = useAuth();
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isWatching, setIsWatching] = useState(false);

  useEffect(() => { 
    if (user?.id) {
      fetchProfile(); 
    } else {
      setLoading(false);
    }
  }, [user]);

  const fetchProfile = async () => {
    try {
      const res = await base44.entities.Profile.filter({ user_id: user.id });
      if (res && res.length > 0) {
        setProfile(res[0]);
      }
    } catch {
      // Fallback profilo locale
    } finally {
      setLoading(false);
    }
  };

  const handleEarnListingCredit = async () => {
    setIsWatching(true);
    toast.info("Caricamento inserzione promozionale in corso...");

    setTimeout(async () => {
      try {
        const currentCredits = profile?.credit_balance ?? 5;
        const newBalance = Number((currentCredits + 1).toFixed(0));

        if (profile?.id) {
          await base44.entities.Profile.update(profile.id, {
            credit_balance: newBalance,
            ad_completed_streak: ((profile.ad_completed_streak || 0) + 1),
          });
          fetchProfile();
        } else {
          setProfile(prev => ({
            ...(prev || {}),
            credit_balance: newBalance,
          }));
        }

        toast.success("+1 Credito per Inserzione Gratuita aggiunto al tuo saldo!");
      } catch {
        toast.error("Errore nell'accredito del credito inserzione");
      } finally {
        setIsWatching(false);
      }
    }, 1200);
  };

  if (loading) return null;

  const currentCredits = profile?.credit_balance ?? 5;

  return (
    <div className="flex flex-col gap-4 p-5 sm:p-6 bg-[#0f172a] text-slate-100 rounded-2xl border border-slate-700/80 shadow-2xl w-full max-w-md mx-auto">
      {/* Intestazione */}
      <div className="flex justify-between items-center bg-[#1e293b] p-4 rounded-xl border border-slate-700">
        <div>
          <div className="flex items-center gap-1.5 text-emerald-400 font-black text-sm uppercase tracking-wider">
            <Zap className="w-4 h-4 fill-emerald-400" />
            <span>HUB PUBBLICITÀ & INSERZIONI</span>
          </div>
          <p className="text-[11px] text-slate-300 mt-0.5">Crediti gratuiti per dare visibilità ai tuoi annunci</p>
        </div>
        <div className="text-right">
          <span className="text-2xl font-black text-emerald-400">{currentCredits}</span>
          <p className="text-[9px] text-slate-400 uppercase tracking-wider font-bold">Crediti Gratuiti</p>
        </div>
      </div>

      {/* Spiegazione trasparente: Nessun importo inventato, solo crediti gratuiti per inserzioni */}
      <div className="bg-emerald-950/30 border border-emerald-500/30 rounded-xl p-3.5 flex items-start gap-2.5 text-xs text-emerald-200">
        <Info className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <p className="font-semibold text-emerald-300">Inserzioni sempre gratuite con i crediti</p>
          <p className="text-[11px] text-emerald-200/80 leading-relaxed">
            Ogni credito accumulato ti permette di pubblicare inserzioni e annunci in bacheca a costo zero.
            Eventuali tariffe o importi specifici verranno definiti e inseriti in futuro nelle prossime fasi.
          </p>
        </div>
      </div>

      {/* Azione di guadagno crediti */}
      <div className="space-y-2">
        <Button 
          disabled={isWatching}
          className="w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs uppercase py-3.5 rounded-xl shadow-lg shadow-emerald-500/20 cursor-pointer flex items-center justify-center gap-2 transition-all active:scale-98"
          onClick={handleEarnListingCredit}
        >
          {isWatching ? (
            <span className="animate-pulse">Accredito Credito in corso...</span>
          ) : (
            <>
              <Video className="w-4 h-4" />
              <span>Guarda Video Sponsor (+1 Credito Inserzione)</span>
            </>
          )}
        </Button>
      </div>

      {/* Ricarica passiva crediti durante la navigazione */}
      <div className="flex items-center justify-between pt-3 border-t border-slate-800">
        <div>
          <span className="text-xs font-semibold text-slate-200 block">Ricarica Passiva Inserzioni</span>
          <span className="text-[10px] text-slate-400 block">Accumula crediti mentre esplori la mappa</span>
        </div>
        <Switch 
          checked={profile?.ad_stream_enabled ?? true} 
          onCheckedChange={async (val) => { 
            if (profile?.id) {
              await base44.entities.Profile.update(profile.id, { ad_stream_enabled: val });
            }
            fetchProfile(); 
          }} 
        />
      </div>
    </div>
  );
}

