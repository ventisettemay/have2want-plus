import React, { useEffect, useRef, useState, useCallback, useMemo } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { COUNTRIES, getCountryForListing } from '@/data/countries';
import { ITALIAN_REGIONS } from '@/data/regions';
import { WORLD_COUNTRIES } from '@/lib/worldAtlas';
import { createPoliticalGlobeTexture } from '@/lib/politicalGlobeTexture';
import { getRealtimeWeather } from '@/lib/weatherService';
import { Globe, RefreshCw, Compass, ZoomIn, ZoomOut, Eye, Sparkles, MapPin, ArrowRight, Layers, Plus, Minus, Disc, X, Cloud, CloudRain, CloudSnow, CloudLightning, CloudFog, Sun, Moon, Wind, Droplets, Thermometer } from 'lucide-react';
import { toast } from 'sonner';

// Database unificato ad altissima copertura per il raycasting su qualsiasi territorio del pianeta
const ALL_COUNTRIES_DATA = (() => {
  const map = new Map();

  // 1. Inserisci tutti i paesi da WORLD_COUNTRIES
  WORLD_COUNTRIES.forEach((wc) => {
    const code = (wc.code || '').toLowerCase();
    map.set(code, {
      id: code,
      code: wc.code,
      name: wc.name,
      capital: wc.capital,
      flag: wc.flag,
      lat: wc.lat,
      lng: wc.lng,
      currency: `${wc.currency?.code || 'EUR'} (${wc.currency?.symbol || '€'})`,
      currencyData: wc.currency,
      lang: wc.language?.name || 'Locale',
      language: wc.language,
      timezone: wc.timezone,
      description: `${wc.name} • Capitale: ${wc.capital} • Lingua: ${wc.language?.name || 'Locale'}`,
    });
  });

  // 2. Unisci/integra con COUNTRIES
  COUNTRIES.forEach((c) => {
    const id = (c.id || '').toLowerCase();
    const existing = map.get(id);
    if (existing) {
      map.set(id, {
        ...existing,
        ...c,
        flag: c.flag || existing.flag,
        lat: c.lat ?? existing.lat,
        lng: c.lng ?? existing.lng,
      });
    } else {
      map.set(id, {
        ...c,
        flag: c.flag || '🌍',
        description: `${c.name} • Capitale: ${c.capital || ''}`,
      });
    }
  });

  return Array.from(map.values());
})();

export default function Globo3D({
  listings = [],
  allListings = [],
  onSelectListing,
  onCountrySelect,
  onZoneIdentified,
  onZoneZoomArrived,
  selectedCountryId,
  resetWorldTrigger = 0,
  focusItalyTrigger = 0,
  onZoomModeChange,
  onEnterUrban3D,
  isGeoMode = false,
  onWeatherUpdate,
}) {
  const containerRef = useRef(null);
  // Di default la Terra ruota dolcemente e naturalmente sul suo asse inclinato astronomico (23.44°) come nella realtà
  const [isRotating, setIsRotating] = useState(true);
  const isRotatingRef = useRef(true);
  isRotatingRef.current = isRotating;

  // Modalità ironica/virale "Terra Piatta": disco rotante circondato da barriera di ghiaccio
  const [isFlatEarth, setIsFlatEarth] = useState(false);
  const isFlatEarthRef = useRef(false);
  isFlatEarthRef.current = isFlatEarth;

  // Modalità filtro territori nella barra: 'ITALIA' o 'MONDO'
  const [territoryTab, setTerritoryTab] = useState('ITALIA');

  // Zoom status state: true = Macro (national markers visible), false = Urban/close (national markers hidden)
  const [isMacroZoom, setIsMacroZoom] = useState(true);
  const isMacroRef = useRef(true);

  // Active identified zone state for floating UI
  const [activeZone, setActiveZone] = useState(null);
  const [isZoomingIn, setIsZoomingIn] = useState(false);

  // === WEATHER SYSTEM ===
  const [weatherData, setWeatherData] = useState(new Map()); // countryId -> weather
  const [weatherEnabled, setWeatherEnabled] = useState(true);
  const [weatherLoading, setWeatherLoading] = useState(new Set());
  const weatherCacheRef = useRef(new Map()); // Persistent cache across renders

  // Fetch weather for a country
  const fetchCountryWeather = useCallback(async (country) => {
    if (!country || !country.lat || !country.lng) return;
    const cacheKey = `${Math.round(country.lat * 100) / 100},${Math.round(country.lng * 100) / 100}`;
    
    // Check cache first
    if (weatherCacheRef.current.has(cacheKey)) {
      const cached = weatherCacheRef.current.get(cacheKey);
      if (Date.now() - cached.timestamp < 5 * 60 * 1000) { // 5 min TTL
        setWeatherData(prev => new Map(prev).set(country.id, cached.data));
        return cached.data;
      }
    }
    
    setWeatherLoading(prev => new Set(prev).add(country.id));
    try {
      const weather = await getRealtimeWeather(country.lat, country.lng);
      if (weather) {
        weatherCacheRef.current.set(cacheKey, { timestamp: Date.now(), data: weather });
        setWeatherData(prev => new Map(prev).set(country.id, weather));
      }
      return weather;
    } catch (err) {
      console.warn('[Globo3D] Weather fetch failed for', country.name, err);
    } finally {
      setWeatherLoading(prev => {
        const next = new Set(prev);
        next.delete(country.id);
        return next;
      });
    }
  }, []);

  // Fetch weather for all visible countries
  const fetchAllVisibleWeather = useCallback(() => {
    if (!weatherEnabled) return;
    ALL_COUNTRIES_DATA.forEach(country => {
      if (country.lat && country.lng) {
        fetchCountryWeather(country);
      }
    });
  }, [weatherEnabled, fetchCountryWeather]);

  // Initialize weather fetching
  useEffect(() => {
    fetchAllVisibleWeather();
    // Refresh every 10 minutes
    const interval = setInterval(fetchAllVisibleWeather, 10 * 60 * 1000);
    return () => clearInterval(interval);
  }, [fetchAllVisibleWeather]);

  // Notify parent of weather updates
  useEffect(() => {
    if (onWeatherUpdate && weatherData.size > 0) {
      // Convert Map to object for easier consumption
      const weatherObj = Object.fromEntries(weatherData);
      onWeatherUpdate(weatherObj);
    }
  }, [weatherData, onWeatherUpdate]);

  // Callback refs to always access latest callbacks inside Three.js loop without re-running useEffect
  const listingsRef = useRef(listings);
  const weatherParticleSystemsRef = useRef([]);
  listingsRef.current = listings.length > 0 ? listings : allListings;
  const onSelectListingRef = useRef(onSelectListing);
  onSelectListingRef.current = onSelectListing;
  const onCountrySelectRef = useRef(onCountrySelect);
  onCountrySelectRef.current = onCountrySelect;
  const onZoneIdentifiedRef = useRef(onZoneIdentified);
  onZoneIdentifiedRef.current = onZoneIdentified;
  const onZoneZoomArrivedRef = useRef(onZoneZoomArrived);
  onZoneZoomArrivedRef.current = onZoneZoomArrived;
  const onZoomModeChangeRef = useRef(onZoomModeChange);
  onZoomModeChangeRef.current = onZoomModeChange;
  const onEnterUrban3DRef = useRef(onEnterUrban3D);
  onEnterUrban3DRef.current = onEnterUrban3D;

  // Ref to hold the fly-to reset function to be called from triggers or buttons
  const flyToResetRef = useRef(null);
  const flyToCountryRef = useRef(null);
  const positionReticleRef = useRef(null);
  const zoomInRef = useRef(null);
  const zoomOutRef = useRef(null);
  const toggleFlatEarthRef = useRef(null);
  const togglePoliticalRevealRef = useRef(null);
  const [isPoliticalRevealed, setIsPoliticalRevealed] = useState(false);

  // Helper per creare badge compatto per la bandiera e il nome nazione (con indicatore annunci presenti)
  const createCountrySprite = (country, isSelected, listingsCount = 0) => {
    const canvas = document.createElement('canvas');
    canvas.width = 210;
    canvas.height = 56;
    const ctx = canvas.getContext('2d');

    const isItaly = country.id === 'it';

    // Sfondo del badge con angoli arrotondati (Nero Puro #000000, Bordo Neon #00ff66)
    ctx.fillStyle = '#000000';
    ctx.strokeStyle = isSelected ? '#00ff66' : isItaly ? '#00ff66' : '#ffffff';
    ctx.lineWidth = 2.5;

    const x = 3, y = 3, w = 204, h = 50, r = 10;
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    // Emoji bandiera
    ctx.font = '24px "Apple Color Emoji", "Segoe UI Emoji", "Noto Color Emoji", sans-serif';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    ctx.fillText(country.flag || '🌍', 10, 28);

    // Nome paese (Bianco puro su Nero)
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 15px system-ui, -apple-system, sans-serif';
    const maxLen = listingsCount > 0 ? 8 : 11;
    const displayName = country.name.length > maxLen ? country.name.slice(0, maxLen - 1) + '…' : country.name;
    ctx.fillText(displayName, 46, 28);

    // Badge con conteggio annunci presenti nel territorio (Nero su Verde Neon)
    if (listingsCount > 0) {
      const bx = 180, by = 28, br = 13;
      ctx.fillStyle = '#00ff66';
      ctx.beginPath();
      ctx.arc(bx, by, br, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#000000';
      ctx.font = '900 12px system-ui, -apple-system, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(String(listingsCount), bx, by);
    }

    const texture = new THREE.CanvasTexture(canvas);
    texture.minFilter = THREE.LinearFilter;
    const spriteMat = new THREE.SpriteMaterial({
      map: texture,
      transparent: true,
      depthTest: true,
      depthWrite: false,
      opacity: 0.95,
    });
    const sprite = new THREE.Sprite(spriteMat);
    // Scala compatta ed elegante (non copre interi continenti)
    sprite.scale.set(4.1, 1.15, 1);
    sprite.userData = { ...country, isNationalMarker: true, listingsCount, baseOpacity: 0.95 };
    return { sprite, texture, material: spriteMat };
  };

  // Helper per creare badge 3D dell'annuncio (Listing)
  const createListingSprite = (listing) => {
    const canvas = document.createElement('canvas');
    canvas.width = 210;
    canvas.height = 54;
    const ctx = canvas.getContext('2d');

    const isCarpool = listing.subcategory === 'trasferte_passaggi_carpool' || 
      (listing.tags && listing.tags.some(t => /trasfert|carpool|passagg/i.test(t))) ||
      /trasfert|carpool|passagg/i.test(listing.title || '');
    const isSell = (listing.intent === 'VENDO' || listing.action_type === 'vendo') && !isCarpool;
    const isCerco = (listing.intent === 'ACQUISTO_CERCO' || listing.intent === 'CERCO' || listing.action_type === 'acquisto_cerco') && !isCarpool;
    const isSwap = (listing.intent === 'BARATTO_SCAMBIO' || listing.action_type === 'baratto' || listing.action_type === 'baratto_scambio') && !isCarpool;
    const isBook = listing.category === 'libri_scuola_cultura' && !isCarpool;
    const isService = (listing.intent === 'OFFRO_SERVIZIO' || listing.category === 'servizi_lavoro_buoni') && !isCarpool;

    // Tema rigoroso Bianco/Nero e Verde Neon: Sfondo nero puro, bordo neon o bianco
    ctx.fillStyle = '#000000';
    ctx.strokeStyle = '#00ff66';
    ctx.lineWidth = 2.0;

    const x = 3, y = 3, w = 204, h = 48, r = 8;
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    // Icona del tipo annuncio distinto
    const icon = isCarpool ? '🚗' : isSell ? '📦' : isCerco ? '🔍' : isSwap ? '🔄' : isBook ? '📚' : isService ? '🛠️' : '✨';
    ctx.font = '20px "Apple Color Emoji", "Segoe UI Emoji", "Noto Color Emoji", sans-serif';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    ctx.fillText(icon, 10, 27);

    // Titolo e città annuncio
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 14px system-ui, -apple-system, sans-serif';
    const city = listing.author?.city || listing.city || '';
    const rawTitle = listing.title || '';
    const titleText = rawTitle.length > 11 ? rawTitle.slice(0, 10) + '…' : rawTitle;
    const label = city ? `${city} • ${titleText}` : titleText;
    ctx.fillText(label, 38, 27);

    const texture = new THREE.CanvasTexture(canvas);
    texture.minFilter = THREE.LinearFilter;
    const spriteMat = new THREE.SpriteMaterial({
      map: texture,
      transparent: true,
      depthTest: true,
      depthWrite: false,
      opacity: 0.95,
    });
    const sprite = new THREE.Sprite(spriteMat);
    sprite.scale.set(3.4, 0.92, 1);
    sprite.userData = { isListingMarker: true, listing, baseOpacity: 0.95 };
    return { sprite, texture, material: spriteMat };
  };

  useEffect(() => {
    if (!containerRef.current) return;

    const container = containerRef.current;
    let width = container.clientWidth || window.innerWidth;
    let height = container.clientHeight || window.innerHeight;

    // 1. SCENA SPAZIALE DARK MODE (#000000 - Nero Assoluto e Alto Contrasto)
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x000000);

    // 2. TELECAMERA ORBITALE (Centratura elevata: il globo è sollevato verticalmente per liberare la parte inferiore)
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 2000);
    const isInitialPortrait = width < height;
    const initialMobileRatio = isInitialPortrait ? Math.max(1.15, (height / width) * 0.6) : 1.0;
    // Puntamento leggermente abbassato sul target (0, -8, 0) o sollevamento camera per mostrare il globo alto e chiaro
    const defaultCameraPos = new THREE.Vector3(20, 36, 155 * initialMobileRatio);
    const defaultCameraTarget = new THREE.Vector3(0, -6, 0);
    camera.position.copy(defaultCameraPos);

    // 3. RENDERER WEBGL
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    container.appendChild(renderer.domElement);

    // 4. CONTROLLI ORBITALI TOUCH E MOUSE STABILI E FLUIDI (NON BALLERINI)
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05; // Frena dolcemente, previene scivolamenti o oscillazioni eccessive
    controls.rotateSpeed = 0.35; // Risposta controllata, fluida e precisa senza scatti repentini
    controls.minDistance = 62; // Permette zoom super ravvicinato sul territorio senza bloccarsi
    controls.maxDistance = 260; // Vista panoramica macro
    controls.enablePan = false;

    let isUserInteracting = false;
    let interactionTimeout = null;
    let isFlying = false;

    const dismissActiveZone = () => {
      setActiveZone(null);
      if (positionReticleRef.current) {
        positionReticleRef.current(null);
      }
    };

    controls.addEventListener('start', () => {
      isUserInteracting = true;
      if (interactionTimeout) clearTimeout(interactionTimeout);
    });

    controls.addEventListener('change', () => {
      if (isUserInteracting && !isFlying) {
        dismissActiveZone();
      }
    });

    controls.addEventListener('end', () => {
      // Breve pausa di 3.5 secondi prima di riprendere la dolce rotazione naturale
      if (interactionTimeout) clearTimeout(interactionTimeout);
      interactionTimeout = setTimeout(() => {
        isUserInteracting = false;
      }, 3500);
    });

    // 5. ILLUMINAZIONE CALIBRATA E RIPOSANTE (Zero abbagliamento agli occhi, contrasto naturale)
    const sunLight = new THREE.DirectionalLight(0xffffff, 1.25); // Luce solare bilanciata
    sunLight.position.set(130, 80, 130);
    scene.add(sunLight);

    const cyanRimLight = new THREE.DirectionalLight(0x7dd3fc, 0.4); // Luce d'atmosfera morbida
    cyanRimLight.position.set(-130, -30, -100);
    scene.add(cyanRimLight);

    const spaceAmbient = new THREE.AmbientLight(0xffffff, 0.75); // Luce ambiente uniforme e riposante
    scene.add(spaceAmbient);

    // 6. CAMPO STELLARE CON PARTICELLE BLU E VERDI
    const starsCount = 950;
    const starsGeo = new THREE.BufferGeometry();
    const starPos = new Float32Array(starsCount * 3);
    const starColors = new Float32Array(starsCount * 3);

    for (let i = 0; i < starsCount; i++) {
      const radius = 550 + Math.random() * 350;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(Math.random() * 2 - 1);
      starPos[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
      starPos[i * 3 + 1] = radius * Math.sin(phi) * Math.sin(theta);
      starPos[i * 3 + 2] = radius * Math.cos(phi);

      const rand = Math.random();
      if (rand > 0.6) {
        starColors[i * 3] = 0.2; starColors[i * 3 + 1] = 0.8; starColors[i * 3 + 2] = 1.0;
      } else if (rand > 0.3) {
        starColors[i * 3] = 0.1; starColors[i * 3 + 1] = 0.95; starColors[i * 3 + 2] = 0.6;
      } else {
        starColors[i * 3] = 0.8; starColors[i * 3 + 1] = 0.9; starColors[i * 3 + 2] = 0.95;
      }
    }
    starsGeo.setAttribute('position', new THREE.BufferAttribute(starPos, 3));
    starsGeo.setAttribute('color', new THREE.BufferAttribute(starColors, 3));
    const starsMat = new THREE.PointsMaterial({
      size: 1.5,
      vertexColors: true,
      transparent: true,
      opacity: 0.75,
    });
    scene.add(new THREE.Points(starsGeo, starsMat));

    // 7. GLOBO 3D INTERATTIVO CON INCLINAZIONE REALE ASSE TERRESTRE (23.44° astronomici)
    const globeGroup = new THREE.Group();
    // Obliquità dell'eclittica: inclinazione esatta di 23.44° rispetto alla perpendicolare
    const EARTH_AXIAL_TILT = (23.44 * Math.PI) / 180;
    globeGroup.rotation.z = EARTH_AXIAL_TILT;
    scene.add(globeGroup);

    const raggioGlobo = 60;
    const textureLoader = new THREE.TextureLoader();

    // Sfera base con texture terrestre ad alta definizione
    const globoGeo = new THREE.SphereGeometry(raggioGlobo, 64, 64);
    const earthTexture = textureLoader.load('/textures/earth_atmos_2048.jpg');
    const earthNormal = textureLoader.load('/textures/earth_normal_2048.jpg');
    const earthSpecular = textureLoader.load('/textures/earth_specular_2048.jpg');

    // Materiale fotorealistico brillante e ad alto contrasto per evidenziare coste, stati, isole e rilievi
    const globoMat = new THREE.MeshStandardMaterial({
      map: earthTexture,
      normalMap: earthNormal,
      normalScale: new THREE.Vector2(0.85, 0.85),
      roughness: 0.45,
      metalness: 0.05,
      color: 0xffffff,
      emissive: 0x051329, // Leggero bagliore per non avere zone buie
      emissiveIntensity: 0.18,
      transparent: true,
      opacity: 1.0,
    });
    const globoMesh = new THREE.Mesh(globoGeo, globoMat);
    globeGroup.add(globoMesh);

    // 9. NUBI ATMOSFERICHE TRASPARENTI (Visibili solo su 3D fotografico)
    const cloudsTexture = textureLoader.load('/textures/earth_clouds_1024.png');
    const cloudsGeo = new THREE.SphereGeometry(raggioGlobo + 0.6, 48, 48);
    const cloudsMat = new THREE.MeshStandardMaterial({
      map: cloudsTexture,
      transparent: true,
      opacity: 0.08, // Molto leggero
      blending: THREE.NormalBlending,
      depthWrite: false,
    });
    const cloudsMesh = new THREE.Mesh(cloudsGeo, cloudsMat);
    globeGroup.add(cloudsMesh);

    // 7B. MODALITÀ GLOBO POLITICO SULLA STESSA IDENTICA SFERA HOME (Raggio 60, zero sfere doppie)
    const politicalTexture = createPoliticalGlobeTexture();
    const initialGeo = Boolean(isGeoMode);
    if (initialGeo) {
      globoMat.map = politicalTexture;
      globoMat.roughness = 0.92;
      globoMat.metalness = 0.0;
      globoMat.normalScale.set(0, 0);
      globoMat.emissiveIntensity = 0.0;
      cloudsMesh.visible = false;
      sunLight.intensity = 0.95;
      spaceAmbient.intensity = 0.85;
      cyanRimLight.intensity = 0.15;
    }
    const isPoliticalActiveRef = { current: initialGeo };
    if (initialGeo) {
      setIsPoliticalRevealed(true);
    }

    togglePoliticalRevealRef.current = (forceValue) => {
      const nextActive = typeof forceValue === 'boolean' 
        ? forceValue 
        : !isPoliticalActiveRef.current;
      isPoliticalActiveRef.current = nextActive;
      globoMat.map = nextActive ? politicalTexture : earthTexture;
      if (nextActive) {
        // Modalità Geopolitica: finitura cartografica opaca riposante, zero abbagliamento
        globoMat.roughness = 0.92;
        globoMat.metalness = 0.0;
        globoMat.normalScale.set(0, 0);
        globoMat.emissiveIntensity = 0.0;
        cloudsMesh.visible = false;
        sunLight.intensity = 0.95;
        spaceAmbient.intensity = 0.85;
        cyanRimLight.intensity = 0.15;
      } else {
        // Modalità Fotografica 3D: pianeta realistico dallo spazio con nubi e rilievi
        globoMat.roughness = 0.45;
        globoMat.metalness = 0.05;
        globoMat.normalScale.set(0.85, 0.85);
        globoMat.emissiveIntensity = 0.18;
        cloudsMesh.visible = true;
        sunLight.intensity = 1.25;
        spaceAmbient.intensity = 0.75;
        cyanRimLight.intensity = 0.4;
      }
      globoMat.needsUpdate = true;
      setIsPoliticalRevealed(nextActive);
      return nextActive;
    };

    // 10A. EASTER EGG "TERRA PIATTA" (DISCO ROTANTE CON MURO DI GHIACCIO & CUPOLA)
    const flatEarthGroup = new THREE.Group();
    flatEarthGroup.visible = false;
    scene.add(flatEarthGroup);

    // Disco orizzontale della Terra Piatta con mappa
    const flatDiskGeo = new THREE.CylinderGeometry(62, 60, 4, 64);
    const flatDiskMat = new THREE.MeshStandardMaterial({
      map: earthTexture,
      roughness: 0.5,
      metalness: 0.1,
      color: 0xffffff,
    });
    const flatDiskMesh = new THREE.Mesh(flatDiskGeo, flatDiskMat);
    flatDiskMesh.rotation.y = Math.PI;
    flatEarthGroup.add(flatDiskMesh);

    // Bordo / Muro di Ghiaccio dell'Antartide (Ice Wall ai confini)
    const iceWallGeo = new THREE.TorusGeometry(62, 3.5, 16, 64);
    const iceWallMat = new THREE.MeshStandardMaterial({
      color: 0xe0f2fe,
      roughness: 0.2,
      metalness: 0.3,
      emissive: 0x38bdf8,
      emissiveIntensity: 0.3,
    });
    const iceWallMesh = new THREE.Mesh(iceWallGeo, iceWallMat);
    iceWallMesh.rotation.x = Math.PI / 2;
    iceWallMesh.position.y = 1.5;
    flatEarthGroup.add(iceWallMesh);

    // Cupola di cristallo superiore
    const domeGeo = new THREE.SphereGeometry(62, 32, 16, 0, Math.PI * 2, 0, Math.PI / 2);
    const domeMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.12,
      wireframe: true,
    });
    const domeMesh = new THREE.Mesh(domeGeo, domeMat);
    flatEarthGroup.add(domeMesh);

    toggleFlatEarthRef.current = (active) => {
      if (active) {
        globeGroup.visible = false;
        flatEarthGroup.visible = true;
        camera.position.set(0, 110, 120);
        controls.target.set(0, 0, 0);
        controls.update();
        toast.info("❄️ Easter Egg 'Terra Piatta' Attivo!", {
          description: "Attenzione: Muro di ghiaccio invalicabile ai bordi del disco!",
          duration: 4000
        });
      } else {
        flatEarthGroup.visible = false;
        globeGroup.visible = true;
        camera.position.copy(defaultCameraPos);
        controls.target.copy(defaultCameraTarget);
        controls.update();
        toast.success("🌍 Ritorno alla Sfera Terrestre Reale 3D");
      }
    };

    // Conversione Coordinate Geografiche (Lat, Lng) in Coordinate Cartesiane 3D
    // Matematica esatta per texture equirettangolare su Three.js SphereGeometry:
    function convertiCoordinate(lat, lng, raggio) {
      const theta = (90 - lat) * (Math.PI / 180);
      const phi = (lng + 180) * (Math.PI / 180);
      return new THREE.Vector3(
        -raggio * Math.cos(phi) * Math.sin(theta),
        raggio * Math.cos(theta),
        raggio * Math.sin(phi) * Math.sin(theta)
      );
    }

    // 11. GRUPPO PUNTI GEOGRAFICI & ANNUNCI (PRECISIONE MILLIMETRICA SUL GLOBO)
    // Punti fissati rigidamente alle coordinate reali: Spagna in Spagna, Cina in Cina, Italia in Italia.
    const nationalMarkersGroup = new THREE.Group();
    globeGroup.add(nationalMarkersGroup);

    const clickableNodes = [];
    const pulsingRings = [];
    const createdResources = [];

    // A) BANDIERE E INDICATORI DEI PAESI (Sempre visibili sul globo per capire dove si trovano gli annunci)
    const sourceListings = (allListings && allListings.length > 0) ? allListings : (listings || []);
    const countryListingsMap = new Map();
    sourceListings.forEach((item) => {
      const c = getCountryForListing(item, COUNTRIES);
      if (c && c.id) {
        if (!countryListingsMap.has(c.id)) {
          countryListingsMap.set(c.id, []);
        }
        countryListingsMap.get(c.id).push(item);
      }
    });

    COUNTRIES.forEach((country) => {
      const countryItems = countryListingsMap.get(country.id) || [];
      const listingsCount = countryItems.length;

      // Mostriamo la bandiera se ci sono annunci nel paese, oppure per i paesi pioniere principali
      const isKeyHub = ['it', 'fr', 'es', 'de', 'gb', 'ch', 'us', 'jp', 'eg'].includes(country.id);
      if (listingsCount === 0 && !isKeyHub) return;

      const pos = convertiCoordinate(country.lat, country.lng, raggioGlobo);
      const normal = pos.clone().normalize();

      const isSelected = selectedCountryId === country.id;
      // Bianco e Verde Neon ad alto contrasto (#00ff66)
      const pinColor = isSelected ? 0x00ff66 : (country.id === 'it' ? 0x00ff66 : 0xffffff);

      // 1. Perno verticale 3D ancorato alla superficie terrestre
      const stemHeight = 2.8;
      const stemGeo = new THREE.CylinderGeometry(0.12, 0.12, stemHeight, 8);
      const stemMat = new THREE.MeshBasicMaterial({ color: pinColor, opacity: 0.85, transparent: true });
      const stemMesh = new THREE.Mesh(stemGeo, stemMat);
      const stemPos = pos.clone().add(normal.clone().multiplyScalar(stemHeight * 0.5));
      stemMesh.position.copy(stemPos);
      stemMesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), normal);
      stemMesh.userData = { ...country, isNationalMarker: true, listingsCount };
      nationalMarkersGroup.add(stemMesh);
      clickableNodes.push(stemMesh);
      createdResources.push({ geo: stemGeo, mat: stemMat });

      // 2. Nucleo luminoso sferico in cima al perno
      const pinHeadGeo = new THREE.SphereGeometry(0.75, 14, 14);
      const pinHeadMat = new THREE.MeshBasicMaterial({ color: pinColor });
      const pinHeadMesh = new THREE.Mesh(pinHeadGeo, pinHeadMat);
      pinHeadMesh.position.copy(pos.clone().add(normal.clone().multiplyScalar(stemHeight)));
      pinHeadMesh.userData = { ...country, isNationalMarker: true, listingsCount };
      nationalMarkersGroup.add(pinHeadMesh);
      clickableNodes.push(pinHeadMesh);
      createdResources.push({ geo: pinHeadGeo, mat: pinHeadMat });

      // 3. Mini-anello radar alla base
      const baseRingGeo = new THREE.RingGeometry(0.4, 1.4, 16);
      const baseRingMat = new THREE.MeshBasicMaterial({
        color: pinColor,
        transparent: true,
        opacity: 0.65,
        side: THREE.DoubleSide,
        depthWrite: false,
      });
      const baseRing = new THREE.Mesh(baseRingGeo, baseRingMat);
      baseRing.position.copy(pos.clone().add(normal.clone().multiplyScalar(0.2)));
      baseRing.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), normal);
      nationalMarkersGroup.add(baseRing);
      pulsingRings.push({ ring: baseRing, baseScale: 1.0 });
      createdResources.push({ geo: baseRingGeo, mat: baseRingMat });

      // Mostra l'etichetta solo se il paese ha annunci attivi o è attualmente selezionato, per evitare sovrapposizioni illeggibili
      if (isSelected || listingsCount > 0) {
        const { sprite, texture, material } = createCountrySprite(country, isSelected, listingsCount);
        sprite.position.copy(pos.clone().add(normal.clone().multiplyScalar(stemHeight + 1.8)));
        nationalMarkersGroup.add(sprite);
        clickableNodes.push(sprite);
        createdResources.push({ texture, mat: material });
      }
    });

    // === CREATE WEATHER PARTICLE SYSTEMS FOR COUNTRIES ===
    const createWeatherParticles = (country) => {
      const weather = weatherData.get(country.id);
      if (!weather || !weather.condition) return;
      
      const category = weather.condition.category;
      const isRain = category === 'rain' || category === 'drizzle' || category === 'thunderstorm';
      const isSnow = category === 'snow';
      const isFog = category === 'fog';
      const isThunder = category === 'thunderstorm';
      
      if (!isRain && !isSnow && !isFog) return;
      
      const pos = convertiCoordinate(country.lat, country.lng, raggioGlobo);
      const particleCount = isRain ? 200 : isSnow ? 120 : 80;
      
      const geometry = new THREE.BufferGeometry();
      const positions = new Float32Array(particleCount * 3);
      const velocities = new Float32Array(particleCount);
      const opacities = new Float32Array(particleCount);
      const sizes = new Float32Array(particleCount);
      
      for (let i = 0; i < particleCount; i++) {
        const i3 = i * 3;
        const radius = raggioGlobo + 1.5 + Math.random() * 2;
        const phi = Math.random() * Math.PI * 2;
        const theta = Math.acos(2 * Math.random() - 1);
        
        positions[i3] = radius * Math.sin(theta) * Math.cos(phi);
        positions[i3 + 1] = radius * Math.cos(theta);
        positions[i3 + 2] = radius * Math.sin(theta) * Math.sin(phi);
        
        velocities[i] = 0.02 + Math.random() * 0.03;
        opacities[i] = 0.4 + Math.random() * 0.4;
        sizes[i] = isRain ? 0.15 : isSnow ? 0.25 : 0.5;
      }
      
      geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
      geometry.setAttribute('velocity', new THREE.BufferAttribute(velocities, 1));
      geometry.setAttribute('opacity', new THREE.BufferAttribute(opacities, 1));
      geometry.setAttribute('size', new THREE.BufferAttribute(sizes, 1));
      
      // Create material based on weather type
      let material;
      if (isRain) {
        material = new THREE.PointsMaterial({
          color: 0x7dd3fc,
          size: 0.3,
          transparent: true,
          opacity: 0.6,
          depthWrite: false,
          blending: THREE.AdditiveBlending,
          vertexColors: false,
        });
      } else if (isSnow) {
        material = new THREE.PointsMaterial({
          color: 0xffffff,
          size: 0.4,
          transparent: true,
          opacity: 0.8,
          depthWrite: false,
          blending: THREE.AdditiveBlending,
        });
      } else { // fog
        material = new THREE.PointsMaterial({
          color: 0xcfd8e3,
          size: 2.0,
          transparent: true,
          opacity: 0.15,
          depthWrite: false,
          blending: THREE.NormalBlending,
        });
      }
      
      const particles = new THREE.Points(geometry, material);
      particles.position.copy(pos);
      globeGroup.add(particles);
      createdResources.push({ geo: geometry, mat: material });
      
      weatherParticleSystemsRef.current.push({ particles, material, countryData: country });
    };
    
    // Create weather particles for countries with active weather
    ALL_COUNTRIES_DATA.forEach(country => {
      if (country.lat && country.lng && weatherData.has(country.id)) {
        createWeatherParticles(country);
      }
    });

    // B) MARKER PUNTUALI PER GLI ANNUNCI FILTRATI
    const activeListingsList = (listings && Array.isArray(listings)) ? listings : [];

    activeListingsList.forEach((listing) => {
      if (typeof listing.lat !== 'number' || typeof listing.lng !== 'number') return;

      const pos = convertiCoordinate(listing.lat, listing.lng, raggioGlobo);
      const normal = pos.clone().normalize();

      const isCarpool = listing.subcategory === 'trasferte_passaggi_carpool' || 
        (listing.tags && listing.tags.some(t => /trasfert|carpool|passagg/i.test(t))) ||
        /trasfert|carpool|passagg/i.test(listing.title || '');
      const isSell = (listing.intent === 'VENDO' || listing.action_type === 'vendo') && !isCarpool;
      const isCerco = (listing.intent === 'ACQUISTO_CERCO' || listing.intent === 'CERCO' || listing.action_type === 'acquisto_cerco') && !isCarpool;
      const isSwap = (listing.intent === 'BARATTO_SCAMBIO' || listing.action_type === 'baratto' || listing.action_type === 'baratto_scambio') && !isCarpool;
      const isBook = listing.category === 'libri_scuola_cultura' && !isCarpool;
      const isService = (listing.intent === 'OFFRO_SERVIZIO' || listing.category === 'servizi_lavoro_buoni') && !isCarpool;

      // Palette rigorosa Bianco e Verde Neon (#00ff66) per gli annunci
      const pinColor = (isSell || isCarpool || isService) ? 0x00ff66 : 0xffffff;

      // 1. Sottile perno verticale 3D ancorato alla superficie
      const stemHeight = 2.4;
      const stemGeo = new THREE.CylinderGeometry(0.12, 0.12, stemHeight, 8);
      const stemMat = new THREE.MeshBasicMaterial({ color: pinColor, opacity: 0.85, transparent: true });
      const stemMesh = new THREE.Mesh(stemGeo, stemMat);
      // Posiziona il perno lungo la normale
      const stemPos = pos.clone().add(normal.clone().multiplyScalar(stemHeight * 0.5));
      stemMesh.position.copy(stemPos);
      stemMesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), normal);
      stemMesh.userData = { isListingMarker: true, listing, name: listing.title, lat: listing.lat, lng: listing.lng };
      nationalMarkersGroup.add(stemMesh);
      clickableNodes.push(stemMesh);
      createdResources.push({ geo: stemGeo, mat: stemMat });

      // 2. Nucleo luminoso sferico in cima al perno
      const pinHeadGeo = new THREE.SphereGeometry(0.85, 14, 14);
      const pinHeadMat = new THREE.MeshBasicMaterial({ color: pinColor });
      const pinHeadMesh = new THREE.Mesh(pinHeadGeo, pinHeadMat);
      pinHeadMesh.position.copy(pos.clone().add(normal.clone().multiplyScalar(stemHeight)));
      pinHeadMesh.userData = { isListingMarker: true, listing, name: listing.title, lat: listing.lat, lng: listing.lng };
      nationalMarkersGroup.add(pinHeadMesh);
      clickableNodes.push(pinHeadMesh);
      createdResources.push({ geo: pinHeadGeo, mat: pinHeadMat });

      // 3. Mini-anello radar alla base dell'annuncio
      const baseRingGeo = new THREE.RingGeometry(0.3, 1.2, 16);
      const baseRingMat = new THREE.MeshBasicMaterial({
        color: pinColor,
        transparent: true,
        opacity: 0.65,
        side: THREE.DoubleSide,
        depthWrite: false,
      });
      const baseRing = new THREE.Mesh(baseRingGeo, baseRingMat);
      baseRing.position.copy(pos.clone().add(normal.clone().multiplyScalar(0.2)));
      baseRing.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), normal);
      nationalMarkersGroup.add(baseRing);
      pulsingRings.push({ ring: baseRing, baseScale: 1.0 });
      createdResources.push({ geo: baseRingGeo, mat: baseRingMat });

      // 4. Badge compatto descrittivo dell'annuncio (Billboard 3D)
      const { sprite, texture, material } = createListingSprite(listing);
      sprite.position.copy(pos.clone().add(normal.clone().multiplyScalar(stemHeight + 1.6)));
      nationalMarkersGroup.add(sprite);
      clickableNodes.push(sprite);
      createdResources.push({ texture, mat: material });
    });

    // 11B. RETICOLO VISIVO 3D DI INDIVIDUAZIONE ZONA (Target Reticle)
    const zoneReticleGroup = new THREE.Group();
    zoneReticleGroup.visible = false;
    globeGroup.add(zoneReticleGroup);

    const reticleInnerRingGeo = new THREE.RingGeometry(2.2, 2.9, 36);
    const reticleInnerRingMat = new THREE.MeshBasicMaterial({
      color: 0x10b981,
      transparent: true,
      opacity: 0.95,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
    const reticleInnerRing = new THREE.Mesh(reticleInnerRingGeo, reticleInnerRingMat);
    zoneReticleGroup.add(reticleInnerRing);

    const reticleOuterRingGeo = new THREE.RingGeometry(4.0, 4.6, 36);
    const reticleOuterRingMat = new THREE.MeshBasicMaterial({
      color: 0x06b6d4,
      transparent: true,
      opacity: 0.75,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
    const reticleOuterRing = new THREE.Mesh(reticleOuterRingGeo, reticleOuterRingMat);
    zoneReticleGroup.add(reticleOuterRing);

    // Punto faro centrale brillante
    const reticleCenterGeo = new THREE.SphereGeometry(1.2, 16, 16);
    const reticleCenterMat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
    });
    const reticleCenter = new THREE.Mesh(reticleCenterGeo, reticleCenterMat);
    zoneReticleGroup.add(reticleCenter);

    createdResources.push(
      { geo: reticleInnerRingGeo, mat: reticleInnerRingMat },
      { geo: reticleOuterRingGeo, mat: reticleOuterRingMat },
      { geo: reticleCenterGeo, mat: reticleCenterMat }
    );

    const positionZoneReticle = (country) => {
      if (!country) {
        zoneReticleGroup.visible = false;
        return;
      }
      const pos = convertiCoordinate(country.lat, country.lng, raggioGlobo + 0.65);
      const normal = pos.clone().normalize();
      zoneReticleGroup.position.copy(pos);
      zoneReticleGroup.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), normal);
      zoneReticleGroup.visible = true;
    };
    positionReticleRef.current = positionZoneReticle;

    // 12. LOGICA FLY-TO E ANIMAZIONI TELECAMERA
    let flyAnimationId = null;
    isFlying = false;

    function flyTo(targetPosition, targetLookAt, duration = 1000, onComplete = null) {
      isFlying = true;
      const startPos = camera.position.clone();
      const startTarget = controls.target.clone();
      const startTime = performance.now();

      // Disattiva comandi utente durante il volo controllato
      controls.enabled = false;

      function step(now) {
        const elapsed = now - startTime;
        const progress = Math.min(elapsed / duration, 1.0);
        // Easing cubico fluido: 1 - (1 - progress)^3
        const ease = 1 - Math.pow(1 - progress, 3);

        camera.position.lerpVectors(startPos, targetPosition, ease);
        controls.target.lerpVectors(startTarget, targetLookAt, ease);
        controls.update();

        if (progress < 1.0) {
          flyAnimationId = requestAnimationFrame(step);
        } else {
          flyAnimationId = null;
          isFlying = false;
          controls.enabled = true;
          if (onComplete) onComplete();
        }
      }

      if (flyAnimationId) cancelAnimationFrame(flyAnimationId);
      flyAnimationId = requestAnimationFrame(step);
    }

    // Funzione Reset "Mondo": riporta la telecamera alla vista macro globale intera
    const flyToGlobalView = (showToast = true) => {
      zoneReticleGroup.visible = false;
      setActiveZone(null);
      setIsZoomingIn(false);

      flyTo(defaultCameraPos, defaultCameraTarget, 950, () => {
        // Garantisce che il gruppo marker torni visibile in macro view
        nationalMarkersGroup.visible = true;
        setIsMacroZoom(true);
        isMacroRef.current = true;
        if (onZoomModeChange) onZoomModeChange('MACRO');
        if (showToast) {
          toast.success("🌍 Vista Globale ripristinata", {
            description: "Telecamera centrata sulla panoramica macro del Mondo",
            duration: 2500,
          });
        }
      });
    };
    flyToResetRef.current = flyToGlobalView;

    // Funzione Fly-To su un paese o annuncio specifico con ingrandimento concreto
    const flyToCountry = (country, onArrivedCallback = null, triggerZoneArrival = true) => {
      if (!country) return;
      positionZoneReticle(country);
      setActiveZone(country);
      setIsZoomingIn(true);

      const countryPos = convertiCoordinate(country.lat, country.lng, raggioGlobo);
      // Trasforma le coordinate locali rispetto alla rotazione e inclinazione reale della sfera
      globeGroup.updateMatrixWorld(true);
      const worldPos = globeGroup.localToWorld(countryPos.clone());
      const direction = worldPos.clone().normalize();

      // INGRANDIMENTO CONCRETO: telecamera scende a quota ravvicinata (~82 vs raggio 60)
      const targetPos = direction.multiplyScalar(82);
      const targetLookAt = new THREE.Vector3(0, 0, 0);

      flyTo(targetPos, targetLookAt, 1050, () => {
        setIsZoomingIn(false);
        if (onArrivedCallback) {
          onArrivedCallback(country);
        }
        if (triggerZoneArrival && onZoneZoomArrivedRef.current) {
          onZoneZoomArrivedRef.current(country);
        }
      });
    };
    flyToCountryRef.current = flyToCountry;

    // Zoom manuale incrementale controllato (avvicina/allontana senza MAI resettare)
    const zoomInManual = () => {
      if (!camera || !controls) return;
      dismissActiveZone();
      const dir = camera.position.clone().sub(controls.target).normalize();
      const currentDist = camera.position.distanceTo(controls.target);
      const newDist = Math.max(controls.minDistance + 2, currentDist - 24);
      camera.position.copy(controls.target.clone().add(dir.multiplyScalar(newDist)));
      controls.update();
    };
    zoomInRef.current = zoomInManual;

    const zoomOutManual = () => {
      if (!camera || !controls) return;
      dismissActiveZone();
      const dir = camera.position.clone().sub(controls.target).normalize();
      const currentDist = camera.position.distanceTo(controls.target);
      const newDist = Math.min(controls.maxDistance - 5, currentDist + 24);
      camera.position.copy(controls.target.clone().add(dir.multiplyScalar(newDist)));
      controls.update();
    };
    zoomOutRef.current = zoomOutManual;

    // 13. GESTIONE GESTI, TAP E INDIVIDUAZIONE ZONA (ROBUSTA ED ANTI-SCATTO)
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();

    let pointerDownX = 0;
    let pointerDownY = 0;
    let pointerDownTime = 0;
    let isPointerDown = false;
    let isDragging = false;
    let isMultiTouchActive = false;
    let multiTouchEndTime = 0;

    const handlePointerDown = (clientX, clientY) => {
      pointerDownX = clientX;
      pointerDownY = clientY;
      pointerDownTime = performance.now();
      isPointerDown = true;
      isDragging = false;
    };

    const handlePointerMove = (clientX, clientY) => {
      if (!isPointerDown) return;
      const moveDist = Math.hypot(clientX - pointerDownX, clientY - pointerDownY);
      if (moveDist > 8) {
        isDragging = true;
        if (!isFlying) {
          dismissActiveZone();
        }
      }
    };

    const handlePointerUp = (clientX, clientY) => {
      isPointerDown = false;
      // Se l'utente era in pinch-to-zoom o ha appena finito un gesto multi-touch,
      // blocca rigorosamente il tap per evitare qualsiasi ripristino involontario
      if (isMultiTouchActive || (performance.now() - multiTouchEndTime < 450)) {
        return;
      }

      const elapsed = performance.now() - pointerDownTime;
      const moveDist = Math.hypot(clientX - pointerDownX, clientY - pointerDownY);

      // FILTRO ANTI-TOCCHI ACCIDENTALI:
      // Tolleranza naturale per smartphone e dita: fino a 700ms e 14px di spostamento
      if (isDragging || elapsed > 700 || moveDist > 14) return;

      const rect = renderer.domElement.getBoundingClientRect();
      mouse.x = ((clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(mouse, camera);

      // Controllo occlusione sferica: interseca il globo terrestre e i nodi marker
      const earthHits = raycaster.intersectObjects([globoMesh], false);
      const nodeHits = raycaster.intersectObjects(clickableNodes, false);

      let targetCountryData = null;

      // 1. Priorità: se l'utente ha toccato direttamente un marker annuncio o un badge nazione
      if (nodeHits.length > 0) {
        const hit = nodeHits[0];

        // Se la superficie terrestre è intersecata a distanza inferiore rispetto al marker,
        // significa che il marker si trova sul retro o dietro la curva del globo: scarta l'interazione!
        if (!(earthHits.length > 0 && earthHits[0].distance < hit.distance - 0.5)) {
          const markerObj = hit.object;

          // Se è un marker di un annuncio reale (Listing)
          if (markerObj.userData && markerObj.userData.isListingMarker && markerObj.userData.listing) {
            const item = markerObj.userData.listing;
            if (onSelectListingRef.current) {
              onSelectListingRef.current(item);
            }
            flyToCountry({
              lat: item.lat,
              lng: item.lng,
              name: item.title,
              flag: '📍',
              description: `${item.author?.city || item.city || ''} • ${item.intent || 'ANNUNCIO'}`,
            });
            return;
          }

          const countryData = markerObj.userData;
          if (countryData && countryData.name) {
            const markerWorldPos = new THREE.Vector3();
            markerObj.getWorldPosition(markerWorldPos);
            const camDir = camera.position.clone().sub(markerWorldPos).normalize();
            const normal = markerWorldPos.clone().normalize();
            if (normal.dot(camDir) >= 0.05) {
              // Trova i dettagli completi per assicurare la bandiera e i dati corretti
              const matchedCountry = ALL_COUNTRIES_DATA.find(
                (c) => c.id === countryData.id || c.name.toLowerCase() === countryData.name.toLowerCase()
              );
              targetCountryData = matchedCountry || countryData;
            }
          }
        }
      }

      // 2. Se l'utente ha toccato la superficie del globo terrestre:
      // Rispetta l'intento dell'utente: NON mostrare luoghi o stati predefiniti casuali.
      // Cerca se esiste un annuncio attivo tra quelli cercati/filtrati vicino al punto cliccato.
      if (!targetCountryData && earthHits.length > 0) {
        const hitPoint = earthHits[0].point;
        const localHit = globeGroup.worldToLocal(hitPoint.clone());

        // Controlla se c'è un annuncio attivo vicino al punto toccato
        let nearestListing = null;
        let minListingDist = Infinity;
        if (activeListingsList && activeListingsList.length > 0) {
          for (const item of activeListingsList) {
            if (typeof item.lat === 'number' && typeof item.lng === 'number') {
              const pos = convertiCoordinate(item.lat, item.lng, raggioGlobo);
              const dist = localHit.distanceTo(pos);
              if (dist < minListingDist) {
                minListingDist = dist;
                nearestListing = item;
              }
            }
          }
        }

        if (nearestListing && minListingDist < 7.5) {
          if (onSelectListingRef.current) {
            onSelectListingRef.current(nearestListing);
          }
          flyToCountry({
            lat: nearestListing.lat,
            lng: nearestListing.lng,
            name: nearestListing.title,
            flag: '📍',
            description: `${nearestListing.author?.city || nearestListing.city || ''}`,
          }, null, false);
          return;
        }

        // Quando l'utente tocca un punto sulla superficie del globo con il dito:
        // Ruota dolcemente il Globo verso quel punto geografico
        const normLocal = localHit.clone().normalize();
        const latClicked = 90 - Math.acos(Math.max(-1, Math.min(1, normLocal.y))) * (180 / Math.PI);
        const lngClicked = ((Math.atan2(normLocal.z, -normLocal.x) * (180 / Math.PI)) - 180 + 540) % 360 - 180;

        flyToCountry({
          lat: latClicked,
          lng: lngClicked,
          name: "Territorio",
          flag: "🌍",
        }, null, false);
        return;
      }

      // Se abbiamo individuato una regione o stato, attiva lo strato politico per mostrare i confini
      if (targetCountryData) {
        if (togglePoliticalRevealRef.current) {
          togglePoliticalRevealRef.current(true);
        }
        positionZoneReticle(targetCountryData);
        setActiveZone(targetCountryData);
        flyToCountry(targetCountryData, null, false);
      }
    };

    const onMouseDown = (e) => handlePointerDown(e.clientX, e.clientY);
    const onMouseMove = (e) => handlePointerMove(e.clientX, e.clientY);
    const onMouseUp = (e) => handlePointerUp(e.clientX, e.clientY);

    const onTouchStart = (e) => {
      if (e.touches.length > 1) {
        isMultiTouchActive = true;
      } else if (e.touches.length === 1) {
        isMultiTouchActive = false;
        handlePointerDown(e.touches[0].clientX, e.touches[0].clientY);
      }
    };
    const onTouchMove = (e) => {
      if (e.touches.length > 1) {
        isMultiTouchActive = true;
        if (!isFlying) {
          dismissActiveZone();
        }
      } else if (e.touches.length === 1 && !isMultiTouchActive) {
        handlePointerMove(e.touches[0].clientX, e.touches[0].clientY);
      }
    };
    const onTouchEnd = (e) => {
      if (isMultiTouchActive || e.touches.length > 0) {
        multiTouchEndTime = performance.now();
        if (e.touches.length === 0) {
          setTimeout(() => {
            isMultiTouchActive = false;
          }, 350);
        }
        return; // Non innescare mai tap durante o al termine di gesti pinch zoom
      }
      if (e.changedTouches.length === 1) {
        handlePointerUp(e.changedTouches[0].clientX, e.changedTouches[0].clientY);
      }
    };

    const domEl = renderer.domElement;
    domEl.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);

    domEl.addEventListener('touchstart', onTouchStart, { passive: true });
    domEl.addEventListener('touchmove', onTouchMove, { passive: true });
    domEl.addEventListener('touchend', onTouchEnd, { passive: true });

    // 14. ANIMATION LOOP & ROTAZIONE FLUIDA
    let animationId;
    let isAlive = true;
    const MACRO_ZOOM_THRESHOLD = 118; // Soglia tra vista macro globale e ingrandimento

    const animate = () => {
      if (!isAlive) return;
      animationId = requestAnimationFrame(animate);

      const currentCameraDist = camera.position.distanceTo(controls.target);
      const isMacro = currentCameraDist > MACRO_ZOOM_THRESHOLD;

      // I MARKER E LE REGIONI RESTANO SEMPRE VISIBILI: MAI NASCONDERLI QUANDO SI INGRANDISCE!
      nationalMarkersGroup.visible = true;

      if (isMacro !== isMacroRef.current) {
        isMacroRef.current = isMacro;
        setIsMacroZoom(isMacro);
        if (onZoomModeChange) {
          onZoomModeChange(isMacro ? 'MACRO' : 'URBANO');
        }
      }

      // Rotazione naturale dolce: attiva solo in vista macro, se abilitata, e se l'utente non sta interagendo
      const canAutoRotate =
        isRotatingRef.current &&
        isMacro &&
        !isFlying &&
        !isUserInteracting &&
        (!controls.state || controls.state === -1);

      if (canAutoRotate) {
        globeGroup.rotation.y += 0.0007; // Rotazione cinematografica lenta e morbida
        if (flatEarthGroup.visible) {
          flatEarthGroup.rotation.y += 0.001; // Rotazione ironica del disco piatto
        }
      }

      // Deriva leggera e naturale delle nubi
      if (cloudsMesh) {
        cloudsMesh.rotation.y += 0.0004;
      }

      // Animazione pulsazione del reticolo di individuazione zona
      if (zoneReticleGroup.visible) {
        const timeNow = Date.now() * 0.004;
        const s1 = 1.0 + Math.sin(timeNow) * 0.16;
        reticleInnerRing.scale.set(s1, s1, 1);
        reticleOuterRing.scale.set(1.15 - Math.sin(timeNow) * 0.12, 1.15 - Math.sin(timeNow) * 0.12, 1);
        reticleOuterRing.rotation.z += 0.015;
      }

      // Pulsazione anelli radar marker
      if (isMacro) {
        const time = Date.now() * 0.003;
        const ringScale = 1.0 + Math.sin(time) * 0.22;
        const ringAlpha = 0.45 + Math.sin(time) * 0.35;
        for (let i = 0; i < pulsingRings.length; i++) {
          const item = pulsingRings[i];
          item.ring.scale.set(ringScale * item.baseScale, ringScale * item.baseScale, 1);
          item.ring.material.opacity = ringAlpha;
        }
      }

      // === WEATHER PARTICLE ANIMATION ===
      if (weatherEnabled && weatherParticleSystemsRef.current) {
        const time = Date.now() * 0.001;
        weatherParticleSystemsRef.current.forEach(({ particles, material, countryData }) => {
          const weather = weatherData.get(countryData.id);
          if (!weather || !weather.condition) return;
          
          const category = weather.condition.category;
          const isRain = category === 'rain' || category === 'drizzle' || category === 'thunderstorm';
          const isSnow = category === 'snow';
          const isFog = category === 'fog';
          
          if (isRain || isSnow) {
            const positions = particles.geometry.attributes.position.array;
            const velocities = particles.geometry.attributes.velocity.array;
            const opacities = particles.geometry.attributes.opacity.array;
            
            for (let i = 0; i < particles.geometry.attributes.position.count; i++) {
              const i3 = i * 3;
              const iv = i; // velocity is 1 component per particle
              
              // Apply gravity and wind
              positions[i3 + 1] -= velocities[iv] * 0.1; // Fall down (y axis in local space)
              positions[i3] += Math.sin(time * 2 + i) * 0.005; // Drift x
              positions[i3 + 2] += Math.cos(time * 2 + i) * 0.005; // Drift z
              
              // Fade out based on opacity attribute
              if (opacities[i] < 0.1) {
                // Reset particle to top of sphere
                const radius = raggioGlobo + 1.5;
                const phi = Math.random() * Math.PI * 2;
                const theta = Math.acos(2 * Math.random() - 1);
                positions[i3] = radius * Math.sin(theta) * Math.cos(phi);
                positions[i3 + 1] = radius * Math.cos(theta);
                positions[i3 + 2] = radius * Math.sin(theta) * Math.sin(phi);
                opacities[i] = 0.6 + Math.random() * 0.4;
              } else {
                opacities[i] *= 0.998;
              }
            }
            particles.geometry.attributes.position.needsUpdate = true;
            particles.geometry.attributes.opacity.needsUpdate = true;
          }
          
          // Rotate fog particles
          if (isFog) {
            particles.rotation.y += 0.0001;
          }
        });
      }

      controls.update();
      renderer.render(scene, camera);
    };
    animate();

    // 15. RESIZE HANDLER ROBUSTO CON RESIZEOBSERVER
    const handleResize = () => {
      if (!container || !isAlive) return;
      width = container.clientWidth || window.innerWidth;
      height = container.clientHeight || window.innerHeight;
      if (width === 0 || height === 0) return;
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

      // Aggiorna la vista globale proporzionale su orientamento o ridimensionamento
      const port = width < height;
      const ratio = port ? Math.max(1.15, (height / width) * 0.6) : 1.0;
      defaultCameraPos.set(20, 36, 155 * ratio);
      defaultCameraTarget.set(0, -6, 0);
    };

    window.addEventListener('resize', handleResize);
    const resizeObserver = new ResizeObserver(() => handleResize());
    resizeObserver.observe(container);
    // Doppio resize su frame successivo per garantire il calcolo corretto dopo il layout CSS
    requestAnimationFrame(handleResize);
    setTimeout(handleResize, 150);

    // 16. CLEANUP UNMOUNT
    return () => {
      isAlive = false;
      cancelAnimationFrame(animationId);
      if (flyAnimationId) cancelAnimationFrame(flyAnimationId);

      resizeObserver.disconnect();
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);

      domEl.removeEventListener('mousedown', onMouseDown);
      domEl.removeEventListener('touchstart', onTouchStart);
      domEl.removeEventListener('touchmove', onTouchMove);
      domEl.removeEventListener('touchend', onTouchEnd);

      controls.dispose();
      renderer.dispose();
      globoGeo.dispose();
      globoMat.dispose();
      politicalTexture.dispose();
      cloudsGeo.dispose();
      cloudsMat.dispose();
      starsGeo.dispose();
      starsMat.dispose();

      createdResources.forEach((res) => {
        if (res.geo) res.geo.dispose();
        if (res.mat) res.mat.dispose();
        if (res.texture) res.texture.dispose();
      });

      if (container && domEl && container.contains(domEl)) {
        container.removeChild(domEl);
      }
    };
  }, []); // Dipendenze vuote: la scena Three.js e OrbitControls restano stabili senza MAI resettare la vista durante lo zoom

  // Ascolta trigger esterno di reset al Mondo
  useEffect(() => {
    if (resetWorldTrigger > 0 && flyToResetRef.current) {
      flyToResetRef.current(true);
    }
  }, [resetWorldTrigger]);

  // Ascolta trigger esterno di centratura rapida sull'Italia
  useEffect(() => {
    if (focusItalyTrigger > 0 && flyToCountryRef.current) {
      const italy = COUNTRIES.find((c) => c.id === 'it');
      if (italy) {
        flyToCountryRef.current(italy);
      }
    }
  }, [focusItalyTrigger]);

  // Sincronizza la modalità Geopolitica / Fotografica con il selettore esterno
  useEffect(() => {
    if (togglePoliticalRevealRef.current) {
      togglePoliticalRevealRef.current(isGeoMode);
    }
  }, [isGeoMode]);

  // === STREET VIEW TRANSITION ===
  const handleStreetViewTransition = useCallback(() => {
    if (!activeZone || !camera || !controls || isZoomingIn) return;
    
    setIsZoomingIn(true);
    
    // Calculate target position on globe surface
    const targetLat = activeZone.lat || 0;
    const targetLng = activeZone.lng || 0;
    
    // Convert lat/lng to 3D position on globe
    const phi = (90 - targetLat) * Math.PI / 180;
    const theta = (targetLng + 180) * Math.PI / 180;
    const radius = raggioGlobo;
    
    const targetPosition = new THREE.Vector3(
      radius * Math.sin(phi) * Math.cos(theta),
      radius * Math.cos(phi),
      radius * Math.sin(phi) * Math.sin(theta)
    );
    
    // Animate camera from current position to street level
    const startPosition = camera.position.clone();
    const startTarget = controls.target.clone();
    const endPosition = targetPosition.clone().multiplyScalar(1.05); // Slightly above surface
    const endTarget = targetPosition.clone();
    
    const duration = 3000; // 3 seconds
    const startTime = Date.now();
    
    const animateTransition = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);
      
      // Easing function (ease-out cubic)
      const eased = 1 - Math.pow(1 - progress, 3);
      
      // Interpolate position and target
      camera.position.lerpVectors(startPosition, endPosition, eased);
      controls.target.lerpVectors(startTarget, endTarget, eased);
      controls.update();
      
      if (progress < 1) {
        requestAnimationFrame(animateTransition);
      } else {
        // Transition complete - trigger Urbano3D view
        setIsZoomingIn(false);
        if (onEnterUrban3DRef.current) {
          onEnterUrban3DRef.current(activeZone);
        } else if (onZoneZoomArrivedRef.current) {
          onZoneZoomArrivedRef.current(activeZone);
        }
      }
    };
    
    animateTransition();
  }, [activeZone, isZoomingIn, onEnterUrban3DRef, onZoneZoomArrivedRef, raggioGlobo]);

  // Se il paese o regione selezionata cambia e flyToCountryRef è pronto, orienta la sfera
  useEffect(() => {
    if (selectedCountryId && flyToCountryRef.current) {
      const match =
        COUNTRIES.find((c) => c.id === selectedCountryId) ||
        ITALIAN_REGIONS.find((r) => r.id === selectedCountryId);
      if (match) {
        flyToCountryRef.current(match);
      }
    }
  }, [selectedCountryId]);

  return (
    <div className="w-full h-full relative overflow-hidden bg-black select-none">
      {/* 3D Canvas Contenitore Sfera Wireframe Blu/Verde */}
      <div
        ref={containerRef}
        className="w-full h-full absolute inset-0 overflow-hidden cursor-grab active:cursor-grabbing"
        style={{
          width: '100%',
          height: '100%',
          position: 'absolute',
          top: 0,
          left: 0,
          touchAction: 'none',
        }}
      />

      {/* Weather Controls - Top Right */}
      {weatherEnabled && (
        <div className="absolute top-4 right-4 z-20 pointer-events-auto">
          <div className="flex flex-col gap-2">
            {/* Weather Toggle */}
            <button
              onClick={() => setWeatherEnabled(!weatherEnabled)}
              className="p-2 rounded-xl bg-black/70 border border-zinc-800 text-slate-300 hover:text-white hover:border-zinc-700 transition-all backdrop-blur-sm"
              title={weatherEnabled ? 'Nascondi meteo' : 'Mostra meteo'}
            >
              <Cloud className="w-5 h-5" />
            </button>

            {/* Weather Legend */}
            <div className="bg-black/80 border border-zinc-800 rounded-xl p-3 min-w-[180px] backdrop-blur-sm shadow-xl">
              <div className="flex items-center gap-2 text-xs font-bold text-slate-300 mb-2">
                <Thermometer className="w-4 h-4 text-[#00ff66]" />
                <span>Meteo Globale</span>
              </div>
              <div className="space-y-1.5 text-[10px]">
                {Array.from(weatherData.entries()).slice(0, 6).map(([countryId, weather]) => {
                  if (!weather || !weather.condition) return null;
                  const country = ALL_COUNTRIES_DATA.find(c => c.id === countryId);
                  if (!country) return null;
                  
                  const condition = weather.condition;
                  const iconMap = {
                    clear: <Sun className="w-3 h-3 text-yellow-400" />,
                    partly_cloudy: <Cloud className="w-3 h-3 text-slate-400" />,
                    overcast: <Cloud className="w-3 h-3 text-zinc-500" />,
                    rain: <CloudRain className="w-3 h-3 text-sky-400" />,
                    drizzle: <CloudRain className="w-3 h-3 text-sky-300" />,
                    thunderstorm: <CloudLightning className="w-3 h-3 text-amber-400" />,
                    snow: <CloudSnow className="w-3 h-3 text-white" />,
                    fog: <CloudFog className="w-3 h-3 text-slate-300" />,
                  };
                  
                  return (
                    <div key={countryId} className="flex items-center gap-2 text-slate-300">
                      {iconMap[condition.category] || <Cloud className="w-3 h-3" />}
                      <span className="font-medium truncate max-w-[80px]">{country.name}</span>
                      <span className="text-[#00ff66] font-mono">{Math.round(weather.temperature)}°</span>
                    </div>
                  );
                })}
                {weatherData.size > 6 && (
                  <div className="text-slate-500 text-center pt-1 border-t border-zinc-800">
                    +{weatherData.size - 6} altri paesi...
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Street View Transition Button - Bottom Center */}
      {activeZone && !isZoomingIn && (
        <div className="absolute bottom-24 left-1/2 -translate-x-1/2 z-20 pointer-events-auto animate-in fade-in slide-in-from-bottom-3 duration-300">
          <button
            onClick={handleStreetViewTransition}
            className="px-6 py-3 rounded-xl bg-gradient-to-r from-[#00ff66] to-[#00e65c] text-black font-black text-sm flex items-center gap-2 cursor-pointer shadow-[0_0_30px_rgba(0,255,102,0.4)] hover:shadow-[0_0_40px_rgba(0,255,102,0.6)] transition-all active:scale-95"
          >
            <Globe className="w-5 h-5" />
            <span>🏙️ Street View: Scendi in {activeZone.name}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Zooming indicator */}
      {isZoomingIn && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm">
          <div className="flex flex-col items-center gap-4 text-white">
            <div className="w-16 h-16 border-4 border-[#00ff66] border-t-transparent rounded-full animate-spin" />
            <div className="text-center">
              <p className="text-lg font-bold">Transizione Street View...</p>
              <p className="text-sm text-slate-400">Zoom fluido dal globo alla strada</p>
            </div>
          </div>
        </div>
      )}

      {/* Scheda Territoriale Fluttuante con Ingresso Diretto (Spostata in alto per liberare totalmente il fondo) */}
      {activeZone && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-30 pointer-events-auto animate-in fade-in slide-in-from-top-3 duration-300">
          <div className="px-4 py-2.5 rounded-xl bg-black border border-zinc-800 shadow-2xl flex flex-col sm:flex-row items-center gap-3 text-white">
            <div className="flex items-center gap-2.5">
              <span className="text-xl">{activeZone.flag || '🌍'}</span>
              <div>
                <div className="text-xs font-black text-white flex items-center gap-1.5">
                  <span className="text-[#00ff66]">{activeZone.name}</span>
                  {activeZone.capital && (
                    <span className="text-[11px] text-zinc-400">({activeZone.capital})</span>
                  )}
                </div>
                <div className="text-[10px] text-zinc-400">
                  {activeZone.description || `Lat: ${activeZone.lat?.toFixed(2)} • Lng: ${activeZone.lng?.toFixed(2)}`}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={() => {
                  if (onEnterUrban3DRef.current) {
                    onEnterUrban3DRef.current(activeZone);
                  } else if (onZoneZoomArrivedRef.current) {
                    onZoneZoomArrivedRef.current(activeZone);
                  }
                }}
                className="px-3 py-1.5 rounded-lg bg-[#00ff66] hover:bg-[#00e65c] text-black font-black text-xs flex items-center gap-1.5 cursor-pointer active:scale-95 transition-colors"
              >
                <span>🏙️ Entra in {activeZone.name}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={() => {
                  setActiveZone(null);
                  if (positionReticleRef.current) {
                    positionReticleRef.current(null);
                  }
                }}
                className="p-1 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white cursor-pointer transition-colors"
                title="Chiudi avviso"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
