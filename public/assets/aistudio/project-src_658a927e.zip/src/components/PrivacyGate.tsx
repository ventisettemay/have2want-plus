import React, { useState, useEffect } from "react";
import { motion } from "motion/react";
import { Shield, FileText, CheckCircle2, AlertCircle, ArrowRight } from "lucide-react";

interface PrivacyGateProps {
  isOpen: boolean;
  onAccept: () => void;
}

const PRIVACY_CONTENT = `
<h3 className="text-lg font-bold text-white mb-2">Norme sulla Privacy</h3>
<p className="text-sm text-slate-300 mb-4 leading-relaxed">
  HAVE2WANT ("l'App") rispetta la tua privacy. Questa informativa descrive come raccogliamo, usiamo e proteggiamo i tuoi dati personali quando utilizzi l'App.
</p>

<h4 className="font-semibold text-white mt-4 mb-2">1. Dati che raccogliamo</h4>
<ul className="list-disc list-inside text-sm text-slate-300 space-y-1 mb-4">
  <li>Dati di geolocalizzazione (fuzzificati al centroide comunale ~2.5 km)</li>
  <li>Dati del profilo (nome, username, avatar, genere opzionale)</li>
  <li>Annunci pubblicati, interazioni, messaggi P2P</li>
  <li>Dati di utilizzo (ricerche, filtri, click, tempo di permanenza)</li>
</ul>

<h4 className="font-semibold text-white mt-4 mb-2">2. Come usiamo i dati</h4>
<ul className="list-disc list-inside text-sm text-slate-300 space-y-1 mb-4">
  <li>Mostrare annunci pertinenti per territorio (geolocalizzazione fuzzificata)</li>
  <li>Abilitare chat P2P e handshake digitale (PIN 4 cifre)</li>
  <li>Calcolare punti H2W e tariffe P2P (0.25 π)</li>
  <li>Prevenire abusi, spam, frodi (moderazione AI + segnalazioni)</li>
  <li>Migliorare l'esperienza utente (suggerimenti, raccomandazioni)</li>
</ul>

<h4 className="font-semibold text-white mt-4 mb-2">3. Condivisione dati</h4>
<ul className="list-disc list-inside text-sm text-slate-300 space-y-1 mb-4">
  <li>Mai venduti a terzi</li>
  <li>Condivisi solo con controparti P2P dopo handshake (PIN 4 cifre)</li>
  <li>Obbligo legale o tutela diritti/sicurezza</li>
</ul>

<h4 className="font-semibold text-white mt-4 mb-2">4. I tuoi diritti (GDPR)</h4>
<ul className="list-disc list-inside text-sm text-slate-300 space-y-1 mb-4">
  <li>Accesso, rettifica, cancellazione dei dati</li>
  <li>Limitazione/opposizione al trattamento</li>
  <li>Portabilità dei dati</li>
  <li>Reclamo all'autorità garante</li>
</ul>

<h4 className="font-semibold text-white mt-4 mb-2">5. Sicurezza</h4>
<ul className="list-disc list-inside text-sm text-slate-300 space-y-1 mb-4">
  <li>Crittografia TLS 1.3 in transito</li>
  <li>Dati sensibili criptati at rest (AES-256)</li>
  <li>Handshake PIN 4 cifre per chat P2P (end-to-end)</li>
  <li>Geolocalizzazione fuzzificata (centroide comunale ~2.5 km)</li>
</ul>

<h4 className="font-semibold text-white mt-4 mb-2">6. Conservazione</h4>
<p className="text-sm text-slate-300 mb-4">
  Dati conservati finché l'account è attivo. Cancellazione su richiesta entro 30 giorni.
  Log anonimizzati per analytics conservati max 12 mesi.
</ul>

<h4 className="font-semibold text-white mt-4 mb-2">7. Contatti</h4>
<p className="text-sm text-slate-300 mb-4">
  DPO: privacy@have2want.app | Titolare: brandoriginalword@gmail.com
</p>
`;

export function PrivacyGate({ isOpen, onAccept }: { isOpen: boolean; onAccept: () => void }) {
  const [accepted, setAccepted] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const accepted = localStorage.getItem('privacy_accepted');
    if (accepted === 'true') {
      onAccept();
    }
  }, [onAccept]);

  const handleAccept = () => {
    localStorage.setItem('privacy_accepted', 'true');
    setAccepted(true);
    onAccept();
  };

  if (!isOpen || accepted) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm"
    >
      <div className="w-full max-w-2xl bg-slate-950 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl max-h-[90vh] overflow-hidden flex flex-col">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 flex items-center justify-center">
              <svg className="w-5 h-5 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.613 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.338 9-6.03 9-11.622 0-1.042-.13-2.062-.382-3.04z"/></svg>
            </div>
            <h2 className="text-xl font-bold text-white">Norme Privacy & Termini</h2>
          </div>
          <span className="text-xs text-slate-400">v1.0 • Aggiornato 2024</span>
        </div>

        <div className="max-h-[60vh] overflow-y-auto pr-2 pb-4 space-y-4 text-sm text-slate-300 leading-relaxed" onScroll={(e) => {
          const { scrollTop, scrollHeight, clientHeight } = e.currentTarget;
          if (scrollTop + clientHeight >= scrollHeight - 50) setScrolled(true);
        }}>
          <div dangerouslySetInnerHTML={{ __html: PRIVACY_CONTENT }} />
        </div>

        <div className="mt-6 pt-4 border-t border-slate-800 flex flex-col sm:flex-row gap-3">
          <button
            onClick={() => {}}
            className="flex-1 py-3 px-4 rounded-xl bg-slate-800 text-slate-400 font-bold text-sm hover:bg-slate-700 transition-colors"
            disabled
          >
            <span className="flex items-center justify-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12"/></svg>
              <span>Non accetto (esci)</span>
            </span>
          </button>
          <button
            onClick={handleAccept}
            disabled={!scrolled}
            className={`flex-1 py-3 px-6 rounded-xl font-black text-sm transition-all shadow-lg ${
              scrolled
                ? 'bg-gradient-to-r from-emerald-400 to-emerald-500 text-slate-950 hover:from-emerald-500 hover:to-emerald-600 shadow-lg shadow-emerald-500/30'
                : 'bg-slate-800 text-slate-500 cursor-not-allowed'
            }`}
          >
            <span className="flex items-center justify-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"/></svg>
              <span>Ho letto e accetto — Entra in HAVE2WANT</span>
            </span>
          </button>
        </div>
      </div>
    </motion.div>
  );
}

export default PrivacyGate;
