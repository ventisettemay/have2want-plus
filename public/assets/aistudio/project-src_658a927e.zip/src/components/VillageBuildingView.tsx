import React, { useState } from "react";
import { motion } from "motion/react";
import {
  ArrowLeft,
  Leaf,
  Store,
  Wrench,
  MessageSquare,
  GraduationCap,
  BookOpen,
  TreeDeciduous,
  Stethoscope,
  Apple,
  Hammer,
  Bike,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  PhoneCall,
  Coins,
  Send,
  HeartHandshake,
  Clock,
  MapPin,
  Coffee,
  Fish,
  ShoppingBag,
  PlusCircle,
  Users
} from "lucide-react";
import {
  CityBuildingId,
  Citizen,
  HaveWantListing,
  CommerceShop,
  SalvavatuttoGuide,
  MemoryArticle,
  PioneerUser
} from "../types";

interface VillageBuildingViewProps {
  buildingId: CityBuildingId;
  shopId?: string;
  citizens: Citizen[];
  listings: HaveWantListing[];
  shops: CommerceShop[];
  guides: SalvavatuttoGuide[];
  memories: MemoryArticle[];
  currentUser: PioneerUser;
  onBackToVillage: () => void;
  onSelectCitizen: (citizen: Citizen) => void;
  onSelectListing: (listing: HaveWantListing) => void;
  onProposeTrade: (listing: HaveWantListing) => void;
  onOpenCreateListing?: () => void;
}

export const VillageBuildingView: React.FC<VillageBuildingViewProps> = ({
  buildingId,
  shopId,
  citizens,
  listings,
  shops,
  guides,
  memories,
  currentUser,
  onBackToVillage,
  onSelectCitizen,
  onSelectListing,
  onProposeTrade,
  onOpenCreateListing,
}) => {
  const [feedbackMsg, setFeedbackMsg] = useState<string | null>(null);
  const [chatInput, setChatInput] = useState("");
  const [chatMessages, setChatMessages] = useState<
    { sender: string; avatar: string; text: string; time: string; isUser?: boolean }[]
  >([
    {
      sender: "Silvia (Commerciante)",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80",
      text: "Benvenuto nel negozio! Tutti i prodotti sono disponibili sia in Euro che in Pi Network o permuta.",
      time: "10 min fa",
    },
  ]);

  const specificShop = shopId ? shops.find((s) => s.id === shopId) : null;

  const giuseppe = citizens.find((c) => c.id === "cit-1") || citizens[0];
  const antonio = citizens.find((c) => c.id === "cit-2") || citizens[1];
  const elena = citizens.find((c) => c.id === "cit-3") || citizens[2];
  const luca = citizens.find((c) => c.id === "cit-4") || citizens[3];
  const clara = citizens.find((c) => c.id === "cit-5") || citizens[4];

  const applesListing = listings.find((l) => l.id === "listing-2") || listings[0];
  const shearsListing = listings.find((l) => l.id === "listing-5") || listings[0];
  const tomatoesListing = listings.find((l) => l.id === "listing-4") || listings[0];
  const bikeListing = listings.find((l) => l.id === "listing-1") || listings[0];
  const drillListing = listings.find((l) => l.id === "listing-3") || listings[0];
  const smartphoneListing = listings.find((l) => l.id === "listing-6") || listings[0];

  const triggerFeedback = (msg: string) => {
    setFeedbackMsg(msg);
    setTimeout(() => setFeedbackMsg(null), 3500);
  };

  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    setChatMessages((prev) => [
      ...prev,
      {
        sender: currentUser.name,
        avatar: currentUser.avatar,
        text: chatInput,
        time: "Adesso",
        isUser: true,
      },
    ]);
    setChatInput("");
    triggerFeedback("Messaggio inviato ai presenti in questo luogo!");
  };

  const getBuildingInfo = () => {
    if (specificShop) {
      return {
        title: specificShop.name,
        subtitle: `${specificShop.category} • Gestito da ${specificShop.owner.name}`,
        badge: "Bottega Locale Reale",
        icon: Store,
        color: "from-purple-600 to-indigo-900",
        borderColor: "border-purple-500/40",
      };
    }

    switch (buildingId) {
      case "giardino":
        return {
          title: "FRUTTA & VERDURA",
          subtitle: "Ortaggi freschi di stagione, frutta nostrana, sementi bio e legumi locali",
          badge: "Frutta & Verdura",
          icon: Leaf,
          color: "from-emerald-600 to-teal-950",
          borderColor: "border-emerald-500/40",
        };
      case "officina":
        return {
          title: "FALEGNAMERIA & MOBILI",
          subtitle: "Lavorazione legno massello, mobili su misura, banco attrezzi e restauro",
          badge: "Falegnameria",
          icon: Wrench,
          color: "from-amber-600 to-yellow-950",
          borderColor: "border-amber-500/40",
        };
      case "commercio":
        return {
          title: "BAZAR & TELEFONIA",
          subtitle: "Smartphone nuovi e ricondizionati con garanzia, elettronica e articoli per la casa",
          badge: "Bazar & Telefonia",
          icon: Store,
          color: "from-purple-600 to-indigo-950",
          borderColor: "border-purple-500/40",
        };
      case "piazza":
        return {
          title: "BAR & CAFFÈ",
          subtitle: "Caffè espresso, colazioni, bevande, tavolini all'aperto e bacheca annunci del paese",
          badge: "Bar & Caffè",
          icon: Coffee,
          color: "from-rose-600 to-pink-950",
          borderColor: "border-rose-500/40",
        };
      case "scuola":
        return {
          title: "LABORATORI & CORSI",
          subtitle: "Corsi pratici di falegnameria, informatica, lingue straniere e aula studio",
          badge: "Laboratori & Corsi",
          icon: GraduationCap,
          color: "from-blue-600 to-indigo-950",
          borderColor: "border-blue-500/40",
        };
      case "memoria":
        return {
          title: "PANETTERIA & FORNO",
          subtitle: "Pane a legna con lievito madre, focacce rustiche e farine macinate a pietra",
          badge: "Panetteria & Forno",
          icon: BookOpen,
          color: "from-amber-700 to-orange-950",
          borderColor: "border-orange-500/40",
        };
      case "albero":
        return {
          title: "PARCO & AREA VERDE",
          subtitle: "Parco alberato con panchine all'ombra, piante aromatiche e sentiero panoramico",
          badge: "Parco & Area Verde",
          icon: TreeDeciduous,
          color: "from-emerald-500 to-amber-950",
          borderColor: "border-emerald-400/50",
        };
      default:
        return {
          title: "Bottega del Paese",
          subtitle: "Spazio commerciale del borgo",
          badge: "Paese Primo",
          icon: Store,
          color: "from-slate-700 to-slate-900",
          borderColor: "border-slate-700",
        };
    }
  };

  const info = getBuildingInfo();
  const Icon = info.icon;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.98, y: 15 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.98, y: 15 }}
      transition={{ duration: 0.25 }}
      className="w-full space-y-6"
    >
      {/* Top Breadcrumb & Return to 3D Village */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-4 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-md">
        <button
          onClick={onBackToVillage}
          className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs sm:text-sm flex items-center gap-2 transition-transform hover:scale-105 cursor-pointer shadow-md"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>← Torna al Paese 3D</span>
        </button>

        <div className="flex items-center gap-2">
          <span className="text-[10px] uppercase font-mono tracking-widest text-slate-400">
            Sei dentro:
          </span>
          <span className="px-2.5 py-1 rounded-lg bg-slate-950 border border-emerald-500/30 text-emerald-300 font-bold text-xs">
            {info.title}
          </span>
        </div>
      </div>

      {/* Building Header Banner */}
      <div className={`p-6 sm:p-8 rounded-3xl bg-gradient-to-r ${info.color} border-2 ${info.borderColor} shadow-2xl relative overflow-hidden text-white`}>
        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-slate-950/80 border border-white/20 flex items-center justify-center text-amber-300 shadow-lg shrink-0">
              <Icon className="w-7 h-7" />
            </div>
            <div>
              <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-black/40 text-white/90 font-bold uppercase tracking-wider border border-white/10">
                {info.badge}
              </span>
              <h1 className="text-xl sm:text-3xl font-black text-white mt-1">
                {info.title}
              </h1>
              <p className="text-xs sm:text-sm text-white/80 mt-1 max-w-xl">
                {info.subtitle}
              </p>
            </div>
          </div>

          {onOpenCreateListing && (
            <button
              onClick={onOpenCreateListing}
              className="px-4 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs sm:text-sm flex items-center gap-1.5 shadow-lg transition-transform hover:scale-105 self-start sm:self-auto cursor-pointer"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Aggiungi Offerta o Richiesta</span>
            </button>
          )}
        </div>
      </div>

      {/* Notification / Feedback Banner */}
      {feedbackMsg && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-3.5 rounded-2xl bg-emerald-500 text-slate-950 font-black text-xs flex items-center justify-center gap-2 shadow-lg"
        >
          <CheckCircle2 className="w-4 h-4" />
          <span>{feedbackMsg}</span>
        </motion.div>
      )}

      {/* ========================================================================= */}
      {/* 1. SEZIONE SPECIFICA PER EDIFICIO / BOTTEGA                               */}
      {/* ========================================================================= */}

      {/* A. ORTO & GIARDINO CIVICO */}
      {buildingId === "giardino" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-4">
            <h3 className="text-base font-black text-white flex items-center gap-2">
              <Apple className="w-4 h-4 text-emerald-400" />
              <span>Raccolto & Beni Disponibili nell'Orto</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Mele Bio */}
              <div
                onClick={() => onSelectListing(applesListing)}
                className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-emerald-400 transition-all cursor-pointer space-y-3 group"
              >
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-300 flex items-center justify-center">
                    <Apple className="w-6 h-6" />
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-400 text-slate-950 font-black">
                    DONO
                  </span>
                </div>
                <h4 className="text-sm font-black text-white group-hover:text-emerald-300">
                  Cassa di Mele Biologiche (5 kg)
                </h4>
                <p className="text-xs text-slate-300">
                  Mele dell'albero dell'orto comunitario. Ritiro libero per le famiglie del borgo.
                </p>
                <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs text-emerald-400 font-bold">
                  <span>Dono Gratuito</span>
                  <span className="flex items-center gap-1">Ritira <ArrowRight className="w-3.5 h-3.5" /></span>
                </div>
              </div>

              {/* Pomodori Cuore di Bue */}
              <div
                onClick={() => onSelectListing(tomatoesListing)}
                className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-rose-400 transition-all cursor-pointer space-y-3 group"
              >
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-xl bg-rose-500/20 text-rose-300 flex items-center justify-center">
                    <Leaf className="w-6 h-6" />
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-rose-400 text-slate-950 font-black">
                    BARATTO
                  </span>
                </div>
                <h4 className="text-sm font-black text-white group-hover:text-rose-300">
                  Pomodori Cuore di Bue Freschi
                </h4>
                <p className="text-xs text-slate-300">
                  1 kg pomodori freschi di giornata ⇄ 2 kg farina o pasta artigianale.
                </p>
                <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs text-rose-300 font-bold">
                  <span>1 kg ⇄ 2 kg Farina</span>
                  <span className="flex items-center gap-1">Scambia <ArrowRight className="w-3.5 h-3.5" /></span>
                </div>
              </div>
            </div>
          </div>

          {/* Persona presente: Peppe Orto */}
          <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4">
            <h3 className="text-sm font-black text-white">Custode dell'Orto</h3>
            <div
              onClick={() => onSelectCitizen(giuseppe)}
              className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-emerald-400 transition-all cursor-pointer flex items-center gap-3"
            >
              <img src={giuseppe.avatar} alt={giuseppe.name} className="w-12 h-12 rounded-full object-cover border-2 border-emerald-400" />
              <div>
                <h4 className="text-xs font-black text-white">{giuseppe.name}</h4>
                <span className="text-[10px] text-emerald-300 block">{giuseppe.role}</span>
                <span className="text-[10px] text-slate-400">Attività: {giuseppe.currentActivity}</span>
              </div>
            </div>
            <button
              onClick={() => triggerFeedback(`Consulenza botanica richiesta a ${giuseppe.name}!`)}
              className="w-full py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs transition-colors cursor-pointer"
            >
              Chiedi Consiglio Coltivazione
            </button>
          </div>
        </div>
      )}

      {/* B. OFFICINA DEI MESTIERI & CICLOFFICINA */}
      {buildingId === "officina" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-4">
            <h3 className="text-base font-black text-white flex items-center gap-2">
              <Wrench className="w-4 h-4 text-amber-400" />
              <span>Banchi di Lavoro, Attrezzi & Riparazioni</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Trapano Bosch */}
              <div
                onClick={() => onSelectListing(drillListing)}
                className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-amber-400 transition-all cursor-pointer space-y-3 group"
              >
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-300 flex items-center justify-center">
                    <Hammer className="w-6 h-6" />
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-sky-400 text-slate-950 font-black">
                    PRESTITO
                  </span>
                </div>
                <h4 className="text-sm font-black text-white group-hover:text-amber-300">
                  Trapano a Percussione Bosch Professional
                </h4>
                <p className="text-xs text-slate-300">
                  Disponibile per prestito nel fine settimana con patto di cura e restituzione pulito.
                </p>
                <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs text-amber-300 font-bold">
                  <span>1.0 Pi o Patto Diretto</span>
                  <span className="flex items-center gap-1">Prenota <ArrowRight className="w-3.5 h-3.5" /></span>
                </div>
              </div>

              {/* Bici Vintage Revisionata */}
              <div
                onClick={() => onSelectListing(bikeListing)}
                className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-sky-400 transition-all cursor-pointer space-y-3 group"
              >
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-xl bg-sky-500/20 text-sky-300 flex items-center justify-center">
                    <Bike className="w-6 h-6" />
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-400 text-slate-950 font-black">
                    RIGENERATA
                  </span>
                </div>
                <h4 className="text-sm font-black text-white group-hover:text-sky-300">
                  Bicicletta da Città Revisionata
                </h4>
                <p className="text-xs text-slate-300">
                  Freni nuovi, gomme nuove, cambio Shimano a 6 rapporti regolato da Luca.
                </p>
                <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs text-sky-300 font-bold">
                  <span>€65 / 12.5 Pi / Permuta</span>
                  <span className="flex items-center gap-1">Acquista <ArrowRight className="w-3.5 h-3.5" /></span>
                </div>
              </div>
            </div>
          </div>

          {/* Artigiani Presenti */}
          <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4">
            <h3 className="text-sm font-black text-white">Artigiani al Lavoro</h3>
            <div className="space-y-2.5">
              <div
                onClick={() => onSelectCitizen(antonio)}
                className="p-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-amber-400 transition-all cursor-pointer flex items-center gap-3"
              >
                <img src={antonio.avatar} alt={antonio.name} className="w-10 h-10 rounded-full object-cover border border-amber-400" />
                <div>
                  <h4 className="text-xs font-black text-white">{antonio.name}</h4>
                  <span className="text-[10px] text-amber-300 block">{antonio.role}</span>
                </div>
              </div>

              <div
                onClick={() => onSelectCitizen(luca)}
                className="p-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-sky-400 transition-all cursor-pointer flex items-center gap-3"
              >
                <img src={luca.avatar} alt={luca.name} className="w-10 h-10 rounded-full object-cover border border-sky-400" />
                <div>
                  <h4 className="text-xs font-black text-white">{luca.name}</h4>
                  <span className="text-[10px] text-sky-300 block">{luca.role}</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => triggerFeedback("Richiesta di riparazione inviata all'Officina!")}
              className="w-full py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs transition-colors cursor-pointer"
            >
              Richiedi Riparazione su Misura
            </button>
          </div>
        </div>
      )}

      {/* C. BOTTEGA & BAZAR LOCALE / COMMERCIO */}
      {(buildingId === "commercio" || specificShop) && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-4">
            <h3 className="text-base font-black text-white flex items-center gap-2">
              <Store className="w-4 h-4 text-purple-400" />
              <span>Vetrina Prodotti & Catalogo</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Smartphone 128GB */}
              <div
                onClick={() => onSelectListing(smartphoneListing)}
                className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-purple-400 transition-all cursor-pointer space-y-3 group"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-400 text-slate-950 font-black">
                    NUOVO • GARANZIA 24M
                  </span>
                  <span className="text-[11px] font-mono text-purple-300">85 Pi / €499</span>
                </div>
                <h4 className="text-sm font-black text-white group-hover:text-purple-300">
                  Smartphone 128GB 5G Sigillato
                </h4>
                <p className="text-xs text-slate-300">
                  Con scontrino e garanzia italiana. Si accettano Euro, Pi Network o permuta con attrezzature.
                </p>
                <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs text-purple-300 font-bold">
                  <span>Trattativa Diretta</span>
                  <span className="flex items-center gap-1">Vedi Offerta <ArrowRight className="w-3.5 h-3.5" /></span>
                </div>
              </div>

              {/* Attrezzatura da pesca o bottega */}
              <div
                onClick={() => triggerFeedback("Prodotto aggiunto al carrello o richiesta inviata!")}
                className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-cyan-400 transition-all cursor-pointer space-y-3 group"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-400 text-slate-950 font-black">
                    ARTIGIANATO LOCALE
                  </span>
                  <span className="text-[11px] font-mono text-cyan-300">15 Pi / €80</span>
                </div>
                <h4 className="text-sm font-black text-white group-hover:text-cyan-300">
                  Set Taglieri in Legno d'Ulivo Fatti a Mano
                </h4>
                <p className="text-xs text-slate-300">
                  Lavorati a mano da legno locale stagionato. Finitura con olio naturale per alimenti.
                </p>
                <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs text-cyan-300 font-bold">
                  <span>Disponibilità: 3 pezzi</span>
                  <span className="flex items-center gap-1">Acquista <ArrowRight className="w-3.5 h-3.5" /></span>
                </div>
              </div>
            </div>
          </div>

          {/* Esercente del Negozio */}
          <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4">
            <h3 className="text-sm font-black text-white">Commerciante</h3>
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center gap-3">
              <img
                src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80"
                alt="Silvia"
                className="w-12 h-12 rounded-full object-cover border-2 border-purple-400"
              />
              <div>
                <h4 className="text-xs font-black text-white">Silvia Commerciante</h4>
                <span className="text-[10px] text-purple-300 block">Elettronica & Bazar</span>
                <span className="text-[10px] text-emerald-400">🟢 In Bottega Adesso</span>
              </div>
            </div>

            <button
              onClick={() => triggerFeedback("Hai aperto il canale di trattativa privata con il commerciante!")}
              className="w-full py-2 rounded-xl bg-purple-500 hover:bg-purple-400 text-white font-black text-xs transition-colors cursor-pointer"
            >
              Parla con il Commerciante
            </button>
          </div>
        </div>
      )}

      {/* D. PIAZZA COMUNALE & CHAT DAL VIVO */}
      {buildingId === "piazza" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-4">
            <h3 className="text-base font-black text-white flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-emerald-400" />
              <span>Voci & Conversazioni in Piazza</span>
            </h3>

            {/* Live chat box in the square */}
            <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
              <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
                {chatMessages.map((msg, idx) => (
                  <div
                    key={idx}
                    className={`p-3 rounded-xl text-xs ${
                      msg.isUser
                        ? "bg-emerald-950/60 border border-emerald-500/40 text-emerald-100 ml-6"
                        : "bg-slate-950 border border-slate-800 text-slate-200"
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1 text-[10px] text-slate-400">
                      <span className="font-bold text-white">{msg.sender}</span>
                      <span>{msg.time}</span>
                    </div>
                    <p className="leading-relaxed">{msg.text}</p>
                  </div>
                ))}
              </div>

              {/* Chat Input form */}
              <form onSubmit={handleSendChat} className="flex gap-2 pt-2 border-t border-slate-800">
                <input
                  type="text"
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  placeholder="Scrivi qualcosa alla piazza del paese..."
                  className="flex-1 px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-400"
                />
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs flex items-center gap-1 cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Invia</span>
                </button>
              </form>
            </div>
          </div>

          {/* Cittadini in Piazza */}
          <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
            <h3 className="text-sm font-black text-white flex items-center gap-2">
              <Users className="w-4 h-4 text-emerald-400" />
              <span>Persone Attorno alla Fontana</span>
            </h3>
            <div className="space-y-2">
              {citizens.slice(0, 4).map((cit) => (
                <div
                  key={cit.id}
                  onClick={() => onSelectCitizen(cit)}
                  className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-emerald-400 transition-all cursor-pointer flex items-center justify-between text-xs"
                >
                  <div className="flex items-center gap-2.5">
                    <img src={cit.avatar} alt={cit.name} className="w-7 h-7 rounded-full object-cover" />
                    <div>
                      <span className="font-bold text-white block leading-tight">{cit.name}</span>
                      <span className="text-[10px] text-slate-400 block">{cit.role}</span>
                    </div>
                  </div>
                  <span className="text-[10px] text-emerald-400 font-mono font-bold">🟢 Qui</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* E. SCUOLA DEI SAPERI */}
      {buildingId === "scuola" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-4">
            <h3 className="text-base font-black text-white flex items-center gap-2">
              <GraduationCap className="w-4 h-4 text-blue-400" />
              <span>Corsi Pratici & Laboratori Condivisi</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div
                onClick={() => triggerFeedback("Iscrizione al corso di falegnameria confermata!")}
                className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-blue-400 transition-all cursor-pointer space-y-2.5"
              >
                <span className="text-[10px] px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 font-bold">
                  SABATO MATTINA
                </span>
                <h4 className="text-sm font-black text-white">
                  Laboratorio Pratico di Falegnameria
                </h4>
                <p className="text-xs text-slate-300">
                  Impara a usare pialla, scalpelli e a restaurare vecchie sedie con Mastro Antonio.
                </p>
                <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs text-blue-400 font-bold">
                  <span>Adesione Libera</span>
                  <span className="flex items-center gap-1">Partecipa <ArrowRight className="w-3.5 h-3.5" /></span>
                </div>
              </div>

              <div
                onClick={() => triggerFeedback("Iscrizione al laboratorio di conversazione in lingua confermata!")}
                className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-indigo-400 transition-all cursor-pointer space-y-2.5"
              >
                <span className="text-[10px] px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-bold">
                  MARTEDÌ SERA
                </span>
                <h4 className="text-sm font-black text-white">
                  Conversazione in Lingue & Informatica
                </h4>
                <p className="text-xs text-slate-300">
                  Scambio linguistico con madrelingua e lezioni di base per l'uso dei computer.
                </p>
                <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs text-indigo-400 font-bold">
                  <span>Adesione Libera</span>
                  <span className="flex items-center gap-1">Partecipa <ArrowRight className="w-3.5 h-3.5" /></span>
                </div>
              </div>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4">
            <h3 className="text-sm font-black text-white">Vuoi Insegnare Qualcosa?</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Ognuno nel borgo possiede un sapere pratico o teorico prezioso da tramandare.
            </p>
            <button
              onClick={() => triggerFeedback("Proposta di corso inviata alla Scuola dei Saperi!")}
              className="w-full py-2.5 rounded-xl bg-blue-500 hover:bg-blue-400 text-white font-black text-xs transition-colors cursor-pointer"
            >
              Proponi un Corso o Laboratorio
            </button>
          </div>
        </div>
      )}

      {/* F. CASA DELLA MEMORIA & FORNO TRADIZIONALE */}
      {buildingId === "memoria" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-4">
            <h3 className="text-base font-black text-white flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-orange-400" />
              <span>Memorie Storiche & Ricettario Antico</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div
                onClick={() => triggerFeedback("Ricetta del pane con lievito madre aperta!")}
                className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-orange-400 transition-all cursor-pointer space-y-2.5"
              >
                <span className="text-[10px] px-2 py-0.5 rounded bg-orange-500/20 text-orange-300 font-bold">
                  FORNO A LEGNA
                </span>
                <h4 className="text-sm font-black text-white">
                  Il Pane Tradizionale di Nonna Rosa
                </h4>
                <p className="text-xs text-slate-300">
                  Pasta madre di 60 anni tramandata di generazione in generazione e cottura su pietra.
                </p>
                <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs text-orange-400 font-bold">
                  <span>Leggi Ricetta & Storia</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </div>
              </div>

              <div
                onClick={() => triggerFeedback("Archivio storico del borgo aperto!")}
                className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-amber-400 transition-all cursor-pointer space-y-2.5"
              >
                <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold">
                  ARCHIVIO DEL PAESE
                </span>
                <h4 className="text-sm font-black text-white">
                  Origini dei Mestieri nel Territorio
                </h4>
                <p className="text-xs text-slate-300">
                  Come i maestri d'ascia e i contadini cooperavano prima dell'era industriale.
                </p>
                <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs text-amber-400 font-bold">
                  <span>Consulta Memoria</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </div>
              </div>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4">
            <h3 className="text-sm font-black text-white">Aggiungi una Memoria</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Conserva le storie, le ricette o le tradizioni della tua famiglia per il futuro della comunità.
            </p>
            <button
              onClick={() => triggerFeedback("Modulo per scrivere una nuova memoria aperto!")}
              className="w-full py-2.5 rounded-xl bg-orange-500 hover:bg-orange-400 text-slate-950 font-black text-xs transition-colors cursor-pointer"
            >
              Scrivi una Memoria
            </button>
          </div>
        </div>
      )}

      {/* G. ALBERO DELLA VITA */}
      {buildingId === "albero" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-4">
            <h3 className="text-base font-black text-white flex items-center gap-2">
              <TreeDeciduous className="w-4 h-4 text-emerald-400" />
              <span>Il Cuore Rigenerativo di Paese Primo</span>
            </h3>

            <div className="p-6 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 space-y-3">
              <h4 className="text-sm font-black text-emerald-300">
                L'Ecosistema Comune
              </h4>
              <p className="text-xs text-slate-200 leading-relaxed">
                L'Albero della Vita raccoglie tutta l'energia, le relazioni e il valore reale generato dagli scambi,
                dalle riparazioni e dagli aiuti reciproci nel paese. Più la comunità scambia e collabora, più l'Albero
                estende le sue radici e fa nascere nuovi borghi nel mondo.
              </p>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4">
            <h3 className="text-sm font-black text-white">Mutuo Soccorso Solidale</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              In caso di emergenza o bisogno imprevisto, puoi attivare la rete di soccorso comunitario.
            </p>
            <button
              onClick={() => triggerFeedback("Segnalazione di mutuo soccorso inviata alla rete!")}
              className="w-full py-2.5 rounded-xl bg-rose-500 hover:bg-rose-400 text-white font-black text-xs transition-colors cursor-pointer"
            >
              Segnala un Bisogno SOS
            </button>
          </div>
        </div>
      )}

    </motion.div>
  );
};
