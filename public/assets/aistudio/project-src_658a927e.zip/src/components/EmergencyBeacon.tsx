import React, { useState } from "react";
import {
  AlertTriangle,
  Radio,
  MapPin,
  Clock,
  ShieldAlert,
  Heart,
  X
} from "lucide-react";

interface EmergencyBeaconProps {
  userCity: string;
}

interface AlertRequest {
  id: string;
  type: "medica" | "tecnica" | "maltempo" | "generica";
  title: string;
  description: string;
  city: string;
  timestamp: string;
  status: "active" | "resolved";
  helpersCount: number;
}

export const EmergencyBeacon: React.FC<EmergencyBeaconProps> = ({ userCity }) => {
  const [alerts, setAlerts] = useState<AlertRequest[]>([
    {
      id: "alert-1",
      type: "tecnica",
      title: "Blackout improvviso quartiere Centro - Cerco generatore o candele",
      description: "Interruzione elettrica da oltre 2 ore. Necessito di luce per frigorifero medicinali.",
      city: "Torino (Zona Centro)",
      timestamp: "15 min fa",
      status: "active",
      helpersCount: 3,
    },
    {
      id: "alert-2",
      type: "maltempo",
      title: "Allagamento garage condominiale - Servono pompe ad immersione",
      description: "Dopo forte temporale abbiamo 20cm d'acqua nei seminterrati.",
      city: "Asti",
      timestamp: "45 min fa",
      status: "active",
      helpersCount: 5,
    },
  ]);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [newDesc, setNewDesc] = useState("");
  const [newType, setNewType] = useState<AlertRequest["type"]>("generica");

  const handleCreateAlert = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newDesc.trim()) return;

    const newAlert: AlertRequest = {
      id: `alert-${Date.now()}`,
      type: newType,
      title: newTitle.trim(),
      description: newDesc.trim(),
      city: userCity || "Torino Hub",
      timestamp: "Adesso",
      status: "active",
      helpersCount: 0,
    };

    setAlerts([newAlert, ...alerts]);
    setIsModalOpen(false);
    setNewTitle("");
    setNewDesc("");
  };

  const handleOfferHelp = (alertId: string) => {
    setAlerts(
      alerts.map((a) => (a.id === alertId ? { ...a, helpersCount: a.helpersCount + 1 } : a))
    );
  };

  return (
    <div className="space-y-6">
      {/* Emergency Hero Banner */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-rose-950/60 via-slate-900 to-slate-900 border border-rose-500/40 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400 animate-pulse">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-slate-100">Modulo di Emergenza Controllata (La Luna)</h2>
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/30">
                  Rete Solidale Attiva
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Segnalazioni prioritarie di mutuo soccorso tra vicini e Pioneer in situazioni critiche
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsModalOpen(true)}
            id="open-emergency-alert-modal-btn"
            className="px-5 py-3 rounded-xl bg-gradient-to-r from-rose-600 to-rose-700 hover:from-rose-500 hover:to-rose-600 text-white font-bold text-xs shadow-lg shadow-rose-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer shrink-0"
          >
            <AlertTriangle className="w-4 h-4" />
            <span>Lancia Segnale d'Emergenza</span>
          </button>
        </div>
      </div>

      {/* Active Alerts List */}
      <div className="space-y-4">
        <div className="flex items-center justify-between text-xs text-slate-400 px-1">
          <span className="font-bold uppercase tracking-wider text-rose-400 flex items-center gap-1.5">
            <Radio className="w-3.5 h-3.5 animate-pulse" />
            Segnali di Soccorso nelle Vicinanze ({alerts.length})
          </span>
          <span>Aggiornato in tempo reale</span>
        </div>

        {alerts.map((item) => (
          <div
            key={item.id}
            className="p-5 rounded-2xl bg-slate-900 border border-rose-500/30 hover:border-rose-500/60 transition-all shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-4"
          >
            <div className="space-y-1.5 flex-1">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/30">
                  {item.type}
                </span>
                <span className="text-[11px] text-slate-400 flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-rose-400" /> {item.city}
                </span>
                <span className="text-[11px] text-slate-500 flex items-center gap-1">
                  <Clock className="w-3 h-3" /> {item.timestamp}
                </span>
              </div>

              <h4 className="text-sm font-bold text-slate-100">{item.title}</h4>
              <p className="text-xs text-slate-300 leading-relaxed">{item.description}</p>
            </div>

            <div className="flex items-center gap-3 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-800">
              <div className="text-right hidden sm:block">
                <div className="text-xs font-bold text-emerald-400">{item.helpersCount} Pioneer</div>
                <div className="text-[10px] text-slate-500">in soccorso</div>
              </div>

              <button
                onClick={() => handleOfferHelp(item.id)}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-rose-600 text-slate-200 hover:text-white text-xs font-bold border border-slate-700 hover:border-rose-500 transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <Heart className="w-3.5 h-3.5 text-rose-400" />
                <span>Offri Aiuto</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Modal create alert */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-rose-950/30">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400">
                  <AlertTriangle className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-100">Segnalazione d'Emergenza Comunitaria</h3>
                  <p className="text-[11px] text-slate-400">Richiedi assistenza immediata ai Pioneer locali</p>
                </div>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-200 p-1 rounded-lg hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateAlert} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Tipologia di Necessità</label>
                <select
                  value={newType}
                  onChange={(e) => setNewType(e.target.value as AlertRequest["type"])}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-rose-500"
                >
                  <option value="generica">Generica / Assistenza</option>
                  <option value="medica">Sanitaria / Farmaci di Prima Necessità</option>
                  <option value="tecnica">Guasto Tecnico / Blackout / Riscaldamento</option>
                  <option value="maltempo">Allagamento / Maltempo</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Cosa sta succedendo (Titolo)</label>
                <input
                  type="text"
                  required
                  placeholder="Es: Blackout nel quartiere, cerco generatore per frigorifero medicinali"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-rose-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Dettagli e Contatto</label>
                <textarea
                  required
                  rows={3}
                  placeholder="Descrivi la situazione esatta, la via o la zona indicativa e di cosa hai bisogno..."
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-rose-500"
                />
              </div>

              <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold hover:bg-slate-700 transition-colors cursor-pointer"
                >
                  Annulla
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition-all shadow-md shadow-rose-600/30 cursor-pointer"
                >
                  Trasmetti Segnale
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
