import React, { useState, useMemo, useContext } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  MapPin,
  Search,
  Filter,
  ShieldCheck,
  Coins,
  Store,
  Compass,
  ArrowRight,
  ExternalLink,
  CheckCircle2,
  X,
  Navigation,
  Globe2,
  Layers,
  HeartHandshake,
  Sparkles,
  Zap,
  ArrowUpRight,
  Info,
  Package,
  ShoppingBag,
  GraduationCap,
  Bike,
  Smartphone,
  Hammer,
  Wrench,
  Tv,
  Send,
  MessageSquare,
  AlertTriangle,
  RotateCcw,
  SlidersHorizontal,
  DollarSign,
  Flame,
  Check,
  Radio,
  Star,
  Stethoscope,
  Brain,
  Scale,
  Building,
  Map as MapIcon,
  ChevronRight,
  Clock,
  ShieldAlert,
  Video,
  Mic,
  MicOff,
  Settings,
  Minimize,
  Maximize2,
  Volume2,
  VolumeX,
  Users,
  MoreHorizontal,
  Monitor,
  PhoneOff,
  Phone
} from "lucide-react";
import {
  CommerceShop,
  HaveWantListing,
  Citizen,
  PioneerUser,
  InteractionIntent,
  RealCategoryKey,
  RealSubcategoryKey,
  AdRewardTokenomicsState,
  CommunitySpecialist,
  DiscreetAIReviewFeedback,
  CertifiedMeetingPoint,
  DigitalHandshakeSession,
  AbuseReportPayload,
  ReportTargetType
} from "../types";
import {
  REAL_CATEGORIES_MATRIX,
  getCategoryLabel,
  getSubcategoryLabel
} from "../categories";
import { INITIAL_SPECIALISTS, INITIAL_CERTIFIED_MEETING_POINTS } from "../data";
import { ExternalRedirectModal } from "./ExternalRedirectModal";
import { GlobalSearchBar, FlightTarget } from "./GlobalSearchBar";
import { DiscreetAIAssistantModal } from "./DiscreetAIAssistantModal";
import { CertifiedMeetingPointsModal } from "./CertifiedMeetingPointsModal";
import { DigitalHandshakeModal } from "./DigitalHandshakeModal";
import { ListingExpiryManager } from "./ListingExpiryManager";
import { AbuseReportModal } from "./AbuseReportModal";
import { computeFuzzyCoordinates, matchesTerritorialHierarchy } from "@/lib/fuzzyGeocoding";
import { H2W_COST, H2W_LIMITS, TEST_MODE, AD_REWARD_POINTS, AD_REWARD_PI } from "@/lib/h2wContext";
import { useH2W } from "@/lib/h2wContext";
import { ExternalListings } from "./have2want/ExternalListings";
} from "lucide-react";
import {
  CommerceShop,
  HaveWantListing,
  Citizen,
  PioneerUser,
  InteractionIntent,
  RealCategoryKey,
  RealSubcategoryKey,
  AdRewardTokenomicsState,
  CommunitySpecialist,
  DiscreetAIReviewFeedback,
  CertifiedMeetingPoint,
  DigitalHandshakeSession,
  AbuseReportPayload,
  ReportTargetType
} from "../types";
import {
  REAL_CATEGORIES_MATRIX,
  getCategoryLabel,
  getSubcategoryLabel
} from "../categories";
import { INITIAL_SPECIALISTS, INITIAL_CERTIFIED_MEETING_POINTS } from "../data";
import { ExternalRedirectModal } from "./ExternalRedirectModal";
import { GlobalSearchBar, FlightTarget } from "./GlobalSearchBar";
import { DiscreetAIAssistantModal } from "./DiscreetAIAssistantModal";
import { CertifiedMeetingPointsModal } from "./CertifiedMeetingPointsModal";
import { DigitalHandshakeModal } from "./DigitalHandshakeModal";
import { ListingExpiryManager } from "./ListingExpiryManager";
import { AbuseReportModal } from "./AbuseReportModal";
import { computeFuzzyCoordinates, matchesTerritorialHierarchy } from "../utils/fuzzyGeocoding";
import { ListingOriginBadge } from "@/components/have2want/ListingOriginBadge";
import { ExternalListings } from "./have2want/ExternalListings";
import { AvatarUtenteChat } from "./have2want/AvatarUtenteChat";
import { BarraCategorieLed } from "./have2want/BarraCategorieLed";
import { EtichettaEsercente } from "./have2want/EtichettaEsercente";
import { BannerRotanteEsercizi } from "./have2want/BannerRotanteEsercizi";
import { VideoChatModal } from "./have2want/VideoChatModal";

interface GeographicMapBridgeProps {
  shops: CommerceShop[];
  listings: HaveWantListing[];
  citizens: Citizen[];
  currentUser: PioneerUser;
  onClose?: () => void;
  onSelectShop?: (shop: CommerceShop) => void;
  onSelectListing?: (listing: HaveWantListing) => void;
  onRegisterNewShop?: () => void;
  onAddListing?: (listing: HaveWantListing) => void;
  onReportAbuse?: (payload: AbuseReportPayload) => void;
}

// Territory Node Definition for Real Hierarchy
interface TerritoryNode {
  country: string;
  region: string;
  province: string;
  city: string;
  lat: number;
  lng: number;
}

export const TERRITORY_DIRECTORY: TerritoryNode[] = [
  // ITALIA - NORD-OVEST
  { country: "Italia", region: "Piemonte", province: "AT", city: "Asti", lat: 44.9008, lng: 8.2065 },
  { country: "Italia", region: "Piemonte", province: "TO", city: "Torino", lat: 45.0703, lng: 7.6869 },
  { country: "Italia", region: "Piemonte", province: "CN", city: "Cuneo", lat: 44.3845, lng: 7.5427 },
  { country: "Italia", region: "Piemonte", province: "AL", city: "Alessandria", lat: 44.9129, lng: 8.6154 },
  { country: "Italia", region: "Valle d'Aosta", province: "AO", city: "Aosta", lat: 45.7371, lng: 7.3197 },
  { country: "Italia", region: "Liguria", province: "GE", city: "Genova", lat: 44.4056, lng: 8.9463 },
  { country: "Italia", region: "Liguria", province: "SV", city: "Savona", lat: 44.3079, lng: 8.4811 },
  { country: "Italia", region: "Lombardia", province: "MI", city: "Milano", lat: 45.4642, lng: 9.1900 },
  { country: "Italia", region: "Lombardia", province: "BS", city: "Brescia", lat: 45.5416, lng: 10.2118 },
  { country: "Italia", region: "Lombardia", province: "BG", city: "Bergamo", lat: 45.6983, lng: 9.6773 },

  // ITALIA - NORD-EST
  { country: "Italia", region: "Trentino-Alto Adige", province: "TN", city: "Trento", lat: 46.0748, lng: 11.1217 },
  { country: "Italia", region: "Trentino-Alto Adige", province: "BZ", city: "Bolzano", lat: 46.4983, lng: 11.3548 },
  { country: "Italia", region: "Veneto", province: "VE", city: "Venezia", lat: 45.4408, lng: 12.3155 },
  { country: "Italia", region: "Veneto", province: "VR", city: "Verona", lat: 45.4384, lng: 10.9916 },
  { country: "Italia", region: "Veneto", province: "PD", city: "Padova", lat: 45.4064, lng: 11.8768 },
  { country: "Italia", region: "Friuli-Venezia Giulia", province: "TS", city: "Trieste", lat: 45.6495, lng: 13.7768 },
  { country: "Italia", region: "Friuli-Venezia Giulia", province: "UD", city: "Udine", lat: 46.0711, lng: 13.2346 },
  { country: "Italia", region: "Emilia-Romagna", province: "BO", city: "Bologna", lat: 44.4949, lng: 11.3426 },
  { country: "Italia", region: "Emilia-Romagna", province: "PR", city: "Parma", lat: 44.8015, lng: 10.3279 },
  { country: "Italia", region: "Emilia-Romagna", province: "MO", city: "Modena", lat: 44.6471, lng: 10.9252 },

  // ITALIA - CENTRO
  { country: "Italia", region: "Toscana", province: "FI", city: "Firenze", lat: 43.7696, lng: 11.2558 },
  { country: "Italia", region: "Toscana", province: "PI", city: "Pisa", lat: 43.7228, lng: 10.4017 },
  { country: "Italia", region: "Toscana", province: "SI", city: "Siena", lat: 43.3188, lng: 11.3308 },
  { country: "Italia", region: "Umbria", province: "PG", city: "Perugia", lat: 43.1107, lng: 12.3908 },
  { country: "Italia", region: "Marche", province: "AN", city: "Ancona", lat: 43.6158, lng: 13.5189 },
  { country: "Italia", region: "Lazio", province: "RM", city: "Roma", lat: 41.9028, lng: 12.4964 },
  { country: "Italia", region: "Lazio", province: "LT", city: "Latina", lat: 41.4676, lng: 12.9037 },
  { country: "Italia", region: "Abruzzo", province: "AQ", city: "L'Aquila", lat: 42.3498, lng: 13.3995 },
  { country: "Italia", region: "Abruzzo", province: "PE", city: "Pescara", lat: 42.4618, lng: 14.2161 },
  { country: "Italia", region: "Molise", province: "CB", city: "Campobasso", lat: 41.5604, lng: 14.6627 },

  // ITALIA - SUD E ISOLE
  { country: "Italia", region: "Campania", province: "NA", city: "Napoli", lat: 40.8518, lng: 14.2681 },
  { country: "Italia", region: "Campania", province: "SA", city: "Salerno", lat: 40.6824, lng: 14.7681 },
  { country: "Italia", region: "Puglia", province: "BA", city: "Bari", lat: 41.1171, lng: 16.8719 },
  { country: "Italia", region: "Puglia", province: "LE", city: "Lecce", lat: 40.3515, lng: 18.1750 },
  { country: "Italia", region: "Basilicata", province: "PZ", city: "Potenza", lat: 40.6404, lng: 15.8056 },
  { country: "Italia", region: "Calabria", province: "CZ", city: "Catanzaro", lat: 38.9098, lng: 16.5877 },
  { country: "Italia", region: "Calabria", province: "RC", city: "Reggio Calabria", lat: 38.1113, lng: 15.6473 },
  { country: "Italia", region: "Sicilia", province: "PA", city: "Palermo", lat: 38.1157, lng: 13.3615 },
  { country: "Italia", region: "Sicilia", province: "CT", city: "Catania", lat: 37.5079, lng: 15.0873 },
  { country: "Italia", region: "Sardegna", province: "CA", city: "Cagliari", lat: 39.2238, lng: 9.1217 },
  { country: "Italia", region: "Sardegna", province: "SS", city: "Sassari", lat: 40.7259, lng: 8.5556 },

  // EUROPA
  { country: "Francia", region: "Île-de-France", province: "75", city: "Parigi", lat: 48.8566, lng: 2.3522 },
  { country: "Francia", region: "Provence-Alpes-Côte d'Azur", province: "13", city: "Marsiglia", lat: 43.2965, lng: 5.3698 },
  { country: "Spagna", region: "Comunidad de Madrid", province: "28", city: "Madrid", lat: 40.4168, lng: -3.7038 },
  { country: "Spagna", region: "Cataluña", province: "08", city: "Barcellona", lat: 41.3851, lng: 2.1734 },
  { country: "Germania", region: "Berlino", province: "11", city: "Berlino", lat: 52.5200, lng: 13.4050 },
  { country: "Germania", region: "Baviera", province: "BY", city: "Monaco di Baviera", lat: 48.1351, lng: 11.5820 },
  { country: "Svizzera", region: "Zurigo", province: "ZH", city: "Zurigo", lat: 47.3769, lng: 8.5417 },
  { country: "Svizzera", region: "Ticino", province: "TI", city: "Lugano", lat: 46.0037, lng: 8.9511 },
];

export const GeographicMapBridge: React.FC<GeographicMapBridgeProps> = ({
  shops,
  listings,
  citizens,
  currentUser,
  onClose,
  onSelectShop,
  onSelectListing,
  onRegisterNewShop,
  onAddListing,
  onReportAbuse,
}) => {
  // 1. Real Territorial Hierarchy Filter (Nazione ➡️ Regione ➡️ Provincia ➡️ Città)
  const [selectedCountry, setSelectedCountry] = useState<string>("Italia");
  const [selectedRegion, setSelectedRegion] = useState<string>("ALL");
  const [selectedProvince, setSelectedProvince] = useState<string>("ALL");
  const [selectedCity, setSelectedCity] = useState<string>("Asti");
  const [searchQuery, setSearchQuery] = useState<string>("");

  // 3D Camera Controls
  const [currentLOD, setCurrentLOD] = useState<"macro" | "urban" | "product">("urban");
  const [tilt3D, setTilt3D] = useState<number>(65);
  const [heading3D, setHeading3D] = useState<number>(35);

  // 2. Interaction Intent Filter (VENDO / BARATTO_SCAMBIO / ACQUISTO_CERCO)
  const [selectedIntent, setSelectedIntent] = useState<InteractionIntent | "ALL">("ALL");

  // 3. Real Category Matrix Filter
  const [selectedCategory, setSelectedCategory] = useState<RealCategoryKey | "ALL">("ALL");
  const [selectedSubcategory, setSelectedSubcategory] = useState<RealSubcategoryKey | "ALL">("ALL");

  // 4. Tokenomics Ad-Reward State
  const [tokenomics, setTokenomics] = useState<AdRewardTokenomicsState>({
    adsEnabled: true,
    userAdCreditBalancePi: 1.25,
    fixedInteractionFeePi: 0.25,
    totalInteractionsExecuted: 8,
    savedPiViaAds: 1.20,
    activeSponsorStreamTitle: "Sponsorizzazioni Etiche del Territorio & Negozi Locali",
  });

  // 5. Sistema Punti H2W e Limiti Esercenti (usa H2WContext)
  const { 
    h2wPoints, 
    h2wDaily, 
    h2wWeekly, 
    h2wMonthly, 
    addPoints,
    incrementDaily, 
    incrementWeekly, 
    incrementMonthly 
  } = useH2W();

  const [showAdRewardDrawer, setShowAdRewardDrawer] = useState<boolean>(false);
  const [adWatchSuccessToast, setAdWatchSuccessToast] = useState<string | null>(null);

  // Selected Entities
  const [selectedShop, setSelectedShop] = useState<CommerceShop | null>(null);
  const [selectedListing, setSelectedListing] = useState<HaveWantListing | null>(
    listings[0] || null
  );
  const [selectedSpecialist, setSelectedSpecialist] = useState<CommunitySpecialist | null>(null);

  // Direct P2P Chat Modal
  const [p2pContactListing, setP2pContactListing] = useState<HaveWantListing | null>(null);
  const [p2pMessageText, setP2pMessageText] = useState<string>("");
  const [p2pMessageSent, setP2pMessageSent] = useState<boolean>(false);

  // Direct Specialist Contact Modal
  const [activeSpecialistChat, setActiveSpecialistChat] = useState<CommunitySpecialist | null>(null);
  const [specialistMessageText, setSpecialistMessageText] = useState<string>("");
  const [specialistMessageSent, setSpecialistMessageSent] = useState<boolean>(false);

  // Review & Discreet AI Feedback Modal
  const [reviewTarget, setReviewTarget] = useState<{
    id: string;
    name: string;
    type: "listing" | "specialist" | "shop";
  } | null>(null);
  const [feedbackSuccessToast, setFeedbackSuccessToast] = useState<string | null>(null);

  // Safety & Neutral Meeting Points Modal
  const [showMeetingPointsModal, setShowMeetingPointsModal] = useState<boolean>(false);
  const [selectedMeetingPoint, setSelectedMeetingPoint] = useState<CertifiedMeetingPoint | null>(null);

  // Digital Handshake (4-digit PIN) Modal
  const [showHandshakeModal, setShowHandshakeModal] = useState<boolean>(false);
  const [handshakeListing, setHandshakeListing] = useState<HaveWantListing | null>(null);
  const [completedHandshakes, setCompletedHandshakes] = useState<DigitalHandshakeSession[]>([]);

  // 30-Day Listing Expiry Manager Modal
  const [showExpiryModal, setShowExpiryModal] = useState<boolean>(false);

  // Video Chat Modal
  const [videoChatOpen, setVideoChatOpen] = useState<boolean>(false);
  const [videoChatListing, setVideoChatListing] = useState<HaveWantListing | null>(null);

  // Abuse Report & Moderation Modal
  const [reportTarget, setReportTarget] = useState<{
    id: string;
    username: string;
    title?: string;
    type: ReportTargetType;
  } | null>(null);

  // External Redirect Modal
  const [redirectShop, setRedirectShop] = useState<CommerceShop | null>(null);

  // Search filter query
  const [filterSearch, setFilterSearch] = useState<string>("");

  // Available Hierarchy Lists dynamically computed from Territory Directory
  const availableCountries = useMemo(() => {
    const set = new Set(TERRITORY_DIRECTORY.map((t) => t.country));
    return Array.from(set);
  }, []);

  const availableRegions = useMemo(() => {
    const list = selectedCountry === "ALL" 
      ? TERRITORY_DIRECTORY 
      : TERRITORY_DIRECTORY.filter((t) => t.country.toLowerCase() === selectedCountry.toLowerCase());
    return Array.from(new Set(list.map((t) => t.region)));
  }, [selectedCountry]);

  const availableProvinces = useMemo(() => {
    let list = TERRITORY_DIRECTORY;
    if (selectedCountry !== "ALL") {
      list = list.filter((t) => t.country.toLowerCase() === selectedCountry.toLowerCase());
    }
    if (selectedRegion !== "ALL") {
      list = list.filter((t) => t.region.toLowerCase() === selectedRegion.toLowerCase());
    }
    return Array.from(new Set(list.map((t) => t.province)));
  }, [selectedCountry, selectedRegion]);

  const availableCities = useMemo(() => {
    let list = TERRITORY_DIRECTORY;
    if (selectedCountry !== "ALL") {
      list = list.filter((t) => t.country.toLowerCase() === selectedCountry.toLowerCase());
    }
    if (selectedRegion !== "ALL") {
      list = list.filter((t) => t.region.toLowerCase() === selectedRegion.toLowerCase());
    }
    if (selectedProvince !== "ALL") {
      list = list.filter((t) => t.province.toLowerCase() === selectedProvince.toLowerCase());
    }
    return list;
  }, [selectedCountry, selectedRegion, selectedProvince]);

  const currentCityObj = useMemo(() => {
    if (selectedCity === "ALL") {
      return availableCities[0] || TERRITORY_DIRECTORY[0];
    }
    return TERRITORY_DIRECTORY.find((c) => c.city.toLowerCase() === selectedCity.toLowerCase()) || TERRITORY_DIRECTORY[0];
  }, [selectedCity, availableCities]);

  // Flight-to-Target Handler for Polymorphic Search Queries
  const handleFlyToTarget = (target: FlightTarget) => {
    setCurrentLOD(target.lod);
    if (target.lod === "macro") {
      setTilt3D(20);
      setHeading3D(0);
      setSelectedCountry("ALL");
      setSelectedRegion("ALL");
      setSelectedProvince("ALL");
      setSelectedCity("ALL");
    } else if (target.lod === "urban") {
      setTilt3D(65);
      setHeading3D(35);
      const matchTerritory = TERRITORY_DIRECTORY.find((t) => t.city.toLowerCase() === target.name.toLowerCase());
      if (matchTerritory) {
        setSelectedCountry(matchTerritory.country);
        setSelectedRegion(matchTerritory.region);
        setSelectedProvince(matchTerritory.province);
        setSelectedCity(matchTerritory.city);
      }
    } else if (target.lod === "product") {
      setTilt3D(75);
      setHeading3D(60);
      if (target.matchedShop) {
        setSelectedShop(target.matchedShop);
        setSelectedListing(null);
        setSelectedSpecialist(null);
        setSelectedCity(target.matchedShop.city);
      } else if (target.matchedListing) {
        setSelectedListing(target.matchedListing);
        setSelectedShop(null);
        setSelectedSpecialist(null);
        setSelectedCity(target.matchedListing.author.city || "Asti");
      }
    }
  };

  // Handler for Watching a Sponsor Ad
  const handleWatchSponsorAd = () => {
    setTokenomics((prev) => ({
      ...prev,
      userAdCreditBalancePi: parseFloat((prev.userAdCreditBalancePi + AD_REWARD_PI).toFixed(2)),
      savedPiViaAds: parseFloat((prev.savedPiViaAds + AD_REWARD_PI).toFixed(2)),
    }));

    // TEST_MODE: visione pubblicità = 0.25 π = 1 punto H2W
    if (TEST_MODE) {
      const pointsEarned = AD_REWARD_POINTS; // = 1 punto H2W
      addPoints(pointsEarned);
      incrementDaily(pointsEarned);
      setAdWatchSuccessToast(`+${AD_REWARD_PI} π accreditati + ${pointsEarned} punto H2W guadagnato!`);
    } else {
      setAdWatchSuccessToast(`+${AD_REWARD_PI} π accreditati sul tuo saldo Ad-Reward!`);
    }
    setTimeout(() => setAdWatchSuccessToast(null), 3500);
  };

  // Handler for Sending P2P Direct Contact message
  const handleConfirmP2PContact = () => {
    if (!p2pContactListing) return;

    const listing = p2pContactListing;
    const isExerciser = listing.isExerciser === true;
    const acceptsPi = listing.acceptsPi === true;

    // Calcola la tariffa effettiva: dimezzata se esercente che accetta Pi
    let fee = tokenomics.fixedInteractionFeePi;
    if (isExerciser && acceptsPi) {
      fee = parseFloat((fee / 2).toFixed(2));
    }

    // Assegna punti H2W per chat aperta (1 punto)
    const pointsEarned = H2W_COST.CHAT;

    // Limiti esercenti: incrementa contatori ma non superare i limiti
    if (isExerciser) {
      incrementDaily(pointsEarned);
      incrementWeekly(pointsEarned);
      incrementMonthly(pointsEarned);
    }

    if (tokenomics.adsEnabled) {
      if (tokenomics.userAdCreditBalancePi >= fee) {
        setTokenomics((prev) => ({
          ...prev,
          userAdCreditBalancePi: parseFloat((prev.userAdCreditBalancePi - fee).toFixed(2)),
          totalInteractionsExecuted: prev.totalInteractionsExecuted + 1,
        }));
      } else {
        setTokenomics((prev) => ({
          ...prev,
          totalInteractionsExecuted: prev.totalInteractionsExecuted + 1,
        }));
      }
    } else {
      setTokenomics((prev) => ({
        ...prev,
        totalInteractionsExecuted: prev.totalInteractionsExecuted + 1,
      }));
    }

    setP2pMessageSent(true);
    setTimeout(() => {
      setP2pMessageSent(false);
      setP2pContactListing(null);
      setP2pMessageText("");
    }, 2000);
  };

  // Handler for Sending Specialist Free Guidance Message
  const handleConfirmSpecialistContact = () => {
    if (!activeSpecialistChat) return;

    setSpecialistMessageSent(true);
    setTimeout(() => {
      setSpecialistMessageSent(false);
      setActiveSpecialistChat(null);
      setSpecialistMessageText("");
    }, 2200);
  };

  // Handler when a review is submitted via Discreet AI modal
  const handleReviewSubmitted = (feedback: DiscreetAIReviewFeedback) => {
    setFeedbackSuccessToast(`Valutazione per ${feedback.targetName} (${feedback.stars}★) registrata con successo!`);
    setTimeout(() => setFeedbackSuccessToast(null), 4000);
  };

  // Handler for Digital Handshake Completion (4-digit PIN verification)
  const handleHandshakeCompleted = (session: DigitalHandshakeSession) => {
    setCompletedHandshakes((prev) => [session, ...prev]);
    setShowHandshakeModal(false);
    setFeedbackSuccessToast(`Stretta di Mano Digitale completata per "${session.listingTitle}"! PIN verificato.`);
    setTimeout(() => setFeedbackSuccessToast(null), 4000);
  };

  // Handler for Auto-Renew toggle
  const handleToggleAutoRenew = (listingId: string, enabled: boolean) => {
    // updates listing lifecycle state
  };

  const handleManualRenew = (listingId: string) => {
    // manual renewal
  };

  // Filtered Listings computation using territorial hierarchy (NO radial Haversine distance)
  const filteredListings = useMemo(() => {
    return listings.filter((listing) => {
      const listingCity = (listing.author.city || "").toLowerCase();
      const listingProvince = (listing.author.province || "").toLowerCase();

      // 1. Territorial Hierarchy Filtering (Nazione ➡️ Regione ➡️ Provincia ➡️ Città)
      // Se selectedCountry === "ALL", l'utente è nella BACHECA MONDIALE (nessuna limitazione geografica)
      if (selectedCity !== "ALL") {
        if (!listingCity.includes(selectedCity.toLowerCase())) return false;
      } else if (selectedProvince !== "ALL") {
        if (!listingProvince.includes(selectedProvince.toLowerCase())) return false;
      } else if (selectedRegion !== "ALL") {
        const matchTerritories = TERRITORY_DIRECTORY.filter((t) => t.region.toLowerCase() === selectedRegion.toLowerCase());
        const citiesInRegion = matchTerritories.map((t) => t.city.toLowerCase());
        if (!citiesInRegion.some((c) => listingCity.includes(c))) return false;
      } else if (selectedCountry !== "ALL") {
        // Filtro per Nazione specifica (es. Italia, Francia, Spagna, ecc.)
        const matchTerritories = TERRITORY_DIRECTORY.filter((t) => t.country.toLowerCase() === selectedCountry.toLowerCase());
        const citiesInCountry = matchTerritories.map((t) => t.city.toLowerCase());
        if (citiesInCountry.length > 0 && !citiesInCountry.some((c) => listingCity.includes(c))) {
          // Se la città non appartiene alle città catalogate del paese, verifica paese autore
          const authorCountry = (listing.author.country || "").toLowerCase();
          if (authorCountry && authorCountry !== selectedCountry.toLowerCase()) return false;
        }
      }

      // 2. Interaction Intent Filter (VENDO, BARATTO_SCAMBIO, ACQUISTO_CERCO)
      if (selectedIntent !== "ALL") {
        if (listing.intent !== selectedIntent) return false;
      }

      // 3. Category Filter
      if (selectedCategory !== "ALL") {
        if (listing.category !== selectedCategory) return false;
      }

      // 4. Subcategory Filter
      if (selectedSubcategory !== "ALL") {
        if (listing.subcategory !== selectedSubcategory) return false;
      }

      // 5. Free text search
      if (filterSearch.trim()) {
        const query = filterSearch.toLowerCase();
        const matchesTitle = listing.title.toLowerCase().includes(query);
        const matchesDesc = listing.description.toLowerCase().includes(query);
        const matchesTags = listing.tags.some((t) => t.toLowerCase().includes(query));
        const matchesAuthor = listing.author.name.toLowerCase().includes(query);
        if (!matchesTitle && !matchesDesc && !matchesTags && !matchesAuthor) return false;
      }

      return true;
    });
  }, [
    listings,
    selectedCity,
    selectedProvince,
    selectedRegion,
    selectedIntent,
    selectedCategory,
    selectedSubcategory,
    filterSearch,
  ]);

  // Filtered Community Specialists (Vetrina Gratis with High 3D Priority)
  const filteredSpecialists = useMemo(() => {
    return INITIAL_SPECIALISTS.filter((spec) => {
      const specCity = spec.city.toLowerCase();
      const specProvince = spec.province.toLowerCase();

      if (selectedCity !== "ALL") {
        if (!specCity.includes(selectedCity.toLowerCase())) return false;
      } else if (selectedProvince !== "ALL") {
        if (!specProvince.includes(selectedProvince.toLowerCase())) return false;
      } else if (selectedRegion !== "ALL") {
        const matchTerritories = TERRITORY_DIRECTORY.filter((t) => t.region.toLowerCase() === selectedRegion.toLowerCase());
        const citiesInRegion = matchTerritories.map((t) => t.city.toLowerCase());
        if (!citiesInRegion.some((c) => specCity.includes(c))) return false;
      }

      if (selectedCategory !== "ALL" && selectedCategory !== "rete_specialisti_supporto") {
        return false;
      }

      if (filterSearch.trim()) {
        const q = filterSearch.toLowerCase();
        const matchName = spec.name.toLowerCase().includes(q);
        const matchField = spec.title.toLowerCase().includes(q);
        const matchBio = spec.bio.toLowerCase().includes(q);
        if (!matchName && !matchField && !matchBio) return false;
      }

      return true;
    });
  }, [selectedCity, selectedProvince, selectedRegion, selectedCategory, filterSearch]);

  // Combined Active Community Pins for Google Earth 3D viewport
  const activeCommunityPins = useMemo(() => {
    // 1. Specialist Pins (Highest Priority)
    const specialistPins = filteredSpecialists.map((spec) => ({
      id: spec.id,
      type: "specialist" as const,
      title: `${spec.name} • ${spec.title}`,
      intent: "VENDO" as InteractionIntent,
      category: "rete_specialisti_supporto" as RealCategoryKey,
      subcategory: spec.specialty as RealSubcategoryKey,
      piPrice: 0,
      owner: spec.name,
      avatar: spec.avatar,
      lat: spec.lat,
      lng: spec.lng,
      city: spec.city,
      isFuzzy: false,
      reputation: spec.trustRating.averageStars,
      data: spec,
    }));

    // 2. Listing Pins
    const listingPins = filteredListings.map((l) => ({
      id: l.id,
      type: "listing" as const,
      title: l.title,
      intent: l.intent || "BARATTO_SCAMBIO",
      category: l.category,
      subcategory: l.subcategory,
      piPrice: l.piPrice,
      owner: l.author.name,
      avatar: l.author.avatar,
      lat: l.lat,
      lng: l.lng,
      city: l.author.city || "Asti",
      isFuzzy: l.isFuzzyLocation,
      reputation: l.author.reputation,
      data: l,
    }));

    // 3. Shop Pins
    const shopPins = shops
      .filter((s) => {
        if (selectedIntent === "ACQUISTO_CERCO") return false;
        if (selectedCity !== "ALL" && !s.city.toLowerCase().includes(selectedCity.toLowerCase())) return false;
        if (filterSearch.trim()) {
          return s.name.toLowerCase().includes(filterSearch.toLowerCase()) || s.description.toLowerCase().includes(filterSearch.toLowerCase());
        }
        return true;
      })
      .map((s) => ({
        id: s.id,
        type: "shop" as const,
        title: s.name,
        intent: "VENDO" as InteractionIntent,
        category: "casa_fai_da_te" as RealCategoryKey,
        subcategory: "arredamento_mobili" as RealSubcategoryKey,
        piPrice: 0,
        owner: s.owner.name,
        avatar: s.owner.avatar,
        lat: s.lat,
        lng: s.lng,
        city: s.city,
        isFuzzy: s.isFuzzyLocation,
        reputation: 4.9,
        data: s,
      }));

    return [...specialistPins, ...listingPins, ...shopPins];
  }, [filteredSpecialists, filteredListings, shops, selectedIntent, selectedCity, filterSearch]);

  // Intent Counters
  const intentCounts = useMemo(() => {
    return {
      ALL: listings.length + INITIAL_SPECIALISTS.length,
      VENDO: listings.filter((l) => l.intent === "VENDO").length + INITIAL_SPECIALISTS.length,
      BARATTO_SCAMBIO: listings.filter((l) => l.intent === "BARATTO_SCAMBIO").length,
      ACQUISTO_CERCO: listings.filter((l) => l.intent === "ACQUISTO_CERCO").length,
    };
  }, [listings]);

  // Selected Category Object
  const currentCategoryObj = REAL_CATEGORIES_MATRIX.find((c) => c.key === selectedCategory);

  return (
    <div className="w-full flex-1 flex flex-col bg-[#030712] text-slate-100 min-h-[calc(100vh-4rem)] overflow-hidden font-sans">
      
      {/* 1st Top Toolbar: Territorial Real Hierarchy Navigation & Tokenomics Quick Bar */}
      <div className="px-4 sm:px-6 py-2.5 bg-slate-950/95 border-b border-slate-800/80 flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3 backdrop-blur-md z-20">
        
        {/* Left: Global Search + Cascading Territorial Hierarchy Selector */}
        <div className="flex flex-wrap items-center gap-2.5 flex-1">
          <div className="w-full sm:w-64 shrink-0">
            <GlobalSearchBar
              shops={shops}
              listings={listings}
              onFlyToTarget={handleFlyToTarget}
              onSearch={setSearchQuery}
            />
          </div>

          {/* TERRITORIAL REAL HIERARCHY SELECTORS (Nazione ➡️ Regione ➡️ Provincia ➡️ Città) */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 font-mono text-xs">
            
            {/* Quick Switch: BACHECA MONDIALE (Globale / Senza Filtri Territoriali) */}
            <button
              onClick={() => {
                setSelectedCountry("ALL");
                setSelectedRegion("ALL");
                setSelectedProvince("ALL");
                setSelectedCity("ALL");
                setCurrentLOD("macro");
              }}
              className={`px-2.5 py-1 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shrink-0 border cursor-pointer ${
                selectedCountry === "ALL"
                  ? "bg-gradient-to-r from-emerald-500 to-cyan-500 text-slate-950 border-emerald-400 font-black shadow-md shadow-emerald-500/20"
                  : "bg-slate-900/90 text-slate-300 hover:text-white border-slate-800 hover:border-slate-700"
              }`}
              title="Passa alla Bacheca Mondiale Globale (Tutti gli Annunci del Pianeta)"
            >
              <Globe2 className="w-3.5 h-3.5" />
              <span>Bacheca Mondiale</span>
            </button>

            {/* Country Selector */}
            <div className="flex items-center gap-1 bg-slate-900 px-2 py-1 rounded-xl border border-slate-800 shrink-0">
              <Globe2 className="w-3.5 h-3.5 text-sky-400" />
              <select
                value={selectedCountry}
                onChange={(e) => {
                  setSelectedCountry(e.target.value);
                  setSelectedRegion("ALL");
                  setSelectedProvince("ALL");
                  setSelectedCity("ALL");
                }}
                className="bg-transparent text-slate-200 text-xs font-bold focus:outline-none cursor-pointer"
              >
                <option value="ALL" className="bg-slate-900 text-emerald-300 font-bold">🌍 Bacheca Mondiale (Tutti i Paesi)</option>
                {availableCountries.map((c) => (
                  <option key={c} value={c} className="bg-slate-900 text-slate-200">{c}</option>
                ))}
              </select>
            </div>

            <ChevronRight className="w-3 h-3 text-slate-600 shrink-0" />

            {/* Region Selector */}
            <div className="flex items-center gap-1 bg-slate-900 px-2 py-1 rounded-xl border border-slate-800 shrink-0">
              <MapIcon className="w-3.5 h-3.5 text-emerald-400" />
              <select
                value={selectedRegion}
                onChange={(e) => {
                  setSelectedRegion(e.target.value);
                  setSelectedProvince("ALL");
                  setSelectedCity("ALL");
                }}
                className="bg-transparent text-slate-200 text-xs font-bold focus:outline-none cursor-pointer"
              >
                <option value="ALL" className="bg-slate-900 text-slate-200">Tutte le Regioni</option>
                {availableRegions.map((r) => (
                  <option key={r} value={r} className="bg-slate-900 text-slate-200">{r}</option>
                ))}
              </select>
            </div>

            <ChevronRight className="w-3 h-3 text-slate-600 shrink-0" />

            {/* Province Selector */}
            <div className="flex items-center gap-1 bg-slate-900 px-2 py-1 rounded-xl border border-slate-800 shrink-0">
              <span className="text-[10px] font-black text-amber-400">PR:</span>
              <select
                value={selectedProvince}
                onChange={(e) => {
                  setSelectedProvince(e.target.value);
                  setSelectedCity("ALL");
                }}
                className="bg-transparent text-slate-200 text-xs font-bold focus:outline-none cursor-pointer"
              >
                <option value="ALL" className="bg-slate-900 text-slate-200">Tutte</option>
                {availableProvinces.map((p) => (
                  <option key={p} value={p} className="bg-slate-900 text-slate-200">{p}</option>
                ))}
              </select>
            </div>

            <ChevronRight className="w-3 h-3 text-slate-600 shrink-0" />

            {/* City Quick Pills */}
            <div className="flex items-center gap-1 shrink-0">
              <button
                onClick={() => {
                  setSelectedCity("ALL");
                  setCurrentLOD("macro");
                  setTilt3D(20);
                }}
                className={`px-2.5 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  selectedCity === "ALL"
                    ? "bg-sky-400 text-slate-950 font-black shadow-md shadow-sky-400/20"
                    : "bg-slate-900 text-slate-400 hover:bg-slate-800 border border-slate-800"
                }`}
              >
                Tutte le Città
              </button>

              {availableCities.slice(0, 4).map((c) => (
                <button
                  key={c.city}
                  onClick={() => {
                    setSelectedCity(c.city);
                    setCurrentLOD("urban");
                    setTilt3D(65);
                  }}
                  className={`px-2.5 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                    selectedCity === c.city
                      ? "bg-emerald-400 text-slate-950 font-black shadow-md shadow-emerald-400/20"
                      : "bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-800"
                  }`}
                >
                  <MapPin className="w-3 h-3 text-rose-400 shrink-0" />
                  <span>{c.city}</span>
                </button>
              ))}
            </div>

          </div>
        </div>

        {/* Right: Tokenomics & 3D Controls */}
        <div className="flex items-center gap-2 shrink-0 justify-between sm:justify-end">
          
          {/* Ad-Reward Switch Pill */}
          <button
            onClick={() => setShowAdRewardDrawer(!showAdRewardDrawer)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all flex items-center gap-2 cursor-pointer shadow-sm ${
              tokenomics.adsEnabled
                ? "bg-emerald-950/60 border-emerald-500/40 text-emerald-300 hover:bg-emerald-900/60"
                : "bg-slate-900 border-amber-500/40 text-amber-300 hover:bg-slate-800"
            }`}
          >
            <div className="flex items-center gap-1.5">
              <span className={`w-2 h-2 rounded-full ${tokenomics.adsEnabled ? "bg-emerald-400 animate-pulse" : "bg-amber-400"}`} />
              <span>Ad-Reward: <b>{tokenomics.adsEnabled ? "ON" : "OFF"}</b></span>
            </div>
            <div className="pl-1.5 border-l border-slate-700 font-mono text-[11px] text-white">
              {tokenomics.userAdCreditBalancePi.toFixed(2)} π
            </div>
          </button>

          {/* 3D Viewport Controls */}
          <div className="flex items-center gap-1 bg-slate-900 px-2 py-1 rounded-xl border border-slate-800 text-xs">
            <button
              onClick={() => setTilt3D(tilt3D === 65 ? 30 : 65)}
              title="Alterna Inclinazione 3D"
              className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-sky-400 font-mono text-[11px] font-bold"
            >
              {tilt3D}° 3D
            </button>
            <button
              onClick={() => setHeading3D((heading3D + 45) % 360)}
              title="Ruota Mappa 3D"
              className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-sky-400 font-mono text-[11px] font-bold"
            >
              ↻ {heading3D}°
            </button>
          </div>

          {onClose && (
            <button
              onClick={onClose}
              className="p-1.5 rounded-xl bg-slate-900 text-slate-400 hover:text-white border border-slate-800"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* 2nd Toolbar: THE 3 ACTION INTENT SWITCHES & REAL CATEGORY MATRIX */}
      <div className="px-4 sm:px-6 py-2.5 bg-slate-900/90 border-b border-slate-800/80 space-y-2.5 backdrop-blur-md z-10">
        
        {/* ROW 1: The 3 Logical Action Switches */}
        <div className="flex flex-wrap items-center justify-between gap-2">
          
          <div className="flex items-center gap-1.5 overflow-x-auto">
            <span className="text-[11px] font-mono font-bold uppercase text-slate-400 mr-1 shrink-0">
              Intento:
            </span>

            {/* Switch ALL */}
            <button
              onClick={() => setSelectedIntent("ALL")}
              className={`px-3 py-1.2 rounded-lg text-xs font-bold transition-all cursor-pointer shrink-0 flex items-center gap-1.5 ${
                selectedIntent === "ALL"
                  ? "bg-sky-500 text-slate-950 font-black shadow-md shadow-sky-500/20 scale-105"
                  : "bg-slate-800 text-slate-300 hover:bg-slate-700"
              }`}
            >
              <span>Tutti ({intentCounts.ALL})</span>
            </button>

            {/* Switch 1: VENDO */}
            <button
              onClick={() => setSelectedIntent("VENDO")}
              className={`px-3.5 py-1.2 rounded-lg text-xs font-bold transition-all cursor-pointer shrink-0 flex items-center gap-1.5 ${
                selectedIntent === "VENDO"
                  ? "bg-emerald-400 text-slate-950 font-black shadow-md shadow-emerald-400/30 scale-105"
                  : "bg-slate-800 text-emerald-300 hover:bg-slate-700 border border-emerald-500/30"
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block" />
              <span>VENDO ({intentCounts.VENDO})</span>
            </button>

            {/* Switch 2: BARATTO / SCAMBIO */}
            <button
              onClick={() => setSelectedIntent("BARATTO_SCAMBIO")}
              className={`px-3.5 py-1.2 rounded-lg text-xs font-bold transition-all cursor-pointer shrink-0 flex items-center gap-1.5 ${
                selectedIntent === "BARATTO_SCAMBIO"
                  ? "bg-amber-400 text-slate-950 font-black shadow-md shadow-amber-400/30 scale-105"
                  : "bg-slate-800 text-amber-300 hover:bg-slate-700 border border-amber-500/30"
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-amber-400 inline-block" />
              <span>BARATTO / SCAMBIO ({intentCounts.BARATTO_SCAMBIO})</span>
            </button>

            {/* Switch 3: ACQUISTO / CERCO */}
            <button
              onClick={() => setSelectedIntent("ACQUISTO_CERCO")}
              className={`px-3.5 py-1.2 rounded-lg text-xs font-bold transition-all cursor-pointer shrink-0 flex items-center gap-1.5 ${
                selectedIntent === "ACQUISTO_CERCO"
                  ? "bg-purple-400 text-slate-950 font-black shadow-md shadow-purple-400/30 scale-105"
                  : "bg-slate-800 text-purple-300 hover:bg-slate-700 border border-purple-500/30"
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-purple-400 inline-block" />
              <span>CERCO / ACQUISTO ({intentCounts.ACQUISTO_CERCO})</span>
            </button>
          </div>

          {/* Quick Safety & Lifecycle Access Badges */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowMeetingPointsModal(true)}
              className="px-2.5 py-1 rounded-xl bg-emerald-950/50 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center gap-1.5 hover:bg-emerald-900/60 transition-all cursor-pointer shadow-sm"
              title="Punti di Incontro Certificati su Google Earth 3D"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden sm:inline">Punti Incontro 3D</span>
            </button>

            <button
              onClick={() => setShowExpiryModal(true)}
              className="px-2.5 py-1 rounded-xl bg-sky-950/50 border border-sky-500/40 text-sky-300 text-xs font-bold flex items-center gap-1.5 hover:bg-sky-900/60 transition-all cursor-pointer shadow-sm"
              title="Gestione Scadenza e Persistenza 30 Giorni con Rinnovo Auto"
            >
              <Clock className="w-3.5 h-3.5 text-sky-400" />
              <span className="hidden sm:inline">Scadenza 30gg</span>
            </button>

            {/* Specialist Network Quick Access Badge */}
            <button
              onClick={() => {
                setSelectedCategory("rete_specialisti_supporto");
                setSelectedSubcategory("ALL");
              }}
              className="px-3 py-1 rounded-xl bg-gradient-to-r from-teal-500/20 to-emerald-500/20 border border-teal-500/40 text-teal-300 text-xs font-bold flex items-center gap-1.5 hover:bg-teal-500/30 transition-all cursor-pointer shadow-sm"
            >
              <Sparkles className="w-3.5 h-3.5 text-teal-300 animate-pulse" />
              <span>Rete Specialisti (Vetrina Gratis)</span>
            </button>
          </div>

        </div>

        {/* ROW 2: Category Matrix Filters */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          <span className="text-[11px] font-mono font-bold uppercase text-slate-400 mr-1 shrink-0">
            Categoria Reale:
          </span>

          <button
            onClick={() => {
              setSelectedCategory("ALL");
              setSelectedSubcategory("ALL");
            }}
            className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all shrink-0 cursor-pointer ${
              selectedCategory === "ALL"
                ? "bg-slate-100 text-slate-950 font-black"
                : "bg-slate-800/80 text-slate-300 hover:bg-slate-800 border border-slate-700"
            }`}
          >
            Tutte le Categorie
          </button>

          {REAL_CATEGORIES_MATRIX.map((cat) => {
            const isSelected = selectedCategory === cat.key;
            const isSpecialist = cat.key === "rete_specialisti_supporto";
            const isSchoolCategory = cat.key === "libri_scuola_cultura";

            return (
              <button
                key={cat.key}
                onClick={() => {
                  setSelectedCategory(cat.key);
                  setSelectedSubcategory("ALL");
                }}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition-all shrink-0 cursor-pointer flex items-center gap-1.5 ${
                  isSelected
                    ? isSpecialist
                      ? "bg-gradient-to-r from-teal-400 to-emerald-400 text-slate-950 font-black shadow-lg shadow-teal-400/30 scale-105"
                      : isSchoolCategory
                      ? "bg-gradient-to-r from-amber-400 to-yellow-400 text-slate-950 font-black shadow-lg shadow-amber-400/20 scale-105"
                      : "bg-sky-400 text-slate-950 font-black shadow-md shadow-sky-400/20 scale-105"
                    : isSpecialist
                    ? "bg-teal-950/40 text-teal-300 border border-teal-500/50 hover:bg-teal-900/40"
                    : isSchoolCategory
                    ? "bg-amber-950/40 text-amber-300 border border-amber-500/50 hover:bg-amber-900/40"
                    : "bg-slate-800/80 text-slate-300 hover:bg-slate-800 border border-slate-700"
                }`}
              >
                {isSpecialist && <Sparkles className="w-3.5 h-3.5 text-teal-300 animate-pulse" />}
                {isSchoolCategory && <GraduationCap className="w-3.5 h-3.5 text-amber-300" />}
                <span>{cat.label}</span>
                {isSpecialist && (
                  <span className="text-[9px] uppercase px-1.5 py-0.2 rounded bg-teal-400/20 text-teal-200 font-black">
                    Solidale
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Subcategories (if a category is active) */}
        {currentCategoryObj && (
          <div className="flex items-center gap-2 overflow-x-auto pt-1 border-t border-slate-800/60">
            <span className="text-[10px] font-mono text-slate-400 shrink-0">Sotto-categorie:</span>
            <button
              onClick={() => setSelectedSubcategory("ALL")}
              className={`px-2 py-0.5 rounded text-[11px] font-semibold transition-all shrink-0 ${
                selectedSubcategory === "ALL"
                  ? "bg-sky-400/20 text-sky-300 border border-sky-400/40"
                  : "bg-slate-800/60 text-slate-400 hover:text-slate-200"
              }`}
            >
              Tutte
            </button>
            {currentCategoryObj.subcategories.map((sub) => (
              <button
                key={sub.key}
                onClick={() => setSelectedSubcategory(sub.key)}
                className={`px-2.5 py-0.5 rounded text-[11px] font-semibold transition-all shrink-0 flex items-center gap-1 ${
                  selectedSubcategory === sub.key
                    ? "bg-sky-400 text-slate-950 font-black shadow-sm"
                    : "bg-slate-800/60 text-slate-300 hover:text-white"
                }`}
              >
                <span>{sub.label}</span>
              </button>
            ))}
          </div>
        )}

      </div>

      {/* Toast Bar */}
      {feedbackSuccessToast && (
        <div className="px-6 py-2 bg-emerald-500/20 border-b border-emerald-500/40 text-emerald-300 text-xs font-bold text-center">
          {feedbackSuccessToast}
        </div>
      )}

      {/* Main Grid Viewport: 3D Map (Left) + P2P Classifieds Bacheca (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 flex-1 relative overflow-hidden">
        
        {/* LEFT: 3D Google Earth Photorealistic Tile Viewport */}
        <div className={`lg:col-span-7 xl:col-span-8 ${currentLOD === 'macro' ? 'lg:col-span-12 xl:col-span-12' : ''} bg-[#090d16] relative flex flex-col justify-between overflow-hidden min-h-[460px] p-4 sm:p-6 select-none`}>
          
          {/* Horizon & 3D Tile Background */}
          <div className="absolute inset-0 bg-gradient-to-b from-[#050814] via-[#0c142b] to-[#070b16] pointer-events-none" />
          
          {/* Simulated 3D Google Earth Mesh */}
          <div 
            className="absolute inset-0 opacity-25 transition-transform duration-700 pointer-events-none"
            style={{
              backgroundImage: `
                radial-gradient(circle at 50% 120%, rgba(56, 189, 248, 0.25), transparent 70%),
                linear-gradient(to right, rgba(56, 189, 248, 0.15) 1px, transparent 1px),
                linear-gradient(to bottom, rgba(56, 189, 248, 0.15) 1px, transparent 1px)
              `,
              backgroundSize: currentLOD === "macro" ? "120px 120px" : "60px 60px",
              transform: `perspective(900px) rotateX(${tilt3D}deg) rotateZ(${heading3D}deg) scale(${currentLOD === "macro" ? 0.9 : 1.3})`
            }}
          />

          {/* Delicate Vector Regional Subdivisions & Territorial Geodesic Mesh (Tenue & Soft) */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-25" viewBox="0 0 900 600" fill="none">
            {/* Soft Territorial Arcs & Subdivisions (delicate pastel tones) */}
            <path d="M80 160 Q220 110 380 170 T680 150" stroke="#38bdf8" strokeWidth="1" strokeDasharray="5 5" opacity="0.4" />
            <path d="M190 90 Q300 200 350 330 T460 480" stroke="#34d399" strokeWidth="1" strokeDasharray="4 4" opacity="0.35" />
            <path d="M140 280 Q290 250 460 290 T760 260" stroke="#38bdf8" strokeWidth="0.8" strokeDasharray="6 6" opacity="0.3" />
            <path d="M280 70 L310 150 L390 170 L430 240 L410 320 L450 420 L500 500" stroke="#94a3b8" strokeWidth="0.8" strokeDasharray="3 4" opacity="0.35" />
            <path d="M390 170 Q450 190 520 160" stroke="#34d399" strokeWidth="0.75" strokeDasharray="3 3" opacity="0.3" />
            <path d="M410 320 Q480 340 550 310" stroke="#38bdf8" strokeWidth="0.75" strokeDasharray="3 3" opacity="0.3" />
            {/* Delicate Regional Boundary Nodes */}
            <circle cx="310" cy="150" r="3.5" fill="#38bdf8" fillOpacity="0.35" />
            <circle cx="390" cy="170" r="3.5" fill="#34d399" fillOpacity="0.35" />
            <circle cx="430" cy="240" r="3.5" fill="#38bdf8" fillOpacity="0.35" />
            <circle cx="410" cy="320" r="3.5" fill="#34d399" fillOpacity="0.35" />
            <circle cx="450" cy="420" r="3.5" fill="#38bdf8" fillOpacity="0.35" />
            {/* Subtle Territorial Zone Labels */}
            <text x="270" y="140" fill="#94a3b8" fillOpacity="0.4" fontSize="10" fontFamily="monospace">NORD-OVEST</text>
            <text x="440" y="160" fill="#94a3b8" fillOpacity="0.4" fontSize="10" fontFamily="monospace">NORD-EST</text>
            <text x="440" y="270" fill="#94a3b8" fillOpacity="0.4" fontSize="10" fontFamily="monospace">CENTRO</text>
            <text x="470" y="380" fill="#94a3b8" fillOpacity="0.4" fontSize="10" fontFamily="monospace">SUD & ISOLE</text>
          </svg>

          {/* Top Status Bar in Map Viewport */}
          <div className="relative z-10 flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 rounded-xl bg-slate-950/90 border border-sky-500/40 text-sky-300 text-xs font-mono font-bold flex items-center gap-2 shadow-lg backdrop-blur-md">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                Google Earth 3D Tiles • LOD: <b className="uppercase text-white">{currentLOD}</b>
              </span>
              <span className="text-[10px] px-2 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold hidden sm:inline">
                POI Passivi: DISATTIVATI (Opt-In Puro)
              </span>
            </div>

            <div className="flex items-center gap-1.5 text-xs text-slate-300 font-mono bg-slate-950/80 px-2.5 py-1 rounded-xl border border-slate-800">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Scudo Anti-AutoSponsorizzazione: <b>ATTIVO</b></span>
            </div>
          </div>

          {/* SUDDIVISIONI TERRITORIALI E BACHECHE REGIONALI ATTIVE (Tenue & Chiaramente Visibile) */}
          <div className="relative z-10 my-2.5 p-2 rounded-2xl bg-slate-950/70 border border-slate-800/80 backdrop-blur-md">
            <div className="flex items-center justify-between gap-2 px-1 mb-1.5">
              <div className="flex items-center gap-1.5 text-xs text-slate-300 font-bold">
                <MapIcon className="w-3.5 h-3.5 text-emerald-400/90" />
                <span>Suddivisioni Territoriali e Bacheche Regionali ({selectedCountry === "ALL" ? "🌍 Bacheca Mondiale" : selectedCountry}):</span>
              </div>
              <span className="text-[10px] font-mono text-slate-400">
                {selectedRegion === "ALL" ? (selectedCountry === "ALL" ? "Visualizzazione Globale Pianeta" : "Tutte le Regioni attive") : `Regione: ${selectedRegion}`}
              </span>
            </div>

            {/* Regional Pills Horizontal Scroll with Subtle Tenue Highlights */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5 scrollbar-none">
              <button
                onClick={() => {
                  setSelectedRegion("ALL");
                  setSelectedProvince("ALL");
                  setSelectedCity("ALL");
                }}
                className={`px-2.5 py-1 rounded-xl text-xs font-semibold transition-all cursor-pointer shrink-0 border ${
                  selectedRegion === "ALL"
                    ? "bg-slate-800/90 border-emerald-400/60 text-emerald-300 shadow-sm shadow-emerald-500/10 font-bold"
                    : "bg-slate-900/40 border-slate-800/80 text-slate-400 hover:text-slate-200 hover:border-slate-700 hover:bg-slate-800/50"
                }`}
              >
                🌐 Tutte le Regioni
              </button>

              {availableRegions.map((reg) => {
                const isSelected = selectedRegion.toLowerCase() === reg.toLowerCase();
                const regionListingCount = listings.filter((l) => {
                  const city = (l.author.city || "").toLowerCase();
                  const matchTerritory = TERRITORY_DIRECTORY.filter((t) => t.region.toLowerCase() === reg.toLowerCase());
                  return matchTerritory.some((t) => city.includes(t.city.toLowerCase()));
                }).length;

                return (
                  <button
                    key={reg}
                    onClick={() => {
                      setSelectedRegion(reg);
                      setSelectedProvince("ALL");
                      setSelectedCity("ALL");
                    }}
                    className={`px-2.5 py-1 rounded-xl text-xs transition-all cursor-pointer shrink-0 flex items-center gap-1.5 border ${
                      isSelected
                        ? "bg-slate-800/95 border-emerald-400/70 text-emerald-200 font-bold shadow-sm shadow-emerald-500/10 scale-[1.02]"
                        : "bg-slate-900/40 border-slate-800/80 text-slate-300 hover:text-white hover:border-slate-700 hover:bg-slate-800/60"
                    }`}
                  >
                    <span className={`w-1.5 h-1.5 rounded-full ${isSelected ? "bg-emerald-400 animate-pulse" : "bg-slate-500"}`} />
                    <span>{reg}</span>
                    {regionListingCount > 0 && (
                      <span className="text-[10px] px-1 py-0.2 rounded bg-slate-800 border border-slate-700 text-slate-300 font-mono">
                        {regionListingCount}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Active Georeferenced Pins Grid */}
          <div className="relative z-10 py-4 grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3 overflow-y-auto pr-1 flex-1">
            {activeCommunityPins.length === 0 ? (
              <div className="col-span-full p-8 rounded-3xl bg-slate-950/85 border border-slate-800 text-center space-y-3 my-auto">
                <Compass className="w-8 h-8 text-sky-400 mx-auto animate-spin" />
                <h4 className="text-sm font-bold text-white">Nessun annuncio o specialista attivo per questo territorio</h4>
                <p className="text-xs text-slate-400 max-w-md mx-auto leading-relaxed">
                  Naviga la gerarchia territoriale (Nazione ➡️ Regione ➡️ Provincia ➡️ Città) per esplorare gli annunci reali.
                </p>
                <button
                  onClick={() => {
                    setSelectedIntent("ALL");
                    setSelectedCategory("ALL");
                    setSelectedSubcategory("ALL");
                    setSelectedCity("ALL");
                    setSelectedProvince("ALL");
                    setSelectedRegion("ALL");
                  }}
                  className="px-4 py-2 rounded-xl bg-sky-500 text-slate-950 font-black text-xs shadow-md cursor-pointer"
                >
                  Reimposta Filtri Territoriali
                </button>
              </div>
            ) : (
              <div className="w-full">
                <BannerRotanteEsercizi />
                {activeCommunityPins.map((pin) => {
                const isSpecialist = pin.type === "specialist";
                const isShop = pin.type === "shop";
                const isSelected = isSpecialist
                  ? selectedSpecialist?.id === pin.id
                  : isShop
                  ? selectedShop?.id === pin.id
                  : selectedListing?.id === pin.id;

                const intent = pin.intent;

                return (
                  <motion.div
                    key={pin.id}
                    whileHover={{ scale: 1.02, y: -2 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => {
                      if (isSpecialist) {
                        setSelectedSpecialist(pin.data as CommunitySpecialist);
                        setSelectedListing(null);
                        setSelectedShop(null);
                      } else if (isShop) {
                        setSelectedShop(pin.data as CommerceShop);
                        setSelectedListing(null);
                        setSelectedSpecialist(null);
                        if (onSelectShop) onSelectShop(pin.data as CommerceShop);
                      } else {
                        setSelectedListing(pin.data as HaveWantListing);
                        setSelectedShop(null);
                        setSelectedSpecialist(null);
                        if (onSelectListing) onSelectListing(pin.data as HaveWantListing);
                      }
                    }}
                    className={`p-4 rounded-2xl border-2 transition-all cursor-pointer backdrop-blur-md relative flex flex-col justify-between min-h-[110px] ${
                      isSelected
                        ? isSpecialist
                          ? "bg-slate-950 border-teal-400 shadow-[0_0_25px_rgba(45,212,191,0.35)] ring-1 ring-teal-400"
                          : "bg-slate-950 border-sky-400 shadow-[0_0_25px_rgba(56,189,248,0.35)] ring-1 ring-sky-400"
                        : isSpecialist
                        ? "bg-slate-950/95 border-teal-500/40 hover:border-teal-400"
                        : "bg-slate-950/90 border-slate-800/90 hover:border-slate-700"
                    }`}
                  >
                    {/* Top Tag & Intent Badge */}
                    <div className="flex items-center justify-between gap-1 mb-2">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        {pin.data?.isExerciser && (
                          <EtichettaEsercente acceptsPi={pin.data?.acceptsPi ?? true} size="sm" />
                        )}
                        <AvatarUtenteChat
                          nome={pin.data.author?.name || "U"}
                          genere={pin.data.author?.genere || "nonSpecificato"}
                          isActive={false}
                        />
                        <span className={`text-[10px] font-black uppercase px-2.5 py-0.5 rounded-lg font-mono ${
                          isSpecialist
                            ? "bg-teal-500/20 text-teal-300 border border-teal-500/40"
                            : intent === "VENDO"
                            ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                            : intent === "BARATTO_SCAMBIO"
                            ? "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                            : "bg-purple-500/20 text-purple-300 border border-purple-500/30"
                        }`}>
                          {isSpecialist ? "✨ SPECIALISTA SOSTENITORE" : intent === "VENDO" ? "🟢 VENDO" : intent === "BARATTO_SCAMBIO" ? "🟡 BARATTO" : "🔵 CERCO"}
                        </span>
                        {!isSpecialist && !isShop && (
                          <ListingOriginBadge listing={pin.data} size="xs" compact={true} />
                        )}
                      </div>

                      <span className="text-[10px] font-bold text-amber-400 font-mono flex items-center gap-0.5">
                        <Star className="w-3 h-3 fill-amber-400" />
                        <span>{pin.reputation}</span>
                      </span>
                    </div>

                    <h4 className="text-xs sm:text-sm font-black text-white line-clamp-2 leading-tight mb-2">
                      {pin.title}
                    </h4>

                    <div className="flex items-center justify-between text-[11px] text-slate-400 pt-2 border-t border-slate-800/80 mt-auto">
                      <span className="flex items-center gap-1 font-mono">
                        <MapPin className="w-3 h-3 text-rose-400 shrink-0" />
                        {pin.city}
                      </span>
                      <span className={`font-bold font-mono ${isSpecialist ? "text-teal-300" : "text-amber-300"}`}>
                        {isSpecialist ? "Supporto Gratuito" : pin.piPrice && pin.piPrice > 0 ? `${pin.piPrice} π` : "Baratto"}
                      </span>
                    </div>
                    <button
                      onClick={() => setP2pContactListing(pin.data)}
                      className="w-full py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-[10px] font-black text-emerald-950 flex items-center justify-center gap-1 transition-colors mt-2"
                    >
                      💬 Contatta
                    </button>
                    <button
                      onClick={() => { setVideoChatListing(pin.data); setVideoChatOpen(true); }}
                      className="w-full py-1.5 rounded-lg bg-sky-500 hover:bg-sky-400 text-[10px] font-black text-sky-950 flex items-center justify-center gap-1 transition-colors mt-2"
                    >
                      📹 Video
                    </button>
                  </motion.div>
                );
              })
            )}
          </div>

          {/* Bottom Coordinates & Live Geodetic Bar */}
          <div className="relative z-10 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-400 bg-slate-950/90 px-4 py-2 rounded-2xl border border-slate-800 backdrop-blur-md">
            <div className="flex items-center gap-2">
              <Navigation className="w-3.5 h-3.5 text-sky-400" />
              <span>
                Gerarchia territoriale attiva:{" "}
                <b className="text-white">
                  {selectedCountry} ➡️ {selectedRegion === "ALL" ? "Tutte le Regioni" : selectedRegion} ➡️ {selectedProvince === "ALL" ? "Tutte le Province" : selectedProvince} ➡️ {selectedCity === "ALL" ? "Tutte le Città" : selectedCity}
                </b>
              </span>
            </div>
            <div className="flex items-center gap-3 font-mono text-[10px]">
              <span className="text-emerald-300">Annunci/Specialisti attivi: {activeCommunityPins.length}</span>
              <span className="text-sky-300">Nessun Limite Chilometrico Radiale</span>
            </div>
          </div>

        </div>

        {/* RIGHT: Pure P2P Classifieds Listing / Specialist Card & Action Module */}
        <div className={`lg:col-span-5 xl:col-span-4 ${currentLOD === 'macro' ? 'hidden' : ''} bg-slate-950 p-5 sm:p-6 border-t lg:border-t-0 lg:border-l border-slate-800 overflow-y-auto space-y-5`}>
          <ExternalListings country={selectedCountry} query={searchQuery} />
          
          {/* Subtle Territorial Board Badge (Tenue) */}
          <div className="p-3 rounded-2xl bg-slate-900/40 border border-slate-800/80 flex items-center justify-between gap-2 text-xs">
            <div className="flex items-center gap-2">
              <span className="text-base">{selectedCountry === "ALL" ? "🌍" : selectedCountry === "Italia" ? "🇮🇹" : selectedCountry === "Francia" ? "🇫🇷" : selectedCountry === "Spagna" ? "🇪🇸" : selectedCountry === "Germania" ? "🇩🇪" : "🌐"}</span>
              <div>
                <div className="font-bold text-slate-200">
                  {selectedCountry === "ALL"
                    ? "Bacheca Mondiale Globale"
                    : `Bacheca ${selectedRegion === "ALL" ? selectedCountry : `${selectedRegion}, ${selectedCountry}`}`}
                </div>
                <div className="text-[10px] text-slate-400">
                  {selectedCountry === "ALL"
                    ? "Traduzione AI Multilingua • Tutte le Valute & Pi Network (π)"
                    : `Lingua: ${selectedCountry === "Italia" ? "Italiano" : selectedCountry === "Francia" ? "Français" : selectedCountry === "Spagna" ? "Español" : "Locale"} • Valuta: EUR (€)`}
                </div>
              </div>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-lg bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 font-bold">
              {selectedCountry === "ALL" ? "Globale P2P" : "AI Moderata"}
            </span>
          </div>

          {selectedSpecialist ? (
            /* SPECIALIST PROFILE CARD (VETRINA SPONSORIZZATA GRATUITA PERMANENTE) */
            <div className="space-y-5">
              <div className="space-y-2 pb-4 border-b border-slate-800">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[10px] font-mono font-black uppercase text-teal-300 bg-teal-500/20 px-2.5 py-0.8 rounded border border-teal-500/40 flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-teal-300" />
                    Vetrina Sponsorizzata Gratuita Permanente
                  </span>
                  <span className="text-xs text-amber-400 font-mono font-bold flex items-center gap-1">
                    <Star className="w-3.5 h-3.5 fill-amber-400" />
                    {selectedSpecialist.trustRating.averageStars} ({selectedSpecialist.trustRating.totalReviewsCount} recensioni)
                  </span>
                </div>

                <div className="flex items-center gap-3 pt-2">
                  <img
                    src={selectedSpecialist.avatar}
                    alt={selectedSpecialist.name}
                    className="w-14 h-14 rounded-2xl object-cover border-2 border-teal-400 shadow-md"
                  />
                  <div>
                    <h3 className="text-base font-black text-white">{selectedSpecialist.name}</h3>
                    <span className="text-xs text-teal-300 font-bold block">{selectedSpecialist.title}</span>
                    <span className="text-[11px] text-slate-400 font-mono">
                      {selectedSpecialist.physicalOfficeAddress || selectedSpecialist.city} ({selectedSpecialist.province})
                    </span>
                  </div>
                </div>
              </div>

              {/* Specialist Free Solidarity Support Notice */}
              <div className="p-4 rounded-2xl bg-teal-950/30 border border-teal-500/40 space-y-2">
                <div className="flex items-center gap-2">
                  <HeartHandshake className="w-4 h-4 text-teal-300" />
                  <span className="text-xs font-bold text-teal-200">Patto Comunitario di Supporto Solidale</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Offre consigli di primo livello e orientamento solidale <b>gratuito in chat</b> a tutti i pionieri del territorio. In cambio, il sistema gli conferisce priorità visiva su Google Earth 3D.
                </p>
                <div className="text-[11px] text-teal-300 font-mono pt-1">
                  Orari Disponibilità Chat: <b>{selectedSpecialist.availabilityHours}</b>
                </div>
              </div>

              {/* Bio */}
              <div className="space-y-1.5">
                <span className="text-xs font-bold text-slate-400">Presentazione Professionale</span>
                <p className="text-xs text-slate-300 leading-relaxed bg-slate-900/60 p-3.5 rounded-xl border border-slate-800/80">
                  {selectedSpecialist.bio}
                </p>
              </div>

              {/* Primary Action Button: Open Specialist Free Chat */}
              <div className="space-y-2">
                <button
                  onClick={() => setActiveSpecialistChat(selectedSpecialist)}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-teal-400 to-emerald-400 hover:from-teal-300 hover:to-emerald-300 text-slate-950 font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-teal-500/20 transition-all cursor-pointer"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>Avvia Chat di Orientamento Solidale (Gratuito)</span>
                </button>

                {/* Star Rating Button with Financial Lock Verification */}
                <button
                  onClick={() => setReviewTarget({
                    id: selectedSpecialist.id,
                    name: selectedSpecialist.name,
                    type: "specialist",
                  })}
                  className="w-full py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 font-bold text-xs border border-amber-500/30 flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                >
                  <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                  <span>Lascia Valutazione a Stelle (Assistente IA Discreto)</span>
                </button>
              </div>
            </div>
          ) : selectedListing ? (
            /* REGULAR LISTING CARD */
            <div className="space-y-5">
              
              {/* Intent & Category Badges */}
              <div className="space-y-2 pb-4 border-b border-slate-800">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className={`text-[10px] font-black uppercase px-2.5 py-0.8 rounded font-mono ${
                      selectedListing.intent === "VENDO"
                        ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40"
                        : selectedListing.intent === "BARATTO_SCAMBIO"
                        ? "bg-amber-500/20 text-amber-300 border border-amber-500/40"
                        : "bg-purple-500/20 text-purple-300 border border-purple-500/40"
                    }`}>
                      {selectedListing.intent === "VENDO" ? "🟢 Offerta di Vendita (VENDO)" : selectedListing.intent === "BARATTO_SCAMBIO" ? "🟡 Proposta di Baratto" : "🔵 Richiesta Utente (CERCO)"}
                    </span>
                    <ListingOriginBadge listing={selectedListing} size="xs" />
                  </div>

                  <span className="text-xs text-slate-400 font-mono">{selectedListing.createdAt}</span>
                </div>

                <h3 className="text-lg font-black text-white leading-tight">
                  {selectedListing.title}
                </h3>

                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-300 font-mono">
                  <span className="flex items-center gap-1 text-slate-400">
                    <MapPin className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                    {selectedListing.locationArea || selectedListing.author.city} ({selectedListing.author.province || "IT"})
                  </span>
                  <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-[11px] text-sky-300">
                    {getCategoryLabel(selectedListing.category)}
                  </span>
                </div>
              </div>

              {/* PURE P2P CONTACT BUTTON (Primary Action: Activates Direct Chat with 0.25 Pi micro-fee / Ad-Reward coverage) */}
              <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-900 via-slate-900 to-slate-950 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-slate-400">Interazione P2P Diretta:</span>
                  <span className="text-amber-400 font-bold">
                    {tokenomics.adsEnabled ? "Coperto da Ad-Reward (0.00 π da wallet)" : "0.25 π (Pi Wallet Diretto)"}
                  </span>
                </div>

                <button
                  onClick={() => setP2pContactListing(selectedListing)}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-sky-400 via-teal-400 to-emerald-400 hover:from-sky-300 hover:to-emerald-300 text-slate-950 font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-sky-500/20 transition-all cursor-pointer"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>Contatta Annunciante P2P / Avvia Chat</span>
                </button>

                {/* Direct Physical Encounter & Safety Action Grid */}
                <div className="grid grid-cols-2 gap-2 pt-1">
                  <button
                    onClick={() => setShowMeetingPointsModal(true)}
                    className="py-2.5 px-3 rounded-xl bg-emerald-950/40 hover:bg-emerald-900/60 border border-emerald-500/40 text-emerald-300 font-bold text-[11px] flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                  >
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Punto Incontro 3D</span>
                  </button>

                  <button
                    onClick={() => {
                      setHandshakeListing(selectedListing);
                      setShowHandshakeModal(true);
                    }}
                    className="py-2.5 px-3 rounded-xl bg-amber-950/40 hover:bg-amber-900/60 border border-amber-500/40 text-amber-300 font-bold text-[11px] flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                  >
                    <HeartHandshake className="w-3.5 h-3.5 text-amber-400" />
                    <span>Stretta di Mano (PIN)</span>
                  </button>
                </div>

                {/* Star Rating Button & Abuse Report Trigger */}
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setReviewTarget({
                      id: selectedListing.id,
                      name: selectedListing.author.name,
                      type: "listing",
                    })}
                    className="py-2 px-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 font-bold text-xs border border-slate-800 flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                  >
                    <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                    <span>Valuta (1-5★)</span>
                  </button>

                  <button
                    onClick={() => setReportTarget({
                      id: selectedListing.id,
                      username: selectedListing.author.username,
                      title: selectedListing.title,
                      type: "listing",
                    })}
                    className="py-2 px-2.5 rounded-xl bg-rose-950/30 hover:bg-rose-900/50 text-rose-300 font-bold text-xs border border-rose-500/40 flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                  >
                    <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
                    <span>Segnala Abuso</span>
                  </button>
                </div>

                <p className="text-[11px] text-slate-400 text-center leading-relaxed">
                  Nessun carrello o intermediario: l'accordo e lo scambio avvengono direttamente tra te e l'autore.
                </p>
              </div>

              {/* Proponent Profile with 5-Star Reputation & Hardware Shield */}
              <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <img
                    src={selectedListing.author.avatar}
                    alt={selectedListing.author.name}
                    className="w-11 h-11 rounded-full object-cover border-2 border-sky-400"
                  />
                  <div>
                    <span className="text-[10px] text-slate-400 block">Autore dell'Annuncio</span>
                    <h4 className="text-xs font-black text-white">{selectedListing.author.name}</h4>
                    <span className="text-[10px] text-sky-300 font-mono">{selectedListing.author.username}</span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-[10px] text-slate-400 block">Affidabilità Verificata</span>
                  <span className="text-xs font-bold text-amber-400 flex items-center justify-end gap-1">
                    <Star className="w-3.5 h-3.5 fill-amber-400" />
                    <span>{selectedListing.author.reputation} / 5.0</span>
                  </span>
                </div>
              </div>

              {/* Listing Full Description */}
              <div className="space-y-1.5">
                <span className="text-xs font-bold text-slate-400">Dettagli dell'Annuncio</span>
                <p className="text-xs text-slate-300 leading-relaxed bg-slate-900/60 p-3.5 rounded-xl border border-slate-800/80">
                  {selectedListing.description}
                </p>
              </div>

              {/* Concrete Exchange Spec (Baratto/Scambio) */}
              {selectedListing.concreteExchange && (
                <div className="p-4 rounded-2xl bg-amber-950/30 border border-amber-500/40 space-y-2 text-xs">
                  <span className="text-[10px] font-black uppercase text-amber-400 font-mono block">
                    Patto di Baratto Concreto
                  </span>
                  <div className="text-slate-200">
                    Offre: <b>{selectedListing.concreteExchange.offer.quantity} {selectedListing.concreteExchange.offer.unit} di {selectedListing.concreteExchange.offer.item}</b>
                  </div>
                  <div className="text-amber-300">
                    Cerca: <b>{selectedListing.concreteExchange.wanted.quantity} {selectedListing.concreteExchange.wanted.unit} di {selectedListing.concreteExchange.wanted.item}</b>
                  </div>
                </div>
              )}

              {/* Tags */}
              <div className="flex flex-wrap gap-1.5 pt-2">
                {selectedListing.tags.map((tag) => (
                  <span key={tag} className="text-[10px] px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-400">
                    #{tag}
                  </span>
                ))}
              </div>

            </div>
          ) : selectedShop ? (
            <div className="space-y-5">
              <div className="space-y-2 pb-4 border-b border-slate-800">
                <span className="text-[10px] font-mono font-black uppercase text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30">
                  Bottega Reale Opt-In
                </span>
                <h3 className="text-xl font-black text-white">{selectedShop.name}</h3>
                <p className="text-xs text-slate-300">{selectedShop.description}</p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
                <span className="text-[10px] font-bold uppercase text-amber-400 font-mono">Offerta in Evidenza:</span>
                <p className="text-xs font-bold text-white">{selectedShop.featuredOffer}</p>
              </div>

              <button
                onClick={() => setRedirectShop(selectedShop)}
                className="w-full py-2.5 rounded-xl bg-sky-400 hover:bg-sky-300 text-slate-950 font-black text-xs flex items-center justify-center gap-1.5 shadow-md cursor-pointer"
              >
                <span>Visita Bottega Ufficiale</span>
                <ArrowUpRight className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div className="p-8 text-center space-y-3">
              <Compass className="w-10 h-10 text-slate-600 mx-auto" />
              <h4 className="text-sm font-bold text-white">Seleziona un marcatore sulla mappa 3D</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Tocca un annuncio o uno specialista della comunità per visualizzare la scheda descrittiva e attivare il contatto diretto P2P.
              </p>
            </div>
          )}

        </div>

      </div>

      {/* DRAWER: Tokenomics Ad-Reward Management Drawer */}
      <AnimatePresence>
        {showAdRewardDrawer && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-lg bg-slate-950 border border-slate-800 rounded-3xl p-6 space-y-5 shadow-2xl relative"
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <Coins className="w-5 h-5 text-amber-400" />
                  <h3 className="text-base font-black text-white">Tokenomics Ad-Reward & Sostenibilità</h3>
                </div>
                <button
                  onClick={() => setShowAdRewardDrawer(false)}
                  className="p-1 rounded-lg text-slate-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Status & Switch */}
              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-white">Canale Ad-Stream Sponsor</h4>
                  <p className="text-[11px] text-slate-400">
                    {tokenomics.adsEnabled
                      ? "Attivo: le quote di interazione P2P vengono coperte dai crediti accumulati."
                      : "Disattivato: paghi la micro-fee fissa (0.25 π) direttamente dal wallet."}
                  </p>
                </div>
                <button
                  onClick={() => setTokenomics((p) => ({ ...p, adsEnabled: !p.adsEnabled }))}
                  className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
                    tokenomics.adsEnabled
                      ? "bg-emerald-400 text-slate-950 shadow-md shadow-emerald-400/20"
                      : "bg-slate-800 text-slate-400 border border-slate-700"
                  }`}
                >
                  {tokenomics.adsEnabled ? "ON (Consigliato)" : "OFF"}
                </button>
              </div>

              {/* Metrics Grid */}
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block font-mono">Saldo Crediti Ad-Reward</span>
                  <span className="text-lg font-black text-amber-400 font-mono">
                    {tokenomics.userAdCreditBalancePi.toFixed(2)} π
                  </span>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block font-mono">Quota Interazione Fissa</span>
                  <span className="text-lg font-black text-sky-400 font-mono">
                    {tokenomics.fixedInteractionFeePi.toFixed(2)} π
                  </span>
                </div>
              </div>

              {/* Watch Sponsor Button */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-950/30 to-emerald-950/30 border border-emerald-500/30 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-emerald-300">Guarda Sponsor Comunitario</span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono font-bold">
                    +0.05 π Credito
                  </span>
                </div>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  Supporta i negozi e gli artigiani del territorio visualizzando un messaggio sponsor etico per azzerare le tue spese di contatto.
                </p>
                <button
                  onClick={handleWatchSponsorAd}
                  className="w-full py-2.5 rounded-xl bg-emerald-400 hover:bg-emerald-300 text-slate-950 font-black text-xs shadow-md transition-all cursor-pointer"
                >
                  Visualizza Sponsor Locale (+0.05 π)
                </button>
              </div>

              {adWatchSuccessToast && (
                <div className="p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold text-center">
                  {adWatchSuccessToast}
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL: Linear P2P Direct Chat Contact Modal */}
      <AnimatePresence>
        {p2pContactListing && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-lg bg-slate-950 border border-slate-800 rounded-3xl p-6 space-y-5 shadow-2xl relative"
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <MessageSquare className="w-5 h-5 text-sky-400" />
                  <h3 className="text-base font-black text-white">Contatto Diretto Bacheca P2P</h3>
                </div>
                <button
                  onClick={() => setP2pContactListing(null)}
                  className="p-1 rounded-lg text-slate-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
                <span className="text-[10px] font-mono text-slate-400 uppercase">Destinatario:</span>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white">{p2pContactListing.author.name} ({p2pContactListing.author.username})</span>
                  <span className="text-xs font-mono text-sky-300">{p2pContactListing.author.city}</span>
                </div>
                <div className="text-[11px] text-slate-300 italic">"{p2pContactListing.title}"</div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-300">Il tuo messaggio di apertura:</label>
                <textarea
                  value={p2pMessageText}
                  onChange={(e) => setP2pMessageText(e.target.value)}
                  placeholder="Ciao! Ho visto il tuo annuncio sulla bacheca 3D di HAVE2WANT e vorrei accordarmi per lo scambio..."
                  rows={4}
                  className="w-full p-3.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-sky-500"
                />
              </div>

              <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 flex items-center justify-between text-xs">
                <span className="text-slate-400">Quota interazione P2P (0.25 π):</span>
                <span className="font-bold text-emerald-400 font-mono">
                  {tokenomics.adsEnabled ? "Coperto da Ad-Reward" : "Firma da Pi Wallet"}
                </span>
              </div>

              {p2pMessageSent ? (
                <div className="p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center justify-center gap-2">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Messaggio P2P inviato con successo al canale diretto dell'autore!</span>
                </div>
              ) : (
                <button
                  onClick={handleConfirmP2PContact}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-sky-400 to-emerald-400 hover:from-sky-300 hover:to-emerald-300 text-slate-950 font-black text-xs flex items-center justify-center gap-2 shadow-lg cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  <span>Invia Messaggio Diretto P2P</span>
                </button>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL: Specialist Free Consultation Chat Modal */}
      <AnimatePresence>
        {activeSpecialistChat && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-lg bg-slate-950 border border-slate-800 rounded-3xl p-6 space-y-5 shadow-2xl relative"
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-teal-300" />
                  <h3 className="text-base font-black text-white">Chat di Orientamento Solidale</h3>
                </div>
                <button
                  onClick={() => setActiveSpecialistChat(null)}
                  className="p-1 rounded-lg text-slate-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="p-3.5 rounded-2xl bg-teal-950/40 border border-teal-500/40 space-y-1">
                <span className="text-[10px] font-mono text-teal-300 uppercase">Specialista Referente:</span>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white">{activeSpecialistChat.name}</span>
                  <span className="text-xs font-mono text-teal-300">{activeSpecialistChat.title}</span>
                </div>
                <div className="text-[11px] text-slate-300 italic">
                  "Consulenza e orientamento di primo livello offerti a titolo gratuito alla comunità."
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-300">Descrivi il tuo dubbio o la richiesta di orientamento:</label>
                <textarea
                  value={specialistMessageText}
                  onChange={(e) => setSpecialistMessageText(e.target.value)}
                  placeholder="Scrivi qui il tuo messaggio per lo specialista..."
                  rows={4}
                  className="w-full p-3.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-teal-500"
                />
              </div>

              <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 flex items-center justify-between text-xs">
                <span className="text-slate-400">Costo del servizio:</span>
                <span className="font-bold text-teal-400 font-mono">
                  GRATUITO (Patto Comunitario)
                </span>
              </div>

              {specialistMessageSent ? (
                <div className="p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center justify-center gap-2">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Messaggio di orientamento inviato con successo allo specialista!</span>
                </div>
              ) : (
                <button
                  onClick={handleConfirmSpecialistContact}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-teal-400 to-emerald-400 hover:from-teal-300 hover:to-emerald-300 text-slate-950 font-black text-xs flex items-center justify-center gap-2 shadow-lg cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  <span>Invia Richiesta allo Specialista</span>
                </button>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL: Discreet AI Feedback & Star Rating Modal */}
      {reviewTarget && (
        <DiscreetAIAssistantModal
          isOpen={!!reviewTarget}
          onClose={() => setReviewTarget(null)}
          targetId={reviewTarget.id}
          targetName={reviewTarget.name}
          targetType={reviewTarget.type}
          isFinancialLocked={true}
          onReviewSubmitted={handleReviewSubmitted}
        />
      )}

      {/* External Redirection Modal */}
      <ExternalRedirectModal
        shop={redirectShop}
        isOpen={!!redirectShop}
        onClose={() => setRedirectShop(null)}
      />

      {/* MODAL: Certified Neutral Meeting Points Modal */}
      {showMeetingPointsModal && (
        <CertifiedMeetingPointsModal
          city={selectedCity === "ALL" ? "Asti" : selectedCity}
          onSelectMeetingPoint={(point) => {
            setSelectedMeetingPoint(point);
            setFeedbackSuccessToast(`Punto di incontro "${point.name}" fissato su Google Earth 3D!`);
            setTimeout(() => setFeedbackSuccessToast(null), 4000);
          }}
          onClose={() => setShowMeetingPointsModal(false)}
        />
      )}

      {/* MODAL: Digital Handshake (PIN Monouso 4 Cifre) Modal */}
      {showHandshakeModal && (
        <DigitalHandshakeModal
          listing={handshakeListing || selectedListing || listings[0]}
          currentUsername={currentUser.username}
          otherPartyUsername={(handshakeListing || selectedListing || listings[0]).author.username}
          meetingPointName={selectedMeetingPoint?.name}
          onHandshakeCompleted={handleHandshakeCompleted}
          onClose={() => setShowHandshakeModal(false)}
          onOpenRatingModal={(targetId, targetName) => {
            setReviewTarget({
              id: targetId,
              name: targetName,
              type: "listing",
            });
          }}
        />
      )}

      {/* MODAL: Listing Expiry & 30-Day Auto-Renew Manager */}
      {showExpiryModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            className="w-full max-w-2xl bg-slate-950 border border-slate-800 rounded-3xl p-2 shadow-2xl relative max-h-[90vh] overflow-y-auto"
          >
            <ListingExpiryManager
              userListings={listings.filter((l) => l.author.username === currentUser.username || true).slice(0, 3)}
              onToggleAutoRenew={handleToggleAutoRenew}
              onManualRenew={handleManualRenew}
              onClose={() => setShowExpiryModal(false)}
            />
          </motion.div>
        </div>
      )}

      {/* MODAL: Abuse Report & P2P Moderation */}
      {reportTarget && (
        <AbuseReportModal
          targetId={reportTarget.id}
          targetUsername={reportTarget.username}
          targetTitle={reportTarget.title}
          targetType={reportTarget.type}
          reporterUsername={currentUser.username}
          onReportSubmitted={(payload) => {
            onReportAbuse?.(payload);
            setReportTarget(null);
            setFeedbackSuccessToast(`Segnalazione inviata per ${payload.targetUsername}. Moderazione attivata.`);
            setTimeout(() => setFeedbackSuccessToast(null), 4500);
          }}
          onClose={() => setReportTarget(null)}
        />
      )}

      {/* Video Chat Modal */}
      <VideoChatModal
        isOpen={videoChatOpen}
        onClose={() => setVideoChatOpen(false)}
        listingId={videoChatListing?.id || ""}
        otherUserName={videoChatListing?.author?.name || ""}
        otherUserAvatar={videoChatListing?.author?.avatar}
      />

    </div>
  );
};
