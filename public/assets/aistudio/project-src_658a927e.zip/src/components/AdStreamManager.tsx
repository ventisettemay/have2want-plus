import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Sparkles,
  Coins,
  ShieldCheck,
  Zap,
  Play,
  CheckCircle2,
  Clock,
  Smartphone,
  CreditCard,
  Tv,
  ArrowRight,
  TrendingUp,
  RefreshCw,
  AlertCircle
} from "lucide-react";
import { PioneerUser, UserCreditBalance } from "../types";

interface AdStreamManagerProps {
  currentUser: PioneerUser;
  onUpdateCreditBalance?: (newBalance: number) => void;
  onPayInteractionFee?: (fee: number) => boolean;
}

export const AdStreamManager: React.FC<AdStreamManagerProps> = ({
  currentUser,
  onUpdateCreditBalance,
  onPayInteractionFee,
}) => {
  // AD-STREAM ON/OFF Toggle (Reward-based advertising system)
  const [adStreamEnabled, setAdStreamEnabled] = useState<boolean>(true);
  const [creditBalance, setCreditBalance] = useState<number>(currentUser.piBalance || 0.45);
  const [adTimerSeconds, setAdTimerSeconds] = useState<number>(15);
  const [isAdPlaying, setIsAdPlaying] = useState<boolean>(false);
  const [rewardToast, setRewardToast] = useState<string | null>(null);
  const [directPaymentStatus, setDirectPaymentStatus] = useState<string | null>(null);

  // Manual Top-up input state
  const [topUpAmount, setTopUpAmount] = useState<number>(1.0);
  const [showTopUpModal, setShowTopUpModal] = useState<boolean>(false);

  // AD-STREAM Automatic Timer Routine (when toggle is ON)
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;

    if (adStreamEnabled && !isAdPlaying) {
      interval = setInterval(() => {
        setAdTimerSeconds((prev) => {
          if (prev <= 1) {
            // Trigger automatic micro-sponsor display and instant +0.05 π credit
            triggerAdReward();
            return 30; // reset 30s cycle
          }
          return prev - 1;
        });
      }, 1000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [adStreamEnabled, isAdPlaying]);

  const triggerAdReward = () => {
    setIsAdPlaying(true);
    setTimeout(() => {
      const reward = 0.05;
      const updated = parseFloat((creditBalance + reward).toFixed(3));
      setCreditBalance(updated);
      onUpdateCreditBalance?.(updated);
      setIsAdPlaying(false);
      setRewardToast(`🎉 Ricompensa AD-STREAM accreditata: +${reward} π (Saldo: ${updated} π)`);
      setTimeout(() => setRewardToast(null), 4000);
    }, 2000);
  };

  const handleManualAdWatch = () => {
    triggerAdReward();
  };

  const handlePayFixedInteractionFee = () => {
    const FIXED_FEE = 0.15;
    if (creditBalance >= FIXED_FEE) {
      const updated = parseFloat((creditBalance - FIXED_FEE).toFixed(3));
      setCreditBalance(updated);
      onUpdateCreditBalance?.(updated);
      setDirectPaymentStatus(`Quota fissa di interazione (0.15 π) coperta con successo dal saldo crediti sponsor.`);
    } else {
      setDirectPaymentStatus(`Saldo crediti insufficiente (${creditBalance} π). Attiva AD-STREAM o connetti Pi SDK.`);
    }
    setTimeout(() => setDirectPaymentStatus(null), 4500);
  };

  const handleConfirmTopUp = () => {
    const updated = parseFloat((creditBalance + topUpAmount).toFixed(3));
    setCreditBalance(updated);
    onUpdateCreditBalance?.(updated);
    setShowTopUpModal(false);
    setRewardToast(`Ricarica manuale completata: +${topUpAmount} π aggiunti al saldo Pioneer.`);
    setTimeout(() => setRewardToast(null), 4000);
  };

  return (
    <div className="w-full space-y-6 font-sans">
      {/* Main Tokenomics Control Card */}
      <div className="p-6 rounded-3xl bg-slate-950 border border-slate-800 shadow-2xl space-y-6">
        
        {/* Header Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center shadow-inner">
              <Zap className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black text-white">
                  AD-STREAM & Tokenomics di Sostenibilità Pi Network
                </h3>
                <span className="text-[10px] uppercase font-mono font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Quota Fissa 0.15 π
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Gestione autonoma delle micro-quote di interazione P2P e ricompense pubblicitarie etiche.
              </p>
            </div>
          </div>

          {/* User Balance Display */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl px-4 py-2 flex items-center gap-3">
            <Coins className="w-5 h-5 text-amber-400" />
            <div>
              <span className="text-[10px] text-slate-400 uppercase font-mono block">Saldo Crediti Disponibile</span>
              <span className="text-base font-black text-amber-400 font-mono">{creditBalance.toFixed(2)} π</span>
            </div>
          </div>
        </div>

        {/* AD-STREAM Toggle Switch Section */}
        <div className="p-5 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900/90 to-slate-900 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1.5 max-w-xl">
            <div className="flex items-center gap-2">
              <Tv className="w-4 h-4 text-emerald-400" />
              <h4 className="text-sm font-bold text-white">Interruttore AD-STREAM</h4>
              <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                adStreamEnabled ? "bg-emerald-500/20 text-emerald-300" : "bg-slate-800 text-slate-400"
              }`}>
                {adStreamEnabled ? "ATTIVO (+0.05 π ogni ciclo)" : "DISATTIVATO"}
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Quando l'interruttore è <b>ON</b>, brevi annunci sponsorizzati etici accreditano automaticamente <b>+0.05 π</b> nel tuo bilancio crediti, azzerando le commissioni per le interazioni dirette.
            </p>
          </div>

          {/* Toggle Switch */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => setAdStreamEnabled(!adStreamEnabled)}
              className={`w-14 h-8 rounded-full transition-colors relative cursor-pointer p-1 ${
                adStreamEnabled ? "bg-emerald-500" : "bg-slate-800"
              }`}
            >
              <div
                className={`w-6 h-6 rounded-full bg-white transition-transform ${
                  adStreamEnabled ? "translate-x-6" : "translate-x-0"
                }`}
              />
            </button>
          </div>
        </div>

        {/* Live Stream Routine Indicator */}
        {adStreamEnabled && (
          <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800/80 flex items-center justify-between text-xs">
            <div className="flex items-center gap-3">
              <Clock className="w-4 h-4 text-sky-400 animate-spin" />
              <span className="text-slate-300">
                Prossima ricompensa sponsorizzata tra: <b className="text-sky-400 font-mono">{adTimerSeconds}s</b>
              </span>
            </div>

            <button
              onClick={handleManualAdWatch}
              disabled={isAdPlaying}
              className="px-3 py-1.5 rounded-xl bg-sky-500/20 hover:bg-sky-500/30 text-sky-300 font-bold border border-sky-500/30 flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <Play className="w-3.5 h-3.5" />
              <span>{isAdPlaying ? "Erogazione..." : "Guarda Ora (+0.05 π)"}</span>
            </button>
          </div>
        )}

        {/* Alternative Actions when Toggle is OFF or for Direct Settlement */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
          
          {/* Interaction Fee Settlement */}
          <div className="p-4 rounded-2xl bg-slate-900/50 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <Coins className="w-4 h-4 text-amber-400" />
                Quota Fissa Interazione P2P
              </span>
              <span className="text-xs font-mono font-bold text-amber-400">0.15 π</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Consumo fisso a copertura dei servizi di geolocalizzazione 3D, chat protetta e sicurezza della stretta di mano digitale.
            </p>
            <button
              onClick={handlePayFixedInteractionFee}
              className="w-full py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Copri Quota con Saldo Crediti</span>
            </button>
          </div>

          {/* Manual Top-up via Pi SDK / Profile */}
          <div className="p-4 rounded-2xl bg-slate-900/50 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <Smartphone className="w-4 h-4 text-emerald-400" />
                Ricarica Manuale Profilo
              </span>
              <span className="text-xs font-mono font-bold text-emerald-400">Pi SDK</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Se l'interruttore AD-STREAM è spento, puoi ricaricare il saldo Pioneer direttamente dal tuo Pi Wallet ufficiale esterno.
            </p>
            <button
              onClick={() => setShowTopUpModal(true)}
              className="w-full py-2 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5"
            >
              <CreditCard className="w-3.5 h-3.5" />
              <span>Ricarica Saldo con Pi Network</span>
            </button>
          </div>

        </div>

        {/* Feedback Notifications */}
        {rewardToast && (
          <div className="p-3.5 rounded-2xl bg-emerald-950/60 border border-emerald-500/50 text-emerald-300 text-xs font-bold text-center animate-in fade-in">
            {rewardToast}
          </div>
        )}

        {directPaymentStatus && (
          <div className="p-3.5 rounded-2xl bg-sky-950/60 border border-sky-500/50 text-sky-300 text-xs font-bold text-center animate-in fade-in">
            {directPaymentStatus}
          </div>
        )}

      </div>

      {/* Manual Top-Up Modal */}
      {showTopUpModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            className="w-full max-w-md bg-slate-950 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-2xl relative"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Coins className="w-5 h-5 text-amber-400" />
                <h4 className="text-sm font-bold text-white">Ricarica Crediti Pi Network</h4>
              </div>
              <button
                onClick={() => setShowTopUpModal(false)}
                className="text-slate-400 hover:text-white text-xs font-bold"
              >
                Chiudi
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <p className="text-slate-300">
                Seleziona l'importo di crediti Pioneer da trasferire dal tuo Pi Wallet ufficiale:
              </p>

              <div className="grid grid-cols-3 gap-2">
                {[0.5, 1.0, 2.5].map((amount) => (
                  <button
                    key={amount}
                    onClick={() => setTopUpAmount(amount)}
                    className={`py-2 rounded-xl font-bold font-mono text-xs border transition-all cursor-pointer ${
                      topUpAmount === amount
                        ? "bg-amber-500 text-slate-950 border-amber-400 shadow-md"
                        : "bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700"
                    }`}
                  >
                    +{amount} π
                  </button>
                ))}
              </div>

              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between text-slate-300">
                <span>Importo Selezionato:</span>
                <span className="font-bold text-amber-400 font-mono text-sm">{topUpAmount} π</span>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-end gap-3">
              <button
                onClick={() => setShowTopUpModal(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold hover:bg-slate-700"
              >
                Annulla
              </button>
              <button
                onClick={handleConfirmTopUp}
                className="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-lg"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Conferma via Pi SDK</span>
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
};
