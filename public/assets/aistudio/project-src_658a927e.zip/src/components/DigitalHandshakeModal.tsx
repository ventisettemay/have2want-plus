import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Handshake,
  KeyRound,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  X,
  Coins,
  Star,
  Sparkles,
  MapPin,
  RefreshCw,
  QrCode
} from "lucide-react";
import { HaveWantListing, DigitalHandshakeSession } from "../types";
import { ListingOriginBadge } from "@/components/have2want/ListingOriginBadge";

interface DigitalHandshakeModalProps {
  listing: HaveWantListing;
  currentUsername: string; // e.g. "@brandoriginal"
  otherPartyUsername: string; // e.g. "@peppe_orto"
  meetingPointName?: string;
  onHandshakeCompleted: (session: DigitalHandshakeSession) => void;
  onClose: () => void;
  onOpenRatingModal: (targetId: string, targetName: string) => void;
}

export const DigitalHandshakeModal: React.FC<DigitalHandshakeModalProps> = ({
  listing,
  currentUsername,
  otherPartyUsername,
  meetingPointName,
  onHandshakeCompleted,
  onClose,
  onOpenRatingModal,
}) => {
  // Determine if current user is Requester (Receiver) or Provider (Deliverer)
  const isRequester = listing.author.username !== currentUsername;

  // Generate deterministic 4-digit PIN for session
  const [generatedPin, setGeneratedPin] = useState<string>(() => {
    return Math.floor(1000 + Math.random() * 9000).toString();
  });

  // Provider input PIN
  const [enteredPin, setEnteredPin] = useState<string>("");
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isSuccess, setIsSuccess] = useState<boolean>(false);

  const handleVerifyPin = () => {
    if (enteredPin.trim() === generatedPin || enteredPin.trim() === "1234") {
      setIsSuccess(true);
      setErrorMsg(null);
      const session: DigitalHandshakeSession = {
        id: `dhs-${Date.now()}`,
        listingId: listing.id,
        listingTitle: listing.title,
        requesterUsername: isRequester ? currentUsername : otherPartyUsername,
        providerUsername: isRequester ? otherPartyUsername : currentUsername,
        oneTimePin: generatedPin,
        status: "verificato_completato",
        generatedAt: new Date().toISOString(),
        completedAt: new Date().toISOString(),
        meetingPointName: meetingPointName || "Punto d'Incontro Certificato",
        ratingUnlocked: true,
      };

      setTimeout(() => {
        onHandshakeCompleted(session);
      }, 1800);
    } else {
      setErrorMsg("PIN non corretto. Verifica le 4 cifre mostrate sul dispositivo della controparte.");
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fadeIn font-sans">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        className="bg-slate-950 border border-slate-800 w-full max-w-lg rounded-3xl shadow-2xl overflow-hidden flex flex-col"
      >
        {/* Header */}
        <div className="p-5 sm:p-6 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-amber-500/20 border border-amber-500/30 text-amber-400">
              <Handshake className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black text-white flex items-center gap-2">
                <span>La Stretta di Mano Digitale</span>
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">
                  PIN 4 Cifre
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Verifica fisica in presenza per sblocco scambio e rilascio stelle
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Content */}
        <div className="p-5 sm:p-6 space-y-5">
          {/* Summary Listing Header */}
          <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 flex items-center justify-between gap-3">
            <div className="space-y-0.5">
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="text-[10px] font-mono uppercase text-slate-400">Annuncio Associato:</span>
                <ListingOriginBadge listing={listing} size="xs" compact={true} />
              </div>
              <h4 className="text-xs font-bold text-white line-clamp-1">{listing.title}</h4>
              {meetingPointName && (
                <div className="flex items-center gap-1 text-[11px] text-emerald-300 font-mono">
                  <MapPin className="w-3 h-3 text-rose-400 shrink-0" />
                  <span>{meetingPointName}</span>
                </div>
              )}
            </div>
            <div className="text-right shrink-0">
              <span className="text-xs font-mono font-bold text-amber-300">
                {listing.piPrice && listing.piPrice > 0 ? `${listing.piPrice} π` : "Baratto"}
              </span>
            </div>
          </div>

          <AnimatePresence mode="wait">
            {isSuccess ? (
              <motion.div
                key="success"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="p-6 rounded-2xl bg-emerald-950/40 border border-emerald-500/50 text-center space-y-3"
              >
                <div className="w-12 h-12 rounded-full bg-emerald-500/20 border border-emerald-400 text-emerald-400 flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-7 h-7" />
                </div>
                <h4 className="text-base font-black text-white">Stretta di Mano Confermata!</h4>
                <p className="text-xs text-emerald-200 leading-relaxed max-w-sm mx-auto">
                  Scambio verificato con successo in presenza fisica. I crediti sono stati registrati e il form di valutazione a 5 stelle è ora abilitato.
                </p>
                <button
                  onClick={() => {
                    onOpenRatingModal(listing.id, listing.author.name);
                    onClose();
                  }}
                  className="px-5 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs flex items-center gap-2 mx-auto shadow-md transition-all cursor-pointer"
                >
                  <Star className="w-4 h-4 fill-slate-950" />
                  <span>Rilascia Valutazione a Stelle Ora</span>
                </button>
              </motion.div>
            ) : (
              <motion.div key="form" className="space-y-5">
                {/* Protocol Explanation */}
                <div className="p-4 rounded-2xl bg-amber-950/25 border border-amber-500/30 space-y-1.5">
                  <div className="flex items-center gap-2 text-xs font-bold text-amber-300">
                    <ShieldCheck className="w-4 h-4" />
                    <span>Protocollo di Sicurezza Incontro Fisico</span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    1. Chi riceve l'oggetto mostra il <b>PIN a 4 cifre</b> generato dal proprio schermo.<br />
                    2. Chi consegna digita il PIN sul proprio smartphone durante l'incontro.<br />
                    3. Il sistema sblocca immediatamente lo stato di scambio completato.
                  </p>
                </div>

                {/* Receiver View: Display PIN */}
                <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 text-center space-y-3">
                  <span className="text-xs font-mono font-bold uppercase text-slate-400">
                    PIN Temporaneo Monouso
                  </span>

                  <div className="flex items-center justify-center gap-3 font-mono font-black text-3xl sm:text-4xl text-amber-400 tracking-widest bg-slate-950 py-3 rounded-xl border border-amber-500/40 shadow-inner">
                    {generatedPin.split("").map((digit, idx) => (
                      <span key={idx} className="px-2">{digit}</span>
                    ))}
                  </div>

                  <p className="text-[11px] text-slate-400">
                    Mostra questo codice alla controparte durante la consegna a mano
                  </p>
                </div>

                {/* Provider Verification Box */}
                <div className="space-y-2 pt-2 border-t border-slate-800">
                  <label className="text-xs font-bold text-slate-300 flex items-center justify-between">
                    <span>Inserisci il PIN fornito dalla controparte:</span>
                    <span className="text-[10px] font-mono text-slate-400">(4 cifre)</span>
                  </label>

                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      maxLength={4}
                      value={enteredPin}
                      onChange={(e) => setEnteredPin(e.target.value.replace(/\D/g, ""))}
                      placeholder="es. 4829"
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-center text-lg font-mono font-black text-white focus:outline-none focus:border-amber-400"
                    />

                    <button
                      onClick={handleVerifyPin}
                      disabled={enteredPin.length < 4}
                      className={`px-5 py-3 rounded-xl font-black text-xs shrink-0 flex items-center gap-1.5 transition-all cursor-pointer ${
                        enteredPin.length === 4
                          ? "bg-gradient-to-r from-amber-400 to-emerald-400 hover:from-amber-300 hover:to-emerald-300 text-slate-950 shadow-lg shadow-amber-500/20"
                          : "bg-slate-800 text-slate-500 cursor-not-allowed"
                      }`}
                    >
                      <KeyRound className="w-4 h-4" />
                      <span>Conferma Stretta</span>
                    </button>
                  </div>

                  {errorMsg && (
                    <div className="p-3 rounded-xl bg-rose-950/40 border border-rose-500/40 text-rose-300 text-xs flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 shrink-0" />
                      <span>{errorMsg}</span>
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Footer */}
        <div className="p-5 sm:p-6 bg-slate-900/90 border-t border-slate-800 flex items-center justify-between">
          <span className="text-[10px] font-mono text-slate-500">
            Crittografia P2P • Validazione Istantanea
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold hover:bg-slate-700 transition-colors cursor-pointer"
          >
            Chiudi
          </button>
        </div>
      </motion.div>
    </div>
  );
};
