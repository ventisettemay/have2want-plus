import React, { useState } from "react";
import {
  Sparkles,
  TreeDeciduous,
  GitBranch,
  Layers,
  Users,
  Archive,
  Bot,
  AlertTriangle,
  ArrowRight,
  X,
  MessageSquare,
  PlusCircle,
  Coins,
  ShieldCheck,
  HeartHandshake,
  TrendingUp,
  Leaf,
  CheckCircle2,
  Share2,
  Compass,
  Zap,
  Info,
  Send,
  Eye
} from "lucide-react";
import {
  HaveWantListing,
  InteractionIntent,
  SalvavatuttoGuide,
  CommunityChatMessage,
  PioneerUser
} from "../types";
import { fuzzyGeocode } from "../lib/fuzzyGeocoding";
import { INITIAL_LISTINGS } from "../data";
import { ListingOriginBadge } from "@/components/have2want/ListingOriginBadge";
import ancientMillennialTreeImg from "../assets/images/ancient_millennial_tree_1788116112908.jpg";
import millennialMacroImg from "../assets/images/millennial_tree_macro_1788116128365.jpg";
import ancientOliveImg from "../assets/images/ancient_olive_tree_1788116151962.jpg";
import treeOfLifeImg from "../assets/images/tree_of_life_h2w_1788115817965.jpg";

interface TreeOfLifeExplorerProps {
  onNavigate: (tab: "planet-possibilita" | "planet-vita" | "planet-salvavatutto" | "ai-assistant" | "emergency") => void;
  listings: HaveWantListing[];
  guides: SalvavatuttoGuide[];
  messages: CommunityChatMessage[];
  currentUser: PioneerUser;
  onAddListing: (listing: HaveWantListing) => void;
  onSelectListingForTrade: (listing: HaveWantListing) => void;
}

type InteractiveTreeZone = 
  | { type: "branch"; branchName: string; branchCategory: string; description: string; chamber: string }
  | { type: "leaf"; listing: HaveWantListing }
  | { type: "new-leaf" }
  | { type: "trunk"; guideCategory?: string }
  | { type: "roots"; focus: "community" | "pioneers" | "trust" }
  | { type: "heart-sap" }
  | { type: "crown-beacon" }
  | null;

export const TreeOfLifeExplorer: React.FC<TreeOfLifeExplorerProps> = ({
  onNavigate,
  listings,
  guides,
  messages,
  currentUser,
  onAddListing,
  onSelectListingForTrade,
}) => {
  // Active Interactive Anatomy Inspector
  const [activeZone, setActiveZone] = useState<InteractiveTreeZone>(null);
  
  // Community Growth Simulation Engine (La comunità che fa crescere l'Albero)
  // Livelli: 1 (Semenzaio/15 Pionieri), 2 (Giovane Albero/85 Pionieri), 3 (Grande Quercia/350 Pionieri), 4 (Albero Millenario Cosmico/1200+ Pionieri)
  const [communityLevel, setCommunityLevel] = useState<number>(3);
  
  // New Leaf / Listing Creation Form State
  const [newTitle, setNewTitle] = useState("");
  const [newIntent, setNewIntent] = useState<InteractionIntent>("BARATTO_SCAMBIO");
  const [newCategory, setNewCategory] = useState("Conoscenza & Digitale");
  const [newDescription, setNewDescription] = useState("");
  const [newPiPrice, setNewPiPrice] = useState(0);

  // Quick Branch Chat Message State
  const [quickMessage, setQuickMessage] = useState("");
  const [branchChatFeedback, setBranchChatFeedback] = useState<string | null>(null);

  // Calcolo dinamico dello sviluppo dell'Albero in base alla Comunità
  const growthConfigs = {
    1: {
      stageName: "Germoglio di Comunità",
      pioneers: 18,
      branchesCount: 3,
      foliageDensity: "Leggera & Nascente",
      trunkDiameter: "Snello & Flessibile (35cm)",
      sapEnergy: "62%",
      trunkGlow: "rgba(245, 158, 11, 0.3)",
      scaleEffect: "scale-95",
      description: "I primi pionieri hanno piantato il seme. Il tronco è giovane e i rami accolgono le prime conversazioni sincere.",
    },
    2: {
      stageName: "Albero Giovane Rigoglioso",
      pioneers: 85,
      branchesCount: 6,
      foliageDensity: "Rigogliosa & Espansiva",
      trunkDiameter: "Solido & Ramificato (80cm)",
      sapEnergy: "84%",
      trunkGlow: "rgba(16, 185, 129, 0.4)",
      scaleEffect: "scale-100",
      description: "La linfa circola velocemente. Centinaia di scambi e manuali pratici arricchiscono la corteccia e le foglie.",
    },
    3: {
      stageName: "Albero Secolare di Comunità",
      pioneers: 360,
      branchesCount: 9,
      foliageDensity: "Fitta & Fruttifera",
      trunkDiameter: "Massiccio & Scolpito (180cm)",
      sapEnergy: "96%",
      trunkGlow: "rgba(16, 185, 129, 0.6)",
      scaleEffect: "scale-105",
      description: "Un gigante vivente. Radici ancorate nella fiducia territoriale, tronco che custodisce l'Arca dei Saperi e rami carichi di frutti.",
    },
    4: {
      stageName: "Albero Millenario Cosmico",
      pioneers: 1420,
      branchesCount: 16,
      foliageDensity: "Infinita & Luminosa",
      trunkDiameter: "Monumentale Eterno (350cm)",
      sapEnergy: "100% (Sinergia Totale)",
      trunkGlow: "rgba(245, 158, 11, 0.8)",
      scaleEffect: "scale-110",
      description: "La rete vivente dell'economia reale. Migliaia di cuori interconnessi senza intermediari o speculazioni.",
    },
  };

  const currentGrowth = growthConfigs[communityLevel as 1 | 2 | 3 | 4];

  // Gestione creazione nuova foglia (inserzione direttamente sull'albero)
  const handleCreateLeafListing = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newDescription.trim()) return;

    const geocoded = fuzzyGeocode(currentUser.city || "Asti", false);

    const newListing: HaveWantListing = {
      id: `leaf-${Date.now()}`,
      intent: newIntent,
      title: newTitle,
      description: newDescription,
      category: "servizi_lavoro_buoni",
      subcategory: "manodopera_mestieri_riparazioni",
      piPrice: newIntent === "VENDO" ? Number(newPiPrice) : 0,
      author: {
        name: currentUser.name,
        username: currentUser.username,
        avatar: currentUser.avatar,
        reputation: currentUser.reputation,
        isPioneerVerified: currentUser.verifiedKYC,
        city: currentUser.city,
      },
      lat: geocoded.lat,
      lng: geocoded.lng,
      locationArea: geocoded.displayName,
      isFuzzyLocation: geocoded.isFuzzyCentroid,
      createdAt: "Pochi istanti fa (dall'Albero)",
      tags: [newCategory, newIntent, "Albero della Vita"],
      status: "active",
      planetId: "planet-possibilita",
      satelliteId: "sat-competenze",
    };

    onAddListing(newListing);
    setActiveZone({ type: "leaf", listing: newListing });
    setNewTitle("");
    setNewDescription("");
  };

  const handleSendQuickBranchMessage = (branchName: string) => {
    if (!quickMessage.trim()) return;
    setBranchChatFeedback(`Messaggio inviato al Ramo "${branchName}"!`);
    setQuickMessage("");
    setTimeout(() => setBranchChatFeedback(null), 3000);
  };

  return (
    <div className="space-y-6 select-none">
      
      {/* ========================================================================= */}
      {/* 1. L'ALBERO DELLA VITA IN PRIMO PIANO — L'INTERFACCIA VIVA (ZERO TASTI) */}
      {/* ========================================================================= */}
      <div className="relative w-full rounded-[36px] overflow-hidden border-2 border-emerald-500/50 shadow-[0_0_100px_rgba(16,185,129,0.3)] bg-gradient-to-b from-[#020611] via-[#040c1c] to-[#01040a]">
        
        {/* Barra di Stato Organica Superiore */}
        <div className="px-5 py-3.5 bg-slate-950/90 border-b border-emerald-500/30 backdrop-blur-md flex flex-wrap items-center justify-between gap-3 z-30 relative">
          <div className="flex items-center gap-3">
            <img
              src={treeOfLifeImg}
              alt="HAVE2WANT Tree of Life"
              className="w-8 h-8 rounded-lg object-cover border border-amber-500/50 shadow-lg"
            />
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-slate-950 font-black shadow-lg shadow-emerald-500/20">
              <TreeDeciduous className="w-5 h-5" />
            </div>
            <div>
              <div className="text-[10px] font-black uppercase tracking-widest text-emerald-400 font-mono">
                Interfaccia Vivente
              </div>
              <div className="text-[9px] px-2 py-0.5 rounded-full bg-amber-400 text-slate-950 font-black">
                Tocca l'Albero per Agire
              </div>
            </div>
            </div>
          </div>

          {/* Selettore Crescita Dinamica della Comunità */}
          <div className="flex items-center gap-2 bg-slate-900/90 p-1 rounded-2xl border border-slate-800">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-2 flex items-center gap-1">
              <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
              <span>Comunità:</span>
            </span>
            {[1, 2, 3, 4].map((level) => (
              <button
                key={level}
                onClick={() => setCommunityLevel(level)}
                className={`px-2.5 py-1 rounded-xl text-[11px] font-black transition-all cursor-pointer ${
                  communityLevel === level
                    ? "bg-gradient-to-r from-emerald-400 to-teal-300 text-slate-950 shadow-md scale-105"
                    : "text-slate-400 hover:text-white bg-slate-950"
                }`}
                title={`Livello ${level}: ${growthConfigs[level as 1|2|3|4].stageName}`}
              >
                Lvl {level} ({growthConfigs[level as 1|2|3|4].pioneers}👥)
              </button>
            ))}
          </div>
        </div>

        {/* GUIDA VISIVA: COME FUNZIONA L'ALBERO */}
        <div className="bg-emerald-950/40 border-b border-emerald-500/20 px-5 py-2 flex items-center justify-between text-[11px] text-emerald-300 overflow-x-auto gap-4">
          <div className="flex items-center gap-4 shrink-0 font-medium">
            <span className="flex items-center gap-1 text-amber-300">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" /> <b>Foglie & Frutti</b>: Inserzioni HAVE & WANT
            </span>
            <span className="flex items-center gap-1 text-sky-300">
              <GitBranch className="w-3.5 h-3.5 text-sky-400" /> <b>Rami</b>: Chat & Stanze di Dialogo
            </span>
            <span className="flex items-center gap-1 text-emerald-300">
              <Archive className="w-3.5 h-3.5 text-emerald-400" /> <b>Tronco</b>: Guide & Saperi Salvavatutto
            </span>
            <span className="flex items-center gap-1 text-amber-400">
              <Users className="w-3.5 h-3.5 text-amber-400" /> <b>Radici</b>: Pionieri & Fiducia
            </span>
          </div>
          <span className="text-[10px] text-emerald-400/80 font-mono hidden md:inline">
            Stadio: <b>{currentGrowth.stageName}</b> ({currentGrowth.pioneers} Membri Attivi)
          </span>
        </div>

        {/* ========================================================================= */}
        {/* CORPO VISIVO DELL'ALBERO TATTIE AD ALTISSIMA DEFINIZIONE */}
        {/* ========================================================================= */}
        <div className="relative w-full h-[520px] sm:h-[640px] md:h-[720px] overflow-hidden flex items-center justify-center">
          
          {/* Fotografia Fondale Millenaria Reale */}
          <img
            src={communityLevel >= 3 ? ancientMillennialTreeImg : ancientOliveImg}
            alt="Albero della Vita Monumentale"
            className={`w-full h-full object-cover object-center filter brightness-[0.88] contrast-[1.08] transition-transform duration-1000 ${currentGrowth.scaleEffect}`}
          />

          {/* Flusso di Linfa Vitale e Aureole di Energia Animata */}
          <div className="absolute inset-0 bg-radial from-transparent via-slate-950/20 to-slate-950/70 pointer-events-none" />

          {/* ========================================================================= */}
          {/* HOTSPOT INTERATTIVI DIRETTAMENTE SULL'ALBERO (TOUCH SULL'ANATOMIA) */}
          {/* ========================================================================= */}

          {/* 1. FARO SOS IN CIMA ALLA CHIOMA (SOMMITÀ) */}
          <div className="absolute top-4 sm:top-8 left-1/2 -translate-x-1/2 z-20">
            <button
              onClick={() => setActiveZone({ type: "crown-beacon" })}
              className="group flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-rose-950/85 border border-rose-500/60 backdrop-blur-md text-rose-300 hover:text-white shadow-[0_0_25px_rgba(244,63,94,0.5)] transition-all hover:scale-110 cursor-pointer animate-pulse"
            >
              <AlertTriangle className="w-4 h-4 text-rose-400" />
              <span className="text-[11px] font-black">Cima dell'Albero: Faro SOS</span>
            </button>
          </div>

          {/* 2. LE FOGLIE E I FRUTTI LUMINOSI (INSERZIONI HAVE & WANT SULLA CHIOMA) */}
          {/* Foglia 1: In alto a Sinistra */}
          <div className="absolute top-[18%] left-[8%] sm:left-[15%] z-20">
            <button
              onClick={() => setActiveZone({ type: "leaf", listing: listings[0] || INITIAL_LISTINGS[0] })}
              className="group flex items-center gap-2 p-2 sm:px-3 sm:py-2 rounded-2xl bg-amber-950/90 border-2 border-amber-400 backdrop-blur-md shadow-[0_0_30px_rgba(245,158,11,0.6)] hover:scale-110 transition-all cursor-pointer text-left max-w-[170px] sm:max-w-[220px]"
            >
              <div className="w-7 h-7 rounded-xl bg-amber-400 flex items-center justify-center text-slate-950 font-black shrink-0 shadow-md">
                <Leaf className="w-4 h-4" />
              </div>
              <div className="overflow-hidden">
                <span className="text-[9px] font-black uppercase text-amber-400 block tracking-wider font-mono">
                  {listings[0]?.type || "HAVE"} • Frutto
                </span>
                <span className="text-xs font-bold text-white truncate block">
                  {listings[0]?.title || "Offro competenze"}
                </span>
              </div>
            </button>
          </div>

          {/* Foglia 2: In alto a Destra */}
          <div className="absolute top-[22%] right-[6%] sm:right-[14%] z-20">
            <button
              onClick={() => setActiveZone({ type: "leaf", listing: listings[1] || INITIAL_LISTINGS[1] })}
              className="group flex items-center gap-2 p-2 sm:px-3 sm:py-2 rounded-2xl bg-sky-950/90 border-2 border-sky-400 backdrop-blur-md shadow-[0_0_30px_rgba(56,189,248,0.6)] hover:scale-110 transition-all cursor-pointer text-left max-w-[170px] sm:max-w-[220px]"
            >
              <div className="w-7 h-7 rounded-xl bg-sky-400 flex items-center justify-center text-slate-950 font-black shrink-0 shadow-md">
                <Sparkles className="w-4 h-4" />
              </div>
              <div className="overflow-hidden">
                <span className="text-[9px] font-black uppercase text-sky-400 block tracking-wider font-mono">
                  {listings[1]?.type || "WANT"} • Foglia
                </span>
                <span className="text-xs font-bold text-white truncate block">
                  {listings[1]?.title || "Cerco attrezzo"}
                </span>
              </div>
            </button>
          </div>

          {/* Foglia 3: Centro-Sinistra (Frutto Dono Cibo) */}
          {communityLevel >= 2 && (
            <div className="absolute top-[35%] left-[5%] sm:left-[12%] z-20 animate-in fade-in duration-500">
              <button
                onClick={() => setActiveZone({ type: "leaf", listing: listings[2] || INITIAL_LISTINGS[2] })}
                className="group flex items-center gap-2 p-2 sm:px-3 sm:py-2 rounded-2xl bg-emerald-950/90 border-2 border-emerald-400 backdrop-blur-md shadow-[0_0_30px_rgba(16,185,129,0.6)] hover:scale-110 transition-all cursor-pointer text-left max-w-[160px] sm:max-w-[210px]"
              >
                <div className="w-7 h-7 rounded-xl bg-emerald-400 flex items-center justify-center text-slate-950 font-black shrink-0 shadow-md">
                  <Coins className="w-4 h-4" />
                </div>
                <div className="overflow-hidden">
                  <span className="text-[9px] font-black uppercase text-emerald-400 block tracking-wider font-mono">
                    DONO • Frutto della Terra
                  </span>
                  <span className="text-xs font-bold text-white truncate block">
                    {listings[2]?.title || "Dono raccolto bio"}
                  </span>
                </div>
              </button>
            </div>
          )}

          {/* Foglia 4: Centro-Destra (Nuove Ramificazioni Livello 3+) */}
          {communityLevel >= 3 && (
            <div className="absolute top-[34%] right-[5%] sm:right-[10%] z-20 animate-in fade-in duration-500">
              <button
                onClick={() => setActiveZone({ type: "leaf", listing: listings[3] || listings[0] })}
                className="group flex items-center gap-2 p-2 sm:px-3 sm:py-2 rounded-2xl bg-amber-950/90 border-2 border-amber-300 backdrop-blur-md shadow-[0_0_30px_rgba(245,158,11,0.6)] hover:scale-110 transition-all cursor-pointer text-left max-w-[160px] sm:max-w-[210px]"
              >
                <div className="w-7 h-7 rounded-xl bg-amber-300 flex items-center justify-center text-slate-950 font-black shrink-0 shadow-md">
                  <Leaf className="w-4 h-4" />
                </div>
                <div className="overflow-hidden">
                  <span className="text-[9px] font-black uppercase text-amber-300 block tracking-wider font-mono">
                    VALORE • Foglia Viva
                  </span>
                  <span className="text-xs font-bold text-white truncate block">
                    {listings[3]?.title || "Scambio & Circolarità"}
                  </span>
                </div>
              </button>
            </div>
          )}

          {/* BOTTONE NATIVO SULL'ALBERO: "FA' GERMOGLIARE UNA NUOVA FOGLIA (INSERZIONE)" */}
          <div className="absolute top-[28%] left-1/2 -translate-x-1/2 z-20">
            <button
              onClick={() => setActiveZone({ type: "new-leaf" })}
              className="group flex items-center gap-2 px-4 py-2.5 rounded-full bg-gradient-to-r from-emerald-500 via-teal-400 to-amber-400 text-slate-950 font-black text-xs shadow-[0_0_35px_rgba(16,185,129,0.8)] hover:scale-110 transition-all cursor-pointer border-2 border-white"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Fai Germogliare una Nuova Foglia (Inserzione)</span>
            </button>
          </div>

          {/* 3. I GRANDI RAMI MAESTRI (CHAT & STANZE DI DIALOGO) */}
          {/* Ramo Sinistro: Competenze & Ingegno */}
          <div className="absolute top-[48%] left-[3%] sm:left-[8%] z-20">
            <button
              onClick={() => setActiveZone({
                type: "branch",
                branchName: "Ramo Competenze & Ingegno",
                branchCategory: "Ingegno Umano",
                description: "Dove si incontrano sviluppatori, artigiani, insegnanti e persone con abilità pratiche da condividere.",
                chamber: "Stanza Offerte & Doni"
              })}
              className="group flex items-center gap-2.5 px-3.5 py-2 rounded-2xl bg-slate-950/95 border-2 border-emerald-400/80 backdrop-blur-md text-white shadow-[0_0_25px_rgba(16,185,129,0.5)] hover:scale-105 transition-all cursor-pointer"
            >
              <GitBranch className="w-4 h-4 text-emerald-400 shrink-0" />
              <div className="text-left">
                <span className="text-[9px] font-black uppercase tracking-wider text-emerald-400 block font-mono">
                  Ramo Chat • Tocca
                </span>
                <span className="text-xs font-black text-white">
                  Competenze & Ingegno
                </span>
              </div>
            </button>
          </div>

          {/* Ramo Destro: Terra, Strumenti & Baratto */}
          <div className="absolute top-[46%] right-[3%] sm:right-[8%] z-20">
            <button
              onClick={() => setActiveZone({
                type: "branch",
                branchName: "Ramo Terra, Strumenti & Baratto",
                branchCategory: "Risorse Tangibili",
                description: "Scambio diretto di attrezzature, semi, alimenti biologici e mutuo soccorso pratico.",
                chamber: "Stanza Bisogni & Ricerca"
              })}
              className="group flex items-center gap-2.5 px-3.5 py-2 rounded-2xl bg-slate-950/95 border-2 border-amber-400/80 backdrop-blur-md text-white shadow-[0_0_25px_rgba(245,158,11,0.5)] hover:scale-105 transition-all cursor-pointer"
            >
              <GitBranch className="w-4 h-4 text-amber-400 shrink-0" />
              <div className="text-left">
                <span className="text-[9px] font-black uppercase tracking-wider text-amber-400 block font-mono">
                  Ramo Chat • Tocca
                </span>
                <span className="text-xs font-black text-white">
                  Terra & Strumenti
                </span>
              </div>
            </button>
          </div>

          {/* 4. IL TRONCO SECOLARE (I SAPERI PRATICI DI SALVAVATUTTO) */}
          <div className="absolute top-[58%] left-1/2 -translate-x-1/2 z-20 w-full max-w-[280px] sm:max-w-[340px] px-2">
            <button
              onClick={() => setActiveZone({ type: "trunk" })}
              className="w-full group flex items-center justify-between p-3.5 rounded-3xl bg-slate-950/95 border-2 border-sky-400/80 backdrop-blur-md text-white shadow-[0_0_40px_rgba(56,189,248,0.5)] hover:scale-105 transition-all cursor-pointer text-left"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-sky-400 flex items-center justify-center text-slate-950 font-black shrink-0 shadow-md">
                  <Archive className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] font-black uppercase tracking-wider text-sky-400 block font-mono">
                    Il Tronco della Conoscenza
                  </span>
                  <span className="text-sm font-black text-white">
                    Saperi di Salvavatutto ({guides.length} Guide)
                  </span>
                  <span className="text-[10px] text-slate-300 block">
                    Corteccia Millenaria • Manuali & Autonomia
                  </span>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-sky-400 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          {/* 5. CUORE DI LINFA VITALE (AI ASSISTANT DISCRETO A CHIAMATA) */}
          <div className="absolute top-[40%] left-1/2 -translate-x-1/2 z-20">
            <button
              onClick={() => setActiveZone({ type: "heart-sap" })}
              className="group flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-cyan-950/90 border border-cyan-400/80 backdrop-blur-md text-cyan-300 shadow-[0_0_25px_rgba(6,182,212,0.6)] hover:scale-110 transition-all cursor-pointer"
            >
              <Zap className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
              <span className="text-[10px] font-black">Linfa AI (A Chiamata)</span>
            </button>
          </div>

          {/* 6. LE RADICI PROFONDE NELLA TERRA (COMUNITÀ & PIONIERI) */}
          <div className="absolute bottom-4 sm:bottom-6 left-1/2 -translate-x-1/2 z-20 w-full max-w-[320px] sm:max-w-[420px] px-3">
            <button
              onClick={() => setActiveZone({ type: "roots", focus: "community" })}
              className="w-full group flex items-center justify-between p-3.5 rounded-3xl bg-slate-950/95 border-2 border-emerald-400/90 backdrop-blur-md text-white shadow-[0_0_45px_rgba(16,185,129,0.6)] hover:scale-105 transition-all cursor-pointer text-left"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-slate-950 font-black shrink-0 shadow-md">
                  <Users className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] font-black uppercase tracking-wider text-emerald-400 block font-mono">
                    Le Radici della Fiducia Umana
                  </span>
                  <span className="text-sm font-black text-white">
                    Piazza dei Pionieri ({messages.length} Messaggi)
                  </span>
                  <span className="text-[10px] text-emerald-300 block font-medium">
                    {currentGrowth.pioneers} Pionieri Connessi nel Territorio
                  </span>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-emerald-400 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

        </div>

        {/* BARRA INFORMATIVA DELLA CRESCITA ORGANICA */}
        <div className="p-5 sm:p-6 bg-slate-950 border-t border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-black uppercase tracking-widest text-emerald-400 px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/30">
                Stato di Crescita Ecosistema
              </span>
              <span className="text-xs font-black text-white">
                {currentGrowth.stageName}
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed max-w-2xl">
              {currentGrowth.description}
            </p>
          </div>

          <div className="flex items-center gap-4 text-xs font-bold text-slate-400 shrink-0">
            <div className="text-right">
              <span className="text-slate-500 block text-[10px]">Tronco Secolare</span>
              <span className="text-white font-mono">{currentGrowth.trunkDiameter}</span>
            </div>
            <div className="w-px h-8 bg-slate-800" />
            <div className="text-right">
              <span className="text-slate-500 block text-[10px]">Linfa Attiva</span>
              <span className="text-emerald-400 font-mono font-black">{currentGrowth.sapEnergy}</span>
            </div>
          </div>
        </div>

      </div>

      {/* ========================================================================= */}
      {/* 2. MODALI & INTERAZIONI ORGANICHE (QUANDO TOCCHI UN RAMO, FOGLIA, TRONCO) */}
      {/* ========================================================================= */}

      {/* MODALE A: DETTAGLIO FOGLIA / FRUTTO (INSERZIONE TOCCATA) */}
      {activeZone?.type === "leaf" && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-lg rounded-3xl bg-slate-900 border-2 border-amber-400/80 shadow-2xl p-6 space-y-5 relative">
            <button
              onClick={() => setActiveZone(null)}
              className="absolute top-5 right-5 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-amber-400 flex items-center justify-center text-slate-950 font-black shadow-lg">
                <Leaf className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2 mb-1 flex-wrap">
                  <span className="text-[10px] font-black uppercase tracking-wider text-amber-400 font-mono">
                    Foglia / Frutto dell'Albero • {activeZone.listing.type}
                  </span>
                  <ListingOriginBadge listing={activeZone.listing} size="xs" />
                </div>
                <h3 className="text-lg font-black text-white">
                  {activeZone.listing.title}
                </h3>
              </div>
            </div>

            <p className="text-sm text-slate-300 leading-relaxed bg-slate-950/60 p-4 rounded-2xl border border-slate-800">
              {activeZone.listing.description}
            </p>

            <div className="flex items-center justify-between text-xs font-bold text-slate-400 pt-2 border-t border-slate-800">
              <div className="flex items-center gap-2">
                <img
                  src={activeZone.listing.author.avatar}
                  alt={activeZone.listing.author.name}
                  className="w-7 h-7 rounded-full object-cover border border-amber-400"
                />
                <div>
                  <span className="text-white block leading-tight">{activeZone.listing.author.name}</span>
                  <span className="text-[10px] text-slate-500">{activeZone.listing.author.city}</span>
                </div>
              </div>
              <div className="text-right">
                <span className="text-[10px] text-slate-500 block uppercase">Modalità</span>
                <span className="text-amber-400 font-mono uppercase">{activeZone.listing.mode}</span>
              </div>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={() => {
                  onSelectListingForTrade(activeZone.listing);
                  setActiveZone(null);
                }}
                className="flex-1 py-3 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-300 text-slate-950 font-black text-sm flex items-center justify-center gap-2 shadow-lg hover:scale-105 transition-transform cursor-pointer"
              >
                <HeartHandshake className="w-4 h-4" />
                <span>Apri Dialogo di Scambio con l'Autore</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODALE B: FA' GERMOGLIARE UNA NUOVA FOGLIA (CREA INSERZIONE SULL'ALBERO) */}
      {activeZone?.type === "new-leaf" && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-xl rounded-3xl bg-slate-900 border-2 border-emerald-400/80 shadow-2xl p-6 sm:p-8 space-y-5 relative max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setActiveZone(null)}
              className="absolute top-5 right-5 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-slate-950 font-black shadow-lg">
                <PlusCircle className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[10px] font-black uppercase tracking-wider text-emerald-400 font-mono block">
                  Crescita della Chioma
                </span>
                <h3 className="text-lg sm:text-xl font-black text-white">
                  Fai Germogliare una Nuova Foglia sull'Albero
                </h3>
              </div>
            </div>

            <form onSubmit={handleCreateLeafListing} className="space-y-4">
              {/* 3 Action Switches: VENDO / BARATTO_SCAMBIO / ACQUISTO_CERCO */}
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setNewIntent("VENDO")}
                  className={`py-2.5 px-1 rounded-xl font-black text-xs transition-all flex flex-col items-center justify-center gap-1 cursor-pointer ${
                    newIntent === "VENDO"
                      ? "bg-amber-400 text-slate-950 shadow-md"
                      : "bg-slate-950 text-slate-400 border border-slate-800"
                  }`}
                >
                  <Coins className="w-3.5 h-3.5" />
                  <span>VENDO (π)</span>
                </button>
                <button
                  type="button"
                  onClick={() => setNewIntent("BARATTO_SCAMBIO")}
                  className={`py-2.5 px-1 rounded-xl font-black text-xs transition-all flex flex-col items-center justify-center gap-1 cursor-pointer ${
                    newIntent === "BARATTO_SCAMBIO"
                      ? "bg-emerald-400 text-slate-950 shadow-md"
                      : "bg-slate-950 text-slate-400 border border-slate-800"
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>BARATTO</span>
                </button>
                <button
                  type="button"
                  onClick={() => setNewIntent("ACQUISTO_CERCO")}
                  className={`py-2.5 px-1 rounded-xl font-black text-xs transition-all flex flex-col items-center justify-center gap-1 cursor-pointer ${
                    newIntent === "ACQUISTO_CERCO"
                      ? "bg-sky-400 text-slate-950 shadow-md"
                      : "bg-slate-950 text-slate-400 border border-slate-800"
                  }`}
                >
                  <HeartHandshake className="w-3.5 h-3.5" />
                  <span>CERCO</span>
                </button>
              </div>

              {/* Titolo */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Titolo della Foglia (Cosa metti a disposizione o cerchi)
                </label>
                <input
                  type="text"
                  required
                  placeholder="Es. Lezioni di Chitarra, Trapano in prestito, Cassa di arance bio..."
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-emerald-400"
                />
              </div>

              {/* Categoria & Prezzo Pi */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Ramo di Riferimento</label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-emerald-400"
                  >
                    <option>Conoscenza & Digitale</option>
                    <option>Strumenti & Casa</option>
                    <option>Alimentazione & Natura</option>
                    <option>Mobilità & Veicoli</option>
                    <option>Artigianato & Riparazioni</option>
                  </select>
                </div>

                {newIntent === "VENDO" && (
                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">Prezzo Pi (π)</label>
                    <input
                      type="number"
                      min="0"
                      max="15"
                      step="0.5"
                      value={newPiPrice}
                      onChange={(e) => setNewPiPrice(Number(e.target.value))}
                      className="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-emerald-400"
                    />
                  </div>
                )}
              </div>

              {/* Descrizione */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Dettagli & Spirito di Condivisione
                </label>
                <textarea
                  required
                  rows={3}
                  placeholder="Descrivi la disponibilità, condizioni e come vorresti concordare lo scambio..."
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                  className="w-full px-4 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-emerald-400"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-400 to-teal-300 text-slate-950 font-black text-sm flex items-center justify-center gap-2 shadow-xl hover:scale-[1.02] transition-transform cursor-pointer"
              >
                <Leaf className="w-4 h-4" />
                <span>Pianta la Foglia sull'Albero</span>
              </button>
            </form>
          </div>
        </div>
      )}

      {/* MODALE C: DIALOGO SUL RAMO (CHAT DIALOGICA TOCCATA) */}
      {activeZone?.type === "branch" && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-lg rounded-3xl bg-slate-900 border-2 border-emerald-400/80 shadow-2xl p-6 space-y-5 relative">
            <button
              onClick={() => setActiveZone(null)}
              className="absolute top-5 right-5 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-emerald-400 flex items-center justify-center text-slate-950 font-black shadow-lg">
                <GitBranch className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[10px] font-black uppercase tracking-wider text-emerald-400 font-mono block">
                  Ramo Attivo • {activeZone.branchCategory}
                </span>
                <h3 className="text-lg font-black text-white">
                  {activeZone.branchName}
                </h3>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed bg-slate-950/60 p-3.5 rounded-2xl border border-slate-800">
              {activeZone.description}
            </p>

            {/* Quick Message Input on Branch */}
            <div className="space-y-2">
              <label className="block text-[11px] font-bold text-emerald-400 uppercase tracking-wider">
                Invia un Segnale a questo Ramo
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  placeholder="Scrivi un messaggio o proposta per questo ramo..."
                  value={quickMessage}
                  onChange={(e) => setQuickMessage(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSendQuickBranchMessage(activeZone.branchName)}
                  className="flex-1 px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-emerald-400"
                />
                <button
                  onClick={() => handleSendQuickBranchMessage(activeZone.branchName)}
                  className="px-4 py-2.5 rounded-xl bg-emerald-400 hover:bg-emerald-300 text-slate-950 font-black text-xs flex items-center gap-1 cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Invia</span>
                </button>
              </div>
              {branchChatFeedback && (
                <span className="text-xs font-bold text-emerald-400 flex items-center gap-1 animate-pulse">
                  <CheckCircle2 className="w-3.5 h-3.5" /> {branchChatFeedback}
                </span>
              )}
            </div>

            <div className="pt-2 flex items-center gap-3">
              <button
                onClick={() => {
                  onNavigate("planet-vita");
                  setActiveZone(null);
                }}
                className="w-full py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs flex items-center justify-center gap-2 border border-slate-700 cursor-pointer"
              >
                <MessageSquare className="w-4 h-4 text-emerald-400" />
                <span>Entra nella Stanza di Dialogo Completa</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODALE D: IL TRONCO DEI SAPERI (SALVAVATUTTO) */}
      {activeZone?.type === "trunk" && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-xl rounded-3xl bg-slate-900 border-2 border-sky-400/80 shadow-2xl p-6 space-y-5 relative max-h-[85vh] overflow-y-auto">
            <button
              onClick={() => setActiveZone(null)}
              className="absolute top-5 right-5 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-sky-400 flex items-center justify-center text-slate-950 font-black shadow-lg">
                <Archive className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[10px] font-black uppercase tracking-wider text-sky-400 font-mono block">
                  Il Tronco della Conoscenza
                </span>
                <h3 className="text-lg sm:text-xl font-black text-white">
                  Arca dei Saperi Pratici (Salvavatutto)
                </h3>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Il tronco racchiude la memoria dell'ecosistema: manuali operativi di autosufficienza, riparazioni, autoproduzione e no-spreco.
            </p>

            <div className="space-y-2.5">
              {guides.slice(0, 3).map((guide) => (
                <div
                  key={guide.id}
                  className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-3"
                >
                  <div>
                    <span className="text-[9px] font-black uppercase text-sky-400 block font-mono">
                      {guide.category} • {guide.difficulty}
                    </span>
                    <span className="text-xs font-black text-white block">
                      {guide.title}
                    </span>
                    <span className="text-[11px] text-slate-400 line-clamp-1">
                      {guide.summary}
                    </span>
                  </div>
                  <span className="text-[10px] px-2 py-1 rounded bg-sky-500/10 text-sky-300 font-bold shrink-0">
                    {guide.duration}
                  </span>
                </div>
              ))}
            </div>

            <button
              onClick={() => {
                onNavigate("planet-salvavatutto");
                setActiveZone(null);
              }}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-sky-400 to-cyan-300 text-slate-950 font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-xl hover:scale-[1.02] transition-transform cursor-pointer"
            >
              <span>Consulta Tutte le Guide dell'Arca</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* MODALE E: LE RADICI DELLA FIDUCIA (COMUNITÀ PIONIERI) */}
      {activeZone?.type === "roots" && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-lg rounded-3xl bg-slate-900 border-2 border-emerald-400/80 shadow-2xl p-6 space-y-5 relative">
            <button
              onClick={() => setActiveZone(null)}
              className="absolute top-5 right-5 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-emerald-400 flex items-center justify-center text-slate-950 font-black shadow-lg">
                <Users className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[10px] font-black uppercase tracking-wider text-emerald-400 font-mono block">
                  Radici dell'Ecosistema
                </span>
                <h3 className="text-lg font-black text-white">
                  Piazza dei Pionieri & Fiducia Territoriale
                </h3>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed bg-slate-950/60 p-4 rounded-2xl border border-slate-800">
              Le radici sono il legame umano: reputazione verificata, presidio locale, relazioni pulite senza intermediari.
            </p>

            <div className="grid grid-cols-2 gap-3 text-center">
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-[10px] text-slate-500 block uppercase font-mono">Pionieri Attivi</span>
                <span className="text-base font-black text-emerald-400">{currentGrowth.pioneers}</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-[10px] text-slate-500 block uppercase font-mono">Fiducia Media</span>
                <span className="text-base font-black text-amber-400">4.95 / 5.0 ⭐</span>
              </div>
            </div>

            <button
              onClick={() => {
                onNavigate("planet-vita");
                setActiveZone(null);
              }}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-400 to-teal-300 text-slate-950 font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-xl hover:scale-[1.02] transition-transform cursor-pointer"
            >
              <span>Entra nella Piazza dei Pionieri</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* MODALE F: LINFA AI A CHIAMATA */}
      {activeZone?.type === "heart-sap" && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-md rounded-3xl bg-slate-900 border-2 border-cyan-400/80 shadow-2xl p-6 space-y-4 relative text-center">
            <button
              onClick={() => setActiveZone(null)}
              className="absolute top-4 right-4 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="w-14 h-14 rounded-2xl bg-cyan-400 mx-auto flex items-center justify-center text-slate-950 font-black shadow-lg">
              <Bot className="w-7 h-7" />
            </div>

            <h3 className="text-lg font-black text-white">Linfa AI Discreta (A Chiamata)</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Un'intelligenza artificiale rispettosa, silenziosa e al servizio dell'utente: non interviene senza permesso, ti assiste nella formulazione di scambi etici e nella sintesi di manuali.
            </p>

            <button
              onClick={() => {
                onNavigate("ai-assistant");
                setActiveZone(null);
              }}
              className="w-full py-3 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-black text-xs flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>Attiva Assistente Linfa AI</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* MODALE G: FARO SOS EMERGENZA */}
      {activeZone?.type === "crown-beacon" && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-md rounded-3xl bg-slate-900 border-2 border-rose-500/80 shadow-2xl p-6 space-y-4 relative text-center">
            <button
              onClick={() => setActiveZone(null)}
              className="absolute top-4 right-4 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="w-14 h-14 rounded-2xl bg-rose-500 mx-auto flex items-center justify-center text-white font-black shadow-lg">
              <AlertTriangle className="w-7 h-7" />
            </div>

            <h3 className="text-lg font-black text-white">Faro SOS & Mutuo Soccorso</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              La cima dell'Albero funge da faro di allerta rapida per emergenze territoriali, blackout, maltempo o necessità improvvise di solidarietà.
            </p>

            <button
              onClick={() => {
                onNavigate("emergency");
                setActiveZone(null);
              }}
              className="w-full py-3 rounded-xl bg-rose-500 hover:bg-rose-400 text-white font-black text-xs flex items-center justify-center gap-2 cursor-pointer shadow-lg"
            >
              <span>Accedi al Centro Mutuo Soccorso (SOS)</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
