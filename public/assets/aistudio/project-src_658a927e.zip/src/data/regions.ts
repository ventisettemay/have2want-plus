// Database delle 20 Regioni Italiane e principali Territori Mondiali
// Con coordinate centroide, capoluogo, coordinate di confine e metadati 3D

export interface RegionData {
  id: string;
  name: string;
  capital: string;
  lat: number;
  lng: number;
  countryId: string;
  countryName: string;
  flag: string;
  description: string;
  population?: string;
  featuredSpots?: string[];
}

// 20 Regioni d'Italia
export const ITALIAN_REGIONS: RegionData[] = [
  {
    id: 'it-lom',
    name: 'Lombardia',
    capital: 'Milano',
    lat: 45.4642,
    lng: 9.1900,
    countryId: 'it',
    countryName: 'Italia',
    flag: '🇮🇹',
    description: 'Capitale economica, moda, innovazione e laghi prealpini',
    population: '10.0M',
    featuredSpots: ['Milano Duomo', 'Brescia', 'Bergamo', 'Lago di Como']
  },
  {
    id: 'it-laz',
    name: 'Lazio',
    capital: 'Roma',
    lat: 41.8902,
    lng: 12.4922,
    countryId: 'it',
    countryName: 'Italia',
    flag: '🇮🇹',
    description: 'Cuore storico, archeologia millenaria e capitale d\'Italia',
    population: '5.7M',
    featuredSpots: ['Roma Colosseo', 'Viterbo', 'Tivoli', 'Latina']
  },
  {
    id: 'it-pie',
    name: 'Piemonte',
    capital: 'Torino',
    lat: 45.0703,
    lng: 7.6869,
    countryId: 'it',
    countryName: 'Italia',
    flag: '🇮🇹',
    description: 'Langhe, Alpi maestose, industria e tradizione enogastronomica',
    population: '4.3M',
    featuredSpots: ['Torino Mole', 'Alba', 'Novara', 'Verbano']
  },
  {
    id: 'it-ven',
    name: 'Veneto',
    capital: 'Venezia',
    lat: 45.4408,
    lng: 12.3155,
    countryId: 'it',
    countryName: 'Italia',
    flag: '🇮🇹',
    description: 'Laguna veneziana, Dolomiti patrimonio UNESCO e ville palladiane',
    population: '4.9M',
    featuredSpots: ['Venezia San Marco', 'Verona Arena', 'Padova', 'Treviso']
  },
  {
    id: 'it-emr',
    name: 'Emilia-Romagna',
    capital: 'Bologna',
    lat: 44.4949,
    lng: 11.3426,
    countryId: 'it',
    countryName: 'Italia',
    flag: '🇮🇹',
    description: 'Motor Valley, Food Valley, università antiche e riviera adriatica',
    population: '4.4M',
    featuredSpots: ['Bologna Due Torri', 'Modena', 'Parma', 'Rimini']
  },
  {
    id: 'it-cam',
    name: 'Campania',
    capital: 'Napoli',
    lat: 40.8518,
    lng: 14.2681,
    countryId: 'it',
    countryName: 'Italia',
    flag: '🇮🇹',
    description: 'Golfo di Napoli, Costiera Amalfitana, Pompei e Vesuvio',
    population: '5.6M',
    featuredSpots: ['Napoli Spaccanapoli', 'Salerno', 'Pompei', 'Capri']
  },
  {
    id: 'it-sic',
    name: 'Sicilia',
    capital: 'Palermo',
    lat: 38.1157,
    lng: 13.3615,
    countryId: 'it',
    countryName: 'Italia',
    flag: '🇮🇹',
    description: 'Isola di luce, templi greci, Etna e cultura mediterranea',
    population: '4.8M',
    featuredSpots: ['Palermo', 'Catania Etna', 'Taormina', 'Siracusa']
  },
  {
    id: 'it-tos',
    name: 'Toscana',
    capital: 'Firenze',
    lat: 43.7696,
    lng: 11.2558,
    countryId: 'it',
    countryName: 'Italia',
    flag: '🇮🇹',
    description: 'Rinascimento, colline del Chianti, arte e borghi medievali',
    population: '3.7M',
    featuredSpots: ['Firenze Uffizi', 'Siena Piazza del Campo', 'Pisa', 'Lucca']
  },
  {
    id: 'it-pug',
    name: 'Puglia',
    capital: 'Bari',
    lat: 41.1171,
    lng: 16.8719,
    countryId: 'it',
    countryName: 'Italia',
    flag: '🇮🇹',
    description: 'Trulli della Valle d\'Itria, mare cristallino e Salento barocco',
    population: '3.9M',
    featuredSpots: ['Bari Vecchia', 'Lecce', 'Alberobello', 'Otranto']
  },
  {
    id: 'it-lig',
    name: 'Liguria',
    capital: 'Genova',
    lat: 44.4056,
    lng: 8.9463,
    countryId: 'it',
    countryName: 'Italia',
    flag: '🇮🇹',
    description: 'Cinque Terre, borghi a picco sul mare e porto storico di Genova',
    population: '1.5M',
    featuredSpots: ['Genova Porto Antico', 'Portofino', 'Cinque Terre', 'Sanremo']
  },
  {
    id: 'it-sar',
    name: 'Sardegna',
    capital: 'Cagliari',
    lat: 39.2238,
    lng: 9.1217,
    countryId: 'it',
    countryName: 'Italia',
    flag: '🇮🇹',
    description: 'Nuraghi millenari, acque turchesi incontaminate e tradizioni vive',
    population: '1.6M',
    featuredSpots: ['Cagliari Bastione', 'Olbia Costa Smeralda', 'Alghero', 'Barbagia']
  },
  {
    id: 'it-cal',
    name: 'Calabria',
    capital: 'Catanzaro',
    lat: 38.9098,
    lng: 16.5877,
    countryId: 'it',
    countryName: 'Italia',
    flag: '🇮🇹',
    description: 'Due mari, parchi della Sila e dell\'Aspromonte e Tropea',
    population: '1.8M',
    featuredSpots: ['Reggio Bronzi', 'Tropea', 'Catanzaro', 'Cosenza']
  },
  {
    id: 'it-mar',
    name: 'Marche',
    capital: 'Ancona',
    lat: 43.6158,
    lng: 13.5189,
    countryId: 'it',
    countryName: 'Italia',
    flag: '🇮🇹',
    description: 'Conero, colline di Leopardi, manifattura di qualità e mare',
    population: '1.5M',
    featuredSpots: ['Ancona', 'Urbino', 'Pesaro', 'Ascoli Piceno']
  },
  {
    id: 'it-fvg',
    name: 'Friuli-Venezia Giulia',
    capital: 'Trieste',
    lat: 45.6495,
    lng: 13.7768,
    countryId: 'it',
    countryName: 'Italia',
    flag: '🇮🇹',
    description: 'Incontro di culture mitteleuropee, Carso, Udine e mare di Trieste',
    population: '1.2M',
    featuredSpots: ['Trieste Piazza Unità', 'Udine', 'Gorizia', 'Pordenone']
  },
  {
    id: 'it-taa',
    name: 'Trentino-Alto Adige',
    capital: 'Trento',
    lat: 46.0748,
    lng: 11.1217,
    countryId: 'it',
    countryName: 'Italia',
    flag: '🇮🇹',
    description: 'Dolomiti, laghi alpini, valli incantate e rifugi d\'alta quota',
    population: '1.1M',
    featuredSpots: ['Trento', 'Bolzano', 'Merano', 'Val di Fassa']
  },
  {
    id: 'it-abr',
    name: 'Abruzzo',
    capital: 'L\'Aquila',
    lat: 42.3498,
    lng: 13.3995,
    countryId: 'it',
    countryName: 'Italia',
    flag: '🇮🇹',
    description: 'Regione verde d\'Europa, Gran Sasso, trabocchi e natura protetta',
    population: '1.3M',
    featuredSpots: ['L\'Aquila', 'Pescara', 'Gran Sasso', 'Costa dei Trabocchi']
  },
  {
    id: 'it-umb',
    name: 'Umbria',
    capital: 'Perugia',
    lat: 43.1107,
    lng: 12.3908,
    countryId: 'it',
    countryName: 'Italia',
    flag: '🇮🇹',
    description: 'Cuore verde d\'Italia, Assisi, lago Trasimeno e borghi di pace',
    population: '0.8M',
    featuredSpots: ['Perugia', 'Assisi San Francesco', 'Orvieto', 'Gubbio']
  },
  {
    id: 'it-bas',
    name: 'Basilicata',
    capital: 'Potenza',
    lat: 40.6404,
    lng: 15.8056,
    countryId: 'it',
    countryName: 'Italia',
    flag: '🇮🇹',
    description: 'Sassi di Matera patrimonio mondiale, Pollino e costa tirrenica',
    population: '0.5M',
    featuredSpots: ['Matera Sassi', 'Potenza', 'Maratea', 'Metaponto']
  },
  {
    id: 'it-mol',
    name: 'Molise',
    capital: 'Campobasso',
    lat: 41.5603,
    lng: 14.6627,
    countryId: 'it',
    countryName: 'Italia',
    flag: '🇮🇹',
    description: 'Tratturi storici, natura incontaminata, borghi fortificati e mare',
    population: '0.3M',
    featuredSpots: ['Campobasso', 'Termoli Borgo Antico', 'Isernia', 'Agnone']
  },
  {
    id: 'it-vda',
    name: 'Valle d\'Aosta',
    capital: 'Aosta',
    lat: 45.7371,
    lng: 7.3197,
    countryId: 'it',
    countryName: 'Italia',
    flag: '🇮🇹',
    description: 'Monte Bianco, Cervino, castelli feudali e natura d\'alta quota',
    population: '0.12M',
    featuredSpots: ['Aosta Romana', 'Courmayeur', 'Cervinia', 'Castello di Fénis']
  }
];

// Negozi e Aziende Inserzioniste d'esempio su Mappa 3D
export interface SponsoredBusiness {
  id: string;
  name: string;
  category: 'ristorazione' | 'artigianato' | 'tecnologia' | 'abbigliamento' | 'servizi' | 'bio_agricoltura';
  categoryLabel: string;
  badge: 'Gold Verified' | 'Diamond Partner' | 'Pi Merchant';
  city: string;
  region: string;
  lat: number;
  lng: number;
  rating: number;
  reviewCount: number;
  description: string;
  promo: string;
  piAccepted: boolean;
  fiatAccepted: boolean;
  phone: string;
  website: string;
  hours: string;
  voiceIntro?: string; // Descrizione vocale del titolare
}

export const SPONSORED_BUSINESSES: SponsoredBusiness[] = [
  {
    id: 'biz-roma-1',
    name: 'Bottega d\'Arte & Restauro Roma',
    category: 'artigianato',
    categoryLabel: 'Artigianato & Restauro',
    badge: 'Diamond Partner',
    city: 'Roma',
    region: 'Lazio',
    lat: 41.8935,
    lng: 12.4820,
    rating: 4.9,
    reviewCount: 88,
    description: 'Maestri ebanisti e restauratori di mobili storici ed orologi d\'epoca.',
    promo: 'Sconto 15% pagando con Pi Network (π) o baratto con materiali d\'epoca.',
    piAccepted: true,
    fiatAccepted: true,
    phone: '+39 06 6982 4110',
    website: 'https://bottegaroma-example.it',
    hours: 'Lun-Sab: 09:00 - 19:30',
    voiceIntro: 'Benvenuti alla Bottega d\'Arte di Roma! Ascolta la nostra storia.'
  },
  {
    id: 'biz-milano-1',
    name: 'Tech & Green Circular Lab',
    category: 'tecnologia',
    categoryLabel: 'Informatica & Rigenerazione',
    badge: 'Pi Merchant',
    city: 'Milano',
    region: 'Lombardia',
    lat: 45.4670,
    lng: 9.1890,
    rating: 4.8,
    reviewCount: 142,
    description: 'Riparazione cellulari, notebook e vendita hardware ricondizionato con garanzia 24 mesi.',
    promo: 'Valutazione immediata del tuo usato in Pi Coin o sconto sul nuovo!',
    piAccepted: true,
    fiatAccepted: true,
    phone: '+39 02 8734 5520',
    website: 'https://techcircular-example.it',
    hours: 'Lun-Ven: 09:30 - 19:00',
    voiceIntro: 'Ciao Pioneer! Qui rigeneriamo tecnologia e accettiamo Pi per qualsiasi riparazione.'
  },
  {
    id: 'biz-napoli-1',
    name: 'Caffè & Dolci Tradizione Partenopea',
    category: 'ristorazione',
    categoryLabel: 'Caffetteria & Pasticceria',
    badge: 'Gold Verified',
    city: 'Napoli',
    region: 'Campania',
    lat: 40.8490,
    lng: 14.2580,
    rating: 5.0,
    reviewCount: 230,
    description: 'Vero espresso napoletano, sfogliatelle calde e babà artigianali.',
    promo: 'Colazione Pi: Caffè speciale + sfogliatella a 0.2 π',
    piAccepted: true,
    fiatAccepted: true,
    phone: '+39 081 552 1904',
    website: 'https://caffetradizione-example.it',
    hours: 'Tutti i giorni: 06:30 - 21:00',
    voiceIntro: 'Profumo di caffè e sfogliatella calda! Vi aspettiamo nel cuore di Napoli.'
  },
  {
    id: 'biz-firenze-1',
    name: 'Libreria del Ponte & Manoscritti',
    category: 'servizi',
    categoryLabel: 'Libri Antichi & Scolastici',
    badge: 'Pi Merchant',
    city: 'Firenze',
    region: 'Toscana',
    lat: 43.7680,
    lng: 11.2530,
    rating: 4.9,
    reviewCount: 76,
    description: 'Compravendita testi universitari, narrativa rara, mappe geografiche e scambio testi.',
    promo: 'Punto scambio scolastico convenzionato con l\'app Salvatutto!',
    piAccepted: true,
    fiatAccepted: true,
    phone: '+39 055 214 789',
    website: 'https://libreriaponte-example.it',
    hours: 'Lun-Sab: 10:00 - 19:30',
    voiceIntro: 'Benvenuti a Firenze: libri rari, saggi e testi scolastici per tutti.'
  }
];
