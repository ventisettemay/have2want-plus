import { CategoryDefinition, RealCategoryKey, RealSubcategoryKey } from "./types";

export const REAL_CATEGORIES_MATRIX: CategoryDefinition[] = [
  {
    key: "rete_specialisti_supporto",
    label: "Rete Specialisti Sostenitori (Vetrina Gratis)",
    iconName: "HeartHandshake",
    description: "Medici, psicologi e consulenti etici: orientamento gratuito in chat in cambio di Vetrina Sponsorizzata permanente su Google Earth 3D.",
    subcategories: [
      {
        key: "medici_comunita",
        label: "Medici di Comunità & Salute Solidale",
        description: "Medici di base, pediatri e specialisti per orientamento clinico e prevenzione solidale in chat.",
        isCommunitySpecialist: true,
      },
      {
        key: "psicologi_ascolto",
        label: "Psicologi dell'Ascolto & Benessere Emotivo",
        description: "Psicoterapeuti e psicologi per supporto emotivo, ascolto attivo e prima consulenza gratuita.",
        isCommunitySpecialist: true,
      },
      {
        key: "consulenza_professionale_etica",
        label: "Consulenza Professionale & Legale Etica",
        description: "Avvocati, commercialisti e consulenti del lavoro per orientamento normativo e fiscale solidale.",
        isCommunitySpecialist: true,
      },
    ],
  },
  {
    key: "libri_scuola_cultura",
    label: "Libri, Scuola & Cultura",
    iconName: "GraduationCap",
    description: "Mercato del sapere: scambio di testi scolastici usati tra studenti, saggistica e narrativa.",
    subcategories: [
      {
        key: "scambio_libri_scolastici",
        label: "Scambio Libri Scolastici (Priorità Studenti)",
        description: "Scambio diretto di testi scolastici usati tra famiglie e studenti senza restrizioni chilometriche.",
      },
      {
        key: "saggistica_narrativa",
        label: "Saggistica & Narrativa",
        description: "Romanzi, manuali tecnici, saggi universitari e collezioni letterarie.",
      },
    ],
  },
  {
    key: "auto_moto_veicoli",
    label: "Auto, Moto & Veicoli",
    iconName: "Bike",
    description: "Pezzi di ricambio, pneumatici usati, accessori e mezzi di trasporto della comunità.",
    subcategories: [
      {
        key: "pneumatici_accessori",
        label: "Pneumatici & Accessori",
        description: "Gomme stagionali, catene da neve, cerchi e barre portapacchi.",
      },
      {
        key: "componenti_meccanici_ricambi",
        label: "Componenti Meccanici & Ricambi",
        description: "Batterie, alternatori, pastiglie freni, specchietti e ricambi officina.",
      },
      {
        key: "veicoli_usati",
        label: "Veicoli Usati & Mobilità Dolce",
        description: "Biciclette, scooter, auto cittadine e furgoni di seconda mano.",
      },
      {
        key: "trasferte_passaggi_carpool",
        label: "Trasferte & Passaggi Condivisi",
        description: "Spostamenti condivisi tra città, trasferte di lavoro e carpooling tra privati.",
      },
    ],
  },
  {
    key: "abbigliamento_accessori",
    label: "Abbigliamento & Accessori",
    iconName: "ShoppingBag",
    description: "Moda circolare, calzature da lavoro e tempo libero, tessuti naturali e accessori.",
    subcategories: [
      {
        key: "vestiario_abiti",
        label: "Vestiario & Abiti",
        description: "Giacconi invernali, divise da lavoro, completi e maglieria in lana/cotone.",
      },
      {
        key: "calzature_scarpe",
        label: "Calzature & Scarpe",
        description: "Scarponi da trekking, stivali antinfortunistici e calzature quotidiane.",
      },
      {
        key: "accessori_moda",
        label: "Accessori Moda & Pelletteria",
        description: "Borse in cuoio, cinture, cappelli, zaini scuola e sciarpe.",
      },
    ],
  },
  {
    key: "elettronica_informatica",
    label: "Elettronica & Informatica",
    iconName: "Smartphone",
    description: "Dispositivi rigenerati, hardware informatico, componentistica ed elettrodomestici.",
    subcategories: [
      {
        key: "telefonia_smartphone",
        label: "Telefonia & Smartphone",
        description: "Cellulari usati, caricabatterie veloci, cover e accessori telefonici.",
      },
      {
        key: "hardware_computer",
        label: "Hardware & Computer",
        description: "Notebook ricondizionati, monitor, schede video, SSD e tastiere.",
      },
      {
        key: "elettrodomestici",
        label: "Elettrodomestici per la Casa",
        description: "Microonde, robot da cucina, lavatrici revisionate e ferri da stiro.",
      },
    ],
  },
  {
    key: "casa_fai_da_te",
    label: "Casa & Fai-da-te",
    iconName: "Hammer",
    description: "Arredamento rustico e moderno, attrezzi da cantiere, utensili manuali e ferramenta.",
    subcategories: [
      {
        key: "arredamento_mobili",
        label: "Arredamento & Mobili",
        description: "Tavoli massello, credenze d'epoca, sedie, librerie e divani.",
      },
      {
        key: "attrezzi_lavoro_utensili",
        label: "Attrezzi da Lavoro & Utensili",
        description: "Trapani a percussione, cesoie da potatura, smerigliatrici e banchi da lavoro.",
      },
    ],
  },
  {
    key: "servizi_lavoro_buoni",
    label: "Servizi, Lavoro & Buoni",
    iconName: "Wrench",
    description: "Prestazioni d'opera territoriali, supporto allo studio e buoni prepagati.",
    subcategories: [
      {
        key: "carte_prepagate_buoni_carburante",
        label: "Carte Prepagate & Buoni Carburante",
        description: "Voucher acquisto, gift card ed esuberi di buoni spesa/benzina.",
      },
      {
        key: "manodopera_mestieri_riparazioni",
        label: "Manodopera, Mestieri & Riparazioni",
        description: "Interventi idraulici, falegnameria, riparazione bici e sartoria.",
      },
      {
        key: "ripetizioni_scolastiche",
        label: "Ripetizioni Scolastiche & Tutoraggio",
        description: "Lezioni di matematica, lingue, scienze e aiuto compiti pomeridiano.",
      },
    ],
  },
];

export function getCategoryDefinition(key: RealCategoryKey): CategoryDefinition | undefined {
  return REAL_CATEGORIES_MATRIX.find((c) => c.key === key);
}

export function getCategoryLabel(key: RealCategoryKey): string {
  return getCategoryDefinition(key)?.label || key;
}

export function getSubcategoryLabel(catKey: RealCategoryKey, subKey: RealSubcategoryKey): string {
  const cat = getCategoryDefinition(catKey);
  const sub = cat?.subcategories.find((s) => s.key === subKey);
  return sub?.label || subKey;
}
