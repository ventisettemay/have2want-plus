import { createClient } from '@base44/sdk';
export const base44 = createClient({
  apiKey: "H2W-PROD-KEY-2026",
  environment: "production"
});
