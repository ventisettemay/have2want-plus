import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

/**
 * Gestisce l'acquisto di visibilità dei palazzi stabili commerciali in Pi Coin Testnet via SDK esterno
 */
export async function processListingVisibilityPurchase(listingId, profileId, weeksCount) {
  try {
    let cost = 6;
    let days = 7;
    if (weeksCount === 2) { cost = 10; days = 14; }
    else if (weeksCount === 4) { cost = 18; days = 30; }

    const walletTransaction = await window.Pi.createPayment({
      amount: cost,
      memo: `Acquisto Visibilità Testnet ${days} Giorni - HAVE2WANT`,
      metadata: { listing_id: listingId }
    });

    if (!walletTransaction) {
      toast.error("Transazione Testnet rifiutata o annullata dal Wallet.");
      return false;
    }

    const end = new Date();
    end.setDate(end.getDate() + days);

    await base44.entities.Listing.update(listingId, {
      visibility_level: "PREMIUM_ILLUMINATO",
      visibility_expires_at: end.toISOString(),
      pi_testnet_tx_id: walletTransaction.txid
    });

    toast.success(`Voilà! Palazzo 3D risaltato ed illuminato per ${days} giorni sul territorio.`);
    return true;
  } catch (err) {
    toast.error("Impossibile attivare il risalto commerciale");
    return false;
  }
}

/**
 * Scudo del Ban Commerciale: Espulsione istantanea a 99 anni nel futuro per truffe o sconti negati
 */
export async function executeCommunityBan(listingId, companyProfileId) {
  try {
    await base44.entities.Listing.update(listingId, {
      visibility_level: "OFF_SPENTO",
      status: "removed"
    });

    const infinityDate = new Date();
    infinityDate.setFullYear(infinityDate.getFullYear() + 99);

    await base44.entities.Profile.update(companyProfileId, {
      trust_rating: 0,
      pi_circuit_suspended_until: infinityDate.toISOString()
    });

    toast.error("Azienda scorretta espulsa permanentemente. Annuncio oscurato, fondi trattenuti.");
    return true;
  } catch (err) {
    console.error("Errore nell'esecuzione del ban di autotutela:", err);
    return false;
  }
}
