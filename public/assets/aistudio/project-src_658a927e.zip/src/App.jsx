import React, { useState, useEffect, useMemo, useRef } from 'react';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import { H2WProvider } from '@/lib/h2wContext';
import { Toaster, toast } from 'sonner';
import MapView3DContainer from '@/components/have2want/MapView3DContainer';
import StrettaDiMano from '@/components/have2want/StrettaDiMano';
import AdRewardHub from '@/components/have2want/AdRewardHub';
import { HomeFeedView } from '@/components/HomeFeedView';
import { ClassicEssentialView } from '@/components/have2want/ClassicEssentialView';
import { CreateListingModal } from '@/components/CreateListingModal';
import { CertifiedMeetingPointsModal } from '@/components/CertifiedMeetingPointsModal';
import { DiscreetAIAssistant } from '@/components/DiscreetAIAssistant';
import { SalvavatuttoPlanet } from '@/components/SalvavatuttoPlanet';
import { DriveExporter } from '@/components/DriveExporter';
import { LegalWelcomeShield } from '@/components/LegalWelcomeShield';
import { AuthorshipCertificateModal } from '@/components/AuthorshipCertificateModal';
import WorldEmergencyModal from '@/components/have2want/WorldEmergencyModal';
import GlobalCarpoolModal from '@/components/have2want/GlobalCarpoolModal';
import CraftMemoryModal from '@/components/have2want/CraftMemoryModal';
import AppTutorModal from '@/components/have2want/AppTutorModal';
import InterruttoriRapidiModal from '@/components/have2want/InterruttoriRapidiModal';
import ListingDetailModal from '@/components/have2want/ListingDetailModal';
import AutoTutorPill from '@/components/have2want/AutoTutorPill';
import { CountrySelectorModal } from '@/components/CountrySelectorModal';
import { PrivacyGate } from '@/components/PrivacyGate';
import SupermarketGlobaleH2W from '@/components/have2want/SupermarketGlobaleH2W';
import BachecaLavoroP2P from '@/components/have2want/BachecaLavoroP2P';
import VetrinaAgenziePaywall from '@/components/have2want/VetrinaAgenziePaywall';
import VetrinaKmZero from '@/components/have2want/VetrinaKmZero';
import SupermarketMondo from '@/components/have2want/SupermarketMondo';
import { COUNTRIES, getCountryForListing } from '@/data/countries';
import { INITIAL_LISTINGS, SALVAVATUTTO_GUIDES } from '@/data';
import { REAL_CATEGORIES_MATRIX } from '@/categories';
import { base44 } from '@/api/base44Client';
import {
  Globe,
  Globe2,
  Building,
  Building2,
  LayoutGrid,
  Plus,
  Sparkles,
  ShieldCheck,
  BookOpen,
  CloudUpload,
  Scale,
  X,
  Lock,
  Eye,
  EyeOff,
  Compass,
  CheckCircle2,
  MapPin,
  Handshake,
  SlidersHorizontal,
  ChevronDown,
  Award,
  Store,
  Mic,
  Search,
  Car,
  Wrench,
  Zap,
  GraduationCap,
  Image as ImageIcon
} from 'lucide-react';
import treeOfLifeImg from '@/assets/images/tree_of_life_h2w_1788115817965.jpg';,
  Image as ImageIcon
} from 'lucide-react';

/* =========================================================================
   1. MODULO PRIVACY GEOGRAFICA (geoPrivacy)
   =========================================================================
   Gestisce la precisione della geolocalizzazione degli annunci.
   Se l'utente attiva "Modalità Discreta" (o se l'annuncio lo richiede),
   la mappa NON mostra le coordinate esatte (lat/lng), ma posiziona l'annuncio
   sul centroide del comune (municipality_centroid), visualizzando un raggio
   di approssimazione (~2.0 - 2.5 km) a tutela della privacy.
*/

const KNOWN_MUNICIPALITY_CENTROIDS = {
  'roma': { lat: 41.8931, lng: 12.4828 },
  'milano': { lat: 45.4642, lng: 9.1900 },
  'torino': { lat: 45.0703, lng: 7.6869 },
  'asti': { lat: 44.9008, lng: 8.2065 },
  'napoli': { lat: 40.8518, lng: 14.2681 },
  'firenze': { lat: 43.7696, lng: 11.2558 },
  'bologna': { lat: 44.4949, lng: 11.3426 },
  'genova': { lat: 44.4056, lng: 8.9463 },
  'palermo': { lat: 38.1157, lng: 13.3615 },
  'bari': { lat: 41.1171, lng: 16.8719 },
  'catania': { lat: 37.5079, lng: 15.0830 },
  'venezia': { lat: 45.4408, lng: 12.3155 },
  'verona': { lat: 45.4384, lng: 10.9916 },
  'cagliari': { lat: 39.2238, lng: 9.1217 },
  'trieste': { lat: 45.6495, lng: 13.7768 },
  'madrid': { lat: 40.4168, lng: -3.7038 },
  'paris': { lat: 48.8566, lng: 2.3522 },
  'berlin': { lat: 52.5200, lng: 13.4050 },
  'london': { lat: 51.5074, lng: -0.1278 },
  'new york': { lat: 40.7128, lng: -74.0060 },
  'tokyo': { lat: 35.6762, lng: 139.6503 }
};

export function calculateMunicipalityCentroid(cityName = '', rawLat = 0, rawLng = 0) {
  const normalized = (cityName || '').trim().toLowerCase();
  if (KNOWN_MUNICIPALITY_CENTROIDS[normalized]) {
    return {
      lat: KNOWN_MUNICIPALITY_CENTROIDS[normalized].lat,
      lng: KNOWN_MUNICIPALITY_CENTROIDS[normalized].lng,
      radiusKm: 2.0,
      label: `Centroide Comunale di ${cityName || 'Comune'}`
    };
  }

  // Calcolo deterministico dell'offset per tutelare l'indirizzo privato
  let hash = 0;
  for (let i = 0; i < normalized.length; i++) {
    hash = (hash << 5) - hash + normalized.charCodeAt(i);
    hash |= 0;
  }
  const offsetLat = ((Math.abs(hash) % 100) / 1000) - 0.05;
  const offsetLng = (((Math.abs(hash >> 3)) % 100) / 1000) - 0.05;

  return {
    lat: Number((Math.round((rawLat + offsetLat) * 100) / 100).toFixed(4)),
    lng: Number((Math.round((rawLng + offsetLng) * 100) / 100).toFixed(4)),
    radiusKm: 2.5,
    label: `Centroide Territoriale (${cityName || 'Comune'})`
  };
}

export function applyGeoPrivacy(listing, isGlobalDiscreetMode = false) {
  if (!listing) {
    return { lat: 0, lng: 0, isMasked: false, mode: 'STANDARD', radiusKm: 0, label: 'Posizione non specificata' };
  }

  const isDiscreet = isGlobalDiscreetMode ||
    listing.privacy_mode_active === true ||
    listing.is_discrete_mode === true ||
    listing.isFuzzyLocation === true ||
    listing.discrete_mode === true;

  if (isDiscreet) {
    if (typeof listing.municipality_centroid_lat === 'number' && typeof listing.municipality_centroid_lng === 'number') {
      return {
        lat: listing.municipality_centroid_lat,
        lng: listing.municipality_centroid_lng,
        isMasked: true,
        mode: 'DISCRETA',
        radiusKm: listing.approximation_radius_km || 2.0,
        label: `Centroide Comune (${listing.city || 'Comune'}) • Raggio tutela ~2 km`
      };
    }

    const rawLat = listing.exact_lat ?? listing.lat ?? 0;
    const rawLng = listing.exact_lng ?? listing.lng ?? 0;
    const centroid = calculateMunicipalityCentroid(listing.city || listing.locationArea, rawLat, rawLng);

    return {
      lat: centroid.lat,
      lng: centroid.lng,
      isMasked: true,
      mode: 'DISCRETA',
      radiusKm: centroid.radiusKm,
      label: `${centroid.label} • Modalità Discreta Attiva`
    };
  }

  return {
    lat: listing.exact_lat ?? listing.lat ?? 0,
    lng: listing.exact_lng ?? listing.lng ?? 0,
    isMasked: false,
    mode: 'ESATTA',
    radiusKm: 0,
    label: 'Coordinate esatte dell\'annuncio'
  };
}

export function haversineDistanceKm(lat1, lon1, lat2, lon2) {
  if (lat1 === undefined || lon1 === undefined || lat2 === undefined || lon2 === undefined) return Infinity;
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  return R * (2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)));
}

/* =========================================================================
   2. VISIBILITY MANAGER & FILTRI
   =========================================================================
   Gli annunci (Vendo, Baratto, Cerco, Libri) compaiono solo se superano
   il filtro di moderazione integrato e se compatibili con le preferenze
   di vicinanza (Near You, Community, Everywhere).
*/

const BANNED_KEYWORDS = ['scam', 'truffa', 'armi', 'droghe', 'illecito', 'contraffatto'];

export function passesModerationFilter(listing) {
  if (!listing) return false;
  if (listing.moderation_status === 'rejected' || listing.moderation_status === 'flagged') return false;
  if (listing.status === 'suspended' || listing.status === 'banned' || listing.status === 'draft') return false;

  const trustRating = listing.author?.reputation ?? listing.author?.trust_rating ?? 5.0;
  if (trustRating < 2.5) return false;

  const fullText = `${listing.title || ''} ${listing.description || ''} ${listing.have_description || ''} ${listing.want_description || ''}`.toLowerCase();
  for (const word of BANNED_KEYWORDS) {
    if (fullText.includes(word)) return false;
  }

  return true;
}

export function isWithinProximityPreference(listing, userLocation = null, proximityPreference = 'EVERYWHERE') {
  if (proximityPreference === 'EVERYWHERE' || !proximityPreference || !userLocation) return true;

  const rawLat = listing.lat ?? listing.exact_lat ?? listing.municipality_centroid_lat;
  const rawLng = listing.lng ?? listing.exact_lng ?? listing.municipality_centroid_lng;
  if (rawLat === undefined || rawLng === undefined || userLocation.lat === 0 && userLocation.lng === 0) return true;

  const dist = haversineDistanceKm(userLocation.lat, userLocation.lng, rawLat, rawLng);
  if (proximityPreference === 'NEAR_YOU') return dist <= 25; // Entro 25 km
  if (proximityPreference === 'COMMUNITY') return dist <= 80; // Entro 80 km
  return true;
}

export function filterVisibleListings({
  listings = [],
  activeFilter = null,
  searchQuery = '',
  userLocation = null,
  proximityPreference = 'EVERYWHERE',
  isDiscreetMode = false
}) {
  const query = (searchQuery || '').trim().toLowerCase();
  // Se nessun filtro e nessuna ricerca è attiva: Mappa e bacheca pulite (nessun luogo predefinito forzato)
  if (!activeFilter && !query) return [];

  return listings.filter((item) => {
    if (!passesModerationFilter(item)) return false;
    if (!isWithinProximityPreference(item, userLocation, proximityPreference)) return false;

    // Filtro testuale per ricerca libera / esigenze dell'utente
    if (query) {
      const matchText = `${item.title || ''} ${item.description || ''} ${item.locationArea || ''} ${item.author?.city || item.city || ''} ${(item.tags || []).join(' ')}`.toLowerCase();
      if (!matchText.includes(query)) return false;
    }

    if (!activeFilter) return true;

    if (activeFilter === 'VENDO') {
      const isCarpool = item.subcategory === 'trasferte_passaggi_carpool';
      return (item.action_type === 'vendo' || item.intent === 'VENDO') && !isCarpool;
    }
    if (activeFilter === 'BARATTO_SCAMBIO' || activeFilter === 'BARATTO' || activeFilter === 'SCAMBIO') {
      return item.action_type === 'baratto_scambio' || item.intent === 'BARATTO_SCAMBIO' || item.action_type === 'baratto';
    }
    if (activeFilter === 'CERCO' || activeFilter === 'ACQUISTO_CERCO') {
      return item.action_type === 'acquisto_cerco' || item.intent === 'ACQUISTO_CERCO' || item.intent === 'CERCO';
    }
    if (activeFilter === 'TRASFERTE') {
      const isCarpoolSubcat = item.subcategory === 'trasferte_passaggi_carpool';
      const text = `${item.title || ''} ${item.description || ''} ${(item.tags || []).join(' ')}`.toLowerCase();
      return isCarpoolSubcat || text.includes('trasfert') || text.includes('passagg') || text.includes('carpool') || text.includes('viaggio');
    }
    if (activeFilter === 'SERVIZI') {
      const isServiceCat = item.category === 'servizi_lavoro_buoni' || item.category === 'rete_specialisti_supporto' || item.subcategory === 'manodopera_mestieri_riparazioni';
      const text = `${item.title || ''} ${item.description || ''} ${(item.tags || []).join(' ')}`.toLowerCase();
      return isServiceCat || text.includes('serviz') || text.includes('riparazion') || text.includes('lezion') || text.includes('manodopera');
    }
    if (activeFilter === 'LIBRI_SCOLASTICI' || activeFilter === 'LIBRI') {
      const isBookCat = item.category === 'libri_scuola_cultura' || item.subcategory === 'scambio_libri_scolastici';
      const text = `${item.title || ''} ${item.description || ''} ${item.have_description || ''} ${item.want_description || ''} ${(item.tags || []).join(' ')}`.toLowerCase();
      return isBookCat || text.includes('libr') || text.includes('scolastic') || text.includes('testi') || text.includes('manual') || text.includes('saggi');
    }
    return true;
  }).map((item) => {
    const privacy = applyGeoPrivacy(item, isDiscreetMode);
    return {
      ...item,
      displayLat: privacy.lat,
      displayLng: privacy.lng,
      isMasked: privacy.isMasked,
      approximationRadiusKm: privacy.radiusKm,
      privacyLabel: privacy.label
    };
  });
}

const MASTER_SPEC_DOCUMENT = `# HAVE2WANT PLUS — MANIFESTO & SPECIFICHE TECNICHE COMPLETE
Denominazione Ufficiale: HAVE2WANT PLUS
Ideatore e Paternità: brandoriginalword@gmail.com
Slogan Identitario: "Molto di più di una bacheca: L'Ecosistema P2P Territoriale & Pi Network"
Flusso Fondamentale: WHAT YOU HAVE → WHAT YOU WANT

## IL MANIFESTO: PERCHÉ PLUS? (I 5 PILASTRI FONDAMENTALI)
1. NON UNA BACHECA, MA IL TUO TERRITORIO 3D
   Non una lista fredda di annunci: vedi il tuo quartiere, la tua città e il mondo in 3D con ciò che accade realmente intorno a te (Globo astronomico, Urbano 3D, botteghe locali).

2. RECIPROCITÀ UMANA INTEGRALE (Cosa Ho ➔ Cosa Cerco)
   Non solo compravendita: scambio diretto di beni inutilizzati, attrezzi, libri, competenze artigiane, passaggi in auto (carpooling) e tempo condiviso.

3. ZERO BANCHE & ECONOMIA PI NETWORK (π)
   Libertà totale da commissioni parassitarie e costi di transazione tradizionali: scambi P2P diretti a costo zero o valorizzati tramite la criptovaluta sociale Pi Network.

4. PIANETA SALVAVATUTTO & MEMORIA COLLETTIVA
   Rigenerare anziché gettare. Guide pratiche comunitarie di autoproduzione, riparazione, ecologia applicata e conservazione dei saperi artigiani locali.

5. SICUREZZA REALE & GEOPRIVACY ASSOLUTA
   Nessun indirizzo privato esposto (sfocatura centroide protetta ~2.5km). Punti d'incontro pubblici certificati, firma della Stretta di Mano e codice PIN a 4 cifre per la massima serenità.

---
Specifiche Moduli di Sicurezza e Privacy:
- geoPrivacy: Posizionamento su centroide comunale (~2.5km) in Modalità Discreta.
- Visibility Manager: Filtro moderazione integrato + preferenze di vicinanza (Near You / Community / Everywhere).
- Stretta di Mano: Accordo sicuro e riservato con protocollo crittografico, PIN e conferma dal vivo.`;

/* =========================================================================
   COMPONENTE PRINCIPALE DI APPLICAZIONE (HAVE2WANT PLUS)
   ========================================================================= */
function Have2WantPlusMain() {
  const { user, updateUser } = useAuth();

  // 1. STATO CATEGORIE & ESIGENZE UTENTE (Filtri distinti per richiesta: VENDO, SCAMBIO, CERCO, TRASFERTE, SERVIZI, LIBRI)
  const [activeFilter, setActiveFilter] = useState(null); // null = "La bacheca e la mappa sono pulite"
  const [searchQuery, setSearchQuery] = useState(''); // Ricerca per esigenza o città

  // Posizione utente dinamica (senza forzature geografiche fisse all'avvio)
  const [userLocation, setUserLocation] = useState(null);

  useEffect(() => {
    if (!userLocation && navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setUserLocation({
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
            name: 'Posizione Attuale'
          });
        },
        (err) => {
          // Fallback neutro di sistema (senza forzatura su una città fissa)
          setUserLocation({ lat: 0, lng: 0, name: 'Seleziona Posizione' });
        },
        { enableHighAccuracy: true }
      );
    }
  }, []);

  // 2. MODULO PRIVACY GEOGRAFICA: Modalità Discreta attiva di default
  const [isDiscreetMode, setIsDiscreetMode] = useState(true);

  // 3. PREFERENZE DI VICINANZA: 'NEAR_YOU' | 'COMMUNITY' | 'EVERYWHERE'
  const [proximityPreference, setProximityPreference] = useState('EVERYWHERE');
  const [showProximityMenu, setShowProximityMenu] = useState(false);
  const [showFilterMenu, setShowFilterMenu] = useState(false);

  // 4. SELETTORE VISTA: 'GLOBO' | 'URBANO_3D' | 'BACHECA'
  const [viewMode, setViewMode] = useState('GLOBO');
  const [globeSubMode, setGlobeSubMode] = useState('3D');
  const [resetWorldCount, setResetWorldCount] = useState(0);

  // CATEGORIA SELEZIONATA DAL MENU A TENDINA
  const [selectedCategory, setSelectedCategory] = useState('ALL');
  const [showCategoryDropdown, setShowCategoryDropdown] = useState(false);

  // INTERFACE DUAL MODE: "Vista 3D" (Cinematografica, Globo e Volumi) vs "Vista Classica" (Testi grandi, alto contrasto, semplificata)
  const [isClassicMode, setIsClassicMode] = useState(false);

  // Dataset Annunci e Guide
  const [listings, setListings] = useState(INITIAL_LISTINGS);
  const [guides, setGuides] = useState(SALVAVATUTTO_GUIDES);

  // 5. 3. LOGICA "STRETTA DI MANO" (Transaction Flow Modal)
  const [selectedHandshakeListing, setSelectedHandshakeListing] = useState(null);

  // Scheda di dettaglio dell'annuncio selezionato (Visualizzazione a tutto schermo)
  const [selectedDetailListing, setSelectedDetailListing] = useState(null);

  // Modali secondarie
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showAIAssistant, setShowAIAssistant] = useState(false);
  const [showMeetingPoints, setShowMeetingPoints] = useState(false);
  const [showGuides, setShowGuides] = useState(false);
  const [showDriveExport, setShowDriveExport] = useState(false);
  const [showLegalShield, setShowLegalShield] = useState(false);
  const [showAdHub, setShowAdHub] = useState(false);
  const [showAuthorshipModal, setShowAuthorshipModal] = useState(false);
  const [showEmergencyModal, setShowEmergencyModal] = useState(false);
  const [showCarpoolModal, setShowCarpoolModal] = useState(false);
  const [showCraftMemoryModal, setShowCraftMemoryModal] = useState(false);
  const [showSupermarket, setShowSupermarket] = useState(false);
  const [showBachecaLavoro, setShowBachecaLavoro] = useState(false);
  const [showVetrinaAgenzie, setShowVetrinaAgenzie] = useState(false);
  const [showVetrinaKmZero, setShowVetrinaKmZero] = useState(false);
  const [showSupermarketMondo, setShowSupermarketMondo] = useState(false);

  // Scorrimento lento automatico della barra superiore (Auto-Pan / Ticker categorie)
  const scrollBarRef = useRef(null);
  const [isAutoScrollActive, setIsAutoScrollActive] = useState(true);
  const [isBarHovered, setIsBarHovered] = useState(false);
  const scrollDirectionRef = useRef(1); // 1 = avanti (destra), -1 = indietro (sinistra)
  const pauseTimeoutRef = useRef(null);
  const isPausedAtEdgeRef = useRef(false);

  useEffect(() => {
    if (!isAutoScrollActive || isBarHovered) return;

    let animFrameId;
    const scrollStep = () => {
      const el = scrollBarRef.current;
      if (el && !isPausedAtEdgeRef.current) {
        const maxScroll = el.scrollWidth - el.clientWidth;
        if (maxScroll > 10) {
          if (scrollDirectionRef.current === 1) {
            el.scrollLeft += 0.45; // Velocità morbida e rilassante
            if (el.scrollLeft >= maxScroll - 2) {
              isPausedAtEdgeRef.current = true;
              pauseTimeoutRef.current = setTimeout(() => {
                scrollDirectionRef.current = -1;
                isPausedAtEdgeRef.current = false;
              }, 2500); // Pausa di 2.5s all'estremità
            }
          } else {
            el.scrollLeft -= 0.55;
            if (el.scrollLeft <= 2) {
              isPausedAtEdgeRef.current = true;
              pauseTimeoutRef.current = setTimeout(() => {
                scrollDirectionRef.current = 1;
                isPausedAtEdgeRef.current = false;
              }, 2500);
            }
          }
        }
      }
      animFrameId = requestAnimationFrame(scrollStep);
    };

    animFrameId = requestAnimationFrame(scrollStep);
    return () => {
      cancelAnimationFrame(animFrameId);
      if (pauseTimeoutRef.current) clearTimeout(pauseTimeoutRef.current);
    };
  }, [isAutoScrollActive, isBarHovered]);

  const pioneerUser = {
    name: user?.name || "Utente Have2Want",
    username: user?.username || "@utente_locale",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80",
    piBalance: typeof user?.credit_balance === 'number' ? user.credit_balance : 12.5,
    reputation: typeof user?.trust_rating === 'number' ? user.trust_rating : 4.9,
    city: "Asti / Torino",
    verifiedKYC: true,
  };

  useEffect(() => {
    async function loadListings() {
      try {
        const remote = await base44.entities.Listing.list();
        if (remote && remote.length > 0) setListings(remote);
      } catch (e) {
        // Fallback su INITIAL_LISTINGS
      }
    }
    loadListings();
  }, []);

  // Gestione toggle filtri ed esigenze utente (VENDO, SCAMBIO, CERCO, TRASFERTE, SERVIZI, LIBRI)
  const handleFilterClick = (filterName) => {
    if (activeFilter === filterName) {
      setActiveFilter(null);
      toast.info('🌍 Filtro rimosso: Mostro tutti gli annunci');
    } else {
      setActiveFilter(filterName);
      if (filterName === 'VENDO') toast.success('🟢 Filtro attivo: Annunci e oggetti disponibili');
      else if (filterName === 'SCAMBIO' || filterName === 'BARATTO') toast.success('🟡 Filtro attivo: Baratto e scambi diretti');
      else if (filterName === 'CERCO') toast.success('🔵 Filtro attivo: Richieste di cose cercate');
      else if (filterName === 'TRASFERTE') toast.success('🚗 Filtro attivo: Passaggi auto e viaggi condivisi');
      else if (filterName === 'SERVIZI') toast.success('🛠️ Filtro attivo: Servizi, manodopera e riparazioni');
      else if (filterName === 'LIBRI') toast.success('📚 Filtro attivo: Libri e testi scolastici');
    }
  };

  // 3 SCHEDE CHIAVE (VENDO, SCAMBIO, CERCO) basate sulla ricerca e sulla categoria
  const { matchedListings, vendoCount, scambioCount, cercoCount } = useMemo(() => {
    let pool = listings;

    // Filtro per categoria se selezionata
    if (selectedCategory && selectedCategory !== 'ALL') {
      pool = pool.filter((item) => {
        const catKey = item.category_key || item.category || '';
        return catKey === selectedCategory;
      });
    }

    // Filtro per ricerca testuale se inserita
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      pool = pool.filter((item) => {
        const title = (item.title || '').toLowerCase();
        const desc = (item.description || '').toLowerCase();
        const city = (item.city || item.location_name || '').toLowerCase();
        const category = (item.category || item.category_label || '').toLowerCase();
        const tags = Array.isArray(item.tags) ? item.tags.join(' ').toLowerCase() : '';
        return title.includes(q) || desc.includes(q) || city.includes(q) || category.includes(q) || tags.includes(q);
      });
    }

    const vendo = pool.filter((item) => item.action_type === 'vendo' || item.intent === 'VENDO');
    const scambio = pool.filter((item) =>
      item.action_type === 'baratto_scambio' ||
      item.intent === 'BARATTO_SCAMBIO' ||
      item.action_type === 'scambio' ||
      item.action_type === 'baratto'
    );
    const cerco = pool.filter((item) => item.action_type === 'cerco' || item.intent === 'ACQUISTO_CERCO' || item.intent === 'CERCO');

    return {
      matchedListings: pool,
      vendoCount: vendo.length,
      scambioCount: scambio.length,
      cercoCount: cerco.length,
    };
  }, [listings, selectedCategory, searchQuery]);

  // Integrazione pubblicazione trasferte da utente: crea l'annuncio sulla bacheca/mappa
  const handlePublishTripToListing = (trip) => {
    const originLower = (trip.originCity || '').toLowerCase();
    let lat = userLocation?.lat || 0, lng = userLocation?.lng || 0;
    if (originLower.includes('milan')) { lat = 45.4642; lng = 9.1900; }
    else if (originLower.includes('torin') || originLower.includes('asti')) { lat = 45.0703; lng = 7.6869; }
    else if (originLower.includes('bologn')) { lat = 44.4949; lng = 11.3426; }
    else if (originLower.includes('firenz')) { lat = 43.7696; lng = 11.2558; }
    else if (originLower.includes('genov')) { lat = 44.4056; lng = 8.9463; }
    else if (originLower.includes('napol')) { lat = 40.8518; lng = 14.2681; }
    else if (originLower.includes('palerm')) { lat = 38.1157; lng = 13.3615; }
    else if (originLower.includes('bari')) { lat = 41.1171; lng = 16.8719; }
    else if (originLower.includes('venez')) { lat = 45.4408; lng = 12.3155; }
    else if (originLower.includes('pari')) { lat = 48.8566; lng = 2.3522; }
    else if (originLower.includes('madrid')) { lat = 40.4168; lng = -3.7038; }
    else if (originLower.includes('barcell')) { lat = 41.3851; lng = 2.1734; }
    else if (originLower.includes('berlin')) { lat = 52.5200; lng = 13.4050; }

    const newListing = {
      id: `carpool-${Date.now()}`,
      title: `Trasferta ${trip.originCity} ➔ ${trip.destinationCity}`,
      description: `${trip.notes} • Partenza: ${trip.departureDate} ore ${trip.departureTime} • Posti liberi: ${trip.availableSeats} • Accordo: ${trip.suggestedPiContribution}`,
      category: 'auto_moto_veicoli',
      subcategory: 'trasferte_passaggi_carpool',
      intent: 'OFFRO_SERVIZIO',
      action_type: 'vendo',
      lat,
      lng,
      city: trip.originCity,
      locationArea: `${trip.originCity} ➔ ${trip.destinationCity}`,
      price: 0,
      tags: ['trasferte', 'carpool', 'passaggi', trip.originCity.toLowerCase(), trip.destinationCity.toLowerCase()],
      author: {
        id: 'usr-pioneer',
        name: trip.driverName || 'Pioniere Conducente',
        trustRating: trip.driverRating || 5.0,
        city: trip.originCity,
      },
      created_at: new Date().toISOString(),
    };

    setListings((prev) => [newListing, ...prev]);
    setActiveFilter('TRASFERTE');
    toast.success(`🚗 Nuova trasferta ${trip.originCity} ➔ ${trip.destinationCity} pubblicata con successo!`);
  };

  // Selettore Territoriale / Nazione: impostato a null di default (Mondo intero pulito all'avvio)
  const [selectedCountry, setSelectedCountry] = useState(null);
  const [showCountrySelector, setShowCountrySelector] = useState(false);
  const [countrySelectCount, setCountrySelectCount] = useState(0);

  const handleSelectCountry = (country) => {
    setSelectedCountry(country);
    setCountrySelectCount((prev) => prev + 1);
    if (viewMode !== 'GLOBO') setViewMode('GLOBO');
    if (country) {
      toast.success(`${country.flag} Destinazione selezionata: ${country.name}`);
    } else {
      setResetWorldCount((prev) => prev + 1);
      toast.info('🌍 Vista globale: Tutto il Mondo');
    }
  };

  const listingsCountsByCountry = useMemo(() => {
    const counts = {};
    listings.forEach((item) => {
      const country = getCountryForListing(item, COUNTRIES);
      if (country && country.id) {
        const id = country.id.toLowerCase();
        counts[id] = (counts[id] || 0) + 1;
      }
    });
    return counts;
  }, [listings]);

  // Reset telecamera al Mondo intero ("🌍 MONDO")
  const handleResetToWorld = () => {
    setSelectedCountry(null);
    setCountrySelectCount((prev) => prev + 1);
    if (viewMode !== 'GLOBO') setViewMode('GLOBO');
    setResetWorldCount((prev) => prev + 1);
    toast.info('🌍 Vista Macro Globale (Tutto il Mondo)');
  };

  // Centratura istantanea su Italia e le sue 20 Regioni ("🇮🇹 ITALIA")
  const [focusItalyCount, setFocusItalyCount] = useState(0);
  const handleFocusItaly = () => {
    const italy = COUNTRIES.find((c) => c.id === 'it');
    setSelectedCountry(italy || null);
    setCountrySelectCount((prev) => prev + 1);
    if (viewMode !== 'GLOBO') setViewMode('GLOBO');
    setFocusItalyCount((prev) => prev + 1);
    toast.success('🇮🇹 Centratura istantanea su Italia e 20 Regioni');
  };

  // Triggers modali integrate nella mappa 3D (Pi Hub, Pubblicizza Negozio, Note Vocali)
  const [openPiHubCount, setOpenPiHubCount] = useState(0);
  const [openAdModalCount, setOpenAdModalCount] = useState(0);
  const [openVoiceChatCount, setOpenVoiceChatCount] = useState(0);

  // Modali Tutor Ufficiale & Pannello Interruttori
  const [showTutorModal, setShowTutorModal] = useState(false);
  const [showInterruttoriModal, setShowInterruttoriModal] = useState(false);
  const [isAutoTutorActive, setIsAutoTutorActive] = useState(true);

  const handleOpenPiHub = () => setOpenPiHubCount((prev) => prev + 1);
  const handleOpenAdModal = () => setOpenAdModalCount((prev) => prev + 1);
  const handleOpenVoiceChat = () => setOpenVoiceChatCount((prev) => prev + 1);

  // Toggle Modalità Discreta (geoPrivacy)
  const handleToggleDiscreetMode = () => {
    const nextState = !isDiscreetMode;
    setIsDiscreetMode(nextState);
    if (nextState) {
      toast.success('🔒 Modalità Discreta Attiva', {
        description: 'Gli annunci sono posizionati sul centroide del comune con raggio approssimato (~2.5km) per tutelare la privacy.',
      });
    } else {
      toast.warning('📍 Modalità Esatta Attiva', {
        description: 'La mappa visualizza le coordinate specifiche ove fornite.',
      });
    }
  };

  // Attivazione flusso protetto "Stretta di Mano" da popup o scheda
  const handleTriggerHandshake = (listing) => {
    setSelectedDetailListing(null);
    setSelectedHandshakeListing(listing);
    toast.info('🤝 Inizializzazione Stretta di Mano Protetta', {
      description: `Accordo sicuro e anonimo con ${listing?.author?.name || 'l\'offerente'}.`,
    });
  };

  const handleAddListing = async (newListing) => {
    setListings((prev) => [newListing, ...prev]);
    try {
      await base44.entities.Listing.create(newListing).catch(() => {});
    } catch (err) {}
  };

  const handleOpenAdHub = () => {
    setShowAdHub(true);
  };

  const hasActiveModal = Boolean(
    showCreateModal ||
    showCarpoolModal ||
    showEmergencyModal ||
    showAdHub ||
    showAIAssistant ||
    showMeetingPoints ||
    showGuides ||
    showDriveExport ||
    showLegalShield ||
    showAuthorshipModal ||
    showCountrySelector ||
    showInterruttoriModal ||
    showTutorModal ||
    showCraftMemoryModal ||
    showSupermarket ||
    showBachecaLavoro ||
    showVetrinaAgenzie ||
    showVetrinaKmZero ||
    showSupermarketMondo ||
    selectedHandshakeListing ||
    selectedDetailListing
  );

  return (
    <div className="w-full h-full max-h-screen relative overflow-hidden bg-black text-white select-none flex flex-col font-sans">
      {/* =================================================================
          SEZIONE SUPERIORE: HEADER & BARRA AZIONI SCORREVOLE ORIZZONTALMENTE
          ================================================================= */}
      <header
        id="main-app-header"
        className="relative shrink-0 w-full z-30 flex flex-col gap-1.5 px-3 sm:px-4 py-2 sm:py-2.5 bg-black/95 backdrop-blur-xl border-b border-zinc-800 shadow-none pointer-events-auto select-none overscroll-none"
      >
        {/* RIGA 1: LOGO IDENTITY COMPATTO & AZIONI PRINCIPALI */}
        <div className="flex items-center justify-between gap-3">
          {/* Brand Wordmark & Tagline */}
          <div 
            onClick={() => setShowTutorModal(true)}
            className="flex items-center gap-2.5 min-w-0 cursor-pointer group"
            title="Clicca per scoprire come funziona Have2Want in 30 secondi"
          >
            <div className="flex items-center gap-2">
              <img
                src={treeOfLifeImg}
                alt="HAVE2WANT Tree of Life"
                className="w-8 h-8 rounded-lg object-cover border border-amber-500/50 shadow-lg"
              />
              <div className="p-2 rounded-xl bg-zinc-900 group-hover:bg-zinc-800 flex items-center justify-center shrink-0 border border-zinc-800 transition-colors">
                <Globe className="w-5 h-5 text-[#00ff66] stroke-[2.5]" />
              </div>
              <div className="flex flex-col leading-tight min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-sm sm:text-base font-black tracking-wider text-white group-hover:text-[#00ff66] transition-colors truncate">
                    HAVE2WANT <span className="text-[#00ff66]">PLUS</span>
                  </span>
                  <span className="hidden xs:inline-block px-2 py-0.5 rounded text-[10px] font-black uppercase bg-zinc-900 text-[#00ff66] border border-zinc-800">
                    BARATTO & PI NETWORK
                  </span>
                </div>
              <span className="text-[10px] sm:text-xs font-semibold text-zinc-300 hidden sm:inline truncate">
                Mappa Solidale: <span className="text-white font-bold">Cosa Hai</span> <span className="text-[#00ff66] font-black">➔</span> <span className="text-white font-bold">Cosa Cerchi</span>
              </span>
            </div>
          </div>

          {/* Azioni Primarie a Destra: Dual Mode & + Pubblica */}
          <div className="flex items-center gap-2 shrink-0">
            {/* INTERRUTTORE DUAL MODE: Vista 3D vs Vista Classica */}
            <button
              id="btn-toggle-dual-mode"
              onClick={() => {
                const next = !isClassicMode;
                setIsClassicMode(next);
                toast.info(next ? "👓 Modalità Classica Attiva: testi grandi e layout essenziale" : "🌐 Modalità 3D Immersiva Attiva");
              }}
              className={`h-10 px-3.5 sm:px-4 rounded-xl text-xs sm:text-sm font-bold tracking-wide flex items-center gap-2 cursor-pointer transition-colors ${
                isClassicMode
                  ? 'bg-[#00ff66] text-black font-black shadow-md'
                  : 'bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-zinc-800'
              }`}
              title={isClassicMode ? "Passa a Vista 3D Immersiva" : "Passa a Vista Classica (alta leggibilità)"}
            >
              <span>{isClassicMode ? '👓 Classica' : '🌐 3D'}</span>
            </button>

            {/* + Pubblica */}
            <button
              id="btn-create-listing"
              onClick={() => setShowCreateModal(true)}
              className="h-10 px-4 sm:px-5 rounded-xl text-xs sm:text-sm font-black bg-[#00ff66] hover:bg-[#00e65c] text-black flex items-center gap-2 cursor-pointer transition-colors active:scale-95 shadow-md"
              title="Pubblica un nuovo annuncio (What you have → What you want)"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <span>Pubblica</span>
            </button>
          </div>
        </div>

        {/* RIGA 2: BARRA SCORREVOLE CENTRALE CONFORTEVOLE E COMPLETA */}
        <div className="relative w-full flex items-center pt-1">
          <div
            id="unified-horizontal-scroll-bar"
            ref={scrollBarRef}
            onMouseEnter={() => setIsBarHovered(true)}
            onMouseLeave={() => setIsBarHovered(false)}
            onTouchStart={() => setIsBarHovered(true)}
            onTouchEnd={() => setTimeout(() => setIsBarHovered(false), 2000)}
            className="flex items-center gap-2 sm:gap-2.5 overflow-x-auto scrollbar-none py-1 border-t border-zinc-850 touch-pan-x w-full overscroll-x-contain"
          >
            {/* 🌍 1. SELETTORE NAZIONE & MONDO */}
            <button
              id="btn-open-country-selector"
              onClick={() => setShowCountrySelector(true)}
              className={`h-11 px-3.5 sm:px-4 rounded-xl text-xs sm:text-sm font-black uppercase tracking-wider transition-all cursor-pointer flex items-center gap-2 shrink-0 border-2 shadow-sm ${
                selectedCountry
                  ? 'bg-emerald-950/90 text-emerald-300 border-[#00ff66]/70 shadow-[0_0_12px_rgba(0,255,102,0.25)]'
                  : 'bg-zinc-900 hover:bg-zinc-800 text-white border-zinc-700 hover:border-[#00ff66]'
              }`}
              title="Cambia Nazione / Territorio: seleziona qualsiasi paese del mondo a tendina"
            >
              <span className="text-lg">{selectedCountry ? selectedCountry.flag : '🌍'}</span>
              <span className="font-mono font-bold">
                {selectedCountry ? selectedCountry.name.toUpperCase() : 'SCEGLI STATO'}
              </span>
              <ChevronDown className="w-4 h-4 text-[#00ff66]" />
            </button>

            <button
              id="btn-nav-world"
              onClick={handleResetToWorld}
              className={`h-11 px-3.5 sm:px-4 rounded-xl text-xs sm:text-sm font-black uppercase tracking-wider transition-colors cursor-pointer flex items-center gap-2 shrink-0 ${
                !selectedCountry && viewMode === 'GLOBO' && globeSubMode === '3D'
                  ? 'bg-[#00ff66] text-black font-black shadow-md'
                  : 'bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-white border border-zinc-800'
              }`}
              title="Vista Macro Globale: Reset telecamera al Mondo intero"
            >
              <span className="text-base">🌍</span>
              <span>MONDO</span>
            </button>

            <button
              id="btn-nav-italy"
              onClick={handleFocusItaly}
              className={`h-11 px-3.5 sm:px-4 rounded-xl text-xs sm:text-sm font-black uppercase tracking-wider transition-colors cursor-pointer flex items-center gap-2 shrink-0 ${
                selectedCountry?.id === 'it' && viewMode === 'GLOBO'
                  ? 'bg-[#00ff66] text-black font-black shadow-md'
                  : 'bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-white border border-zinc-800'
              }`}
              title="Centratura rapida su Italia e 20 Regioni"
            >
              <span className="text-base">🇮🇹</span>
              <span>ITALIA</span>
            </button>

            {/* SELETTORE VISTE INTEGRATO: 🌐 3D GLOBO • 🗺️ GEO STATI • 🏙️ URBANO 3D */}
            <div className="flex items-center bg-zinc-950 p-1 rounded-xl border border-zinc-800 gap-1 shrink-0 h-11">
              <button
                id="btn-scroll-globo-3d"
                onClick={() => {
                  setViewMode('GLOBO');
                  setGlobeSubMode('3D');
                  toast.success("🌐 Globo 3D: Superficie fotografica terrestre");
                }}
                className={`h-full px-3.5 rounded-lg text-xs sm:text-sm font-black uppercase flex items-center gap-1.5 transition-colors cursor-pointer ${
                  viewMode === 'GLOBO' && globeSubMode === '3D'
                    ? 'bg-[#00ff66] text-black font-black shadow-md'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
                }`}
                title="Globo 3D: Superficie fotografica terrestre reale"
              >
                <Globe className="w-4 h-4" />
                <span>3D GLOBO</span>
              </button>

              <button
                id="btn-scroll-globo-geo"
                onClick={() => {
                  setViewMode('GLOBO');
                  setGlobeSubMode('GEO');
                  toast.info("🗺️ Globo Geopolitico: Confini internazionali, stati e territori");
                }}
                className={`h-full px-3.5 rounded-lg text-xs sm:text-sm font-black uppercase flex items-center gap-1.5 transition-colors cursor-pointer ${
                  viewMode === 'GLOBO' && globeSubMode === 'GEO'
                    ? 'bg-[#00ff66] text-black font-black shadow-md'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
                }`}
                title="Globo Geopolitico: Confini internazionali, stati e territori"
              >
                <span>🗺️</span>
                <span>GEO STATI</span>
              </button>

              <button
                id="btn-scroll-urbano-3d"
                onClick={() => {
                  setViewMode('URBANO_3D');
                  toast.info("🏙️ Urbano 3D: Mappa volumetrica delle città");
                }}
                className={`h-full px-3.5 rounded-lg text-xs sm:text-sm font-black uppercase flex items-center gap-1.5 transition-colors cursor-pointer ${
                  viewMode === 'URBANO_3D'
                    ? 'bg-[#00ff66] text-black font-black shadow-md'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
                }`}
                title="Urbano 3D: Fotogrammetria e mappa volumetrica"
              >
                <Building className="w-4 h-4" />
                <span>URBANO 3D</span>
              </button>
            </div>

            {/* CONTROLLO ROTAZIONE / SCORRIMENTO DELLA BARRA */}
            <button
              id="btn-toggle-autoscroll"
              onClick={() => {
                const next = !isAutoScrollActive;
                setIsAutoScrollActive(next);
                toast.info(next ? "▶️ Scorrimento automatico attivo" : "⏸️ Scorrimento automatico in pausa");
              }}
              className={`h-11 px-3 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors shrink-0 border ${
                isAutoScrollActive ? 'bg-zinc-900 text-zinc-400 hover:text-white border-zinc-800' : 'bg-amber-950/80 text-amber-300 border-amber-500/40'
              }`}
              title={isAutoScrollActive ? "Metti in pausa lo scorrimento automatico della barra" : "Avvia lo scorrimento automatico"}
            >
              <span>{isAutoScrollActive ? '⏸️' : '▶️'}</span>
              <span>{isAutoScrollActive ? 'Pausa Barra' : 'Scorri'}</span>
            </button>

            {/* Separatore */}
            <div className="w-[1px] h-6 bg-zinc-800 shrink-0" />

            {/* SFOGLIA TUTTI GLI ANNUNCI (BACHECA) */}
            <button
              id="btn-nav-bacheca"
              onClick={() => {
                if (viewMode === 'BACHECA') setViewMode('GLOBO');
                else {
                  setViewMode('BACHECA');
                  toast.info('📋 Apertura Bacheca Annunci & Categorie');
                }
              }}
              className={`h-11 px-4 sm:px-5 rounded-xl text-xs sm:text-sm font-black flex items-center gap-2 cursor-pointer transition-all shrink-0 shadow-md ${
                viewMode === 'BACHECA'
                  ? 'bg-white text-black ring-2 ring-[#00ff66]'
                  : 'bg-[#00ff66] hover:bg-[#00e65c] text-black font-black'
              }`}
              title="Apri la bacheca completa di tutti gli annunci con foto, dettagli e filtri"
            >
              <LayoutGrid className="w-4 h-4 stroke-[2.5]" />
              <span>📋 SFOGLIA TUTTI GLI ANNUNCI</span>
            </button>

            {/* MENU A TENDINA CATEGORIE + BARRA DI RICERCA GRANDE AD ALTO CONTRASTO */}
            <div className="flex items-center gap-2 shrink-0">
              {/* SELETTORE A TENDINA VERTICALE DELLE CATEGORIE */}
              <div className="relative">
                <button
                  type="button"
                  id="btn-category-dropdown-trigger"
                  onClick={() => setShowCategoryDropdown((prev) => !prev)}
                  className={`h-11 px-3.5 sm:px-4 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-all cursor-pointer border ${
                    selectedCategory !== 'ALL'
                      ? 'bg-[#00ff66] text-black border-[#00ff66]'
                      : 'bg-zinc-900 hover:bg-zinc-800 text-white border-zinc-700'
                  }`}
                  title="Scegli una categoria dal menu a tendina"
                >
                  <span className="text-base">📂</span>
                  <span className="max-w-[140px] truncate">
                    {selectedCategory === 'ALL'
                      ? 'Tutte le Categorie'
                      : REAL_CATEGORIES_MATRIX.find((c) => c.key === selectedCategory)?.label || selectedCategory}
                  </span>
                  <ChevronDown className="w-4 h-4 opacity-70" />
                </button>

                {/* TENDINA VERTICALE A SCOMPARSA */}
                {showCategoryDropdown && (
                  <>
                    <div
                      className="fixed inset-0 z-40"
                      onClick={() => setShowCategoryDropdown(false)}
                    />
                    <div className="absolute left-0 top-full mt-2 w-64 max-h-80 overflow-y-auto bg-zinc-950 border-2 border-emerald-500/50 rounded-2xl p-1.5 z-50 shadow-2xl space-y-1">
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedCategory('ALL');
                          setShowCategoryDropdown(false);
                          toast.info('Mostro tutte le categorie');
                        }}
                        className={`w-full px-3 py-2 rounded-xl text-xs font-bold text-left flex items-center gap-2 cursor-pointer transition-colors ${
                          selectedCategory === 'ALL'
                            ? 'bg-[#00ff66] text-black'
                            : 'text-zinc-200 hover:bg-zinc-900'
                        }`}
                      >
                        <span>🌍</span>
                        <span>Tutte le Categorie</span>
                      </button>
                      {REAL_CATEGORIES_MATRIX.map((cat) => (
                        <button
                          key={cat.key}
                          type="button"
                          onClick={() => {
                            setSelectedCategory(cat.key);
                            setShowCategoryDropdown(false);
                            toast.success(`Categoria: ${cat.label}`);
                          }}
                          className={`w-full px-3 py-2 rounded-xl text-xs font-bold text-left flex items-center gap-2 cursor-pointer transition-colors ${
                            selectedCategory === cat.key
                              ? 'bg-[#00ff66] text-black'
                              : 'text-zinc-200 hover:bg-zinc-900'
                          }`}
                        >
                          <span className="text-sm">📌</span>
                          <span className="truncate">{cat.label}</span>
                        </button>
                      ))}
                    </div>
                  </>
                )}
              </div>

              {/* BARRA DI RICERCA GRANDE, LUMINOSA E AD ALTO CONTRASTO */}
              <div className="relative flex items-center min-w-[240px] sm:min-w-[320px]">
                <Search className="w-4 h-4 text-[#00ff66] absolute left-3.5 pointer-events-none stroke-[2.5]" />
                <input
                  type="text"
                  id="input-user-need-search"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Cosa cerchi? (es. trapano, libro, bici...)"
                  className="w-full h-11 pl-10 pr-9 rounded-xl text-xs sm:text-sm font-medium bg-zinc-900 hover:bg-zinc-850 text-white placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-[#00ff66] focus:bg-zinc-950 transition-all border-2 border-zinc-700 focus:border-[#00ff66] shadow-inner"
                />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => setSearchQuery('')}
                    className="absolute right-3 w-5 h-5 rounded-full bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white flex items-center justify-center text-xs cursor-pointer"
                    title="Cancella testo"
                  >
                    ✕
                  </button>
                )}
              </div>

              {/* Pulsante reset rapido se attivo */}
              {(selectedCategory !== 'ALL' || searchQuery || activeFilter) && (
                <button
                  type="button"
                  id="btn-reset-filter"
                  onClick={() => {
                    setSelectedCategory('ALL');
                    setSearchQuery('');
                    setActiveFilter(null);
                    toast.info('🌍 Ricerca azzerata: mostro tutto');
                  }}
                  className="h-11 px-3 rounded-xl text-xs sm:text-sm font-bold text-zinc-300 bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 cursor-pointer transition-colors shrink-0 flex items-center gap-1.5"
                  title="Azzera filtri e ricerca"
                >
                  <span>✕</span>
                  <span>Pulisci</span>
                </button>
              )}
            </div>

            {/* Separatore */}
            <div className="w-[1px] h-6 bg-zinc-800 shrink-0" />

            {/* HUB PUBBLICITÀ & CREDITI INSERZIONE */}
            <button
              id="btn-nav-hub-pubblicita"
              onClick={handleOpenAdHub}
              className="h-11 px-3.5 sm:px-4 rounded-xl text-xs sm:text-sm font-black bg-[#00ff66] hover:bg-[#00e65c] text-black flex items-center gap-2 cursor-pointer transition-all active:scale-95 shrink-0 shadow-sm"
              title="Hub Pubblicità - Crediti per inserzioni gratuite"
            >
              <Zap className="w-4 h-4 fill-black text-black" />
              <span>HUB PUBBLICITÀ</span>
            </button>

            {/* 🚗 TRASFERTE & CARPOOLING DIRETTO */}
            <button
              id="btn-open-carpool-quick"
              onClick={() => setShowCarpoolModal(true)}
              className="h-11 px-3.5 sm:px-4 rounded-xl text-xs sm:text-sm font-bold bg-zinc-900 hover:bg-zinc-800 text-zinc-200 hover:text-white border border-zinc-800 flex items-center gap-2 cursor-pointer transition-colors shrink-0"
              title="Bacheca Trasferte & Carpooling tra privati (Offri o cerca un passaggio)"
            >
              <Car className="w-4 h-4 text-[#00ff66]" />
              <span>Trasferte & Carpool</span>
            </button>

            {/* 🚨 NUMERI UTILI & EMERGENZE MONDIALI */}
            <button
              id="btn-open-emergency-quick"
              onClick={() => setShowEmergencyModal(true)}
              className="h-11 px-3.5 sm:px-4 rounded-xl text-xs sm:text-sm font-bold bg-zinc-900 hover:bg-zinc-800 text-rose-300 hover:text-rose-200 border border-rose-900/50 flex items-center gap-2 cursor-pointer transition-colors shrink-0"
              title="Numeri Utili, Pronto Intervento ed Emergenze per Nazione"
            >
              <span className="text-base">🚨</span>
              <span>Emergenze Mondo</span>
            </button>

            {/* 📜 MEMORIA STORICA & SAPER FARE */}
            <button
              id="btn-nav-craft-memory"
              onClick={() => setShowCraftMemoryModal(true)}
              className="h-11 px-3.5 sm:px-4 rounded-xl text-xs sm:text-sm font-bold bg-zinc-900 hover:bg-zinc-800 text-zinc-200 hover:text-white border border-zinc-800 flex items-center gap-2 cursor-pointer transition-colors shrink-0"
              title="Memoria Storica & Antichi Mestieri (Botteghe Artigiane & Guide)"
            >
              <BookOpen className="w-4 h-4 text-[#00ff66]" />
              <span>Memoria Storica</span>
            </button>

            {/* 🛒 SUPERMARKET GLOBALE & MAGAZZINO H2W (KM ZERO) */}
            <button
              id="btn-nav-supermarket"
              onClick={() => setShowSupermarket(true)}
              className="h-11 px-3.5 sm:px-4 rounded-xl text-xs sm:text-sm font-bold bg-zinc-900 hover:bg-zinc-800 text-amber-300 hover:text-amber-200 border border-amber-500/40 flex items-center gap-2 cursor-pointer transition-colors shrink-0"
              title="Supermarket Globale & Magazzino H2W: Corsie prodotti Km Zero con prezzi in π, ordini live via video"
            >
              <span className="w-5 h-5 rounded-full bg-amber-500/20 flex items-center justify-center text-amber-400">🛒</span>
              <span>Supermarket Km0</span>
            </button>

            {/* 💼 BACHECA LAVORO P2P & SCAMBIO MANODOPERA */}
            <button
              id="btn-nav-bacheca-lavoro"
              onClick={() => setShowBachecaLavoro(true)}
              className="h-11 px-3.5 sm:px-4 rounded-xl text-xs sm:text-sm font-bold bg-zinc-900 hover:bg-zinc-800 text-indigo-300 hover:text-indigo-200 border border-indigo-500/40 flex items-center gap-2 cursor-pointer transition-colors shrink-0"
              title="Bacheca Lavoro P2P: Annunci diretti aziende/privati, scambio merce per lavoro - NO agenzie"
            >
              <span className="w-5 h-5 rounded-full bg-indigo-500/20 flex items-center justify-center text-indigo-400">💼</span>
              <span>Bacheca Lavoro P2P</span>
            </button>

            {/* 🏢 VETRINA AGENZIE PAYWALL */}
            <button
              id="btn-nav-vetrina-agenzie"
              onClick={() => setShowVetrinaAgenzie(true)}
              className="h-11 px-3.5 sm:px-4 rounded-xl text-xs sm:text-sm font-bold bg-zinc-900 hover:bg-zinc-800 text-rose-300 hover:text-rose-200 border border-rose-500/40 flex items-center gap-2 cursor-pointer transition-colors shrink-0"
              title="Vetrina Agenzie Paywall: Accesso riservato agenzie interinali con tariffa π (sconto 50% se acceptsPi)"
            >
              <span className="w-5 h-5 rounded-full bg-rose-500/20 flex items-center justify-center text-rose-400">🏢</span>
              <span>Vetrina Agenzie</span>
            </button>

            {/* 🥦 VETRINA KM ZERO */}
            <button
              id="btn-nav-vetrina-kmzero"
              onClick={() => setShowVetrinaKmZero(true)}
              className="h-11 px-3.5 sm:px-4 rounded-xl text-xs sm:text-sm font-bold bg-zinc-900 hover:bg-zinc-800 text-emerald-300 hover:text-emerald-200 border border-emerald-500/40 flex items-center gap-2 cursor-pointer transition-colors shrink-0"
              title="Vetrina Km Zero: Ortofrutta, Pescheria, Macelleria locali con prezzi in π e Georadar"
            >
              <span className="w-5 h-5 rounded-full bg-emerald-500/20 flex items-center justify-center text-emerald-400">🥦</span>
              <span>Vetrina Km Zero</span>
            </button>

            {/* 🌍 SUPERMARKET MONDO & MAGAZZINO */}
            <button
              id="btn-nav-supermarket-mondo"
              onClick={() => setShowSupermarketMondo(true)}
              className="h-11 px-3.5 sm:px-4 rounded-xl text-xs sm:text-sm font-bold bg-zinc-900 hover:bg-zinc-800 text-sky-300 hover:text-sky-200 border border-sky-500/40 flex items-center gap-2 cursor-pointer transition-colors shrink-0"
              title="Supermarket Mondo: Forno, Biscotti, Salumi, Formaggi rari, Dispensa & Miele, Cantina - B2B/B2C"
            >
              <span className="w-5 h-5 rounded-full bg-sky-500/20 flex items-center justify-center text-sky-400">🌍</span>
              <span>Supermarket Mondo</span>
            </button>

            {/* Separatore */}
            <div className="w-[1px] h-6 bg-zinc-800 shrink-0" />

            {/* GRUPPO PI NETWORK, NEGOZI & NOTE VOCALI */}
            <button
              id="btn-pi-hub"
              onClick={handleOpenPiHub}
              className="h-11 px-3.5 sm:px-4 rounded-xl text-xs sm:text-sm font-bold bg-zinc-900 hover:bg-zinc-800 text-zinc-200 hover:text-white border border-zinc-800 flex items-center gap-2 cursor-pointer transition-colors shrink-0"
              title="Integrazione Pi App Studio & SDK"
            >
              <span className="w-5 h-5 rounded-full bg-[#00ff66] text-black font-black flex items-center justify-center text-xs">π</span>
              <span>Pi Studio Hub</span>
            </button>

            <button
              id="btn-open-ad-modal"
              onClick={handleOpenAdModal}
              className="h-11 px-3.5 sm:px-4 rounded-xl text-xs sm:text-sm font-bold bg-zinc-900 hover:bg-zinc-800 text-zinc-200 hover:text-white border border-zinc-800 flex items-center gap-2 cursor-pointer transition-colors shrink-0"
              title="Pubblicizza la tua attività sulla mappa 3D"
            >
              <Store className="w-4 h-4 text-[#00ff66]" />
              <span>Negozi Pi</span>
            </button>

            <button
              id="btn-open-voice-chat"
              onClick={handleOpenVoiceChat}
              className="h-11 px-3.5 sm:px-4 rounded-xl text-xs sm:text-sm font-bold bg-zinc-900 hover:bg-zinc-800 text-zinc-200 hover:text-white border border-zinc-800 flex items-center gap-2 cursor-pointer transition-colors shrink-0"
              title="Invia Note Vocali a negozianti e utenti"
            >
              <Mic className="w-4 h-4 text-[#00ff66]" />
              <span>Note Vocali</span>
            </button>

            {/* Separatore */}
            <div className="w-[1px] h-6 bg-zinc-800 shrink-0" />

            {/* GRUPPO STRUMENTI, VICINANZA & SICUREZZA */}
            <div className="relative shrink-0">
              <button
                id="btn-toggle-proximity-menu"
                onClick={() => setShowProximityMenu(!showProximityMenu)}
                className="h-11 px-3.5 sm:px-4 rounded-xl text-xs sm:text-sm font-bold bg-zinc-900 hover:bg-zinc-800 text-zinc-200 hover:text-white border border-zinc-800 flex items-center gap-2 cursor-pointer transition-colors shrink-0"
                title="Preferenze di vicinanza"
              >
                <Compass className="w-4 h-4 text-[#00ff66]" />
                <span>
                  {proximityPreference === 'NEAR_YOU' ? 'Vicinanza: Near You (≤25km)' : proximityPreference === 'COMMUNITY' ? 'Vicinanza: Community (≤80km)' : 'Vicinanza: Everywhere'}
                </span>
                <ChevronDown className="w-3.5 h-3.5 text-[#00ff66]" />
              </button>

              {showProximityMenu && (
                <div
                  id="proximity-dropdown-menu"
                  className="absolute left-0 top-full mt-2 w-56 bg-zinc-950 border border-zinc-800 rounded-xl p-2 shadow-2xl z-50 flex flex-col gap-1 text-xs"
                >
                  <div className="px-2.5 py-1 text-[10px] text-zinc-400 font-bold uppercase tracking-wider border-b border-zinc-800">
                    Preferenze di Vicinanza
                  </div>
                  <button
                    onClick={() => {
                      setProximityPreference('NEAR_YOU');
                      setShowProximityMenu(false);
                      toast.info('📍 Vicinanza: Near You (entro 25 km)');
                    }}
                    className={`px-3 py-2 rounded-lg text-left font-bold flex items-center justify-between cursor-pointer ${
                      proximityPreference === 'NEAR_YOU' ? 'bg-[#00ff66] text-black font-black' : 'text-zinc-300 hover:bg-zinc-900'
                    }`}
                  >
                    <span>Near You</span>
                    <span className="text-[10px] opacity-80">≤ 25 km</span>
                  </button>
                  <button
                    onClick={() => {
                      setProximityPreference('COMMUNITY');
                      setShowProximityMenu(false);
                      toast.info('🏘️ Vicinanza: In Your Community (entro 80 km)');
                    }}
                    className={`px-3 py-2 rounded-lg text-left font-bold flex items-center justify-between cursor-pointer ${
                      proximityPreference === 'COMMUNITY' ? 'bg-[#00ff66] text-black font-black' : 'text-zinc-300 hover:bg-zinc-900'
                    }`}
                  >
                    <span>In Your Community</span>
                    <span className="text-[10px] opacity-80">≤ 80 km</span>
                  </button>
                  <button
                    onClick={() => {
                      setProximityPreference('EVERYWHERE');
                      setShowProximityMenu(false);
                      toast.info('🌍 Vicinanza: Everywhere (Globale)');
                    }}
                    className={`px-3 py-2 rounded-lg text-left font-bold flex items-center justify-between cursor-pointer ${
                      proximityPreference === 'EVERYWHERE' ? 'bg-[#00ff66] text-black font-black' : 'text-zinc-300 hover:bg-zinc-900'
                    }`}
                  >
                    <span>Everywhere</span>
                    <span className="text-[10px] opacity-80">Mondo</span>
                  </button>
                </div>
              )}
            </div>

            <button
              id="btn-meeting-points"
              onClick={() => setShowMeetingPoints(true)}
              className="h-11 px-3.5 sm:px-4 rounded-xl text-xs sm:text-sm font-bold bg-zinc-900 hover:bg-zinc-800 text-zinc-200 hover:text-white border border-zinc-800 flex items-center gap-2 cursor-pointer transition-colors shrink-0"
              title="Punti d'Incontro Certificati (Sicurezza 3D)"
            >
              <ShieldCheck className="w-4 h-4 text-[#00ff66]" />
              <span>Punti Sicuri</span>
            </button>

            {/* 🔒 INTERRUTTORE MODALITÀ DISCRETA */}
            <button
              id="btn-scroll-discreet-mode"
              onClick={handleToggleDiscreetMode}
              className={`h-11 px-3.5 sm:px-4 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 cursor-pointer transition-colors shrink-0 border ${
                isDiscreetMode
                  ? 'bg-zinc-900 text-[#00ff66] border-emerald-500/40'
                  : 'bg-zinc-900 text-zinc-300 hover:text-white border-zinc-800'
              }`}
              title={isDiscreetMode ? "Modalità Discreta attiva: centroide comunale (~2.5km)" : "Modalità Esatta"}
            >
              {isDiscreetMode ? (
                <>
                  <Lock className="w-4 h-4 text-[#00ff66]" />
                  <span>DISCRETA ON</span>
                </>
              ) : (
                <>
                  <Eye className="w-4 h-4 text-zinc-400" />
                  <span>ESATTA</span>
                </>
              )}
            </button>

            <button
              id="btn-ai-assistant"
              onClick={() => setShowAIAssistant(true)}
              className="h-11 px-3.5 sm:px-4 rounded-xl text-xs sm:text-sm font-bold bg-zinc-900 hover:bg-zinc-800 text-zinc-200 hover:text-white border border-zinc-800 flex items-center gap-2 cursor-pointer transition-colors shrink-0"
              title="Assistente AI Discreto (Simply Discreet)"
            >
              <Sparkles className="w-4 h-4 text-[#00ff66]" />
              <span>AI Discreta</span>
            </button>

            <button
              id="btn-guides"
              onClick={() => setShowGuides(true)}
              className="h-11 px-3.5 sm:px-4 rounded-xl text-xs sm:text-sm font-bold bg-zinc-900 hover:bg-zinc-800 text-zinc-200 hover:text-white border border-zinc-800 flex items-center gap-2 cursor-pointer transition-colors shrink-0"
              title="Guide Pratiche, Fai-da-Te e Riparazioni"
            >
              <BookOpen className="w-4 h-4 text-[#00ff66]" />
              <span>Guide & Riparazioni</span>
            </button>

            <button
              id="btn-drive-export"
              onClick={() => setShowDriveExport(true)}
              className="h-11 px-3.5 sm:px-4 rounded-xl text-xs sm:text-sm font-bold bg-zinc-900 hover:bg-zinc-800 text-zinc-200 hover:text-white border border-zinc-800 flex items-center gap-2 cursor-pointer transition-colors shrink-0"
              title="Backup & Specifiche su Google Drive"
            >
              <CloudUpload className="w-4 h-4 text-[#00ff66]" />
              <span>Drive Backup</span>
            </button>

            {/* Separatore */}
            <div className="w-[1px] h-6 bg-zinc-800 shrink-0" />

            {/* 🎓 TUTOR UFFICIALE (GUIDA & ASSISTENZA DIRETTA) */}
            <button
              id="btn-scroll-tutor"
              onClick={() => setShowTutorModal(true)}
              className="h-11 px-3.5 sm:px-4 rounded-xl text-xs sm:text-sm font-black bg-zinc-900 hover:bg-zinc-800 text-white hover:text-[#00ff66] flex items-center gap-2 cursor-pointer transition-colors shrink-0 border border-zinc-750 shadow-sm"
              title="Apri il Tutor Ufficiale: Guida interattiva e spiegazione rapida"
            >
              <GraduationCap className="w-4 h-4 text-[#00ff66]" />
              <span>TUTOR GUIDA</span>
            </button>

            {/* 🎛️ PANNELLO INTERRUTTORI COMPLETO */}
            <button
              id="btn-scroll-interruttori"
              onClick={() => setShowInterruttoriModal(true)}
              className="h-11 px-3.5 sm:px-4 rounded-xl text-xs sm:text-sm font-black bg-zinc-900 hover:bg-zinc-800 text-zinc-200 hover:text-white flex items-center gap-2 cursor-pointer transition-colors shrink-0 border border-zinc-750 shadow-sm"
              title="Pannello Interruttori: Attiva e gestisci ogni funzione nel posto corretto"
            >
              <SlidersHorizontal className="w-4 h-4 text-[#00ff66]" />
              <span>INTERRUTTORI</span>
            </button>

            <button
              id="btn-legal-shield"
              onClick={() => setShowLegalShield(true)}
              className="h-11 px-3.5 sm:px-4 rounded-xl text-xs sm:text-sm font-black bg-emerald-950/80 hover:bg-emerald-900/90 text-emerald-300 border border-emerald-500/40 hover:border-emerald-400 flex items-center gap-2 cursor-pointer transition-all shrink-0 shadow-sm"
              title="Guida Introduttiva, Zero Fiat, Pi SDK, Privacy GDPR e Regolamento Comunità"
            >
              <Scale className="w-4 h-4 text-emerald-400" />
              <span>Regolamento & Privacy</span>
            </button>

            {/* PULSANTE RISERVATO ESCLUSIVAMENTE ALL'ADMIN */}
            {(import.meta.env.DEV || (typeof window !== 'undefined' && window.location.search.includes('admin'))) && (
              <button
                id="btn-authorship-seal-admin"
                onClick={() => setShowAuthorshipModal(true)}
                className="h-11 px-3.5 rounded-xl text-xs font-bold bg-amber-950/60 hover:bg-amber-900/80 text-amber-300 border border-amber-500/40 flex items-center gap-1.5 cursor-pointer transition-colors shrink-0"
                title="Area Riservata Ideatore / Admin (Non visibile agli utenti esterni)"
              >
                <Award className="w-4 h-4 text-amber-400" />
                <span>Admin ©</span>
              </button>
            )}
          </div>
        </div>
      </header>

      {/* =================================================================
          PANNELLO RISULTATI A 3 SCHEDE CHIAVE: VENDO • SCAMBIO • CERCO
          Compare quando l'utente cerca nella barra o seleziona una categoria
          ================================================================= */}
      {(searchQuery.trim() || selectedCategory !== 'ALL' || activeFilter) && (
        <div className="bg-zinc-950/95 border-b-2 border-emerald-500/40 px-3 sm:px-6 py-3 z-30 shrink-0 backdrop-blur-md shadow-2xl">
          <div className="max-w-5xl mx-auto space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#00ff66] animate-ping" />
                <span className="text-xs sm:text-sm font-black text-white">
                  Risultati per:{' '}
                  <span className="text-[#00ff66]">
                    {searchQuery ? `"${searchQuery}"` : ''}
                    {searchQuery && selectedCategory !== 'ALL' ? ' in ' : ''}
                    {selectedCategory !== 'ALL'
                      ? REAL_CATEGORIES_MATRIX.find((c) => c.key === selectedCategory)?.label || selectedCategory
                      : ''}
                    {!searchQuery && selectedCategory === 'ALL' && activeFilter ? activeFilter : ''}
                  </span>
                </span>
              </div>
              <button
                type="button"
                onClick={() => {
                  setActiveFilter(null);
                  setSearchQuery('');
                  setSelectedCategory('ALL');
                  toast.info('🌍 Ricerca azzerata: mostro tutto');
                }}
                className="text-[11px] font-bold text-zinc-400 hover:text-white px-2 py-1 rounded-lg bg-zinc-900 hover:bg-zinc-800 transition-colors cursor-pointer"
              >
                ✕ Chiudi ricerca
              </button>
            </div>

            {/* LE 3 GRANDI SCHEDE SOLUZIONE */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {/* SCHEDA 1: VENDO */}
              <button
                type="button"
                onClick={() => {
                  setActiveFilter('VENDO');
                  setViewMode('BACHECA');
                  toast.success(`🟢 Entro in VENDO: ${vendoCount} annunci trovati`);
                }}
                className={`p-3 rounded-2xl text-left transition-all cursor-pointer border-2 flex items-center justify-between group ${
                  activeFilter === 'VENDO'
                    ? 'bg-emerald-950/90 border-[#00ff66] ring-2 ring-[#00ff66]/30'
                    : 'bg-zinc-900/90 hover:bg-zinc-850 border-emerald-500/30 hover:border-[#00ff66]'
                }`}
              >
                <div className="space-y-0.5">
                  <div className="flex items-center gap-1.5">
                    <span className="w-3 h-3 rounded-full bg-[#00ff66]" />
                    <span className="text-sm font-black text-white group-hover:text-[#00ff66] transition-colors">
                      VENDO
                    </span>
                  </div>
                  <p className="text-[11px] text-zinc-400">Chi offre questo bene</p>
                </div>
                <div className="text-right">
                  <span className="text-base font-mono font-black text-[#00ff66] block">
                    {vendoCount}
                  </span>
                  <span className="text-[10px] font-bold text-zinc-300 group-hover:underline">
                    Vedi →
                  </span>
                </div>
              </button>

              {/* SCHEDA 2: SCAMBIO */}
              <button
                type="button"
                onClick={() => {
                  setActiveFilter('SCAMBIO');
                  setViewMode('BACHECA');
                  toast.success(`🟡 Entro in SCAMBIO: ${scambioCount} annunci trovati`);
                }}
                className={`p-3 rounded-2xl text-left transition-all cursor-pointer border-2 flex items-center justify-between group ${
                  activeFilter === 'SCAMBIO' || activeFilter === 'BARATTO'
                    ? 'bg-amber-950/90 border-amber-400 ring-2 ring-amber-400/30'
                    : 'bg-zinc-900/90 hover:bg-zinc-850 border-amber-500/30 hover:border-amber-400'
                }`}
              >
                <div className="space-y-0.5">
                  <div className="flex items-center gap-1.5">
                    <span className="w-3 h-3 rounded-full bg-amber-400" />
                    <span className="text-sm font-black text-white group-hover:text-amber-400 transition-colors">
                      SCAMBIO
                    </span>
                  </div>
                  <p className="text-[11px] text-zinc-400">Chi vuole scambiare</p>
                </div>
                <div className="text-right">
                  <span className="text-base font-mono font-black text-amber-400 block">
                    {scambioCount}
                  </span>
                  <span className="text-[10px] font-bold text-zinc-300 group-hover:underline">
                    Vedi →
                  </span>
                </div>
              </button>

              {/* SCHEDA 3: CERCO */}
              <button
                type="button"
                onClick={() => {
                  setActiveFilter('CERCO');
                  setViewMode('BACHECA');
                  toast.success(`🔵 Entro in CERCO: ${cercoCount} annunci trovati`);
                }}
                className={`p-3 rounded-2xl text-left transition-all cursor-pointer border-2 flex items-center justify-between group ${
                  activeFilter === 'CERCO'
                    ? 'bg-blue-950/90 border-blue-400 ring-2 ring-blue-400/30'
                    : 'bg-zinc-900/90 hover:bg-zinc-850 border-blue-500/30 hover:border-blue-400'
                }`}
              >
                <div className="space-y-0.5">
                  <div className="flex items-center gap-1.5">
                    <span className="w-3 h-3 rounded-full bg-blue-400" />
                    <span className="text-sm font-black text-white group-hover:text-blue-400 transition-colors">
                      CERCO
                    </span>
                  </div>
                  <p className="text-[11px] text-zinc-400">Chi lo sta cercando</p>
                </div>
                <div className="text-right">
                  <span className="text-base font-mono font-black text-blue-400 block">
                    {cercoCount}
                  </span>
                  <span className="text-[10px] font-bold text-zinc-300 group-hover:underline">
                    Vedi →
                  </span>
                </div>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =================================================================
          AREA CENTRALE: MAPPA & STATO VUOTO (O VISTA CLASSICA ACCESSIBILE)
          ================================================================= */}
      <main className="w-full flex-1 min-h-0 relative overflow-hidden">
        {isClassicMode ? (
          <ClassicEssentialView
            listings={listings}
            currentUser={pioneerUser}
            onSelectListing={(item) => handleTriggerHandshake(item)}
            onTriggerHandshake={(item) => handleTriggerHandshake(item)}
            onBackTo3D={() => setIsClassicMode(false)}
            onOpenEmergency={() => setShowEmergencyModal(true)}
            onOpenCarpool={() => setShowCarpoolModal(true)}
            onOpenMemory={() => setShowCraftMemoryModal(true)}
            onOpenLegalShield={() => setShowLegalShield(true)}
          />
        ) : viewMode === 'BACHECA' ? (
          <div className="fixed inset-0 z-50 bg-black overflow-y-auto w-full h-full">
            <HomeFeedView
              listings={listings}
              currentUser={pioneerUser}
              onAddListing={handleAddListing}
              onSelectListingForTrade={(item) => handleTriggerHandshake(item)}
              onNavigate={(tab) => {
                if (tab === 'citta-viva' || tab === 'map') setViewMode('URBANO_3D');
                else if (tab === 'universe') setViewMode('GLOBO');
                else if (tab === 'planet-salvavatutto') setShowGuides(true);
              }}
              onReportAbuse={() => {
                toast.success("Segnalazione inviata al Comitato di Moderazione Etico.");
              }}
              initialFilter={activeFilter}
              onSectionSelect={(sec) => setActiveFilter(sec)}
              onOpenCarpoolModal={() => setShowCarpoolModal(true)}
              onBackToMap={() => setViewMode('GLOBO')}
              selectedCountry={selectedCountry}
              onSelectCountry={handleSelectCountry}
              onOpenCountrySelector={() => setShowCountrySelector(true)}
            />
          </div>
        ) : (
          <div className="w-full h-full relative">
            <MapView3DContainer
              listings={listings}
              currentProfile={user}
              userLocation={userLocation}
              filter={activeFilter}
              searchQuery={searchQuery}
              viewMode={viewMode}
              onViewModeChange={setViewMode}
              onResetFilter={() => {
                setActiveFilter(null);
                setSearchQuery('');
              }}
              resetWorldTrigger={resetWorldCount}
              onResetToWorld={handleResetToWorld}
              focusItalyTrigger={focusItalyCount}
              selectedCountryId={selectedCountry?.id || null}
              countrySelectTrigger={countrySelectCount}
              openPiHubTrigger={openPiHubCount}
              openAdModalTrigger={openAdModalCount}
              openVoiceChatTrigger={openVoiceChatCount}
              isDiscreetMode={isDiscreetMode}
              onToggleDiscreetMode={handleToggleDiscreetMode}
              proximityPreference={proximityPreference}
              onProximityPreferenceChange={setProximityPreference}
              onTriggerHandshake={handleTriggerHandshake}
              onSelectListing={(item) => {
                setSelectedDetailListing(item);
              }}
              onOpenAdHub={handleOpenAdHub}
              onOpenTutor={() => setShowTutorModal(true)}
              globeSubMode={globeSubMode}
              onGlobeSubModeChange={setGlobeSubMode}
            />
          </div>
        )}
      </main>

      {/* =================================================================
          3. LOGICA "STRETTA DI MANO" (Transaction Flow Modal)
          Accordo sicuro e anonimo tra chi offre e chi cerca con messaggio
          di conferma a schermo.
          ================================================================= */}
      {selectedHandshakeListing && (
        <div
          id="handshake-flow-overlay"
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto overscroll-contain animate-in fade-in duration-200"
        >
          <div className="relative w-full max-w-md">
            <button
              onClick={() => setSelectedHandshakeListing(null)}
              className="absolute -top-3 -right-3 z-20 p-2 rounded-full bg-[#070b19] hover:bg-slate-800 text-slate-200 border border-slate-700 shadow-xl cursor-pointer"
              title="Chiudi accordo"
            >
              ✕
            </button>
            <StrettaDiMano
              listing={selectedHandshakeListing}
              currentProfile={pioneerUser}
              onVerificationSuccess={() => {
                // Aggiornamento locale dello stato dell'annuncio
                setListings((prev) =>
                  prev.map((l) =>
                    l.id === selectedHandshakeListing.id ? { ...l, handshake_confirmed: true, status: 'completed' } : l
                  )
                );
              }}
              onClose={() => setSelectedHandshakeListing(null)}
            />
          </div>
        </div>
      )}

      {/* CREATE LISTING MODAL */}
      <CreateListingModal
        isOpen={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        onAddListing={handleAddListing}
        currentUser={pioneerUser}
        defaultIntent={activeFilter === 'VENDO' ? 'VENDO' : activeFilter === 'CERCO' ? 'ACQUISTO_CERCO' : 'BARATTO_SCAMBIO'}
        defaultCategory={activeFilter === 'LIBRI' ? 'libri_scuola_cultura' : 'casa_fai_da_te'}
      />

      {/* ASSISTENTE AI DISCRETO */}
      {showAIAssistant && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
          <div className="relative w-full max-w-2xl bg-[#070b19] border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-2xl max-h-[90vh] flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-white">Assistente AI Discreto</h3>
                  <p className="text-xs text-slate-400">Simply Discreet • Zero tracciamento • Risponde a comando</p>
                </div>
              </div>
              <button
                onClick={() => setShowAIAssistant(false)}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto pt-3">
              <DiscreetAIAssistant
                listings={listings}
                guides={guides}
                onNavigateToPlanet={(planet) => {
                  if (planet === 'planet-possibilita') setViewMode('BACHECA');
                  if (planet === 'planet-salvavatutto') setShowGuides(true);
                  setShowAIAssistant(false);
                }}
              />
            </div>
          </div>
        </div>
      )}

      {/* PUNTI D'INCONTRO CERTIFICATI */}
      {showMeetingPoints && (
        <CertifiedMeetingPointsModal
          city="Asti"
          onSelectMeetingPoint={(point) => {
            toast.success(`Punto Certificato selezionato: ${point.name} (${point.address})`);
            setShowMeetingPoints(false);
          }}
          onClose={() => setShowMeetingPoints(false)}
        />
      )}

      {/* PIANETA SALVAVATUTTO GUIDES */}
      {showGuides && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
          <div className="relative w-full max-w-4xl bg-[#070b19] border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-2xl max-h-[92vh] flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
                  <BookOpen className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-white">Guide Pratiche & Riparazioni</h3>
                  <p className="text-xs text-slate-400">Manuali fai-da-te, consigli di riuso e autoproduzione per la comunità</p>
                </div>
              </div>
              <button
                onClick={() => setShowGuides(false)}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto pt-3">
              <SalvavatuttoPlanet
                guides={guides}
                onAddGuide={(newGuide) => {
                  setGuides((prev) => [newGuide, ...prev]);
                  toast.success("Guida aggiunta a Salvavatutto!");
                }}
                onSelectListingForTrade={(item) => handleTriggerHandshake(item)}
              />
            </div>
          </div>
        </div>
      )}

      {/* GOOGLE DRIVE EXPORT */}
      {showDriveExport && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
          <div className="relative w-full max-w-xl bg-[#070b19] border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-2xl max-h-[90vh] flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-sky-500/20 text-sky-400 border border-sky-500/30">
                  <CloudUpload className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-white">Google Drive Export</h3>
                  <p className="text-xs text-slate-400">Archiviazione documentale crittografata</p>
                </div>
              </div>
              <button
                onClick={() => setShowDriveExport(false)}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto pt-3">
              <DriveExporter
                documentTitle="HAVE2WANT_SPECIFICHE_TECNICHE"
                markdownContent={MASTER_SPEC_DOCUMENT}
              />
            </div>
          </div>
        </div>
      )}

      {/* AD REWARD HUB MODAL */}
      {showAdHub && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm">
          <div className="relative w-full max-w-md">
            <button
              onClick={() => setShowAdHub(false)}
              className="absolute -top-3 -right-3 z-10 p-2 rounded-full bg-[#070b19] hover:bg-slate-800 text-slate-200 border border-slate-700 shadow-xl cursor-pointer"
            >
              ✕
            </button>
            <AdRewardHub />
          </div>
        </div>
      )}

      {/* LEGAL SHIELD */}
      {showLegalShield && (
        <LegalWelcomeShield onAcceptTerms={() => setShowLegalShield(false)} />
      )}

      {/* AUTHORSHIP & COPYRIGHT CERTIFICATE MODAL */}
      <AuthorshipCertificateModal
        isOpen={showAuthorshipModal}
        onClose={() => setShowAuthorshipModal(false)}
      />

      {/* MODALI EMERGENZE, TRASFERTE E MEMORIA STORICA (Trigger da Vista Classica) */}
      <WorldEmergencyModal
        isOpen={showEmergencyModal}
        onClose={() => setShowEmergencyModal(false)}
        defaultCountryCode="IT"
      />

      <GlobalCarpoolModal
        isOpen={showCarpoolModal}
        onClose={() => setShowCarpoolModal(false)}
        onPublishTripToListing={handlePublishTripToListing}
      />

      <CraftMemoryModal
        isOpen={showCraftMemoryModal}
        onClose={() => setShowCraftMemoryModal(false)}
      />

      {/* 🛒 SUPERMARKET GLOBALE & MAGAZZINO H2W (KM ZERO) */}
      <SupermarketGlobaleH2W
        isOpen={showSupermarket}
        onClose={() => setShowSupermarket(false)}
        currentUser={user}
      />

      {/* 💼 BACHECA LAVORO P2P & SCAMBIO MANODOPERA */}
      <BachecaLavoroP2P
        isOpen={showBachecaLavoro}
        onClose={() => setShowBachecaLavoro(false)}
      />

      {/* 🏢 VETRINA AGENZIE PAYWALL */}
      <VetrinaAgenziePaywall
        isOpen={showVetrinaAgenzie}
        onClose={() => setShowVetrinaAgenzie(false)}
      />

      {/* 🥦 VETRINA KM ZERO */}
      <VetrinaKmZero
        isOpen={showVetrinaKmZero}
        onClose={() => setShowVetrinaKmZero(false)}
        currentUser={user}
      />

      {/* 🌍 SUPERMARKET MONDO & MAGAZZINO */}
      <SupermarketMondo
        isOpen={showSupermarketMondo}
        onClose={() => setShowSupermarketMondo(false)}
        currentUser={user}
      />

      {/* SELETTORE TERRITORIALE DINAMICO GLOBALE */}
      <CountrySelectorModal
        isOpen={showCountrySelector}
        onClose={() => setShowCountrySelector(false)}
        selectedCountry={selectedCountry}
        onSelectCountry={handleSelectCountry}
        listingsCountsByCountry={listingsCountsByCountry}
      />

      {/* 🎓 TUTOR UFFICIALE APP (GUIDA PASSO-PASSO) */}
      <AppTutorModal
        isOpen={showTutorModal}
        onClose={() => setShowTutorModal(false)}
        onActionTrigger={(action) => {
          if (action === 'open_create') {
            setShowTutorModal(false);
            setShowCreateModal(true);
          } else if (action === 'open_voice') {
            setShowTutorModal(false);
            handleOpenVoiceChat();
          } else if (action === 'open_carpool') {
            setShowTutorModal(false);
            setShowCarpoolModal(true);
          } else if (action === 'open_meeting') {
            setShowTutorModal(false);
            setShowMeetingPoints(true);
          } else if (action === 'open_legal') {
            setShowTutorModal(false);
            setShowLegalShield(true);
          } else if (action === 'reset_world') {
            setShowTutorModal(false);
            handleResetToWorld();
          }
        }}
      />

      {/* 🎛️ PANNELLO INTERRUTTORI RAPIDI */}
      <InterruttoriRapidiModal
        isOpen={showInterruttoriModal}
        onClose={() => setShowInterruttoriModal(false)}
        isClassicMode={isClassicMode}
        onToggleClassicMode={() => {
          setIsClassicMode((prev) => !prev);
          toast.info(!isClassicMode ? "👓 Modalità Classica Attiva" : "🌐 Modalità 3D Attiva");
        }}
        isDiscreetMode={isDiscreetMode}
        onToggleDiscreetMode={handleToggleDiscreetMode}
        isAutoTutorActive={isAutoTutorActive}
        onToggleAutoTutor={() => {
          setIsAutoTutorActive((prev) => !prev);
          toast.info(!isAutoTutorActive ? "💡 Aiuto Automatico Contestuale Attivato" : "Aiuto Automatico Disattivato");
        }}
        onOpenCreateModal={() => setShowCreateModal(true)}
        onOpenVoiceChat={handleOpenVoiceChat}
        onOpenCarpool={() => setShowCarpoolModal(true)}
        onOpenShops={handleOpenAdModal}
        onOpenTutor={() => setShowTutorModal(true)}
        onOpenLegalShield={() => setShowLegalShield(true)}
        onOpenSafePoints={() => setShowMeetingPoints(true)}
        onResetWorld={handleResetToWorld}
      />

      {/* SCHEDA DETTAGLIO COMPLETA DELL'ANNUNCIO (Aperta a schermo intero con pulsante 'Torna alla Mappa') */}
      {selectedDetailListing && (
        <ListingDetailModal
          isOpen={Boolean(selectedDetailListing)}
          listing={{
            id: selectedDetailListing.id,
            title: selectedDetailListing.title || selectedDetailListing.have_description || 'Annuncio',
            description: selectedDetailListing.description || selectedDetailListing.have_description || '',
            category: selectedDetailListing.category || 'Generale',
            price: typeof selectedDetailListing.price === 'number' ? selectedDetailListing.price : parseFloat(selectedDetailListing.price) || 0,
            currency: '€',
            imageUrl: selectedDetailListing.imageUrl,
            images: selectedDetailListing.images || (selectedDetailListing.photos ? selectedDetailListing.photos : []),
            city: selectedDetailListing.city || selectedDetailListing.author?.city || selectedCountry?.name || 'Mondo',
            region: selectedDetailListing.stateOrRegion,
            authorName: selectedDetailListing.author?.name || selectedDetailListing.owner_name || selectedDetailListing.author,
            authorUsername: selectedDetailListing.author?.username,
            originType: selectedDetailListing.originType || (selectedDetailListing.isSample ? 'SAMPLE' : 'REAL_P2P'),
            piPrice: selectedDetailListing.piPrice,
            condition: selectedDetailListing.condition || 'Ottimo stato',
            wantsInExchange: selectedDetailListing.wantsInExchange || selectedDetailListing.want_description || selectedDetailListing.concreteExchange?.itemOrServiceAccepted || 'Scambio alla pari o Pi Coin',
          }}
          onClose={() => setSelectedDetailListing(null)}
          returnToLabel="Torna alla Mappa 🗺️"
          onProposeBarter={(item) => {
            setSelectedDetailListing(null);
            handleTriggerHandshake(item);
          }}
          onContactSeller={(item) => {
            toast.info(`Messaggio diretto per ${item.title}: contatta l'offerente per organizzare lo scambio.`);
          }}
        />
      )}
    </div>
  );
}

export default function App() {
  const [privacyAccepted, setPrivacyAccepted] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('privacy_accepted') === 'true';
    }
    return false;
  });

  const handleAcceptPrivacy = () => {
    localStorage.setItem('privacy_accepted', 'true');
    setPrivacyAccepted(true);
  };

  if (!privacyAccepted) {
    return (
      <AuthProvider>
        <PrivacyGate isOpen={true} onAccept={handleAcceptPrivacy} />
      </AuthProvider>
    );
  }

  return (
    <AuthProvider>
      <H2WProvider>
        <div className="w-screen h-screen h-[100vh] w-[100vw] overflow-hidden bg-black text-white relative selection:bg-[#00ff66]/30 selection:text-[#00ff66] font-sans antialiased">
          <Have2WantPlusMain />
          <Toaster 
            position="top-right" 
            richColors 
            closeButton 
            theme="dark" 
            duration={5000}
            toastOptions={{
              className: '!text-sm sm:!text-[15px] !font-bold !py-3.5 !px-4 !bg-[#070b14] !border-2 !border-[#00ff66]/70 !shadow-[0_10px_30px_rgba(0,0,0,0.9)] !text-white',
              descriptionClassName: '!text-xs !text-zinc-300',
            }}
          />
        </div>
      </H2WProvider>
    </AuthProvider>
  );
}
